import json
from urllib.parse import parse_qsl, urlsplit
from urllib.request import urlopen

import pytest
from PySide6.QtCore import QEvent, QSettings
from PySide6.QtWidgets import QPushButton
from test_vmix_control import app, fake_api, wait_for
from test_camera_workflow import MATCH, snapshot
from test_camera_native_sync import NativePreset
from test_camera_vdo_publish import guid


@pytest.fixture
def desk(app, fake_api, tmp_path, monkeypatch):
    from observer_assist.pop_roster_desk import RosterDesk
    s = QSettings(str(tmp_path/'pop.ini'), QSettings.Format.IniFormat)
    s.setValue('statsExportAddress', '127.0.0.1/8')
    import socket
    with socket.socket() as probe:
        probe.bind(('127.0.0.1', 0))
        s.setValue('povCompanionPort', probe.getsockname()[1])
    s.setValue('cameraVdoVmixPort', fake_api.server_port)
    w = RosterDesk(s)
    def start(match_id):
        w.source_tv._match_id = match_id
        w.source_tv._clear_players()
    monkeypatch.setattr(w.source_tv, '_start', start)
    w.address.setText(MATCH)
    w.connect_button.click()
    yield w
    w.close()
    w.deleteLater()
    app.sendPostedEvents(None, QEvent.Type.DeferredDelete)


def test_match_to_copies_and_companion_on_two_maps(desk, fake_api):
    preset = NativePreset()
    preset.order = preset.order[:12]
    preset.active[2] = guid(2)
    created = []
    def answer(path):
        q = dict(parse_qsl(urlsplit(path).query))
        if q.get('Function') == 'CreateVirtualInput':
            g = guid(preset.order.index(q['Input'])+13)
            assert g not in preset.order
            preset.order.append(g)
            created.append(g)
            return 200, {}, b''
        return preset.answer(path)
    fake_api.answer = answer
    names = [f'Player {i}' for i in range(1, 13)]
    snapshot(desk, names)
    assert desk.apply.isEnabled() and not created and not preset.writes
    assert not any(b.text() == 'Инструменты' for b in desk.findChildren(QPushButton))
    desk.apply.click()
    wait_for(lambda: '24/24' in desk.result.text())
    assert len(created) == 12
    assert [preset.inputs[g]['title'] for g in preset.order] == names + [n + ' - Virtual' for n in names]
    writes = len(preset.writes)
    names = names[6:]+names[:6]
    desk.address.setText('23456789')
    desk.refresh.click()
    assert not desk.apply.isEnabled() and not desk.payload['hud_slots']
    rows = [dict(team=2+i//6, name=n, assignedLane=(1,4,6)[i%6//2]) for i,n in enumerate(names)]
    desk.source_tv.consume(dict(type='snapshot', matchId='23456789', players=rows))
    with urlopen(desk.server.url, timeout=2) as response:
        slots = json.load(response)['hud_slots']
    assert list(slots.values()) == names and desk.table.item(11, 1).text() == slots['12']
    assert len(preset.writes) == writes
    desk.apply.click()
    wait_for(lambda: '24/24' in desk.result.text())
    assert len(created) == 12 and preset.inputs[guid(24)]['title'] == names[11]+' - Virtual'
    assert not any(c['Function'] in ('ActiveInput','BrowserNavigate') for c in preset.writes)


def test_panorama_follows_new_map_and_recovers_without_vmix(desk, fake_api):
    names = [f'Nick{i}' for i in range(1, 13)]
    data = dict(version=1, status='live', panorama_match_id='222',
                panorama_slots=dict(zip(map(str, range(1, 13)), names)))
    def answer(path):
        assert path == '/api/v1/pov/match?token=test'
        return 200, {}, json.dumps(data).encode()
    fake_api.answer = answer
    desk.source.setCurrentIndex(desk.source.findData('remote'))
    desk.address.setText(f'http://127.0.0.1:{fake_api.server_port}/api/v1/stats?token=test')
    desk.connect_button.click()
    wait_for(lambda: desk.apply.isEnabled())
    assert desk.payload['hud_slots']['12'] == names[-1]
    data.update(panorama_match_id='333', panorama_slots=dict(zip(map(str, range(1,13)), reversed(names))))
    desk.remote._poll()
    wait_for(lambda: desk.payload['matchId'] == '333')
    assert desk.payload['hud_slots']['12'] == names[0] and desk.table.item(11, 1).text() == names[0]
    data.update(status='waiting')
    desk.remote._poll()
    wait_for(lambda: not desk.apply.isEnabled())
    assert not desk.payload['hud_slots']
    names[0] = names[1] = 'Snow\u00a0Fox'
    data.update(status='live', panorama_match_id=None, panorama_slots=dict(zip(map(str, range(1, 13)), names)))
    desk.remote._poll()
    wait_for(lambda: desk.apply.isEnabled())
    with urlopen(desk.server.url, timeout=2) as response:
        exported = json.load(response)
    assert exported['matchId'] is None and list(exported['hud_slots'].values()) == names
    data['panorama_match_id'] = '444'
    desk.remote._poll()
    wait_for(lambda: desk.payload['matchId'] == '444')
    assert {urlsplit(path).path for path in fake_api.requests} == {'/api/v1/pov/match'}
