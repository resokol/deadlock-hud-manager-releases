"""Verify and physically order two banks of existing vMix inputs by GUID."""

from dataclasses import asdict, dataclass, replace
from ipaddress import IPv4Address
from xml.etree import ElementTree

from PySide6.QtCore import QObject, QTimer, QUrl, Signal

from .camera_native_geometry import neutral_issue, read_native_geometry, reset_commands
from .camera_native_recovery import (
    ConfirmedLayout, NativeLayoutStore, compatible, geometry_undo, record_command, safe_title, snapshot, title_matches,
)
from .camera_vdo_publish import AppliedBatch, AppliedInput, VmixRequest
from .camera_vmix import _read_state, browser_source, virtual_source
from .match_stats import is_lan_address
from .vmix_control import _guid


@dataclass(frozen=True)
class NativePair:
    original_guid: str
    virtual_guid: str
    name: str
    empty: bool = False
    operator_verified: bool = False
    caption: str = ''

    @property
    def display_name(self):
        return self.caption or self.name


@dataclass(frozen=True)
class _Take:
    slot: int
    guid: str
    virtual: bool
    validate: object


@dataclass
class _MixRequest:
    http: VmixRequest
    latest: _Take


def read_native_catalog(xml):
    state = _read_state(xml)
    return state, {guid: info['virtual_parent'] for guid, info in state.inputs.items() if 'virtual_parent' in info}


def _check_pairs(pairs, *, require_names=True):
    if len(pairs) != 12 or any(not isinstance(row, NativePair) for row in pairs):
        raise ValueError('Нужны 12 назначенных пар камер в порядке игровых позиций.')
    keys = [key for row in pairs for key in (row.original_guid, row.virtual_guid)]
    if len(set(keys)) != 24 or any(not key or _guid(key) != key for key in keys):
        raise ValueError('Укажите 24 различных GUID оригиналов и виртуальных копий.')
    if not require_names:
        return
    if any(not isinstance(row.name, str) or not row.name.strip() or row.name == '-' or len(row.name) > 246
           or not row.name.isprintable() or '://' in row.name for row in pairs):
        raise ValueError('Для каждой игровой позиции нужен ник игрока.')
    if any(not isinstance(row.caption, str) or (row.caption and (row.caption == '-' or len(row.caption) > 246
           or not row.caption.strip() or not row.caption.isprintable() or '://' in row.caption)) for row in pairs):
        raise ValueError('Проверьте ники подключённых гостей VDO.')
    if len({row.display_name.strip().casefold() for row in pairs}) != 12:
        raise ValueError('Названия входов повторяются. Проверьте ники гостей VDO.')
    if len({row.name.strip().casefold() for row in pairs}) != 12:
        raise ValueError('Повторяются ники игроков. Проверьте состав.')


def check_native_layout(state, parents, pairs, *, sorted_names=False, require_names=True):
    _check_pairs(pairs, require_names=sorted_names or require_names)
    originals = {row.original_guid for row in pairs}
    copies = {row.virtual_guid for row in pairs}
    if {g for g, info in state.inputs.items() if 1 <= info['number'] <= 12} != originals:
        raise ValueError('Входы 1–12 должны содержать ровно 12 назначенных оригиналов.')
    if {g for g, info in state.inputs.items() if 13 <= info['number'] <= 24} != copies:
        raise ValueError('Входы 13–24 должны содержать ровно 12 назначенных виртуальных копий.')
    for slot, row in enumerate(pairs, 1):
        orig, copy = state.inputs[row.original_guid], state.inputs[row.virtual_guid]
        if not browser_source(orig) or row.original_guid in parents:
            raise ValueError(f'Позиция {slot}: оригинал должен быть входом Web Browser.')
        if (copy.get('virtual') is False or not virtual_source(copy)
                or copy['type'].casefold() not in ('virtual', 'browser', 'webbrowser', 'web browser')):
            raise ValueError(f'Позиция {slot}: вход Replay не является виртуальной копией.')
        if row.virtual_guid in parents:
            if parents[row.virtual_guid] != row.original_guid:
                raise ValueError(f'Позиция {slot}: источник копии в XML не совпадает с оригиналом.')
        elif row.operator_verified is not True:
            raise ValueError(f'Позиция {slot}: подтвердите в vMix, от какого оригинала создана копия.')
        if sorted_names and (orig['number'] != slot or copy['number'] != slot + 12
                             or orig['title'] != row.display_name or not title_matches(copy['title'], row.display_name + ' - Virtual', virtual=True)):
            raise ValueError(f'Позиция {slot}: порядок или названия камер изменились. Повторите синхронизацию.')


def _move_for_order(current, wanted, swap=False):
    """Return the first move of a shortest insertion (or exchange) sequence."""
    if current == wanted:
        return None
    if swap:
        destination = next(i for i, key in enumerate(wanted) if key != current[i])
        return current.index(wanted[destination]), destination
    rank = {key: i for i, key in enumerate(wanted)}
    # Every common subsequence can stay in place. Keep a longest one; each
    # other GUID requires exactly one insertion. A bank contains only 12 rows.
    chains = []
    for i, key in enumerate(current):
        prior = max((chains[j] for j in range(i) if rank[current[j]] < rank[key]), key=len, default=())
        chains.append((*prior, key))
    keep = set(max(chains, key=len))
    for i in range(len(wanted) - 1, -1, -1):
        if wanted[i] not in keep:
            before = current.index(wanted[i])
            without = current[:before] + current[before + 1:]
            after = without.index(wanted[i + 1]) if i + 1 < len(wanted) else len(without)
            return before, after


class NativePairSync(QObject):
    changed = Signal()
    finished = Signal(bool, str)
    _observe_bank = None

    def __init__(self, parent=None, *, settings=None):
        super().__init__(parent)
        self._http = VmixRequest(self)
        self._store = NativeLayoutStore(settings)
        self._journal = None
        self._private_titles = {}
        self._reset_ack = {}
        self._match_id = ''
        self._poll = QTimer(self, singleShot=True, interval=2000)
        self._poll.timeout.connect(self._monitor)
        self._retry = QTimer(self, singleShot=True, interval=100)
        self._retry.timeout.connect(self._read)
        self._generation = 0
        self._mode = ''
        self._takes = {}
        self._room_layout = False
        self._armed = self.ready = False
        self._repair_waiting = False
        self.endpoint = None
        self.preset = ''
        self.pairs = ()
        self.receipt = None
        self.numbers, self.mixes = {}, {}
        self.external2 = self.verification_note = self.message = ''
        self._baseline = None
        self.pending_title = None

    @property
    def busy(self):
        return self._mode not in ('', 'monitor')

    def _interrupt(self):
        self._generation += 1
        self._clear_takes()
        self._http.cancel()
        self._poll.stop()
        self._retry.stop()
        self._mode = ''

    def cancel(self):
        interrupted = bool(self._journal) and self._mode in ('sync', 'recover')
        self._interrupt()
        self._journal = None
        self._armed = self.ready = False
        self._repair_waiting = False
        self.receipt = self.endpoint = None
        self.pairs = ()
        if interrupted:
            self.message = 'Синхронизация прервана. Сохранён журнал для восстановления входов.'
        self.numbers, self.mixes = {}, {}
        self.external2 = self.verification_note = ''
        self.changed.emit()

    def _begin(self, mode, endpoint, preset, pairs, validate, authorize, *, match_id='', journal=None, restore=False, fixed_slots=False):
        observing = self._observe_bank is not None
        if self.busy or observing != (mode == 'observe'):
            return False
        self._interrupt()
        self._armed = self.ready = False
        self._repair_waiting = False
        self.receipt = self.endpoint = None
        self.numbers, self.mixes = {}, {}
        self.external2 = self.verification_note = ''
        try:
            host, port = endpoint
            address = IPv4Address(host)
            if not (address.is_loopback or is_lan_address(address)) or type(port) is not int or not 1 <= port <= 65535:
                raise ValueError
        except (TypeError, ValueError):
            self._fail('Проверьте локальный адрес и порт vMix.')
            return False
        try:
            pairs = tuple(pairs)
            if not observing:
                _check_pairs(pairs, require_names=mode != 'room')
        except TypeError:
            self._fail('Проверьте список камер.')
            return False
        except ValueError as exc:
            self._fail(str(exc))
            return False
        self.endpoint, self.preset, self.pairs = (str(address), port), preset or '', pairs
        self._url = QUrl(f'http://{address}:{port}/api/')
        self._match_id = str(match_id or '')
        self._journal = journal
        self._pinned_preset = self.preset if mode == 'room' else self.preset or None
        self._validate = validate
        self._authorize = authorize
        self._mode = mode
        self._room_layout = mode == 'room' or observing
        self._armed = restore or self._room_layout
        self._baseline = None
        self._expected = None
        self._swaps = False
        self._moves = 0
        self._fixed_slots = fixed_slots
        self._geometry = []
        self._recovery_previous = None
        self._recovery_attempts = 0
        self._geometry_started = False
        self.message = 'Читаем входы vMix…'
        generation = self._generation
        self.changed.emit()
        if generation == self._generation:
            self._read()
        return True

    def start(self, endpoint, preset, pairs, *, validate=None, authorize=None, match_id='', fixed_slots=False):
        return self._begin('sync', endpoint, preset, pairs, validate, authorize, match_id=match_id, fixed_slots=fixed_slots)

    def verify(self, endpoint, preset, pairs, *, validate=None):
        return self._begin('verify', endpoint, preset, pairs, validate, None)

    def verify_room(self, endpoint, preset, pairs, *, validate=None):
        """Arm the prepared physical camera pool before a match roster exists."""
        return self._begin('room', endpoint, preset, pairs, validate, None)

    def saved_layout(self, endpoint, preset):
        try:
            data = self._store.read(endpoint, preset, 'confirmed')
            if not data:
                return None
            rows = tuple(NativePair(**row) for row in data['pairs'])
            _check_pairs(rows)
            return ConfirmedLayout(tuple(endpoint), preset, data['match_id'], rows)
        except (KeyError, TypeError, ValueError):
            return None

    def restore_confirmed(self, endpoint, preset, match_id, *, validate=None):
        layout = self.saved_layout(endpoint, preset)
        if self.busy:
            return False
        if not layout or not match_id or layout.match_id != str(match_id) or self.has_recovery(endpoint, preset):
            self.cancel()
            return False
        return self._begin('verify', endpoint, preset, layout.pairs, validate, None, match_id=match_id, restore=True)

    def has_recovery(self, endpoint, preset):
        try:
            return bool(self._store.read(endpoint, preset, 'pending'))
        except ValueError:
            return True

    def recovery_rows(self, endpoint, preset):
        try:
            journal = self._store.read(endpoint, preset, 'pending')
            if not journal:
                return ()
            before = journal['before']
            return tuple((i, g, before['titles'][g] if isinstance(before['titles'][g], str)
                          else 'Название скрыто: сверьте с сохранённым пресетом')
                         for i, g in enumerate(before['order'], 1))
        except (KeyError, TypeError, ValueError):
            return ()

    def recover(self, endpoint, preset, *, validate=None, authorize=None):
        if self.busy:
            return False
        try:
            journal = self._store.read(endpoint, preset, 'pending')
            if not journal:
                return False
            rows = tuple(NativePair(**row) for row in journal['pairs'])
            _check_pairs(rows)
        except (KeyError, TypeError, ValueError):
            self._fail('Журнал нечитаем. Используйте копию рабочего пресета vMix.')
            return False
        self._recovery_reason = ''
        return self._begin('recover', endpoint, preset, rows, validate, authorize, journal=journal)

    def discard_recovery(self, endpoint, preset):
        """Operator acknowledged that the preset has been repaired separately."""
        if self.busy:
            return False
        self._store.remove(endpoint, preset, 'pending')
        return True

    def route(self, slot):
        if not self.ready or self._repair_waiting or type(slot) is not int or not 1 <= slot <= 12:
            return None
        row = self.pairs[slot - 1]
        return dict(original_guid=row.original_guid, original_number=self.numbers[row.original_guid],
                    virtual_guid=row.virtual_guid, virtual_number=self.numbers[row.virtual_guid], title=row.name,
                    empty=row.empty)

    def take(self, slot, mix=2, *, validate=None, allow_main=False):
        if mix == 1 and not allow_main:
            return False
        return self._request_take(slot, mix, True, validate)

    def take_live(self, slot, mix=1, *, validate=None):
        return self._request_take(slot, mix, False, validate)

    def _request_take(self, slot, mix, virtual, validate):
        if self._mode not in ('', 'monitor', 'take') or type(mix) is not int or mix < 1:
            return False
        route = self.route(slot)
        if not route:
            return False
        intent = _Take(slot, route['virtual_guid' if virtual else 'original_guid'], virtual, validate)
        if mix in self._takes:
            self._takes[mix].latest = intent
            return True
        if self._mode != 'take':
            self._interrupt()
            self._mode = 'take'
        channel = self._takes[mix] = _MixRequest(VmixRequest(self), intent)
        channel.http.send(self._url, None, lambda error, xml: self._receive(error, xml, mix=mix))
        return True

    def _clear_takes(self):
        for channel in self._takes.values():
            channel.http.cancel()
            channel.http.deleteLater()
        self._takes.clear()

    def _monitor(self):
        if self._armed and not self.busy:
            self._mode = 'monitor'
            self._read()

    def _current(self):
        generation = self._generation
        try:
            valid = self._validate is None or self._validate()
        except Exception:
            valid = False
        if generation != self._generation:
            return False
        if not valid:
            self._fail('Состав, назначение или управление изменились. Сверьте текущий план.')
        return bool(valid)

    def _read(self):
        if self._current():
            self._http.send(self._url, None, self._receive)

    def _title_during_navigation(self, state):
        # Only the active room monitor can attest to this exact, short-lived title.
        if self._mode not in ('monitor', 'take') or not self.ready or self.pending_title is None:
            return state
        candidates = [row for row in self.pairs if row.original_guid in state.inputs
                      and state.inputs[row.original_guid]['title'] != row.display_name]
        if len(candidates) != 1:
            return state
        row = candidates[0]
        info = state.inputs[row.original_guid]
        try:
            if not self.pending_title(self.endpoint, state.preset, row.original_guid, info['title']):
                return state
        except Exception:
            return state
        return replace(state, inputs={**state.inputs, row.original_guid: dict(info, title=row.display_name)})

    def _receive(self, error, xml, *, mix=None, written=None):
        if error:
            message = f'Не удалось получить XML vMix ({error}).'
            if mix is None:
                self._fail(message)
            else:
                self._finish_take(mix, False, message)
            return
        if not self._current():
            return
        try:
            state, parents = read_native_catalog(xml)
            evidence = read_native_geometry(xml)
            self.numbers = {guid: info['number'] for guid, info in state.inputs.items()}
            if mix is None:
                self.mixes = evidence.mixes
            else:
                # Independent XML requests can finish in a different order on other mixes.
                self.mixes[mix] = evidence.mixes.get(mix, '')
            self.external2 = evidence.external2
            if self._observe_bank is not None:
                observed = self._observe_bank(state, parents, xml)
                if mix is not None and (observed != self.pairs or state.preset != self.preset):
                    raise ValueError('Банк vMix изменился. Выберите камеру по обновлённому списку.')
                self.pairs = observed
                self._pinned_preset = state.preset
            self._geometry_count = sum(bool(evidence.positions.get(row.original_guid)) for row in self.pairs)
            if self._observe_bank is None and self._mode not in ('sync', 'recover') and self.has_recovery(self.endpoint, state.preset):
                raise ValueError('Есть прерванная синхронизация. Сначала проверьте восстановление входов.')
            if self._pinned_preset is not None and state.preset != self._pinned_preset:
                raise ValueError('Пресет vMix изменился. Проверьте пары.')
            self._pinned_preset = self.preset = state.preset
            checked_state = state if self._room_layout else self._title_during_navigation(state)
            sorted_names = not self._room_layout and self._mode not in ('sync', 'recover')
            check_native_layout(checked_state, parents, self.pairs, sorted_names=sorted_names,
                                require_names=not self._room_layout)
            if self._room_layout and any(self.numbers[row.original_guid] != slot
                                         for slot, row in enumerate(self.pairs, 1)):
                raise ValueError('Изменён порядок оригиналов. Повторите проверку пула камер.')
        except ElementTree.ParseError:
            self._fail('Web Controller вернул некорректный XML.')
            return
        except ValueError as exc:
            self._fail(str(exc) if str(exc) not in ('vMix XML', 'Ambiguous input') else 'Неверный список входов vMix.')
            return
        if self._mode not in ('sync', 'recover'):
            issue = '' if self._room_layout else self._neutral_problem(evidence)
            if issue:
                self._fail(issue)
            elif checked_state is not state:
                # Keep the monitor's authority for its own scoped repair, but never
                # publish a routable position or replay a take across the discrepancy.
                requested = self._mode == 'take'
                self._clear_takes()
                first_read = not self._repair_waiting
                self._repair_waiting = True
                self._mode = ''
                self.message = 'Ожидаем восстановления названия после обновления страницы камеры.'
                if first_read:
                    self.changed.emit()
                if requested:
                    self.finished.emit(False, self.message)
                if self._armed and not self._mode:
                    self._poll.start()
            elif mix is not None:
                self._take_checked(mix, written, evidence)
            else:
                self._success()
            return
        if self._mode == 'sync' and self._baseline is None:
            if self.has_recovery(self.endpoint, self.preset):
                self._fail('Есть прерванная синхронизация. Проверьте журнал и восстановите входы.')
                return
            if self._authorize is not None:
                self._approve()
                return
        self._observed = snapshot(state, evidence)
        if self._mode == 'recover':
            self._recover_step()
        else:
            self._sync(state, evidence)

    def _approve(self):
        authorize, self._authorize = self._authorize, None
        generation = self._generation
        try:
            approved = authorize(self.endpoint, {key for row in self.pairs for key in (row.original_guid, row.virtual_guid)})
        except Exception:
            approved = False
        if self._generation != generation:
            return
        if not approved:
            self._fail('Операция отменена.')
        else:
            self._read()

    def _fail(self, message):
        mode = self._mode
        if mode == 'take':
            self._clear_takes()
        if mode == 'sync' and self._journal and self._journal.get('pending'):
            # Read the actual preset before undoing anything, even on a rejected or timed-out write.
            self._mode = 'recover'
            self._recovery_reason = message
            self._expected = None
            self._recovery_previous = None
            self._recovery_attempts = 0
            self.message = message + ' Проверяем возможность вернуть прежние назначения.'
            generation = self._generation
            self.changed.emit()
            if generation == self._generation:
                self._read()
            return
        if mode == 'recover' and self._journal:
            reason = getattr(self, '_recovery_reason', '')
            message = (reason + ' ' if reason and reason != message else '') + message
            message += ' Журнал сохранён. Сверьте входы и повторите восстановление.'
        self._reset_ack.pop((self.endpoint, self.preset), None)
        self._mode = ''
        self.ready = False
        self.receipt = None
        self.message = message
        self.changed.emit()
        if mode != 'monitor':
            self.finished.emit(False, message)
        if self._armed and not self._mode:
            self._poll.start()

    def _success(self):
        mode = self._mode
        self._mode = ''
        if mode == 'sync':
            try:
                self._store.confirmed(self.endpoint, self.preset, self._match_id, self.pairs)
            except ValueError as exc:
                self._mode = mode
                self._fail(str(exc))
                return
            self._journal = None
            self._private_titles = {}
            self._reset_ack[self.endpoint, self.preset] = {
                row.virtual_guid: (row.original_guid, self._observed['geometry'][row.virtual_guid]) for row in self.pairs
            }
        self._armed = self.ready = True
        self._repair_waiting = False
        receipt = None if self._room_layout else AppliedBatch(self.endpoint, self.preset, tuple(
            AppliedInput(i, row.original_guid, row.name, row.empty) for i, row in enumerate(self.pairs, 1)))
        if self.receipt != receipt:
            self.receipt = receipt
        self.verification_note = (f'XML показывает параметры геометрии у {self._geometry_count} из 12 оригиналов. '
                                  'Сверьте скрытые параметры Position, Crop, Rotation и пропорции копий в vMix. '
                                  'Физический выход External 2 проверьте на приёмнике.')
        self.message = 'Проверены входы 1–12 и виртуальные копии 13–24.'
        self.changed.emit()
        if mode != 'monitor':
            self.finished.emit(True, self.message)
        if self._armed and not self._mode:
            self._poll.start()

    def _take_checked(self, mix, written, evidence):
        channel = self._takes[mix]
        intent = channel.latest
        current = self.mixes.get(mix)
        if not current:
            self._finish_take(mix, False, f'Mix {mix} отсутствует или неоднозначен в XML vMix.')
            return
        if written is intent:
            ok = current == intent.guid
            message = (f'Позиция {intent.slot} в Program Mix {mix}.' if ok else
                       f'vMix не подтвердил позицию {intent.slot} в Program Mix {mix}.')
            self._finish_take(mix, ok, message)
            return
        if self._room_layout and intent.virtual:
            issue = neutral_issue(evidence.positions[intent.guid])
            if issue:
                self._finish_take(mix, False, issue)
                return
        try:
            authorized = intent.validate is None or intent.validate()
        except Exception:
            authorized = False
        if self._takes.get(mix) is not channel:
            return
        if channel.latest is not intent:
            channel.http.send(self._url, None, lambda error, xml: self._receive(error, xml, mix=mix))
            return
        if not authorized:
            self._finish_take(mix, False, f'Назначение Mix {mix} изменилось.')
            return
        if current == intent.guid:
            self._finish_take(mix, True, f'Позиция {intent.slot} в Program Mix {mix}.')
            return

        def sent(error, _):
            if error:
                self._finish_take(mix, False, f'Команда для Mix {mix} не подтверждена ({error}).')
            else:
                # This read also validates the latest click if one arrived during the write.
                channel.http.send(self._url, None, lambda error, xml: self._receive(error, xml, mix=mix, written=intent))

        channel.http.send(self._url, dict(Function='ActiveInput', Input=intent.guid, Mix=mix - 1), sent)

    def _finish_take(self, mix, ok, message):
        channel = self._takes.pop(mix)
        channel.http.deleteLater()
        if not self._takes:
            self._mode = ''
        self.message = message
        self.changed.emit()
        self.finished.emit(ok, message)
        if self._armed and not self._mode:
            self._poll.start()

    def _sync(self, state, evidence):
        order = tuple(sorted(self.numbers, key=self.numbers.get))
        titles = {guid: state.inputs[guid]['title'] for guid in order[:24]}
        if self._baseline is None:
            self._private_titles = {g: title for g, title in titles.items() if not isinstance(safe_title(title), str)}
            self._before = self._observed
            self._baseline = evidence
            self._outside = {g: self.numbers[g] for g in order[24:]}
            self._order = order[:24]
            self._titles = titles
        issue = self._baseline.guard(evidence, [row.original_guid for row in self.pairs])
        if issue or self._outside != {g: self.numbers[g] for g in order[24:]}:
            self._fail(issue or 'Номера посторонних входов изменились. Синхронизация остановлена.')
            return
        if self._journal and not compatible(self._journal['checkpoint'], self._observed, self._journal['pending']):
            self._fail('Обнаружено постороннее изменение входов. Синхронизация остановлена.')
            return
        if not self._check_effect(order[:24], titles):
            return
        desired = tuple(r.original_guid for r in self.pairs) + tuple(r.virtual_guid for r in self.pairs)
        if self._fixed_slots and self._order != desired:
            self._fail('Порядок входов изменился. Повторите применение.')
            return
        for base in (0, 12):
            move = _move_for_order(self._order[base:base + 12], desired[base:base + 12], self._swaps)
            if move:
                a, b = (base + i for i in move)
                inserted, swapped = list(self._order), list(self._order)
                inserted.insert(b, inserted.pop(a))
                swapped[a], swapped[b] = swapped[b], swapped[a]
                self._moves += 1
                if self._moves > 24:
                    self._fail('Перестановка входов не сходится. Сверьте порядок в vMix.')
                    return
                self._expected = ('move', tuple(inserted), tuple(swapped))
                self._send(dict(Function='MoveInput', Input=self._order[a], Value=b + 1))
                return
        for row in self.pairs:
            for guid, name in ((row.original_guid, row.display_name), (row.virtual_guid, row.display_name + ' - Virtual')):
                if not title_matches(self._titles[guid], name, virtual=guid == row.virtual_guid):
                    self._expected = ('name', guid, name)
                    self._send(dict(Function='SetInputName', Input=guid, Value=name))
                    return
        self._normalize(evidence)

    def _recover_step(self):
        journal, now = self._journal, self._observed
        keys = {g for row in self.pairs for g in (row.original_guid, row.virtual_guid)}
        try:
            before, checkpoint = journal['before'], journal['checkpoint']
            if (len(before['order']) != 24 or set(before['order']) != keys or set(before['titles']) != keys
                    or set(before['geometry']) != keys or journal['touched'].keys() - {r.virtual_guid for r in self.pairs}
                    or any(now[k] != before[k] for k in ('outside', 'mixes', 'external2'))
                    or any(now['geometry'][r.original_guid] != before['geometry'][r.original_guid] for r in self.pairs)
                    or (now != before and not compatible(checkpoint, now, journal['pending']))):
                raise ValueError
        except (KeyError, ValueError, TypeError, IndexError):
            self._fail('Текущее состояние отличается от журнала. Проверьте Program, пресет и изменения других операторов.')
            return
        if self._authorize is not None:
            self._approve()
            return
        if journal['pending']['Function'] == 'MoveInput' and checkpoint['order'] != now['order']:
            move = journal['pending']
            trial = list(checkpoint['order'])
            i, j = trial.index(move['Input']), int(move['Value']) - 1
            if abs(i - j) > 1:
                trial[i], trial[j] = trial[j], trial[i]
                self._swaps = trial == now['order']
        command = None
        manual = False
        for base in (0, 12):
            move = _move_for_order(tuple(now['order'][base:base + 12]), tuple(before['order'][base:base + 12]), self._swaps)
            if move:
                a, b = (base + n for n in move)
                command = dict(Function='MoveInput', Input=now['order'][a], Value=b + 1)
                break
        if not command:
            for guid in before['order']:
                title = before['titles'][guid]
                if now['titles'][guid] == title:
                    continue
                if not isinstance(title, str):
                    title = self._private_titles.get(guid)
                    if title is None or safe_title(title) != before['titles'][guid]:
                        manual = True
                        continue
                # First try the exact saved title. If the controller demonstrably
                # prepended another prefix to that write, undo its decoration.
                pending = journal['pending']
                if (guid in before['order'][12:24] and title.startswith('Virtual - ')
                        and pending['Function'] == 'SetInputName' and pending['Input'] == guid
                        and pending['Value'] == title and now['titles'][guid] == 'Virtual - ' + title):
                    title = title.removeprefix('Virtual - ')
                command = dict(Function='SetInputName', Input=guid, Value=title)
                break
        if not command:
            command, hidden = geometry_undo(journal, now)
            manual |= hidden
        if command:
            if self._recovery_previous == (now, command):
                if self._recovery_attempts < 5:
                    self._recovery_attempts += 1
                    self._retry.start()
                else:
                    self._fail('vMix не подтвердил команду восстановления.')
                return
            self._recovery_previous = now, command
            self._recovery_attempts = 0
            self._send(command)
            return
        self._armed = self.ready = False
        self._repair_waiting = False
        self.receipt = None
        self._mode = ''
        reason = getattr(self, '_recovery_reason', '')
        if manual:
            message = 'Доступные параметры восстановлены. Сверьте скрытые значения или заголовки с копией пресета vMix.'
        else:
            try:
                self._store.remove(self.endpoint, self.preset, 'pending')
            except ValueError as exc:
                self._fail(str(exc))
                return
            message = 'Предыдущие порядок, названия и изменённые доступные параметры восстановлены.'
        self._journal = None
        self.message = (reason + ' ' if reason else '') + message
        self.changed.emit()
        self.finished.emit(not reason and not manual, self.message)

    def _check_effect(self, order, titles):
        pending = self._expected
        if pending:
            if pending[0] == 'move' and order in pending[1:] and titles == self._titles:
                if pending[1] != pending[2]:
                    self._swaps = order == pending[2]
                self._order = order
            elif (pending[0] == 'name' and order == self._order
                  and title_matches(titles[pending[1]], pending[2], virtual=pending[1] in order[12:24])
                  and titles == {**self._titles, pending[1]: titles[pending[1]]}):
                self._titles = titles
            elif order == self._order and titles == self._titles:
                if self._attempts < 5:
                    self._attempts += 1
                    self._retry.start()
                else:
                    self._fail('vMix не подтвердил перемещение или название входа в XML.')
                return False
            else:
                self._fail('GUID, порядок или заголовки изменились во время записи. Обновите план.')
                return False
            self._expected = None
        elif order != self._order or titles != self._titles:
            self._fail('Список входов изменился во время синхронизации.')
            return False
        return True

    def _send(self, command):
        if not self._current():
            return
        if self._mode in ('sync', 'recover'):
            if self._journal is None:
                self._journal = dict(before=self._before, pairs=[asdict(row) for row in self.pairs],
                                     match_id=self._match_id, touched={})
            record_command(self._journal, self._observed, command)
            try:
                self._store.write(self.endpoint, self.preset, 'pending', self._journal)
            except ValueError as exc:
                self._mode = 'recover'
                self._fail(str(exc))
                return
        self._attempts = 0
        def sent(error, _):
            if error:
                self._fail(f'vMix не подтвердил {command["Function"]} ({error}). Повторите синхронизацию.')
            else:
                self._read()
        self._http.send(self._url, command, sent)

    def _neutral_problem(self, evidence):
        for i, row in enumerate(self.pairs, 13):
            issue = neutral_issue(evidence.positions.get(row.virtual_guid, {}))
            if issue:
                return f'Виртуальная копия № {i}: {issue}'
        return ''

    def _normalize(self, evidence):
        if not self._geometry_started:
            self._geometry_started = True
            trusted = self._reset_ack.get((self.endpoint, self.preset), {})
            for row in self.pairs:
                observed = evidence.positions.get(row.virtual_guid, {})
                reuse = trusted.get(row.virtual_guid) == (row.original_guid, observed)
                self._geometry.extend(reset_commands(row.virtual_guid, observed, include_unreported=not reuse))
        if self._geometry:
            self._send(self._geometry.pop(0))
            return
        issue = self._neutral_problem(evidence)
        if issue:
            self._fail(issue)
            return
        self._success()
