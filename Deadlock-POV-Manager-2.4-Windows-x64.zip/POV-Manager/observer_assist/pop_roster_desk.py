"""Match rosters and explicit vMix input preparation for the tournament desk."""
from secrets import token_urlsafe
from unicodedata import category

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QApplication, QComboBox, QFormLayout, QGroupBox, QHBoxLayout,
                               QHeaderView, QLabel, QLineEdit, QPushButton, QSpinBox,
                               QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget)

from .broadcast_tables import players_by_match_position
from .camera_native_setup import NativePoolSetup
from .camera_native_sync import NativePair, NativePairSync, check_player_title
from .camera_vdo_panel import HOST_KEY, PORT_KEY
from .live_stats_panel import lan_interfaces
from .match_stats import STATS_PORT, StatsLanServer
from .pop_input_picker import InputPicker
from .pop_mix_peers import PopMixPeers
from .pov_match_data import _ordered_names
from .pov_remote import PovRemote
from .source_tv_panel import SourceTvPanel
from .ui import STYLE


def vmix_roster_titles(names):
    titles = []
    positions = {}
    for slot, name in enumerate(names, 1):
        # Keep joiners used by emoji and scripts, strip invisible layout marks from vMix labels.
        title = ''.join(' ' if category(ch) == 'Zs' else ch for ch in name
                        if category(ch) != 'Cf' or ch in '\u200c\u200d').strip()
        check_player_title(title, slot)
        key = title.casefold()
        if key in positions:
            raise ValueError(f'Позиции {positions[key]} и {slot}: одинаковое название для vMix.')
        positions[key] = slot
        titles.append(title)
    return tuple(titles)


class RosterDesk(QWidget):
    def __init__(self, settings):
        super().__init__()
        self.settings = settings
        self.setWindowTitle('Pop Manager 2.4')
        self.setStyleSheet(STYLE + '''
            QTableWidget { background: #192229; alternate-background-color: #202c34;
                color: #edf3f5; gridline-color: #35424c; selection-background-color: #31544a; }
            QHeaderView::section { background: #26323c; color: #dae5e9; padding: 5px; border: 0; }
        ''')
        self.resize(760, 800)
        self.match_id, self.names = '', ()
        self.job = self.server = None
        self.recovering = False
        self.connected_to = None
        self.loaded_roster = None
        self.payload = dict(version=1, status='waiting', matchId=None, hud_slots={})
        self.source_tv = SourceTvPanel(self)
        self.source_tv.hide()
        self.remote = PovRemote(self, by_position=True)
        self.setup = NativePoolSetup(settings, self)
        self.sync = NativePairSync(self, settings=settings)
        self.peers = PopMixPeers(self)

        layout = QVBoxLayout(self)
        layout.setSpacing(9)
        heading = QLabel('Состав матча')
        heading.setObjectName('title')
        layout.addWidget(heading)
        self.source = QComboBox()
        self.source.addItem('По Match ID · SourceTV', 'match')
        self.source.addItem('Panorama · HUD Manager', 'remote')
        saved = settings.value('povMatchSource', 'match', type=str)
        self.source.setCurrentIndex(max(0, self.source.findData(saved)))
        layout.addWidget(self.source)
        row = QHBoxLayout()
        self.address = QLineEdit()
        self.connect_button = QPushButton('Подключиться')
        self.refresh = QPushButton('Обновить составы')
        row.addWidget(self.address, 1)
        row.addWidget(self.connect_button)
        row.addWidget(self.refresh)
        layout.addLayout(row)
        self.remote_status = QLabel()
        layout.addWidget(self.remote_status)
        layout.addWidget(self.source_tv.status)
        self.order_info = QLabel()
        self.order_info.setWordWrap(True)
        layout.addWidget(self.order_info)
        self.table = QTableWidget(12, 4)
        self.table.setHorizontalHeaderLabels(['Позиция', 'Игрок', 'Оригинал', 'Virtual Input'])
        self.table.verticalHeader().hide()
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        for i in range(12):
            for col, value in enumerate((str(i+1), '—', str(i+1), str(i+13))):
                self.table.setItem(i, col, QTableWidgetItem(value))
        layout.addWidget(self.table, 1)
        vmix = QGroupBox('vMix · Web Controller')
        controls = QHBoxLayout(vmix)
        self.host = QLineEdit(settings.value(HOST_KEY, '127.0.0.1', type=str))
        self.host.setAccessibleName('IP компьютера с vMix')
        self.port = QSpinBox()
        self.port.setRange(1, 65535)
        self.port.setValue(settings.value(PORT_KEY, 8088, type=int))
        controls.addWidget(QLabel('IP'))
        controls.addWidget(self.host, 1)
        controls.addWidget(QLabel('Порт'))
        controls.addWidget(self.port)
        self.apply = QPushButton('Применить к vMix')
        self.apply.setObjectName('primary')
        controls.addWidget(self.apply)
        self.picker = InputPicker(settings, self.table, self.host, self.port)
        layout.addWidget(self.picker)
        layout.addWidget(vmix)
        self.result = QLabel()
        self.result.setWordWrap(True)
        self.result.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.result)

        footer = QHBoxLayout()
        self.copy = QPushButton('Копировать URL для Companion')
        self.network_button = QPushButton('Настройки сети')
        self.network_button.setCheckable(True)
        footer.addWidget(self.copy)
        footer.addStretch()
        footer.addWidget(self.network_button)
        layout.addLayout(footer)
        network_panel = QWidget()
        form = QFormLayout(network_panel)
        self.network = QComboBox()
        for name, addr in lan_interfaces():
            self.network.addItem(f'{name} · {addr.ip}', str(addr))
        self.network.addItem('Этот ПК · 127.0.0.1', '127.0.0.1/8')
        self.network.setCurrentIndex(max(0, self.network.findData(settings.value('statsExportAddress', '', type=str))))
        self.api_port = QSpinBox()
        self.api_port.setRange(1, 65535)
        self.api_port.setKeyboardTracking(False)
        self.api_port.setValue(settings.value('povCompanionPort', STATS_PORT + 1, type=int))
        form.addRow('Адрес для Companion', self.network)
        form.addRow('Порт API', self.api_port)
        layout.addWidget(network_panel)
        network_panel.hide()
        self.api_status = QLabel()
        self.api_status.setWordWrap(True)
        layout.addWidget(self.api_status)
        self.network_button.toggled.connect(network_panel.setVisible)
        self.network.currentIndexChanged.connect(self._start_api)
        self.api_port.valueChanged.connect(self._start_api)
        self.copy.clicked.connect(self._copy_url)
        self.source.currentIndexChanged.connect(self._source_changed)
        self.address.textChanged.connect(self._buttons)
        self.address.returnPressed.connect(self._connect)
        self.connect_button.clicked.connect(self._connect)
        self.refresh.clicked.connect(self._connect)
        self.picker.changed.connect(self._buttons)
        self.apply.clicked.connect(self._apply)
        self.setup.finished.connect(self._pool_done)
        self.sync.finished.connect(self._sync_done)
        self.source_tv.roster_changed.connect(self._read)
        self.remote.changed.connect(self._read)
        self.remote.status.connect(self.remote_status.setText)
        self._source_changed()
        self._start_api()

    def _source_changed(self):
        self.loaded_roster = None
        self.connected_to = None
        self.source_tv.stop()
        self.remote.stop()
        remote = self.source.currentData() == 'remote'
        self.remote_status.setVisible(remote)
        self.source_tv.status.setVisible(not remote)
        self.settings.setValue('povMatchSource', self.source.currentData())
        self.address.setEchoMode(QLineEdit.EchoMode.PasswordEchoOnEdit if remote else QLineEdit.EchoMode.Normal)
        self.address.setPlaceholderText('URL JSON матча с ПК наблюдателя' if remote else 'Match ID')
        key = 'povHudUrl' if remote else 'popLastSourceMatch'
        self.address.setText(self.settings.value(key, '', type=str))
        self.remote_status.setText('На ПК наблюдателя откройте HUD Manager → Статистика → Копировать URL JSON матча.')
        self.result.clear()
        self._read()

    def _connect(self):
        if self.job:
            return
        mode, address = self.source.currentData(), self.address.text().strip()
        self.loaded_roster = None
        self.connected_to = (mode, address)
        self.result.clear()
        if mode == 'remote':
            if self.remote.set_url(address):
                self.settings.setValue('povHudUrl', address)
            else:
                self.connected_to = None
        elif address.isascii() and address.isdecimal() and 0 < len(address) <= 20:
            self.settings.setValue('popLastSourceMatch', address)
            self.source_tv._clear_players()
            self.source_tv.url.setText(address)
            self.source_tv.connect_button.click()
        else:
            self.connected_to = None
            self.source_tv.stop()
            self.source_tv.status.setText('Введите числовой Match ID.')
        self._read()

    def _read(self, *_):
        if self.source.currentData() == 'remote':
            packet = self.remote.snapshot
            match_id, names = (packet.match_id, packet.names) if packet else ('', ())
            note = 'Порядок портретов Panorama слева направо.'
        else:
            roster = self.source_tv.roster or {}
            match_id = str(roster.get('matchId') or '')
            names = _ordered_names(players_by_match_position(roster))
            if self.source_tv.requested_match_id and match_id != self.source_tv.requested_match_id:
                names = ()
            note = 'Порядок SourceTV рассчитан по командам и линиям. Внутри линии он может отличаться от HUD.'
        waiting = 'Ожидание позиций 12 игроков.'
        if self.source.currentData() == 'match' and roster and not names:
            waiting = 'SourceTV ещё не передал 12 однозначных позиций по линиям. Для порядка портретов используйте Panorama.'
        if self.connected_to and names and (self.source.currentData() == 'remote' or match_id):
            if self.source.currentData() == 'remote' or self.loaded_roster is None:
                self.loaded_roster = (match_id, names)
            elif self.loaded_roster != (match_id, names):
                waiting = 'Матч или порядок игроков изменился. Нажмите «Обновить составы».'
                match_id, names = '', ()
        elif self.connected_to and self.source.currentData() == 'remote' and match_id:
            waiting = f'Матч {match_id} · ожидаем позиции 12 игроков.'
        else:
            match_id, names = '', ()
        if (match_id, names) != (self.match_id, self.names):
            self.match_id, self.names = match_id, names
            self.payload = dict(version=1, status='live' if names else 'waiting', matchId=match_id or None,
                                hud_slots={str(i): n for i, n in enumerate(names, 1)})
            for i in range(12):
                self.table.item(i, 1).setText(names[i] if names else '—')
            if not self.job:
                self.result.clear()
        identity = f'Матч {match_id}' if match_id else 'Ожидаем Match ID'
        self.order_info.setText(f'{identity} · 12 игроков. {note}' if names else waiting)
        self._buttons()

    def _buttons(self, *_):
        busy = self.job is not None
        current = (self.source.currentData(), self.address.text().strip())
        for widget in (self.source, self.address, self.host, self.port):
            widget.setEnabled(not busy)
        self.connect_button.setEnabled(not busy and bool(current[1]))
        self.refresh.setEnabled(not busy and bool(self.connected_to) and bool(current[1]))
        self.picker.set_busy(busy)
        selection_ok = not self.picker.custom or bool(self.picker.pairs)
        self.apply.setEnabled(not busy and bool(self.names) and current == self.connected_to and selection_ok)

    def _start_api(self):
        if self.server:
            self.server.close()
            self.server = None
        addr, port = self.network.currentData(), self.api_port.value()
        token = self.settings.value('statsExportToken', '', type=str) or token_urlsafe(24)
        self.settings.setValue('statsExportToken', token)
        self.settings.setValue('statsExportAddress', addr)
        self.settings.setValue('povCompanionPort', port)
        try:
            self.server = StatsLanServer(addr, token, lambda: self.payload, port)
            self.api_status.clear()
        except (OSError, ValueError) as exc:
            self.api_status.setText(f'API Companion недоступен. Проверьте настройки сети. {exc}')
        self.copy.setEnabled(self.server is not None)

    def _copy_url(self):
        if self.server:
            QApplication.clipboard().setText(self.server.url)
            self.api_status.setText('URL для HTTP GET скопирован.')

    def _current_job(self):
        return ((self.host.text().strip(), self.port.value()), self.match_id, self.names)

    def _valid(self):
        return self.job is not None and self.job == self._current_job() and not self.peers.remote_sorting(self.job[0])

    def _apply(self):
        if not self.apply.isEnabled():
            return
        try:
            self._titles = vmix_roster_titles(self.names)
        except ValueError as exc:
            self.result.setText(str(exc))
            return
        self.job = self._current_job()
        endpoint, _, _ = self.job
        self.settings.setValue(HOST_KEY, endpoint[0])
        self.settings.setValue(PORT_KEY, endpoint[1])
        self.peers.set_claims(endpoint, (), sorting=True)
        self._buttons()
        self._start_apply()

    def _start_apply(self):
        endpoint, match, _ = self.job
        if self.picker.custom:
            preset = self.picker.state.preset
            if self.sync.has_recovery(endpoint, preset):
                self.recovering = True
                self.result.setText('Проверяем прерванную запись vMix…')
                if not self.sync.recover(endpoint, preset, validate=self._valid) and self.job:
                    self.recovering = False
                    self._done('Проверьте журнал восстановления vMix.')
                return
            pairs = tuple(NativePair(g, v, title, operator_verified=True)
                          for (g, v), title in zip(self.picker.pairs, self._titles))
            self.result.setText('Применяем ники к выбранным входам…')
            self.sync.start(endpoint, preset, pairs, match_id=match, selected_inputs=True, validate=self._valid)
            return
        self.result.setText('Проверяем оригиналы 1–12 и готовим виртуальные копии 13–24…')
        self.setup.start(endpoint, validate=self._valid,
                         allow_preset=lambda preset: not self.sync.has_recovery(endpoint, preset))

    def _pool_done(self, ok, message):
        if self.job is None:
            return
        endpoint, match_id, _ = self.job
        if not ok:
            if self._valid() and self.setup.preset is not None and self.sync.has_recovery(endpoint, self.setup.preset):
                self.recovering = True
                self.result.setText('Проверяем прерванную запись перед повторным применением…')
                if self.sync.recover(endpoint, self.setup.preset, validate=self._valid):
                    return
                self.recovering = False
            self._done(message)
            return
        pairs = tuple(NativePair(g, v, n, operator_verified=True)
                      for (g, v), n in zip(self.setup.paired_guids, self._titles))
        self.result.setText('Применяем ники и проверяем 24 входа vMix…')
        self.sync.start(endpoint, self.setup.preset, pairs, match_id=match_id, fixed_slots=True, validate=self._valid)

    def _sync_done(self, ok, message):
        if self.job is None:
            return
        if self.recovering:
            self.recovering = False
            preset = self.picker.state.preset if self.picker.custom else self.setup.preset
            if self._valid() and not self.sync.has_recovery(self.job[0], preset):
                self._start_apply()
                return
        self._done('vMix подтвердил 24/24 входа.' if ok else message)
        if ok and self.picker.custom:
            self.picker.fetch()

    def _done(self, message):
        self.sync.cancel()
        self.job = None
        self.peers.set_claims(None, ())
        self.result.setText(message)
        self._buttons()

    def closeEvent(self, event):
        self.job = None
        self.picker.http.cancel()
        self.setup.cancel()
        self.sync.cancel()
        self.peers.close()
        self.source_tv.stop()
        self.remote.stop()
        if self.server:
            self.server.close()
        self.source_tv.process.waitForFinished(1500)
        self.settings.sync()
        super().closeEvent(event)
