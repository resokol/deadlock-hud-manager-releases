"""Map HUD slots to existing browser inputs and native copies on a vMix workstation."""
import json
from hashlib import sha256
from ipaddress import IPv4Address
from xml.etree.ElementTree import ParseError

from PySide6.QtCore import QSignalBlocker, QUrl, Signal
from PySide6.QtWidgets import QComboBox, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget

from .camera_native_recovery import safe_title
from .camera_vdo_panel import HOST_KEY, PORT_KEY
from .camera_native_sync import read_native_catalog
from .camera_vdo_publish import VmixRequest
from .camera_vmix import browser_source, virtual_source
from .match_stats import is_lan_address


class InputPicker(QWidget):
    changed = Signal()

    def __init__(self, settings, table, host, port):
        super().__init__()
        self.settings, self.table, self.host, self.port = settings, table, host, port
        self.http = VmixRequest(self)
        self.state = None
        self.rows = []
        self.pairs = ()
        self.mode = QComboBox()
        self.mode.addItem('Стандартные входы 1–24', False)
        self.mode.addItem('Выбрать входы из vMix', True)
        self.mode.setCurrentIndex(int(settings.value('popSelectInputs', False, type=bool)))
        self.load = QPushButton('Обновить список')
        self.note = QLabel()
        self.note.setWordWrap(True)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        line = QHBoxLayout()
        line.addWidget(QLabel('Входы vMix'))
        line.addWidget(self.mode, 1)
        line.addWidget(self.load)
        layout.addLayout(line)
        layout.addWidget(self.note)
        self.load.clicked.connect(self.fetch)
        self.mode.currentIndexChanged.connect(self._mode_changed)
        host.textChanged.connect(self.clear_catalog)
        port.valueChanged.connect(self.clear_catalog)
        self._mode_changed()

    @property
    def custom(self):
        return self.mode.currentData()

    def clear_catalog(self):
        self.http.cancel()
        self.state = None
        self.pairs = ()
        self.rows.clear()
        for i in range(12):
            for col, number in ((2, i + 1), (3, i + 13)):
                self.table.removeCellWidget(i, col)
                self.table.item(i, col).setText('—' if self.custom else str(number))
        self.load.setEnabled(True)
        self.note.setText('Укажите адрес и нажмите «Обновить список».' if self.custom else '')
        self.note.setVisible(self.custom)
        self.changed.emit()

    def _mode_changed(self):
        self.settings.setValue('popSelectInputs', self.custom)
        self.load.setVisible(self.custom)
        self.clear_catalog()
        if self.custom:
            self.fetch()

    def fetch(self):
        self.clear_catalog()
        if not self.custom:
            return
        try:
            ip = IPv4Address(self.host.text().strip())
            if not (is_lan_address(ip) or ip.is_loopback):
                raise ValueError
        except ValueError:
            self.note.setText('Проверьте локальный IPv4-адрес vMix.')
            return
        self.endpoint = str(ip), self.port.value()
        self.load.setEnabled(False)
        self.note.setText('Получаем входы из vMix…')
        self.http.send(QUrl(f'http://{ip}:{self.port.value()}/api/'), None, self._received)

    def _received(self, error, xml):
        self.load.setEnabled(True)
        if error:
            self.note.setText(f'Не удалось получить список входов vMix ({error}).')
            return
        try:
            self.state, self.parents = read_native_catalog(xml)
        except (ValueError, ParseError):
            self.note.setText('Web Controller вернул некорректный список входов.')
            return
        host, port = self.endpoint
        self.settings.setValue(HOST_KEY, host)
        self.settings.setValue(PORT_KEY, port)
        preset_key = sha256(self.state.preset.encode()).hexdigest()
        self.key = f'popInputSelection/{host}/{port}/{preset_key}'
        try:
            saved = json.loads(self.settings.value(self.key, 'null', type=str))
        except (TypeError, ValueError):
            saved = []
        inputs = sorted(self.state.inputs.items(), key=lambda item: item[1]['number'])
        originals = [(g, info) for g, info in inputs if browser_source(info)]
        copies = [(g, info) for g, info in inputs if info.get('virtual') is not False and virtual_source(info)
                  and info['type'].casefold() in ('virtual', 'browser', 'webbrowser', 'web browser')]
        self.copy_options = copies
        for i in range(12):
            original, virtual = QComboBox(), QComboBox()
            self.rows.append((original, virtual))
            self._options(original, originals)
            if saved is None:
                source = next((g for g, info in originals if info['number'] == i + 1), '')
                copy = next((g for g, info in copies if info['number'] == i + 13 and virtual_source(info, verified=True)), '')
            elif (isinstance(saved, list) and len(saved) == 12 and isinstance(saved[i], list)
                  and len(saved[i]) == 2 and all(isinstance(g, str) for g in saved[i])):
                source, copy = saved[i]
            else:
                source = copy = ''
            original.setCurrentIndex(max(0, original.findData(source)))
            self._copies(i, copy, auto=saved is None)
            self.table.setCellWidget(i, 2, original)
            self.table.setCellWidget(i, 3, virtual)
            original.currentIndexChanged.connect(lambda _, row=i: self._original_changed(row))
            virtual.currentIndexChanged.connect(self._selection)
        self._selection()

    @staticmethod
    def _options(combo, entries):
        combo.clear()
        combo.addItem('Выберите вход', '')
        for guid, info in entries:
            title = safe_title(info['title'])
            combo.addItem(f"{info['number']} · {title if isinstance(title, str) else 'Web Browser'}", guid)

    def _copies(self, row, preferred, *, auto):
        original, virtual = self.rows[row]
        source = original.currentData()
        options = [(g, info) for g, info in self.copy_options
                   if source and g != source and self.parents.get(g, source) == source]
        with QSignalBlocker(virtual):
            self._options(virtual, options)
            known = [g for g, _ in options if self.parents.get(g) == source]
            selected = known[0] if auto and len(known) == 1 else preferred
            virtual.setCurrentIndex(max(0, virtual.findData(selected)))

    def _original_changed(self, row):
        self._copies(row, '', auto=True)
        self._selection()

    def _selection(self):
        self.pairs = ()
        used = {}
        for pos, row in enumerate(self.rows, 1):
            for combo in row:
                guid = combo.currentData()
                if not guid or guid in used:
                    self.note.setText(f'Позиция {pos}. Выберите оригинал и его виртуальную копию.' if not guid else
                                      f'Один вход выбран для позиций {used[guid]} и {pos}.')
                    self.changed.emit()
                    return
                used[guid] = pos
        self.pairs = tuple(tuple(combo.currentData() for combo in row) for row in self.rows)
        self.settings.setValue(self.key, json.dumps(self.pairs))
        self.settings.sync()
        hidden = any(copy not in self.parents for _, copy in self.pairs)
        self.note.setText('Пары выбраны. vMix скрывает часть связей. Проверьте соответствие копий перед применением.'
                          if hidden else 'Выбрано 12 пар. Связи подтверждены пресетом vMix.')
        self.changed.emit()

    def set_busy(self, busy):
        self.setEnabled(not busy)
        for row in self.rows:
            for combo in row:
                combo.setEnabled(not busy)
