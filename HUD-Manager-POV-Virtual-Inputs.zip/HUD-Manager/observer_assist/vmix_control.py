"""Follow the observed player in one dedicated vMix input layer."""

from ipaddress import ip_address
from typing import NamedTuple
from urllib.parse import urlencode
from uuid import UUID
from xml.etree import ElementTree

from PySide6.QtCore import QObject, QTimer, QUrl, Signal
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkProxy, QNetworkReply, QNetworkRequest

from .hud_nicknames import normalize_name


REQUEST_TIMEOUT_MS = 2000
RETRY_DELAY_MS = 400
MAX_ATTEMPTS = 2


class _Configuration(NamedTuple):
    url: QUrl
    target: str
    layer: int
    mappings: dict[str, str]


def _guid(reference):
    try:
        return str(UUID(reference))
    except (ValueError, TypeError, AttributeError):
        return None


def _resolve_input(inputs, reference):
    guid = _guid(reference)
    if guid is not None:
        matches = [entry for entry in inputs if _guid(entry.get('key')) == guid]
    else:
        field = 'number' if reference.isascii() and reference.isdecimal() else 'title'
        matches = [entry for entry in inputs if entry.get(field) == reference]
    return matches[0] if len(matches) == 1 else None


class VmixPovControl(QObject):
    status = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._network = QNetworkAccessManager(self)
        self._network.setProxy(QNetworkProxy(QNetworkProxy.ProxyType.NoProxy))
        self._deadline = QTimer(self, singleShot=True)
        self._deadline.timeout.connect(self._abort_request)
        self._retry = QTimer(self, singleShot=True)
        self._retry.timeout.connect(self._send_desired)
        self._config = None
        self._reply = None
        self._desired = ''
        self._applied = ''
        self._attempts = 0
        self._closed = False

    def configure(self, address, port, target, layer, mappings, enabled):
        if self._closed:
            return
        config = None
        if enabled:
            try:
                address = str(ip_address(address))
                port, layer = int(port), int(layer)
                if not (1 <= port <= 65535 and 1 <= layer <= 10 and target.strip()):
                    raise ValueError
            except (AttributeError, TypeError, ValueError):
                self._cancel_pending()
                self._config = None
                self.status.emit('vMix: проверьте IP-адрес, порт, вход и слой.')
                return
            url = QUrl()
            url.setScheme('http')
            url.setHost(address)
            url.setPort(port)
            url.setPath('/api/')
            names = {normalize_name(name): str(source).strip() for name, source in mappings.items()}
            config = _Configuration(url, target.strip(), layer, names)
        if config != self._config:
            self._cancel_pending()
            self._config = config
            self._applied = ''
            self._attempts = 0
            self._send_desired()
        if not enabled:
            self.status.emit('Управление POV в vMix выключено.')

    def observe(self, player: str | None):
        if self._closed:
            return
        desired = normalize_name(player)
        if desired != self._desired:
            self._desired = desired
            self._attempts = 0
            self._retry.stop()
            self._send_desired()

    def close(self):
        self._closed = True
        self._config = None
        self._cancel_pending()

    def _cancel_pending(self):
        self._deadline.stop()
        self._retry.stop()
        reply, self._reply = self._reply, None
        if reply is not None:
            reply.abort()

    def _abort_request(self):
        if self._reply is not None:
            self._reply.abort()

    def _send_desired(self):
        if (self._config is None or self._reply is not None or self._retry.isActive()
                or self._attempts >= MAX_ATTEMPTS):
            return
        player = self._desired
        if not player:
            self.status.emit('vMix: ожидание игрока под наблюдением.')
        elif not self._config.mappings.get(player):
            self.status.emit(f'vMix: для «{player}» вход не настроен.')
        elif player != self._applied:
            self._attempts += 1
            self._send(player)

    def _send(self, player, command=None):
        url = QUrl(self._config.url)
        if command is not None:
            # The layer may change before the acknowledgement arrives.
            self._applied = ''
            url.setQuery(urlencode(command))
        request = QNetworkRequest(url)
        request.setAttribute(QNetworkRequest.Attribute.RedirectPolicyAttribute,
                             QNetworkRequest.RedirectPolicy.ManualRedirectPolicy)
        reply = self._network.get(request)
        self._reply = reply
        reply.finished.connect(lambda: self._finished(reply, player, command is not None))
        self._deadline.start(REQUEST_TIMEOUT_MS)

    def _finished(self, reply, player, layer_changed):
        if self._reply is not reply:
            reply.deleteLater()
            return
        self._reply = None
        self._deadline.stop()
        code = reply.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute)
        success = code == 200 and reply.error() == QNetworkReply.NetworkError.NoError
        xml = bytes(reply.readAll()) if success and not layer_changed else b''
        reply.deleteLater()
        if layer_changed and success:
            self._applied = player
        if player != self._desired:
            self._send_desired()
        elif not success:
            if (code is None or code >= 500) and self._attempts < MAX_ATTEMPTS:
                self._retry.start(RETRY_DELAY_MS)
            suffix = ' Повторим запрос.' if self._retry.isActive() else ''
            reason = f'ошибка HTTP {code}' if code and code != 200 else 'нет ответа от Web Controller'
            self.status.emit(f'vMix: {reason}.{suffix}')
        elif layer_changed:
            self.status.emit(f'vMix: POV «{player}» выбран.')
        else:
            self._switch(player, xml)

    def _switch(self, player, xml):
        try:
            state = ElementTree.fromstring(xml)
        except ElementTree.ParseError:
            self.status.emit('vMix: Web Controller вернул некорректный XML.')
            return
        inputs = state.findall('./inputs/input') if state.tag == 'vmix' else []
        composite = _resolve_input(inputs, self._config.target)
        source = _resolve_input(inputs, self._config.mappings[player])
        target_key = _guid(composite.get('key')) if composite is not None else None
        source_key = _guid(source.get('key')) if source is not None else None
        source_number = source.get('number', '').lstrip('0') if source is not None else ''
        if (not target_key or not source_key or target_key == source_key or
                not source_number.isascii() or not source_number.isdecimal()):
            self.status.emit('vMix: проверьте, что для POV настроены два разных входа.')
            return
        self._send(player, {'Function': 'SetLayer', 'Input': target_key,
                            'Value': f'{self._config.layer},{source_number}'})


class VmixInputNames(QObject):
    status = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.network = QNetworkAccessManager(self)
        self.network.setProxy(QNetworkProxy(QNetworkProxy.ProxyType.NoProxy))
        self.timer = QTimer(self, interval=5000)
        self.timer.timeout.connect(self._refresh)
        self.url = None
        self.names = {}
        self.reply = None
        self.pending = []
        self.missing = []
        self.errors = []

    def configure(self, address, port, names):
        url = QUrl()
        url.setScheme('http')
        url.setHost(address)
        url.setPort(port)
        url.setPath('/api/')
        if self.names == names and self.url == url:
            return
        self.close()
        self.names, self.url = dict(names), url
        if names:
            self.timer.start()
            self._refresh()

    def close(self):
        self.timer.stop()
        self.names = {}
        self.pending.clear()
        self.missing.clear()
        self.errors.clear()
        reply, self.reply = self.reply, None
        if reply is not None:
            reply.abort()

    def _refresh(self):
        if self.reply is None and self.names:
            self._request()

    def _request(self, key=None, name=None):
        url = QUrl(self.url)
        if key:
            url.setQuery(urlencode({'Function': 'SetInputName', 'Input': key, 'Value': name}))
        request = QNetworkRequest(url)
        request.setTransferTimeout(REQUEST_TIMEOUT_MS)
        request.setAttribute(QNetworkRequest.Attribute.RedirectPolicyAttribute,
                             QNetworkRequest.RedirectPolicy.ManualRedirectPolicy)
        reply = self.network.get(request)
        self.reply = reply
        reply.finished.connect(lambda: self._finished(reply, key))

    def _finished(self, reply, key):
        reply.deleteLater()
        if reply is not self.reply:
            return
        self.reply = None
        code = reply.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute)
        if code != 200 or reply.error() != QNetworkReply.NetworkError.NoError:
            reason = reply.errorString()
            if key is None:
                self.status.emit(f'Названия входов vMix: {reason}')
                return
            self.errors.append(reason)
        elif key is None:
            try:
                state = ElementTree.fromstring(bytes(reply.readAll()))
                if state.tag != 'vmix':
                    raise ValueError
            except (ElementTree.ParseError, ValueError):
                self.status.emit('Названия входов: проверьте адрес vMix Web Controller.')
                return
            inputs = state.findall('./inputs/input')
            self.pending.clear()
            self.missing.clear()
            self.errors.clear()
            for number, name in self.names.items():
                entry = _resolve_input(inputs, str(number))
                guid = _guid(entry.get('key')) if entry is not None else None
                if not guid:
                    self.missing.append(str(number))
                elif name not in (entry.get('shortTitle'), entry.get('title')):
                    self.pending.append((guid, name))
        if self.pending:
            self._request(*self.pending.pop(0))
        elif self.errors:
            self.status.emit(f'Не удалось переименовать входы ({len(self.errors)}): {self.errors[0]}')
        elif self.missing:
            self.status.emit('В vMix не найдены входы: ' + ', '.join(self.missing))
        else:
            self.status.emit(f'Названия входов vMix синхронизированы: {len(self.names)}.')


class VmixProgram(QObject):
    """Serialize Program writes and let a newer camera choice supersede queued writes."""
    status = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.network = QNetworkAccessManager(self)
        self.network.setProxy(QNetworkProxy(QNetworkProxy.ProxyType.NoProxy))
        self.reply = None
        self.url = QUrl()
        self.desired = None
        self.pending = []

    def configure(self, address, port):
        self.cancel()
        self.url = QUrl()
        self.url.setScheme('http')
        self.url.setHost(address)
        self.url.setPort(port)
        self.url.setPath('/api/')

    def cancel(self):
        self.desired = None
        self.pending.clear()
        reply, self.reply = self.reply, None
        if reply is not None:
            reply.abort()

    def select(self, targets):
        """Each target is a (Mix number in vMix, input number) pair."""
        if not targets:
            self.cancel()
            return
        self.desired = tuple(targets)
        if self.reply is None:
            self._start()

    def _start(self):
        self.pending.clear()
        self._send(self.desired)

    def _send(self, targets, mix=None, guid=None):
        url = QUrl(self.url)
        if mix is not None:
            url.setQuery(urlencode({'Function': 'ActiveInput', 'Input': guid, 'Mix': mix - 1}))
        request = QNetworkRequest(url)
        request.setTransferTimeout(REQUEST_TIMEOUT_MS)
        request.setAttribute(QNetworkRequest.Attribute.RedirectPolicyAttribute,
                             QNetworkRequest.RedirectPolicy.ManualRedirectPolicy)
        reply = self.network.get(request)
        self.reply = reply
        reply.finished.connect(lambda: self._finished(reply, targets, mix))

    def _finished(self, reply, targets, mix):
        reply.deleteLater()
        if self.reply is not reply:
            return
        self.reply = None
        if targets != self.desired:
            self._start()
            return
        if reply.error() != QNetworkReply.NetworkError.NoError or reply.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute) != 200:
            self.pending.clear()
            self.status.emit(f'Ошибка vMix{f" Mix {mix}" if mix else ""}: {reply.errorString()}')
            return
        if mix is None:
            try:
                state = ElementTree.fromstring(bytes(reply.readAll()))
            except ElementTree.ParseError:
                self.status.emit('Web Controller вернул некорректный XML.')
                return
            inputs = state.findall('./inputs/input')
            available = {entry.get('number') for entry in state.findall('./mix')}
            for destination, number in targets:
                source = _resolve_input(inputs, str(number))
                guid = _guid(source.get('key')) if source is not None else None
                if state.tag != 'vmix' or not guid or (destination != 1 and str(destination) not in available):
                    self.pending.clear()
                    self.status.emit(f'Проверьте наличие входа {number} и Mix {destination} в vMix.')
                    return
                self.pending.append((destination, guid))
        if self.pending:
            self._send(targets, *self.pending.pop(0))
        else:
            self.status.emit('Program: ' + ', '.join(f'Mix {m} ← вход {n}' for m, n in targets))
