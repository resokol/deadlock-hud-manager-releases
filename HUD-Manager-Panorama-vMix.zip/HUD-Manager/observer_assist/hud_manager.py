"""Desktop entry point for Deadlock and its optional observer module."""

import sys
from pathlib import Path
from time import monotonic

from PySide6.QtCore import QSettings, QSignalBlocker, QStandardPaths, QTimer, Qt
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (
    QApplication, QBoxLayout, QButtonGroup, QCheckBox, QComboBox, QFormLayout, QFrame, QGroupBox, QHBoxLayout,
    QLabel, QPushButton, QScrollArea, QSpinBox, QStackedWidget, QVBoxLayout, QWidget,
)

from . import steam
from .__main__ import create_panel
from .hud_desktop import DesktopHud
from .hud_kda import BroadcastKda
from .hud_library import HudLibrary
from .hud_packages import HudPackages
from .hud_positions import PanoramaPositions
from .hud_pov import VmixPovPanel
from .hud_switch_delay import SpectatorSwitchDelay, with_spectator_fields
from .live_stats_panel import LiveStatsPanel
from .minimap_local import LocalMinimapOverlay
from .native_hud_config import NATIVE_HUD_ELEMENTS, normalize_native_hud_options
from .panorama_health import PanoramaHealthLog
from .panorama_hud_mode import PanoramaTelemetryServer
from .source_tv_panel import SourceTvPanel
from .ui import STYLE
from .win32 import set_dpi_awareness


class HudManager(QWidget):
    def __init__(self, settings=None, hud_directory=None, *, release=None):
        super().__init__()
        self.settings = settings if settings is not None else QSettings('DeadlockHUDManager', 'DeadlockHUDManager')
        self.observer_panel = None
        self._restore_after_capture = False
        self._health_log = None
        self._telemetry = None
        self._broadcast_kda = BroadcastKda(self)
        self._hud_switches = SpectatorSwitchDelay()
        self._desktop_hud = None
        self._local_minimap = None
        self._studio = None
        data_home = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.GenericDataLocation)
        self.hud_packages = HudPackages(hud_directory if hud_directory is not None else
                                        Path(data_home) / 'DeadlockHUDManager' / 'HUDs')
        self._health_timer = QTimer(self, timerType=Qt.TimerType.PreciseTimer)
        self._health_timer.timeout.connect(self._poll_panorama_health)
        self.setWindowTitle('Deadlock HUD Manager')
        self.setMinimumSize(600, 370)
        self.setStyleSheet(STYLE + '''
QWidget#workspace, QScrollArea#workspace { background: #171D22; }
QWidget#rail, QPushButton#section { background: #12181D; }
QPushButton#section { border: 1px solid transparent; text-align: left; padding: 10px 12px; }
QPushButton#section:hover { background: #232E36; }
QPushButton#section:checked { background: #25363B; color: #C0F4EC; border-color: #456460; }
QPushButton#section:focus { border-color: #89DDD5; }
QLabel#workspaceHeading { font-size: 19pt; font-weight: 600; }
QLabel#appName { font-size: 14pt; font-weight: 600; }
QScrollBar:vertical { background: #12181D; width: 10px; }
QScrollBar::handle:vertical { background: #52656C; border-radius: 4px; min-height: 24px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: transparent; }
QCheckBox::indicator { width: 14px; height: 14px; }
QCheckBox::indicator:unchecked { border: 1px solid #70828D; border-radius: 3px; background: #101519; }
''')

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 14, 18, 14)
        layout.setSpacing(12)
        header = QHBoxLayout()
        title = QLabel('Deadlock HUD Manager')
        title.setObjectName('appName')
        header.addWidget(title)
        header.addStretch()
        if release:
            from .release_ui import ReleaseControls

            config, expiry, activation = release
            header.addWidget(ReleaseControls(config, expiry, self, activation))
        self.launch_button = QPushButton('Запустить Deadlock')
        self.launch_button.setObjectName('primary')
        self.launch_button.clicked.connect(self._launch)
        header.addWidget(self.launch_button)
        layout.addLayout(header)

        self._workspace = QBoxLayout(QBoxLayout.Direction.LeftToRight)
        self._workspace.setSpacing(14)
        layout.addLayout(self._workspace, 1)
        self._rail = QWidget()
        self._rail.setObjectName('rail')
        self._navigation = QBoxLayout(QBoxLayout.Direction.TopToBottom, self._rail)
        self._navigation.setContentsMargins(6, 6, 6, 6)
        self._navigation.setSpacing(4)
        self._workspace.addWidget(self._rail)
        self.sections = QStackedWidget()
        self._workspace.addWidget(self.sections, 1)
        self._sections = QButtonGroup(self)
        self._sections.idClicked.connect(self.sections.setCurrentIndex)

        launch_group = QGroupBox('Запуск игры')
        launch_layout = QVBoxLayout(launch_group)
        self.selective_hud = QCheckBox('Оставлять только миникарту при запуске')
        self.selective_hud.setChecked(self.settings.value('selectiveHud', False, type=bool))
        self.selective_hud.toggled.connect(self._save_hud_mode)
        launch_layout.addWidget(self.selective_hud)
        hint = QLabel('Фильтр Panorama применяется после появления миникарты в режиме наблюдателя.')
        hint.setObjectName('subtle')
        hint.setWordWrap(True)
        launch_layout.addWidget(hint)

        self.source_tv = SourceTvPanel(self)
        match_group = QGroupBox('Текущий матч')
        match_layout = QVBoxLayout(match_group)
        self.current_match_id = QLabel('ID матча —')
        self.current_match_id.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        match_layout.addWidget(self.current_match_id)
        match_layout.addWidget(self.source_tv.connection)
        self.source_tv.hide()
        match_layout.addWidget(self.source_tv)

        series = QGroupBox('Серия матчей')
        series_layout = QVBoxLayout(series)
        controls = QHBoxLayout()
        self.series_best_of = QComboBox()
        for games in range(1, 10):
            self.series_best_of.addItem(f'BO{games}', games)
        self.series_best_of.setCurrentIndex(self.series_best_of.findData(
            self.settings.value('seriesBestOf', 1, type=int)))
        self.series_left_wins = QSpinBox()
        self.series_right_wins = QSpinBox()
        for control, caption, key in (
            (self.series_best_of, 'Формат', None),
            (self.series_left_wins, 'Победы слева', 'seriesLeftWins'),
            (self.series_right_wins, 'Победы справа', 'seriesRightWins'),
        ):
            field = QVBoxLayout()
            label = QLabel(caption)
            label.setBuddy(control)
            field.addWidget(label)
            field.addWidget(control)
            controls.addLayout(field)
            if key:
                control.setValue(self.settings.value(key, 0, type=int))
                control.valueChanged.connect(self._change_series)
        series_layout.addLayout(controls)
        match_layout.addWidget(series)
        self.series_best_of.currentIndexChanged.connect(self._change_series)
        self._change_series()

        overview = QWidget()
        self._overview = QBoxLayout(QBoxLayout.Direction.LeftToRight, overview)
        self._overview.setContentsMargins(0, 0, 0, 0)
        self._overview.setSpacing(14)
        self._overview.setAlignment(Qt.AlignmentFlag.AlignTop)
        self._overview.addWidget(match_group, 3, Qt.AlignmentFlag.AlignTop)
        self._overview.addWidget(launch_group, 2, Qt.AlignmentFlag.AlignTop)

        self.pov = VmixPovPanel(self.settings)
        self.positions = PanoramaPositions(self.settings)
        self.positions.slots_changed.connect(self.pov.set_hud_slots)
        self.positions.local_requested.connect(lambda: self.panorama_enabled.setChecked(True))
        self.source_tv.roster_changed.connect(self._update_match_roster)
        self.pov.mappings_changed.connect(self._update_match_roster)
        self.pov.video_changed.connect(self._change_pov_source)

        self.hud_library = HudLibrary(self.hud_packages, self.settings, self._start_overlay_server)
        self.hud_library.desktop_overlay.toggled.connect(self._toggle_desktop_hud)
        self.hud_library.desktop_monitor_changed.connect(self._change_desktop_monitor)
        self.hud_library.studio_requested.connect(self._open_studio)
        self.live_stats = LiveStatsPanel(self.settings, self._start_overlay_server)

        modules = QGroupBox('Модули')
        modules_layout = QVBoxLayout(modules)
        self.observer_enabled = QCheckBox('Deadlock Observer Assist')
        self.observer_enabled.toggled.connect(self._toggle_observer)
        modules_layout.addWidget(self.observer_enabled)
        self.source_tv_enabled = QCheckBox('Данные SourceTV')
        self.source_tv_enabled.toggled.connect(self._toggle_source_tv)
        self.source_tv.connection_requested.connect(self.source_tv_enabled.setChecked)
        modules_layout.addWidget(self.source_tv_enabled)
        self.panorama_enabled = QCheckBox('Данные Panorama')
        self.panorama_enabled.toggled.connect(self._toggle_panorama_health)
        modules_layout.addWidget(self.panorama_enabled)
        self.panorama_status = QLabel()
        self.panorama_status.setTextFormat(Qt.TextFormat.PlainText)
        self.panorama_status.setWordWrap(True)
        self.panorama_status.hide()
        modules_layout.addWidget(self.panorama_status)

        self.minimap_numbers = QComboBox()
        for text, mode in [('Выкл.', 'off'), ('Поверх портретов', 'overlay'), ('Вместо портретов', 'replace')]:
            self.minimap_numbers.addItem(text, mode)
        mode_index = self.minimap_numbers.findData(self.settings.value('minimapNumbers', 'off'))
        self.minimap_numbers.setCurrentIndex(max(0, mode_index))
        self.minimap_numbers.currentIndexChanged.connect(self._save_minimap_numbers)
        numbers_label = QLabel('Клавиши игроков на миникарте')
        numbers_label.setBuddy(self.minimap_numbers)
        modules_layout.addWidget(numbers_label)
        modules_layout.addWidget(self.minimap_numbers)
        self.minimap_for_observer = QCheckBox('Показывать локальные метки наблюдателю')
        self.minimap_for_observer.setChecked(self.settings.value('minimapForObserver', True, type=bool))
        self.minimap_for_observer.setEnabled(self.minimap_numbers.currentData() != 'off')
        self.minimap_for_observer.toggled.connect(self._save_minimap_observer)
        modules_layout.addWidget(self.minimap_for_observer)
        self.minimap_in_broadcast = QCheckBox('Показывать метки в трансляции')
        self.minimap_in_broadcast.setChecked(self.settings.value('minimapInBroadcast', True, type=bool))
        self.minimap_in_broadcast.setEnabled(self.minimap_numbers.currentData() != 'off')
        self.minimap_in_broadcast.toggled.connect(self._save_minimap_broadcast)
        modules_layout.addWidget(self.minimap_in_broadcast)
        self.minimap_numbers_hint = QLabel(
            'Локальные метки можно включать и выключать во время матча. '
            'Чтобы изменить видимость меток в трансляции, перезапустите Deadlock через менеджер. '
            'Чтобы отключить метки, которые рисует игра, выберите «Выкл.» перед перезапуском. '
            'В начале матча выберите каждого игрока один раз.'
        )
        self.minimap_numbers_hint.setObjectName('subtle')
        self.minimap_numbers_hint.setWordWrap(True)
        self.minimap_numbers_hint.setVisible(self.minimap_numbers.currentData() != 'off')
        modules_layout.addWidget(self.minimap_numbers_hint)
        self.minimap_status = QLabel()
        self.minimap_status.setTextFormat(Qt.TextFormat.PlainText)
        self.minimap_status.setWordWrap(True)
        self.minimap_status.hide()
        modules_layout.addWidget(self.minimap_status)
        modules_layout.addWidget(self._native_hud_controls())
        for section, panel in (('Матч', overview), ('HUD', self.hud_library),
                               ('POV vMix', self.pov), ('Статистика', self.live_stats), ('Модули', modules),
                               ('Позиции Panorama', self.positions)):
            self._add_section(section, panel)
        self._sections.button(0).setChecked(True)

        self.status = QLabel()
        self.status.setObjectName('subtle')
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.status.hide()
        available = self.screen().availableGeometry()
        self.resize(min(1070, max(600, available.width() - 48)),
                    min(620, max(370, available.height() - 64)))
        self._arrange_workspace(self.width())
        self.panorama_enabled.setChecked(self.settings.value('panoramaEnabled', False, type=bool))
        if not self.panorama_enabled.isChecked():
            self._start_panorama_log()
        self.hud_library.desktop_overlay.setChecked(self.settings.value('desktopHudEnabled', False, type=bool))

    def _start_overlay_server(self):
        if self._telemetry is None:
            self._telemetry = PanoramaTelemetryServer(packages=self.hud_packages)
            self._telemetry.set_pov_source(*self.pov.source)
            self._update_match_roster()
            self._telemetry.set_player_aliases(self.hud_library.player_aliases)
            self._telemetry.set_series(*self._series)
        return self._telemetry

    def _update_match_roster(self):
        roster = self.source_tv.roster
        self._refresh_match_id()
        self.pov.set_match_roster(roster)
        if self._telemetry:
            self._telemetry.set_match_roster(roster, self.pov.camera_inputs)

    def _refresh_match_id(self):
        roster = self.source_tv.roster or {}
        match_id = roster.get('matchId') or (self._health_log.match_id if self._health_log else None)
        match_text = f'ID матча {match_id or "—"}'
        if self.current_match_id.text() != match_text:
            self.current_match_id.setText(match_text)

    def _change_series(self):
        best_of = self.series_best_of.currentData() or 1
        maximum = best_of // 2 + 1
        left = min(self.series_left_wins.value(), maximum)
        right = min(self.series_right_wins.value(), maximum, best_of - left)
        with QSignalBlocker(self.series_left_wins), QSignalBlocker(self.series_right_wins):
            self.series_left_wins.setMaximum(min(maximum, best_of - right))
            self.series_right_wins.setMaximum(min(maximum, best_of - left))
            self.series_left_wins.setValue(left)
            self.series_right_wins.setValue(right)
        self._series = best_of, left, right
        for key, value in zip(('seriesBestOf', 'seriesLeftWins', 'seriesRightWins'), self._series):
            self.settings.setValue(key, value)
        if self._telemetry:
            self._telemetry.set_series(*self._series)

    def _native_hud_controls(self):
        group = QGroupBox('Штатный HUD Deadlock')
        layout = QFormLayout(group)
        self.minimap_background = QCheckBox('Показывать фон миникарты')
        self.minimap_background.setChecked(self.settings.value('nativeHud/minimapBackground', True, type=bool))
        self.minimap_background.toggled.connect(
            lambda visible: self.settings.setValue('nativeHud/minimapBackground', visible))
        layout.addRow(self.minimap_background)
        self.native_hud_elements = {}
        captions = (
            'Миникарта', 'Верхняя панель', 'Здоровье', 'Способности', 'Предметы', 'Статистика',
            'Лента событий', 'Управление наблюдателя', 'Объявления', 'Чат',
        )
        for element, title in zip(NATIVE_HUD_ELEMENTS, captions):
            control = QComboBox()
            key = f'nativeHud/{element}'
            for label, value in (('По умолчанию', None), ('Показать', True), ('Скрыть', False)):
                control.addItem(label, value)
            control.setCurrentIndex(min(2, max(0, self.settings.value(key, 0, type=int))))
            control.currentIndexChanged.connect(lambda index, path=key: self.settings.setValue(path, index))
            self.native_hud_elements[element] = control
            layout.addRow(title, control)
        hint = QLabel('Применяется при следующем запуске Deadlock через менеджер.')
        hint.setWordWrap(True)
        layout.addRow(hint)
        return group

    def _change_pov_source(self, url, media_format):
        if self._telemetry:
            self._telemetry.set_pov_source(url, media_format)

    def _add_section(self, title, panel):
        scroll = QScrollArea()
        scroll.setObjectName('workspace')
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setWidgetResizable(True)
        content = QWidget()
        content.setObjectName('workspace')
        layout = QVBoxLayout(content)
        layout.setContentsMargins(6, 4, 10, 10)
        heading = QLabel(title)
        heading.setObjectName('workspaceHeading')
        layout.addWidget(heading)
        layout.addWidget(panel)
        layout.addStretch()
        scroll.setWidget(content)
        index = self.sections.addWidget(scroll)
        button = QPushButton(title)
        button.setObjectName('section')
        button.setCheckable(True)
        self._sections.addButton(button, index)
        self._navigation.addWidget(button)

    def _arrange_workspace(self, width):
        wide = width >= 850
        self._workspace.setDirection(QBoxLayout.Direction.LeftToRight if wide else QBoxLayout.Direction.TopToBottom)
        self._navigation.setDirection(QBoxLayout.Direction.TopToBottom if wide else QBoxLayout.Direction.LeftToRight)
        self._overview.setDirection(QBoxLayout.Direction.LeftToRight if width >= 950 else QBoxLayout.Direction.TopToBottom)
        self._rail.setMaximumWidth(174 if wide else 16777215)
        self._rail.setMinimumWidth(164 if wide else 0)
        self._navigation.setAlignment(Qt.AlignmentFlag.AlignTop if wide else Qt.AlignmentFlag.AlignLeft)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, '_overview'):
            self._arrange_workspace(event.size().width())

    def _open_studio(self, package_id):
        if self._studio and not self._studio.close():
            return
        package = self.hud_packages.get(package_id) if package_id else None
        try:
            if package and not package.built_in and 'studio.json' not in package.files:
                from .hud_source_editor import PackageSourceEditor

                self._studio = PackageSourceEditor(self.hud_library, package_id, self)
            else:
                from .hud_editor import HudEditor

                self._studio = HudEditor(self._start_overlay_server().url, self.hud_library, package_id, self,
                                         pov_navigation=self.pov.allows_video_navigation)
        except (OSError, RuntimeError, ValueError) as exc:
            self.hud_library.show_message(f'Не удалось открыть редактор. {exc}')
            return
        self._studio.finished.connect(self._studio_closed)
        self._studio.show()

    def _studio_closed(self):
        self._studio = None

    def _save_hud_mode(self, enabled):
        self.settings.setValue('selectiveHud', enabled)

    def _save_minimap_numbers(self):
        mode = self.minimap_numbers.currentData()
        self.settings.setValue('minimapNumbers', mode)
        self.minimap_numbers_hint.setVisible(mode != 'off')
        self.minimap_for_observer.setEnabled(mode != 'off')
        self.minimap_in_broadcast.setEnabled(mode != 'off')
        self._start_panorama_log()

    def _save_minimap_observer(self, enabled):
        self.settings.setValue('minimapForObserver', enabled)
        self._refresh_local_minimap()

    def _save_minimap_broadcast(self, enabled):
        self.settings.setValue('minimapInBroadcast', enabled)

    def _toggle_desktop_hud(self, enabled):
        if enabled:
            try:
                self._desktop_hud = DesktopHud(self._start_overlay_server().url, self,
                                               pov_navigation=self.pov.allows_video_navigation,
                                               monitor_id=self.hud_library.desktop_monitor.currentData() or '')
                self._desktop_hud.start()
            except (OSError, RuntimeError, ValueError) as exc:
                self.hud_library.desktop_overlay.setChecked(False)
                self.hud_library.show_message(f'Не удалось открыть оверлей. {exc}')
                return
        else:
            self._close_desktop_hud()
        self.settings.setValue('desktopHudEnabled', enabled)

    def _change_desktop_monitor(self, monitor):
        if self._desktop_hud is not None:
            self._desktop_hud.set_monitor(monitor)

    def _close_desktop_hud(self):
        if self._desktop_hud is not None:
            self._desktop_hud.close()
            self._desktop_hud = None

    def _launch(self):
        self.status.show()
        selective = self.selective_hud.isChecked()
        options = {}
        if self.panorama_enabled.isChecked():
            options['panorama_health'] = True
        number_mode = self.minimap_numbers.currentData()
        if number_mode != 'off':
            options['minimap_numbers'] = number_mode if self.minimap_in_broadcast.isChecked() else 'local'
        native = {
            'minimapBackground': self.minimap_background.isChecked(),
            'elements': {name: control.currentData() for name, control in self.native_hud_elements.items()
                         if control.currentIndex()},
        }
        active = self.hud_packages.active()
        if active and active['id'] == 'battle-report':
            colors = self.hud_packages.settings(active['id']) or {}
            if colors.get('leftColor') and colors.get('rightColor'):
                native['minimapTeamColors'] = {'left': colors['leftColor'], 'right': colors['rightColor']}
        try:
            native_options = normalize_native_hud_options(native)
            if native_options is not None:
                options['native_hud'] = native_options
            steam.launch_deadlock(selective, **options)
        except (OSError, RuntimeError, ValueError) as exc:
            self.status.setText(f'Ошибка запуска: {exc}')
            return

        if selective:
            self.status.setText('Запуск передан Steam. Фильтр Panorama ждёт миникарту в режиме наблюдателя.')
        else:
            self.status.setText('Команда обычного запуска отправлена в Steam.')

    def _toggle_observer(self, enabled):
        if enabled:
            panel = create_panel()
            panel.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
            panel.closed.connect(self._observer_closed)
            panel.capture_started.connect(self._observer_capture_started)
            panel.capture_finished.connect(self._restore_after_observer_capture)
            self.observer_panel = panel
            panel.show()
        elif self.observer_panel is not None:
            self.observer_panel.close()

    def _observer_closed(self):
        self.observer_panel = None
        self.observer_enabled.setChecked(False)
        self._restore_after_observer_capture()

    def _observer_capture_started(self):
        if self.isVisible() and not self.isMinimized():
            self._restore_after_capture = True
            self.hide()

    def _restore_after_observer_capture(self):
        if self._restore_after_capture:
            self._restore_after_capture = False
            self.show()

    def _toggle_source_tv(self, enabled):
        self.source_tv.setVisible(enabled)
        if enabled:
            if self.source_tv.url.isVisible():
                self.source_tv.url.setFocus()
        else:
            self.source_tv.stop()

    def _toggle_panorama_health(self, enabled):
        self.settings.setValue('panoramaEnabled', enabled)
        self.panorama_status.setVisible(enabled)
        if not enabled:
            self._broadcast_kda.update(None, None)
            self._hud_switches.update(None, None, self.pov.hud_delay_ms)
            self.positions.observe(None)
            self.pov.observe(None)
            if self._telemetry:
                self._telemetry.telemetry = None
        self._start_panorama_log()

    def _start_panorama_log(self):
        enabled = self.panorama_enabled.isChecked()
        if sys.platform != 'win32':
            self.panorama_status.setText('Чтение данных установленного Deadlock доступно в Windows.')
            return
        try:
            if self._health_log is None:
                self._health_log = PanoramaHealthLog(steam.find_deadlock_citadel() / 'console.log')
            if enabled:
                self._start_overlay_server()
        except (OSError, RuntimeError, ValueError) as exc:
            self.panorama_status.setText(str(exc))
            return
        self._poll_panorama_health()
        minimap = self.minimap_numbers.currentData() != 'off'
        self._health_timer.start(20 if enabled else 50 if minimap else 500)

    def _poll_panorama_health(self):
        enabled = self.panorama_enabled.isChecked()
        number_mode = self.minimap_numbers.currentData()
        sample = self._health_log.poll(include_telemetry=enabled, include_minimap=number_mode != 'off')
        match_id = self._health_log.match_id
        telemetry = None
        if enabled:
            broadcast = self._health_log.broadcast_url
            telemetry = self._broadcast_kda.update(broadcast, self._health_log.telemetry())
            match = match_id, broadcast
            now = monotonic()
            delay = self.pov.hud_delay_ms
            fields = self._hud_switches.update(telemetry, match, delay, now=now)
            if self._telemetry:
                if delay:
                    self._telemetry.publish(telemetry, broadcast, hud_value=with_spectator_fields(telemetry, fields),
                                            match_id=match_id)
                else:
                    self._telemetry.publish(telemetry, broadcast, match_id=match_id)
            self.positions.observe(telemetry)
            self.pov.observe(telemetry, match, roster=self._health_log.match_roster, now=now)
        self._refresh_local_minimap()
        self._refresh_match_id()
        if not enabled:
            return
        if sample is None:
            self.panorama_status.setText('Жду данные Panorama. Откройте матч в режиме наблюдателя и выберите игрока.')
            return
        player, hp, maximum = sample
        description = f'Panorama · {player} · {hp} / {maximum} HP'
        if telemetry and telemetry.get('gameClock'):
            description += f' · {telemetry["gameClock"]}'
        self.panorama_status.setText(description)

    def _refresh_local_minimap(self):
        mode = self.minimap_numbers.currentData()
        markers = ()
        if self._health_log is not None and mode != 'off' and self.minimap_for_observer.isChecked():
            markers = self._health_log.minimap_markers()
        message = ''
        try:
            if markers and self._local_minimap is None:
                self._local_minimap = LocalMinimapOverlay()
            if self._local_minimap is not None and not self._local_minimap.display(markers, mode):
                message = 'Windows не подтвердил исключение меток из захвата. Локальные метки скрыты.'
        except (OSError, RuntimeError) as exc:
            if self._local_minimap is not None:
                self._local_minimap.clear()
            message = f'Не удалось открыть локальные метки миникарты. {exc}'
        if message != self.minimap_status.text():
            self.minimap_status.setText(message)
            self.minimap_status.setVisible(bool(message))

    def closeEvent(self, event):
        if self._studio and not self._studio.close():
            event.ignore()
            return
        self._restore_after_capture = False
        self.observer_enabled.setChecked(False)
        self.source_tv_enabled.setChecked(False)
        self._close_desktop_hud()
        if self._local_minimap is not None:
            self._local_minimap.close()
        self.live_stats.stop()
        self._health_timer.stop()
        self.positions.stop()
        self.pov.shutdown()
        self._broadcast_kda.close()
        if self._telemetry:
            self._telemetry.close()
            self._telemetry = None
        self.source_tv.process.waitForFinished(1500)
        self.settings.sync()
        super().closeEvent(event)


def main():
    set_dpi_awareness()
    app = QApplication(sys.argv[:1])
    app.setWindowIcon(QIcon(str(Path(__file__).with_name('assets') / 'dhm.ico')))
    settings = QSettings('DeadlockHUDManager', 'DeadlockHUDManager')
    release = None
    if getattr(sys, 'frozen', False):
        from PySide6.QtWidgets import QMessageBox

        from .release_ui import activate, release_config

        activation = None
        try:
            config = release_config()
            if config.get('activation'):
                from .activation_ui import ActivationAccess

                activation = ActivationAccess(config, settings)
        except (ImportError, OSError, ValueError) as exc:
            QMessageBox.critical(None, 'Deadlock HUD Manager', f'Конфигурация выпуска недоступна. {exc}')
            return 1
        if activation:
            if not activation.usable and not activation.open_dialog():
                return 0
            expiry = activation.record['until']
        else:
            expiry = activate(config, settings)
        if expiry is None:
            return 0
        release = config, expiry, activation
    window = HudManager(settings, release=release)
    try:
        window._start_overlay_server()
    except (OSError, ValueError) as exc:
        window.hud_library.show_message(f'Сервер HUD недоступен. {exc}')
    window.show()
    return app.exec()


if __name__ == '__main__':
    raise SystemExit(main())
