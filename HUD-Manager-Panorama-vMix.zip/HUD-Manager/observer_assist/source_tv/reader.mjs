import { Readable } from 'node:stream';
import { setTimeout as sleep } from 'node:timers/promises';
import { DemoSource, InterceptorStage, Logger, MessagePacketType, Parser, ParserConfiguration } from '@deademx/deadlock';
import { MatchEvents } from './match_events.mjs';

const emit = record => process.stdout.write(`${JSON.stringify(record)}\n`);

function broadcastUrl(input) {
    const url = new URL(input);
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) {
        throw new Error('Ожидается HTTP(S) URL трансляции SourceTV.');
    }
    url.pathname = url.pathname.replace(/\/(?:sync)?$/, '').replace(/\/+$/, '');
    url.hash = '';
    return url;
}

async function resolveBroadcast(input) {
    if (!/^\d{1,20}$/.test(input)) return broadcastUrl(input);
    const api = 'https://api.deadlock-api.com/v1/matches';
    try {
        const response = await fetch(`${api}/live/urls?match_ids=${input}`, { signal: AbortSignal.timeout(2500) });
        if (response.ok) {
            const entries = await response.json();
            const stored = entries.find(entry => String(entry.match_id) === input)?.broadcast_url;
            if (stored) return broadcastUrl(stored);
        }
    } catch {
        // The cached list can be unavailable even when match lookup succeeds.
    }
    const response = await fetch(`${api}/${input}/live/url`, { signal: AbortSignal.timeout(9000) });
    if (response.status === 429) {
        throw new Error('Deadlock API ограничил частоту запросов. Можно вставить готовый URL трансляции.');
    }
    if (response.status === 404) {
        throw new Error(`Для матча ${input} пока нет трансляции SourceTV.`);
    }
    if (!response.ok) throw new Error(`Deadlock API: HTTP ${response.status}.`);
    const { broadcast_url: url } = await response.json();
    if (!url) throw new Error(`Deadlock API не вернул адрес трансляции матча ${input}.`);
    return broadcastUrl(url);
}

async function request(base, path, asJson = false, fragment = null) {
    const url = new URL(base);
    url.pathname += `/${path}`;
    if (fragment !== null) url.searchParams.set('fragment', fragment);
    const response = await fetch(url, { signal: AbortSignal.timeout(5000) });
    if (!response.ok) {
        await response.body?.cancel();
        const error = new Error(`SourceTV: HTTP ${response.status} (${path}).`);
        error.status = response.status;
        throw error;
    }
    return asJson ? response.json() : new Uint8Array(await response.arrayBuffer());
}

async function readSync(base, fragment = null) {
    const sync = await request(base, 'sync', true, fragment);
    if (!Number.isSafeInteger(sync.fragment) || sync.fragment < 0 ||
        !Number.isSafeInteger(sync.signup_fragment) || sync.signup_fragment < 0 ||
        !Number.isFinite(sync.tps) || sync.tps <= 0) {
        throw new Error('В ответе /sync нет корректных номеров сегментов или частоты тиков.');
    }
    return sync;
}

async function waitForSync(base) {
    const started = performance.now();
    for (;;) {
        try {
            return await readSync(base);
        } catch (error) {
            if (error.status !== 404 || performance.now() - started >= 20000) throw error;
            await sleep(1000);
        }
    }
}

function reportSync(sync) {
    const lag = (sync.maxtick - sync.endtick) / sync.tps;
    emit({
        type: 'sync',
        delaySeconds: Number.isFinite(sync.rtdelay) ? sync.rtdelay : null,
        segmentLagSeconds: Number.isFinite(lag) && lag >= 0 && sync.endtick > sync.tick ? lag : null,
        fragmentSeconds: Number.isFinite(sync.keyframe_interval) ? sync.keyframe_interval : null,
        fragment: sync.fragment,
    });
}

async function selectStart(base, relay) {
    const ticksPerFragment = relay.tps * relay.keyframe_interval;
    const ahead = Math.floor((relay.maxtick - relay.endtick) / ticksPerFragment);
    if (ticksPerFragment > 0 && Number.isFinite(ahead) && ahead > 0) {
        const newest = relay.fragment + Math.min(ahead, 12);
        for (let fragment = newest; fragment > relay.fragment && fragment > newest - 3; fragment -= 1) {
            try {
                const sync = await readSync(base, fragment);
                if (sync.fragment !== fragment) break;
                const full = await request(base, `${fragment}/full`);
                return { sync, full };
            } catch (error) {
                if (error.status !== 404 && error.status !== 405) break;
            }
        }
    }
    return { sync: relay, full: null };
}

async function readFragment(base, path) {
    for (let attempts = 0; ; attempts += 1) {
        try {
            return await request(base, path);
        } catch (error) {
            if (error.status !== 404 || attempts >= 3) throw error;
            await sleep(700);
        }
    }
}

function readLoadout(demo, hero) {
    const handles = hero?.getField('m_CCitadelAbilityComponent.m_vecAbilities');
    if (!Array.isArray(handles)) return null;
    return handles.flatMap(handle => {
        const ability = Number.isInteger(handle) ? demo.getEntityByHandle(handle) : null;
        const id = ability?.getField('m_nSubclassID');
        const raw = ability?.getField('m_eAbilitySlot');
        if (!Number.isInteger(id) || id <= 0 || !Number.isInteger(raw) || raw < 0) return [];
        // The pinned parser reads this signed varint as an unsigned value.
        return [{ id: id >>> 0, slot: (raw >>> 1) ^ -(raw & 1) }];
    });
}

function accountId(controller) {
    const account = controller.getField('m_unEconAccountID');
    if (Number.isSafeInteger(account) && account > 0 && account <= 0xffffffff) return account;
    const steamId = controller.getField('m_steamID');
    if (typeof steamId !== 'bigint' && typeof steamId !== 'string') return null;
    if (!/^\d{17}$/.test(String(steamId))) return null;
    const id = BigInt(steamId) - 76561197960265728n;
    return id > 0n && id <= 0xffffffffn ? Number(id) : null;
}

function readPlayers(demo, streaks, events) {
    return demo.getEntitiesByClassName('CCitadelPlayerController').flatMap(controller => {
        const team = controller.getField('m_iTeamNum');
        if (team !== 2 && team !== 3) return [];
        const handle = controller.getField('m_hHeroPawn');
        const hero = Number.isInteger(handle) ? demo.getEntityByHandle(handle) : null;
        const stats = key => controller.getField(`m_PlayerDataGlobal.${key}`) ?? null;
        const killStreak = stats('m_iKillStreak');
        return [{
            team,
            name: controller.getField('m_iszPlayerName') || '',
            heroId: stats('m_nHeroID'),
            heroDamage: stats('m_iHeroDamage'),
            rank: stats('m_unPackedRank'),
            lane: controller.getField('m_nOriginalLaneAssignment') ?? null,
            accountId: accountId(controller),
            kills: stats('m_iPlayerKills'),
            deaths: stats('m_iDeaths'),
            assists: stats('m_iPlayerAssists'),
            killStreak: Number.isSafeInteger(killStreak) && killStreak >= 0 ? killStreak : streaks.get(handle) ?? null,
            netWorth: stats('m_iGoldNetWorth'),
            health: hero?.getField('m_iHealth') ?? stats('m_iHealth'),
            maxHealth: hero?.getField('m_iMaxHealth') ?? stats('m_iHealthMax'),
            loadout: readLoadout(demo, hero),
            purchaseHistory: events.purchasesFor(controller),
        }];
    }).sort((left, right) => left.team - right.team);
}

function gameClock(demo, tick, tickRate) {
    const rules = demo.getEntitiesByClassName('CCitadelGameRulesProxy')[0];
    const start = rules?.getField('m_pGameRules.m_flGameStartTime');
    const totalPaused = rules?.getField('m_pGameRules.m_nTotalPausedTicks') ?? 0;
    const pauseStart = rules?.getField('m_pGameRules.m_nPauseStartTick');
    const currentPause = rules?.getField('m_pGameRules.m_bServerPaused') &&
        Number.isInteger(pauseStart) && pauseStart > 0 ? Math.max(0, tick - pauseStart) : 0;
    return Number.isFinite(start) && start > 0 ? (tick - totalPaused - currentPause) / tickRate - start : null;
}

async function follow(input, historySeconds) {
    const base = await resolveBroadcast(input);
    const relay = await waitForSync(base);
    let start = await selectStart(base, relay);
    if (historySeconds > 0 && relay.keyframe_interval > 0) {
        const first = Math.max(relay.signup_fragment + 1,
                               relay.fragment - Math.ceil(historySeconds / relay.keyframe_interval));
        for (let fragment = first; fragment < relay.fragment; fragment += 1) {
            try {
                const sync = await readSync(base, fragment);
                if (sync.fragment !== fragment) continue;
                const full = await request(base, `${fragment}/full`);
                start = { sync, full };
                break;
            } catch (error) {
                if (error.status !== 404 && error.status !== 405) break;
            }
        }
    }
    const { sync, full } = start;
    reportSync(sync);
    let fragment = sync.fragment;
    let lastReported = fragment;
    let transportError;
    let reading = true;
    // The starting keyframe and all subsequent deltas belong to the same broadcast.
    async function* fragments() {
        try {
            yield await readFragment(base, `${sync.signup_fragment}/start`);
            yield full ?? await readFragment(base, `${fragment}/full`);
            let lastFragmentAt = performance.now();
            for (;;) {
                try {
                    const bytes = await request(base, `${fragment}/delta`);
                    const completed = fragment++;
                    lastFragmentAt = performance.now();
                    yield bytes;
                    if (completed > lastReported) {
                        // Metadata is optional and must never hold back player data.
                        readSync(base, completed).then(position => {
                            if (reading && position.fragment === completed && completed > lastReported) {
                                lastReported = completed;
                                reportSync(position);
                            }
                        }).catch(() => {});
                    }
                } catch (error) {
                    if (error.status !== 404 && error.status !== 405) throw error;
                    if (performance.now() - lastFragmentAt > 20000) {
                        throw new Error('SourceTV не выдал новых сегментов за 20 секунд.');
                    }
                    await sleep(500);
                }
            }
        } catch (error) {
            transportError = error;
            throw error;
        }
    }

    const parser = new Parser(ParserConfiguration.DEFAULT, Logger.NOOP);
    const streaks = new Map();
    const matchId = /\/([0-9]{1,20})_[0-9]+$/.exec(base.pathname)?.[1] ?? 'match';
    const events = new MatchEvents(matchId);
    let nextSampleTick = 0;
    parser.registerPostInterceptor(InterceptorStage.MESSAGE_PACKET, (packet, message) => {
        if (message.is(MessagePacketType.CITADEL_USER_MESSAGE_KILL_STREAK)) {
            const { playerPawn, numKills, streakEnded } = message.data;
            if (!Number.isInteger(playerPawn) || playerPawn < 0 || playerPawn === 0xffffff) return;
            if (streakEnded) streaks.set(playerPawn, 0);
            else if (Number.isSafeInteger(numKills) && numKills > 0) streaks.set(playerPawn, numKills);
        } else if (message.is(MessagePacketType.CITADEL_USER_MESSAGE_HERO_KILLED)) {
            const demo = parser.getDemo();
            events.record(demo, packet.tick, gameClock(demo, packet.tick, sync.tps), 'kill', message.data);
            const { entindexVictim } = message.data;
            if (!Number.isInteger(entindexVictim) || entindexVictim < 0) return;
            const victim = demo.getEntity(entindexVictim);
            if (victim) streaks.set(victim.handle, 0);
        } else if (message.is(MessagePacketType.CITADEL_USER_MESSAGE_ABILITY_CHANGED)) {
            const demo = parser.getDemo();
            events.record(demo, packet.tick, gameClock(demo, packet.tick, sync.tps), 'purchase', message.data);
        }
    });
    parser.registerPostInterceptor(InterceptorStage.DEMO_PACKET, packet => {
        if (packet.tick <= 0 || packet.tick < nextSampleTick) return;
        const demo = parser.getDemo();
        const players = readPlayers(demo, streaks, events);
        if (!players.length) return;
        nextSampleTick = packet.tick + sync.tps;
        emit({ type: 'snapshot', matchId: matchId === 'match' ? null : matchId, tick: packet.tick, gameSeconds: gameClock(demo, packet.tick, sync.tps),
               players, events: events.kills });
    });
    try {
        await parser.parse(Readable.from(fragments()), DemoSource.HTTP_BROADCAST);
        reading = false;
        if (transportError) throw transportError;
        emit({ type: 'end' });
    } finally {
        reading = false;
        await parser.dispose();
    }
}

try {
    await follow(process.argv[2], Math.min(90, Number(process.argv[3]) || 0));
} catch (error) {
    emit({ type: 'error', message: error.message });
    process.exitCode = 1;
}
