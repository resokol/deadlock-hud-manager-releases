"""Display the live left-to-right order of the spectator's top bar."""

import json

from PySide6.QtCore import Qt, QTimer, QUrl, Signal
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkProxy, QNetworkReply, QNetworkRequest
from PySide6.QtWidgets import (
    QComboBox, QFormLayout, QGroupBox, QHeaderView, QLabel, QLineEdit, QPushButton,
    QTableWidget, QTableWidgetItem, QVBoxLayout,
)

from .broadcast_tables import observed_hud_slot, players_by_portrait
from .panorama_hud_mode import video_origin


class PanoramaPositions(QGroupBox):
    slots_changed = Signal(dict)
    local_requested = Signal()

    def __init__(self, settings):
        super().__init__('Верхняя полоса наблюдателя')
        self.settings = settings
        self.slots = {}
        self.observed = None
        self.remote = ''
        self.reply = None
        self.network = QNetworkAccessManager(self)
        self.network.setProxy(QNetworkProxy(QNetworkProxy.ProxyType.NoProxy))
        self.timer = QTimer(self, interval=1000)
        self.timer.timeout.connect(self._poll)
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.source = QComboBox()
        self.source.addItems(['Panorama на этом ПК', 'Panorama по локальной сети'])
        self.url = QLineEdit(settings.value('positionsUrl', '', type=str))
        self.url.setPlaceholderText('URL JSON матча с ПК наблюдателя')
        self.source.setCurrentIndex(int(settings.value('positionsRemote', False, type=bool)))
        self.url.setEnabled(bool(self.source.currentIndex()))
        self.source.currentIndexChanged.connect(lambda index: self.url.setEnabled(bool(index)))
        form.addRow('Источник', self.source)
        form.addRow('URL JSON матча', self.url)
        layout.addLayout(form)
        apply = QPushButton('Подключить')
        apply.clicked.connect(self.connect_source)
        layout.addWidget(apply, alignment=Qt.AlignmentFlag.AlignLeft)
        self.status = QLabel()
        self.status.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.status)
        self.table = QTableWidget(12, 2)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setHorizontalHeaderLabels(['Позиция слева направо', 'Ник в Deadlock'])
        self.table.verticalHeader().hide()
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        for i in range(12):
            self.table.setItem(i, 0, QTableWidgetItem(str(i + 1)))
            self.table.setItem(i, 1, QTableWidgetItem('—'))
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        layout.addWidget(self.table)
        self._show({}, None)
        if self.source.currentIndex():
            self.connect_source()

    def stop(self):
        self.timer.stop()
        reply, self.reply = self.reply, None
        if reply:
            reply.abort()

    def connect_source(self):
        use_remote = bool(self.source.currentIndex())
        address = self.url.text().strip()
        if use_remote and not video_origin(address):
            self.status.setText('Вставьте полный URL JSON матча с ПК наблюдателя.')
            return
        self.stop()
        self.remote = address if use_remote else ''
        self.settings.setValue('positionsUrl', address)
        self.settings.setValue('positionsRemote', use_remote)
        self._show({}, None)
        if self.remote:
            self.timer.start()
            self._poll()
        else:
            self.local_requested.emit()

    def observe(self, telemetry):
        if not self.remote:
            telemetry = telemetry or {}
            slots = players_by_portrait(telemetry.get('teams', []))
            self._show(slots, observed_hud_slot(slots, telemetry.get('selected')))

    def _poll(self):
        if self.reply is not None:
            return
        request = QNetworkRequest(QUrl(self.remote))
        request.setTransferTimeout(2500)
        request.setAttribute(QNetworkRequest.Attribute.RedirectPolicyAttribute,
                             QNetworkRequest.RedirectPolicy.ManualRedirectPolicy)
        reply = self.network.get(request)
        self.reply = reply
        reply.finished.connect(lambda: self._received(reply))

    def _received(self, reply):
        reply.deleteLater()
        if self.reply is not reply:
            return
        self.reply = None
        try:
            if reply.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute) != 200 or reply.error() != QNetworkReply.NetworkError.NoError:
                raise ValueError
            stats = json.loads(bytes(reply.readAll()))
            slots = stats['hud_slots']
            if not isinstance(slots, dict) or slots and (
                set(slots) != {str(i) for i in range(1, 13)} or
                not all(isinstance(name, str) and name.strip() for name in slots.values())
            ):
                raise ValueError
            self._show(slots, observed_hud_slot(slots, stats.get('selected')))
        except (KeyError, TypeError, ValueError, AttributeError):
            self._show({}, None, 'Проверьте URL JSON матча и наличие поля hud_slots на ПК наблюдателя.')

    def _show(self, slots, observed, message=None):
        changed = slots != self.slots
        if changed:
            self.slots = slots
            for i in range(12):
                self.table.item(i, 1).setText(slots.get(str(i + 1), '—'))
            self.slots_changed.emit(slots)
        self.observed = observed
        status = message or 'Ожидание 12 портретов Panorama.'
        if not message and slots:
            status = (f'Под наблюдением: {observed} · {slots[str(observed)]}' if observed else
                      'Получены 12 позиций. Игрок под наблюдением не выбран.')
        if self.status.text() != status:
            self.status.setText(status)
