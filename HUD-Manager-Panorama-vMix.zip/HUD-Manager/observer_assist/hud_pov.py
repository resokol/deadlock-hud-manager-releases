"""Configure the HUD camera feed and remote vMix input mapping."""

import json
from ipaddress import ip_address

from PySide6.QtCore import Qt, QUrl, Signal
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkProxy, QNetworkReply, QNetworkRequest
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QFormLayout, QGroupBox, QGridLayout, QHBoxLayout, QHeaderView, QLabel,
    QLineEdit, QPushButton, QSpinBox, QTableWidget, QTableWidgetItem, QVBoxLayout,
)

from .hud_nicknames import normalize_name, roster_names
from .panorama_hud_mode import video_origin
from .hud_switch_delay import MAX_SWITCH_DELAY_MS, SpectatorSwitchDelay
from .vmix_control import VmixPovControl, VmixInputNames


class VmixPovPanel(QGroupBox):
    video_changed = Signal(str, str)
    mappings_changed = Signal()

    def __init__(self, settings):
        super().__init__('Камера игрока')
        self.settings = settings
        self.control = VmixPovControl(self)
        self._switches = SpectatorSwitchDelay()
        self.hud_delay_ms = self.pov_delay_ms = 0
        self.roster = ()
        self.match_names = ()
        self.camera_inputs = {}
        self._roster_network = QNetworkAccessManager(self)
        self._roster_network.setProxy(QNetworkProxy(QNetworkProxy.ProxyType.NoProxy))
        self._roster_reply = None
        self.input_names = VmixInputNames(self)
        self._names_config = None
        self._hud_slots = {}
        self.source = '', 'video'
        try:
            config = json.loads(settings.value('povVmix', '{}', type=str))
        except ValueError:
            config = {}
        if not isinstance(config, dict):
            config = {}

        layout = QVBoxLayout(self)
        self.enabled = QCheckBox('Переключать вход в vMix вслед за игроком в кадре')
        self.enabled.setChecked(config.get('enabled') is True)
        layout.addWidget(self.enabled)
        form = QFormLayout()
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.address = QLineEdit(str(config.get('address', '')))
        self.address.setPlaceholderText('192.168.1.50')
        self.port = QSpinBox()
        self.port.setRange(1, 65535)
        self.port.setValue(config['port'] if type(config.get('port')) is int else 8088)
        self.target = QLineEdit(str(config.get('target', '')))
        self.target.setPlaceholderText('Например, POV')
        self.target.setToolTip('Имя, номер или GUID входа vMix, выделенного для POV.')
        self.layer = QSpinBox()
        self.layer.setRange(1, 10)
        self.layer.setValue(config['layer'] if type(config.get('layer')) is int else 1)
        self.video_url = QLineEdit(str(config.get('video', '')))
        self.video_url.setMaxLength(2048)
        self.video_url.setPlaceholderText('http://192.168.1.50:8889/pov')
        self.video_format = QComboBox()
        for label, key in (('Веб-плеер (например, WebRTC)', 'iframe'), ('Видео MP4 / WebM', 'video'), ('Поток MJPEG', 'mjpeg')):
            self.video_format.addItem(label, key)
        format_index = self.video_format.findData(config.get('format', 'iframe'))
        self.video_format.setCurrentIndex(max(0, format_index))
        self.hud_switch_delay = QSpinBox()
        self.pov_switch_delay = QSpinBox()
        for field, key in ((self.hud_switch_delay, 'hudDelayMs'), (self.pov_switch_delay, 'povDelayMs')):
            field.setRange(0, MAX_SWITCH_DELAY_MS)
            field.setSingleStep(50)
            field.setSuffix(' мс')
            value = config.get(key, 0)
            field.setValue(value if type(value) is int else 0)
        form.addRow('IP компьютера с vMix', self.address)
        form.addRow('Порт Web Controller', self.port)
        form.addRow('Вход-компоновка для POV', self.target)
        form.addRow('Слой камеры во входе', self.layer)
        form.addRow('URL видеопотока или плеера', self.video_url)
        form.addRow('Формат видео', self.video_format)
        form.addRow('Задержка смены игрока в HUD', self.hud_switch_delay)
        form.addRow('Задержка переключения POV в vMix', self.pov_switch_delay)
        self.roster_url = QLineEdit(str(config.get('rosterUrl', '')))
        self.roster_url.setPlaceholderText('Для второго ПК — ссылка из меню «JSON для vMix / CharacterWorks → Игроки»')
        form.addRow('URL таблицы игроков', self.roster_url)
        layout.addLayout(form)

        self.mapping = QTableWidget(0, 2)
        self.mapping.setAccessibleName('Соответствие игроков и входов vMix')
        self.mapping.setHorizontalHeaderLabels(['Ник в Deadlock', 'Имя, GUID или номер входа камеры'])
        self.mapping.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.mapping.verticalHeader().hide()
        self.mapping.setMinimumHeight(150)
        self.mapping.setMaximumHeight(235)
        layout.addWidget(self.mapping)
        mappings = config.get('mappings')
        if isinstance(mappings, dict):
            for name, source in mappings.items():
                if isinstance(source, str):
                    self._add_row(name, source)
        if not self.mapping.rowCount():
            self._add_row()

        actions = QHBoxLayout()
        self.fill_roster = QPushButton('Подставить игроков матча')
        self.roster_url.textChanged.connect(self._roster_source_changed)
        self._update_fill_button()
        self.fill_roster.clicked.connect(self._fill_roster)
        add = QPushButton('Добавить строку')
        add.clicked.connect(lambda: self._add_row(edit=True))
        remove = QPushButton('Удалить строку')
        remove.clicked.connect(self._remove_row)
        for button in (self.fill_roster, add, remove):
            actions.addWidget(button)
        actions.addStretch()
        layout.addLayout(actions)
        names_box = QGroupBox('Названия POV-входов vMix')
        names_layout = QVBoxLayout(names_box)
        self.rename_inputs = QCheckBox('Ставить ник игрока из позиции HUD в название входа')
        self.rename_inputs.setChecked(config.get('renameInputs') is True)
        names_layout.addWidget(self.rename_inputs)
        grid = QGridLayout()
        self.slot_inputs = []
        saved_inputs = config.get('slotInputs')
        for index in range(12):
            slot = index + 1
            spin = QSpinBox()
            spin.setRange(0, 9999)
            spin.setSpecialValueText('Выкл.')
            spin.setAccessibleName(f'Номер входа для позиции {slot}')
            value = saved_inputs[index] if isinstance(saved_inputs, list) and len(saved_inputs) == 12 else slot
            spin.setValue(value if type(value) is int and 0 <= value <= 9999 else slot)
            self.slot_inputs.append(spin)
            row, col = divmod(index, 4)
            grid.addWidget(QLabel(f'Позиция {slot}'), row, 2 * col)
            grid.addWidget(spin, row, 2 * col + 1)
        names_layout.addLayout(grid)
        self.names_status = QLabel()
        self.names_status.setTextFormat(Qt.TextFormat.PlainText)
        self.names_status.setWordWrap(True)
        self.input_names.status.connect(self.names_status.setText)
        names_layout.addWidget(self.names_status)
        layout.addWidget(names_box)
        apply = QPushButton('Применить настройки POV')
        apply.setObjectName('primary')
        apply.clicked.connect(lambda: self._apply(save=True))
        layout.addWidget(apply, alignment=Qt.AlignmentFlag.AlignLeft)
        self.status = QLabel()
        self.status.setObjectName('subtle')
        self.status.setTextFormat(Qt.TextFormat.PlainText)
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.control.status.connect(self.status.setText)
        self._apply(save=False)

    def allows_video_navigation(self, url):
        source, mode = self.source
        return bool(source and mode == 'iframe' and
                    video_origin(bytes(url.toEncoded()).decode('ascii')) == video_origin(source))

    def _update_fill_button(self):
        self.fill_roster.setEnabled(self._roster_reply is None and bool(self.roster_url.text().strip() or self.roster or self.match_names))

    def _roster_source_changed(self):
        if self._roster_reply is not None:
            reply, self._roster_reply = self._roster_reply, None
            reply.abort()
        self._update_fill_button()

    def set_match_roster(self, roster):
        self.match_names = roster_names(roster)
        self._update_fill_button()

    def observe(self, telemetry, match=None, *, roster=None, now=None):
        names = roster_names(telemetry if telemetry and telemetry.get('teams') else roster)
        if names != self.roster:
            self.roster = names
            self._update_fill_button()
        fields = self._switches.update(telemetry, match, self.pov_delay_ms, now=now)
        self.control.observe(fields.get('selected', {}).get('player'))

    def _configure_input_names(self, config):
        self.input_names.close()
        self._names_config = config
        if config:
            self.set_hud_slots(self._hud_slots)
        else:
            self.names_status.clear()

    def set_hud_slots(self, slots):
        self._hud_slots = slots
        if not self._names_config:
            return
        address, port, inputs = self._names_config
        names = {}
        if all(isinstance(slots.get(str(i)), str) and slots[str(i)].strip() for i in range(1, 13)):
            names = {number: slots[str(slot)] for slot, number in enumerate(inputs, 1) if number}
        self.input_names.configure(address, port, names)
        if not names:
            self.names_status.setText('Ожидание позиций Panorama.')

    def shutdown(self):
        self._configure_input_names(None)
        self.control.close()

    def _add_row(self, name='', source='', *, edit=False):
        row = self.mapping.rowCount()
        self.mapping.insertRow(row)
        for col, value in enumerate((name, source)):
            self.mapping.setItem(row, col, QTableWidgetItem(value))
        if edit:
            self.mapping.setCurrentCell(row, 0)
            self.mapping.editItem(self.mapping.item(row, 0))

    def _remove_row(self):
        row = self.mapping.currentRow()
        if row >= 0:
            self.mapping.removeRow(row)

    def _fill_roster(self):
        address = self.roster_url.text().strip()
        if not address:
            self._insert_players((name, '') for name in (self.roster or self.match_names))
            return

        url = QUrl(address)
        if not url.isValid() or url.scheme() not in ('http', 'https') or not url.host():
            self.status.setText('Вставьте полный URL таблицы «Игроки» из HUD Manager.')
            return
        request = QNetworkRequest(url)
        request.setTransferTimeout(3000)
        request.setAttribute(QNetworkRequest.Attribute.RedirectPolicyAttribute,
                             QNetworkRequest.RedirectPolicy.ManualRedirectPolicy)
        reply = self._roster_network.get(request)
        self._roster_reply = reply
        self._update_fill_button()
        reply.finished.connect(lambda: self._received_players(reply))

    def _received_players(self, reply):
        reply.deleteLater()
        if reply is not self._roster_reply:
            return
        self._roster_reply = None
        self._update_fill_button()
        status = reply.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute)
        if status != 200 or reply.error() != QNetworkReply.NetworkError.NoError:
            reason = f'HTTP {status}' if status else 'нет ответа'
            self.status.setText(f'Таблица игроков недоступна ({reason}). Проверьте сетевую ссылку.')
            return
        try:
            rows = json.loads(bytes(reply.readAll()))
            if not isinstance(rows, list):
                raise ValueError
            players = {}
            for row in rows:
                slot, name = row['player_number'], row['player_name']
                if type(slot) not in (str, int) or not isinstance(name, str):
                    raise ValueError
                slot = int(slot)
                if not 1 <= slot <= 12 or slot in players:
                    raise ValueError
                players[slot] = name.strip()
        except (ValueError, KeyError, TypeError):
            self.status.setText('Ответ не соответствует таблице «Игроки». Проверьте ссылку.')
            return
        if not any(players.values()):
            self.status.setText('В сетевой таблице пока нет ников игроков.')
            return
        self._insert_players((players[slot], str(slot)) for slot in sorted(players) if players[slot])

    def _insert_players(self, players):
        known = {normalize_name(self.mapping.item(row, 0).text()): row for row in range(self.mapping.rowCount())}
        changed = 0
        for name, source in players:
            key = normalize_name(name)
            if key in known:
                cell = self.mapping.item(known[key], 1)
                if not source or cell.text().strip():
                    continue
                cell.setText(source)
            else:
                known[key] = self.mapping.rowCount()
                self._add_row(name, source)
            changed += 1
        self.status.setText(f'Заполнено строк: {changed}.' if changed else 'Все полученные ники уже в таблице.')

    def _mappings(self):
        result = {}
        known = set()
        for row in range(self.mapping.rowCount()):
            name, source = (self.mapping.item(row, col).text().strip() for col in (0, 1))
            if not name and source:
                raise ValueError(f'Укажите ник для входа в строке {row + 1}.')
            if not name:
                continue
            key = normalize_name(name)
            if key in known:
                raise ValueError(f'Ник «{name}» указан несколько раз.')
            result[name] = source
            known.add(key)
        return result

    def _apply(self, *, save):
        enabled = self.enabled.isChecked()
        address = self.address.text().strip()
        target = self.target.text().strip()
        video = self.video_url.text().strip()
        media_format = self.video_format.currentData()
        try:
            if address:
                try:
                    parsed = ip_address(address)
                    if getattr(parsed, 'scope_id', None):
                        raise ValueError
                    address = str(parsed)
                except ValueError:
                    raise ValueError('Укажите IP-адрес компьютера с vMix.') from None
            if enabled and (not address or not target):
                raise ValueError('Для переключения укажите IP и вход-компоновку vMix.')
            if video and not video_origin(video):
                raise ValueError('Укажите полный HTTP или HTTPS URL видео или плеера.')
            mappings = self._mappings()
            rename = self.rename_inputs.isChecked()
            inputs = tuple(field.value() for field in self.slot_inputs)
            if rename:
                if not address:
                    raise ValueError('Укажите IP компьютера с vMix для переименования входов.')
                numbers = [number for number in inputs if number]
                if not numbers or len(numbers) != len(set(numbers)):
                    raise ValueError('Назначьте разные номера входов для позиций HUD. Ноль отключает позицию.')
        except ValueError as exc:
            self.status.setText(str(exc))
            return

        port = self.port.value()
        layer = self.layer.value()
        self.hud_delay_ms = self.hud_switch_delay.value()
        pov_delay_ms = self.pov_switch_delay.value()
        if pov_delay_ms != self.pov_delay_ms:
            self.pov_delay_ms = pov_delay_ms
            self.control.observe(None)
        if save:
            self.settings.setValue('povVmix', json.dumps(dict(enabled=enabled, address=address,
                                   target=target, port=port, layer=layer, video=video,
                                   renameInputs=rename, slotInputs=inputs,
                                   format=media_format, mappings=mappings, rosterUrl=self.roster_url.text().strip(),
                                   hudDelayMs=self.hud_delay_ms,
                                   povDelayMs=self.pov_delay_ms), ensure_ascii=False))
        if self.source != (video, media_format):
            self.source = video, media_format
            self.video_changed.emit(*self.source)
        camera_inputs = {normalize_name(name): int(source) for name, source in mappings.items()
                         if source.isascii() and source.isdecimal() and len(source) <= 4 and int(source) > 0}
        if self.camera_inputs != camera_inputs:
            self.camera_inputs = camera_inputs
            self.mappings_changed.emit()
        self._configure_input_names((address, port, inputs) if rename else None)
        self.control.configure(address, port, target, layer,
                               {name: source for name, source in mappings.items() if source}, enabled)
        if not enabled:
            self.status.setText('Источник видео сохранён.' if video else 'Переключение vMix выключено.')
