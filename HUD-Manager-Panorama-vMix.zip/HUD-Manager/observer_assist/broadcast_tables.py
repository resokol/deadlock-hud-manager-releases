"""Stable, flat data-source tables for vMix and CharacterWorks."""

from math import isfinite

from .hero_stats import LANES
from .hud_nicknames import normalize_name


BROADCAST_ROUTES = {f'/api/v1/broadcast/{table}': table for table in ('match', 'players', 'lanes', 'loadout')}
CHARACTERWORKS_QUERY = '''for $row in /*/*
return <row>{
    for $cell in $row/*
    let $key := if ($cell/@key) then string($cell/@key) else replace(local-name($cell), '__', '_')
    return element {$key} {string($cell)}
}</row>'''
TEAM_NAMES = {2: 'Янтарные', 3: 'Сапфировые'}
TEAM_SIZE = 6
LOADOUT_SIZE = 8
PLAYER_FIELDS = {
    'player_name': 'name', 'hero_name': 'hero', 'kills': 'kills', 'deaths': 'deaths',
    'assists': 'assists', 'souls': 'souls', 'level': 'level', 'respawn': 'respawn',
    'hero_id': 'heroId', 'rank': 'rank', 'hero_damage': 'heroDamage',
}
HISTORY_NUMBERS = {
    'hero_matches': 'matches', 'hero_avg_damage': 'avgHeroDamage', 'hero_souls_per_minute': 'soulsPerMinute',
}
HISTORY_RATES = {
    'hero_win_rate_pct': 'winRate', 'hero_headshot_rate_pct': 'headshotRate', 'hero_accuracy_pct': 'accuracy',
}


def _row(**values):
    def cell(value):
        if type(value) is bool:
            return '1' if value else '0'
        if value is None or (type(value) is float and not isfinite(value)):
            return ''
        return str(value)

    return {key: cell(value) for key, value in values.items()}


def _percent(rate):
    if type(rate) in (int, float) and 0 <= rate <= 1:
        return round(rate * 100.0, 1)
    return None


def _clock_seconds(clock):
    if isinstance(clock, str):
        minutes, _, seconds = clock.partition(':')
        if minutes.isascii() and minutes.isdecimal() and seconds.isascii() and seconds.isdecimal():
            return 60 * int(minutes) + int(seconds)
    return None


def _match(stats, common):
    teams = {team['side']: team for team in stats['teams']}
    amber, sapphire = teams.get(2, {}), teams.get(3, {})
    selected = stats.get('selected') or {}
    return [_row(**common, clock_seconds=_clock_seconds(stats['gameClock']), sampled_at_ms=stats.get('sampledAt'),
                 amber_name=TEAM_NAMES[2], sapphire_name=TEAM_NAMES[3],
                 amber_kills=amber.get('kills'), sapphire_kills=sapphire.get('kills'),
                 amber_souls=amber.get('netWorth'), sapphire_souls=sapphire.get('netWorth'),
                 mid_boss_timer=stats.get('midBossTimer'), observed_player=selected.get('player'),
                 observed_hp=selected.get('hp'), observed_max_hp=selected.get('maxHp'),
                 observed_regen=selected.get('regen'), kda_source=stats.get('kdaSource'))]


def _players(stats, heroes, common):
    native = {team['side']: team['players'] for team in stats['teams']}
    detailed = {team['side']: team['players'] for team in heroes['teams']}
    selected = (stats.get('selected') or {}).get('player')
    result = []
    for team_index, (side, team_name) in enumerate(TEAM_NAMES.items()):
        players, enrichments = native.get(side, []), detailed.get(side, [])
        for slot in range(TEAM_SIZE):
            player = players[slot] if slot < len(players) else {}
            detail = enrichments[slot] if slot < len(enrichments) else {}
            if detail.get('name') != player.get('name'):
                detail = {}
            history = detail.get('history') or {}
            merged = {**player, **detail}
            result.append(_row(
                **common, player_number=team_index * TEAM_SIZE + slot + 1, team_side=side,
                team_name=team_name, team_slot=slot + 1, occupied=bool(player),
                observed=selected is not None and player.get('name') == selected,
                lane_id=merged.get('lane'), lane_name=LANES.get(merged.get('lane')),
                history_status=heroes['historyStatus'],
                **{column: merged.get(field) for column, field in PLAYER_FIELDS.items()},
                **{column: history.get(field) for column, field in HISTORY_NUMBERS.items()},
                **{column: _percent(history.get(field)) for column, field in HISTORY_RATES.items()},
            ))
    return result


def players_by_portrait(teams):
    """Read the observer's visible 12-player top bar in window coordinates."""
    if len(teams) != 2 or any(len(team['players']) != TEAM_SIZE for team in teams):
        return {}
    portraits = []
    for team in teams:
        for player in team['players']:
            x = player.get('portraitX')
            name = player.get('name')
            if type(x) not in (int, float) or not isfinite(x) or not name:
                return {}
            portraits.append((x, name))
    portraits.sort()
    if any(right[0] - left[0] < 4 for left, right in zip(portraits, portraits[1:])):
        return {}
    return {str(slot): name for slot, (_, name) in enumerate(portraits, 1)}


def observed_hud_slot(slots, selected):
    name = (selected or {}).get('player')
    matches = [int(slot) for slot, nick in slots.items() if nick == name]
    return matches[0] if len(matches) == 1 else None


def players_by_input(roster, camera_inputs):
    assigned = {}
    for team in roster['teams']:
        for player in team['players']:
            slot = camera_inputs.get(normalize_name(player.get('name')))
            if slot is not None:
                assigned[slot] = None if slot in assigned else (team['side'], player)
    return assigned


def mapped_player_rows(roster, camera_inputs):
    """SourceTV roster order is independent of the camera inputs assigned by the operator."""
    heroes = {'teams': [], 'historyStatus': 'waiting'}
    rows = _players({'teams': []}, heroes, dict(schema_version=1, status='waiting',
                                                match_id=roster['matchId'], game_clock=None))
    for slot, assignment in players_by_input(roster, camera_inputs).items():
        if assignment is not None and 1 <= slot <= len(rows):
            side, player = assignment
            rows[slot - 1].update(_row(status='live', occupied=True, player_name=player['name'],
                                       team_side=side, team_name=TEAM_NAMES[side], team_slot=None,
                                       kills=player.get('kills'), deaths=player.get('deaths'),
                                       assists=player.get('assists')))
    return rows


def _lanes(heroes, common):
    lanes = {lane['id']: lane for lane in heroes['lanes']}
    names = {player.get('heroId'): player.get('hero') for team in heroes['teams'] for player in team['players']}
    result = []
    for lane_id, label in LANES.items():
        lane = lanes.get(lane_id, {})
        sides = {}
        for side in ('amber', 'sapphire'):
            ids = lane.get(side, ())
            for index in range(2):
                hero_id = ids[index] if index < len(ids) else None
                sides[f'{side}_hero_{index + 1}_id'] = hero_id
                sides[f'{side}_hero_{index + 1}_name'] = names.get(hero_id) if hero_id is not None else None
        result.append(_row(**common, lane_id=lane_id, lane_name=label, **sides,
                           amber_win_rate_pct=_percent(lane.get('winRate')), matches=lane.get('matches'),
                           samples_at_15=lane.get('sampleMatches'), amber_souls_diff_at_15=lane.get('soulsDiff15')))
    return result


def _loadout(stats, common):
    selected = stats.get('selected') or {}
    result = []
    for group, (slot_type, field) in enumerate((('ability', 'abilitySlots'), ('item', 'itemSlots'))):
        slots = selected.get(field) or []
        for index in range(LOADOUT_SIZE):
            slot = (slots[index] or {}) if index < len(slots) else {}
            result.append(_row(**common, observed_player=selected.get('player'),
                               row_number=group * LOADOUT_SIZE + index + 1, slot_type=slot_type,
                               slot_number=index + 1, occupied=bool(slot), name=slot.get('name'),
                               key=slot.get('key'), cooldown_seconds=slot.get('cooldown'),
                               image_ref=slot.get('image'), entity_id=slot.get('id')))
    return result


def broadcast_rows(table, stats, heroes=None):
    common = dict(schema_version=1, status=stats['status'], match_id=stats['matchId'], game_clock=stats['gameClock'])
    if table == 'match':
        return _match(stats, common)
    if table == 'players':
        return _players(stats, heroes, common)
    if table == 'lanes':
        return _lanes(heroes, common)
    if table == 'loadout':
        return _loadout(stats, common)
    raise ValueError('Неизвестная таблица для графики.')
