"""Controls for the independent OBS table and the LAN statistics feed."""

from ipaddress import IPv4Interface
from secrets import token_urlsafe

from PySide6.QtCore import QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtNetwork import QAbstractSocket, QNetworkInterface
from PySide6.QtWidgets import QApplication, QCheckBox, QComboBox, QGroupBox, QHBoxLayout, QLabel, QMenu, QPushButton, QVBoxLayout

from .broadcast_tables import BROADCAST_ROUTES, CHARACTERWORKS_QUERY
from .match_stats import StatsLanServer, is_lan_address


def lan_interfaces():
    result = []
    for interface in QNetworkInterface.allInterfaces():
        if not interface.flags() & QNetworkInterface.InterfaceFlag.IsUp:
            continue
        name = interface.humanReadableName()
        virtual = interface.type() not in (QNetworkInterface.InterfaceType.Ethernet,
                                           QNetworkInterface.InterfaceType.Wifi) or name.lower().startswith('vethernet')
        for entry in interface.addressEntries():
            if entry.ip().protocol() != QAbstractSocket.NetworkLayerProtocol.IPv4Protocol or entry.prefixLength() <= 0:
                continue
            address = IPv4Interface(f'{entry.ip().toString()}/{entry.prefixLength()}')
            if is_lan_address(address.ip):
                result.append((virtual, name, address))
    return [(name, address) for _, name, address in sorted(result)]


class LiveStatsPanel(QGroupBox):
    def __init__(self, settings, start_server):
        super().__init__('Статистика матча')
        self.settings = settings
        self.start_server = start_server
        self._export = None
        self._copy_graphics = []

        layout = QVBoxLayout(self)
        for path, preview_title, copy_title in (
            ('/stats/', 'Предпросмотр таблицы', 'Копировать URL таблицы'),
            ('/hero-stats/', 'Предпросмотр героев', 'Копировать URL героев'),
            ('/fight-recap/', 'Предпросмотр Fight Recap', 'Копировать URL Fight Recap'),
        ):
            links = QHBoxLayout()
            preview = QPushButton(preview_title)
            preview.clicked.connect(lambda _checked=False, route=path: self._preview(route))
            obs = QPushButton(copy_title)
            obs.clicked.connect(lambda _checked=False, route=path: self._copy_table(route))
            network_url = QPushButton('URL по сети')
            network_url.setAccessibleName(copy_title + ' по сети')
            network_url.clicked.connect(lambda _checked=False, route=path: self._copy_network_table(route))
            self._copy_graphics.append(network_url)
            links.addWidget(preview)
            links.addWidget(obs)
            links.addWidget(network_url)
            layout.addLayout(links)

        self.hero_history = QCheckBox('История игроков через Deadlock API')
        self.hero_history.setToolTip('Отправляет Steam Account ID и ID героев для запроса истории на выбранном герое.')
        self.hero_history.toggled.connect(self._configure_history)
        layout.addWidget(self.hero_history)

        access = QHBoxLayout()
        self.share = QCheckBox('Доступ по локальной сети')
        self.network = QComboBox()
        self.network.setAccessibleName('Сетевой адрес статистики')
        for name, address in lan_interfaces():
            self.network.addItem(f'{name} · {address.ip}', str(address))
        index = self.network.findData(settings.value('statsExportAddress', '', type=str))
        self.network.setCurrentIndex(max(0, index))
        access.addWidget(self.share)
        access.addWidget(self.network, 1)
        layout.addLayout(access)

        json_links = QHBoxLayout()
        self.copy_json = QPushButton('Копировать URL JSON матча')
        self.copy_json.clicked.connect(lambda: self._copy_json())
        self.copy_hero_json = QPushButton('Копировать URL JSON героев')
        self.copy_hero_json.clicked.connect(lambda: self._copy_json(heroes=True))
        json_links.addWidget(self.copy_json)
        json_links.addWidget(self.copy_hero_json)
        layout.addLayout(json_links)

        self.broadcast_links = QPushButton('JSON для vMix / CharacterWorks')
        menu = QMenu(self.broadcast_links)
        labels = {'match': 'Матч', 'players': 'Игроки', 'lanes': 'Линии', 'loadout': 'Способности и предметы'}
        for path, table in BROADCAST_ROUTES.items():
            action = menu.addAction(labels[table])
            action.triggered.connect(lambda _checked=False, route=path: self._copy_broadcast(route))
        menu.addSeparator()
        menu.addAction('Копировать XQuery для CharacterWorks', self._copy_characterworks_query)
        self.broadcast_links.setMenu(menu)
        layout.addWidget(self.broadcast_links)
        self.message = QLabel()
        self.message.setObjectName('subtle')
        self.message.setWordWrap(True)
        layout.addWidget(self.message)

        self.network.setVisible(False)
        self._enable_network_links(False)
        self.message.hide()
        self.share.toggled.connect(self._configure_export)
        self.network.currentIndexChanged.connect(self._configure_export)
        self.share.setChecked(settings.value('statsExportEnabled', False, type=bool))
        self.hero_history.setChecked(settings.value('heroHistoryEnabled', False, type=bool))

    def _status(self, value):
        self.message.setText(value)
        self.message.setVisible(bool(value))

    def _table_url(self, path):
        try:
            return self.start_server().url + path
        except (OSError, ValueError) as exc:
            self._status(f'Таблица недоступна. {exc}')
            return None

    def _preview(self, path):
        url = self._table_url(path)
        if url:
            QDesktopServices.openUrl(QUrl(url + '?preview=1'))

    def _copy_table(self, path):
        url = self._table_url(path)
        if url:
            QApplication.clipboard().setText(url)
            self._status('URL таблицы скопирован. Добавьте его в OBS как источник «Браузер».')

    def _copy_network_table(self, path):
        if self._export is not None:
            QApplication.clipboard().setText(self._export.graphic_url(path))
            self._status('Сетевой URL скопирован. На втором ПК добавьте его в OBS как источник «Браузер».')

    def _enable_network_links(self, enabled):
        for button in (self.copy_json, self.copy_hero_json, *self._copy_graphics):
            button.setEnabled(enabled)

    def _configure_history(self, enabled):
        try:
            self.start_server().set_hero_history_enabled(enabled)
        except (OSError, ValueError) as exc:
            self._status(f'История героев недоступна. {exc}')
            self.hero_history.blockSignals(True)
            self.hero_history.setChecked(False)
            self.hero_history.blockSignals(False)
            enabled = False
        self.settings.setValue('heroHistoryEnabled', enabled)

    def _configure_export(self):
        self.stop()
        enabled = self.share.isChecked()
        self.network.setVisible(enabled)
        self._enable_network_links(False)
        self.settings.setValue('statsExportEnabled', enabled)
        if not enabled:
            self._status('')
            return
        address = self.network.currentData()
        if not address:
            self._status('Локальный IPv4-адрес не найден.')
            return
        token = self.settings.value('statsExportToken', '', type=str)
        if not token:
            token = token_urlsafe(24)
            self.settings.setValue('statsExportToken', token)
        try:
            bridge = self.start_server()
            self._export = StatsLanServer(address, token, bridge.stats, hero_snapshot=bridge.hero_stats, fight_snapshot=bridge.fight_recap,
                                          assets=bridge.stats_asset, stream=bridge.events, broadcast=bridge.broadcast_stats)
        except (OSError, ValueError) as exc:
            self._status(f'Сетевой доступ недоступен. {exc}')
            return
        self.settings.setValue('statsExportAddress', address)
        self._enable_network_links(True)
        self._status(f'На втором ПК откройте скопированный URL · {self._export.address}:{self._export.port}')

    def _copy_json(self, *, heroes=False):
        if self._export is not None:
            QApplication.clipboard().setText(self._export.hero_url if heroes else self._export.url)
            self._status('URL JSON скопирован. В нём уже есть ключ доступа.')

    def _copy_broadcast(self, path):
        if self._export is not None:
            url = self._export.broadcast_url(path)
            message = 'Сетевой URL для vMix и CharacterWorks скопирован.'
        elif self.share.isChecked():
            self._status('Сетевой доступ недоступен. Проверьте выбранный интерфейс.')
            return
        else:
            url = self._table_url(path)
            message = 'Локальный URL для vMix и CharacterWorks скопирован.'
        if url:
            QApplication.clipboard().setText(url)
            self._status(message)

    def _copy_characterworks_query(self):
        QApplication.clipboard().setText(CHARACTERWORKS_QUERY)
        self._status('XQuery скопирован. Вставьте его в источник XML/JSON в CharacterWorks.')

    def stop(self):
        if self._export is not None:
            self._export.close()
            self._export = None
