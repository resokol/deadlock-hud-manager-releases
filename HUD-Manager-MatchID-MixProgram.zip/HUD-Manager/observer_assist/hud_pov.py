"""Map top-bar positions to vMix inputs and route them to the selected Mix outputs."""

import json
import re
from ipaddress import ip_address

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox, QFormLayout, QGridLayout, QGroupBox, QLabel, QLineEdit,
    QPushButton, QSpinBox, QVBoxLayout,
)

from .vmix_control import VmixInputNames, VmixProgram


class VmixPovPanel(QGroupBox):
    mappings_changed = Signal()

    def __init__(self, settings):
        super().__init__('Камеры по позициям 1–12')
        self.settings = settings
        self.input_names = VmixInputNames(self)
        self.program = VmixProgram(self)
        self.slots = {}
        self.inputs = tuple(range(1, 13))
        self.observed = None
        self.following_request = False
        self.auto = self.rename = False
        self.endpoint = ('', 8088)
        try:
            config = json.loads(settings.value('povVmix', '{}', type=str))
        except ValueError:
            config = {}
        if not isinstance(config, dict):
            config = {}

        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.address = QLineEdit(str(config.get('address', '')))
        self.port = QSpinBox()
        self.port.setRange(1, 65535)
        self.port.setValue(config['port'] if type(config.get('port')) is int else 8088)
        self.mixes = QLineEdit(str(config.get('mixes', '')))
        self.mixes.setPlaceholderText('Например, 2, 3. Mix 1 — основной Program.')
        form.addRow('IP компьютера с vMix', self.address)
        form.addRow('Порт Web Controller', self.port)
        form.addRow('Вывод в Program · номера Mix', self.mixes)
        layout.addLayout(form)
        self.rename_inputs = QCheckBox('Переименовывать входы по никам игроков')
        self.rename_inputs.setChecked(config.get('renameInputs') is True)
        layout.addWidget(self.rename_inputs)
        self.follow = QCheckBox('Автоматически выводить игрока под наблюдением в выбранные Mix')
        self.follow.setChecked(config.get('followProgram') is True)
        layout.addWidget(self.follow)
        grid = QGridLayout()
        self.slot_inputs, self.buttons = [], []
        saved = config.get('slotInputs')
        for column, label in enumerate(('Позиция', 'Вход vMix', 'Program')):
            for group in (0, 3):
                grid.addWidget(QLabel(label), 0, group + column)
        for index in range(12):
            slot = index + 1
            row, col = index % 6 + 1, 3 * (index // 6)
            grid.addWidget(QLabel(str(slot)), row, col)
            field = QSpinBox()
            field.setRange(0, 9999)
            field.setSpecialValueText('Выкл.')
            value = saved[index] if isinstance(saved, list) and len(saved) == 12 else slot
            field.setValue(value if type(value) is int else slot)
            self.slot_inputs.append(field)
            grid.addWidget(field, row, col + 1)
            button = QPushButton('—')
            button.setEnabled(False)
            button.clicked.connect(lambda _, n=slot: self.take(n))
            self.buttons.append(button)
            grid.addWidget(button, row, col + 2)
        layout.addLayout(grid)
        apply = QPushButton('Применить настройки POV')
        apply.clicked.connect(lambda: self._apply(save=True))
        layout.addWidget(apply, alignment=Qt.AlignmentFlag.AlignLeft)
        self.status, self.names_status = QLabel(), QLabel()
        for label in (self.status, self.names_status):
            label.setWordWrap(True)
            label.setTextFormat(Qt.TextFormat.PlainText)
            layout.addWidget(label)
        self.program.status.connect(self.status.setText)
        self.input_names.status.connect(self.names_status.setText)
        self._apply(save=False)

    def _apply(self, *, save):
        address = self.address.text().strip()
        mixes_text = self.mixes.text().strip()
        auto, rename = self.follow.isChecked(), self.rename_inputs.isChecked()
        inputs = tuple(f.value() for f in self.slot_inputs)
        try:
            if address:
                address = str(ip_address(address))
            if (auto or rename or mixes_text) and not address:
                raise ValueError('Укажите IP компьютера с vMix.')
            numbers = [n for n in inputs if n]
            if len(numbers) != len(set(numbers)):
                raise ValueError('Укажите разные входы vMix. Ноль отключает позицию.')
            if mixes_text and not re.fullmatch(r'[1-9][0-9]*(?:[\s,;]+[1-9][0-9]*)*', mixes_text, re.ASCII):
                raise ValueError('Укажите номера Mix через запятую, например 2, 3.')
            mixes = tuple(dict.fromkeys(int(n) for n in re.findall(r'[0-9]+', mixes_text)))
            if auto and not mixes:
                raise ValueError('Укажите Mix для автоматического переключения.')
        except ValueError as exc:
            self.status.setText(str(exc))
            return
        self.endpoint = address, self.port.value()
        self.inputs, self.auto, self.rename = inputs, auto, rename
        self.program.configure(*self.endpoint, mixes)
        if save:
            self.settings.setValue('povVmix', json.dumps(dict(address=address, port=self.port.value(),
                                   mixes=mixes_text, followProgram=auto, renameInputs=rename, slotInputs=inputs)))
        self.status.setText('Настройки POV применены.' if save else '')
        self._refresh()
        self.mappings_changed.emit()
        if self.auto and self.observed:
            self.take(self.observed, automatic=True)

    def set_hud_slots(self, slots):
        if slots != self.slots:
            self.program.cancel()
            self.slots = slots
            self._refresh()

    def _refresh(self):
        names = {}
        for i, (number, button) in enumerate(zip(self.inputs, self.buttons), 1):
            name = self.slots.get(str(i))
            button.setText(name or '—')
            button.setEnabled(bool(name and number and self.program.mixes))
            if number and name and self.rename:
                names[number] = name
        self.input_names.configure(*self.endpoint, names)
        if not names:
            self.names_status.setText('Ожидание позиций игроков.' if self.rename else '')

    def set_observed(self, slot):
        self.observed = slot
        if self.auto and slot:
            self.take(slot, automatic=True)
        elif self.following_request:
            self.program.cancel()
            self.following_request = False

    def take(self, slot, *, automatic=False):
        if type(slot) is int and 1 <= slot <= 12 and str(slot) in self.slots and self.inputs[slot - 1]:
            self.following_request = automatic
            self.program.select(self.inputs[slot - 1])

    def shutdown(self):
        self.program.cancel()
        self.input_names.close()
