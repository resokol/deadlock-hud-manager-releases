"""Camera process works before Deadlock starts and accepts either match data source."""
from urllib.request import urlopen
import json

import pytest
from PySide6.QtCore import QSettings

from observer_assist.pov_manager import PovManager
from test_camera_workflow import MATCH, Mixer, snapshot
from test_vmix_control import app, fake_api, wait_for


@pytest.fixture
def pov(app, tmp_path):
    settings = QSettings(str(tmp_path / 'pov.ini'), QSettings.Format.IniFormat)
    window = PovManager(settings)
    try:
        yield window
    finally:
        window.close()


def test_source_switch_clears_all_old_slots_and_exposes_confirmed_remote_order(pov, fake_api):
    panel = pov.vdo_panel
    names = [f'Player {i}' for i in range(1, 13)]
    snapshot(pov, names)
    assert pov.names == tuple(names)
    assert not pov.camera_roster.slots  # SourceTV estimates require confirmation for account-based routing.
    assert 'SourceTV' in panel.positions.hint.text()
    pov.camera_roster.apply.click()
    assert pov.camera_roster.slots[1] == '501'
    assert 'Ручной порядок' in panel.positions.hint.text()
    pov.mode.setCurrentIndex(1)
    assert not pov.names and not pov.camera_roster.slots
    assert pov.companion.payload['pov_inputs'] == {}

    slots = {str(i): name for i, name in enumerate(reversed(names), 1)}
    remote = dict(version=1, status='live', panorama_match_id='999',
                  panorama_slots=slots, panorama_observed_slot=3)
    fake_api.answer = lambda _: (200, {}, json.dumps(remote).encode())
    pov.remote_url.setText(f'http://127.0.0.1:{fake_api.server_port}/api/v1/stats?token=test')
    pov._connect_remote()
    wait_for(lambda: pov.names == tuple(reversed(names)))
    assert pov.companion.payload['hud_slots'] == slots
    assert pov.companion.payload['hud_observed_slot'] == 3
    assert pov.companion.payload['camera_slots']['1']['account_id'] == ''
    pov.mode.setCurrentIndex(0)
    assert not pov.names and not pov.remote.snapshot


def test_pov_room_can_apply_before_match_and_companion_uses_own_port(pov, fake_api):
    vmix = Mixer(fake_api, 1200)
    panel = pov.vdo_panel
    pov.vdo_import.open_url = lambda _: True
    panel.url.setText('https://vdo.ninja/?director=room')
    panel.connect_button.click()
    pov.vdo_import._accept(pov.vdo_import.generation, [dict(streamID='cam-player', label='Player One', video='live')])
    panel.vmix_host.setText('127.0.0.1')
    panel.vmix_port.setValue(vmix.port)
    panel.apply_vmix.click()
    wait_for(lambda: vmix.names[1] == 'Player One' and not pov.vdo_publisher.busy)
    assert not pov.names and not pov.source_tv.roster
    assert pov.companion.port.value() == 53559
    pov.companion.network.setCurrentIndex(pov.companion.network.findData('127.0.0.1/8'))
    pov.companion.share.setChecked(True)
    server = pov.companion.server
    assert server is not None
    with urlopen(server.url, timeout=2) as response:
        assert json.load(response)['status'] == 'waiting'
    snapshot(pov, [f'Player {i}' for i in range(1, 13)])
    panel.positions.inputs[1].setValue(21)
    with urlopen(server.url, timeout=2) as response:
        data = json.load(response)
    assert data['pov_inputs']['21'] == 'Player 2'
    assert '2' not in data['pov_inputs']
    assert 'cam-player' not in json.dumps(data)
    assert not hasattr(pov, 'hud_library') and not hasattr(pov, '_telemetry')


def test_remote_observer_drives_live_and_companion_drives_replay(pov, fake_api, monkeypatch):
    from urllib.request import Request
    from observer_assist import camera_vmix
    from observer_assist.pov_match_data import RemoteMatch
    from test_camera_workflow import configure

    monkeypatch.setattr(camera_vmix, 'POLL_MS', 60)
    mixer = Mixer(fake_api, 1500)
    names = [f'Player {i}' for i in range(1, 13)]
    src = [dict(side=side, players=[dict(name=names[i], accountId=str(100 + i)) for i in indices])
           for side, indices in [(2, range(6)), (3, range(6, 12))]]
    before = pov.cameras.preparation_rows()
    draft = list(before)
    for i in range(2):
        draft[i] = (str(100 + i), names[i], f'https://vdo.ninja/?view=test{i}')
    pov.cameras.save_preparation(before, draft)
    configure(pov, 'live', mixer)
    configure(pov, 'replay', mixer)
    pov.mode.setCurrentIndex(1)
    pov.remote.snapshot = RemoteMatch(MATCH, tuple(names), 2, dict(matchId=MATCH, teams=src))
    pov.remote.changed.emit(pov.remote.snapshot)
    wait_for(lambda: mixer.active[1] == 2 and pov.companion.payload['camera_slots']['1']['replay_ready'])
    pov.companion.network.setCurrentIndex(pov.companion.network.findData('127.0.0.1/8'))
    pov.companion.share.setChecked(True)
    server = pov.companion.server
    with urlopen(Request(server.program_url(1), method='POST'), timeout=2) as response:
        assert response.status == 202
    wait_for(lambda: mixer.active[2] == 3)
    assert mixer.active[1] == 2 and 'test0' not in json.dumps(pov.companion.payload)
