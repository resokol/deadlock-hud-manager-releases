"""Standalone production camera workspace. Match acquisition is optional before camera setup."""
import sys
from pathlib import Path
from secrets import token_urlsafe

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QFormLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QScrollArea, QSpinBox, QStackedWidget, QTabWidget, QVBoxLayout, QWidget,
)

from .broadcast_tables import players_by_match_position
from .camera_mapping import operator_camera_mapping
from .camera_panel import CameraPanel
from .camera_roster import CameraRoster
from .camera_routing import CameraRouting
from .camera_vdo import VdoImport
from .camera_vdo_panel import VdoRoomPanel
from .camera_vdo_publish import VdoVmixPublisher, publish_room_cameras
from .hud_pov import VmixPovPanel
from .live_stats_panel import lan_interfaces
from .match_stats import STATS_PORT, StatsLanServer
from .pov_remote import PovRemote
from .source_tv_panel import SourceTvPanel
from .ui import STYLE
from .win32 import set_dpi_awareness


class CompanionPanel(QWidget):
    """Publish completed Qt snapshots; deliver replay requests back to the GUI thread."""
    take_requested = Signal(int, str, str, str)

    def __init__(self, settings):
        super().__init__()
        self.settings = settings
        self.server = None
        self.payload = {}
        form = QFormLayout(self)
        self.share = QCheckBox('Доступ для Companion')
        self.network = QComboBox()
        for name, addr in lan_interfaces():
            self.network.addItem(f'{name} · {addr.ip}', str(addr))
        self.network.addItem('На этом ПК · 127.0.0.1', '127.0.0.1/8')
        selected = self.network.findData(settings.value('statsExportAddress', '', type=str))
        self.network.setCurrentIndex(max(0, selected))
        self.port = QSpinBox()
        self.port.setRange(1, 65535)
        self.port.setValue(settings.value('povCompanionPort', STATS_PORT + 1, type=int))
        self.port.setKeyboardTracking(False)
        self.copy = QPushButton('Копировать URL JSON для Companion')
        self.copy.clicked.connect(self._copy_json)
        self.slot = QSpinBox()
        self.slot.setRange(1, 12)
        post = QHBoxLayout()
        post.addWidget(self.slot)
        self.copy_post = QPushButton('Копировать URL POST для Replay')
        self.copy_post.clicked.connect(self._copy_post)
        post.addWidget(self.copy_post)
        self.status = QLabel()
        self.status.setWordWrap(True)
        form.addRow(self.share)
        form.addRow('Сетевой интерфейс', self.network)
        form.addRow('Порт', self.port)
        form.addRow(self.copy)
        form.addRow('Позиция кнопки', post)
        form.addRow(self.status)
        self.share.setChecked(settings.value('statsExportEnabled', False, type=bool))
        self.share.toggled.connect(self._configure)
        self.network.currentIndexChanged.connect(self._configure)
        self.port.valueChanged.connect(self._configure)
        self._configure()

    def _configure(self):
        self.stop()
        s = self.settings
        s.setValue('statsExportEnabled', self.share.isChecked())
        address = self.network.currentData()
        s.setValue('statsExportAddress', address)
        s.setValue('povCompanionPort', self.port.value())
        text = ''
        if self.share.isChecked():
            def token(key):
                value = s.value(key, '', type=str) or token_urlsafe(24)
                s.setValue(key, value)
                return value

            try:
                self.server = StatsLanServer(address, token('statsExportToken'), lambda: self.payload,
                                            port=self.port.value(), take=self._queue_take,
                                            control_token=token('povControlToken'))
                text = f'Доступно · {self.server.address}:{self.server.port}'
            except (ValueError, OSError) as exc:
                text = f'Подключение недоступно. {exc}'
        self.status.setText(text)
        for item in (self.copy, self.slot, self.copy_post):
            item.setEnabled(self.server is not None)

    def _queue_take(self, slot):
        row = self.payload.get('camera_slots', {}).get(str(slot), {})
        if row.get('replay_ready'):
            self.take_requested.emit(slot, row.get('account_id') or '', row['match_id'], row['name'])
            return True
        return False

    def _copy_json(self):
        if self.server:
            QApplication.clipboard().setText(self.server.url)

    def _copy_post(self):
        if self.server:
            QApplication.clipboard().setText(self.server.program_url(self.slot.value()))

    def stop(self):
        if self.server:
            self.server.close()
            self.server = None


class PovManager(QWidget):
    def __init__(self, settings):
        super().__init__()
        self.settings = settings
        self.setWindowTitle('Deadlock POV Manager')
        self.setStyleSheet(STYLE)
        self.setMinimumSize(600, 420)
        self.resize(1120, 760)
        layout = QVBoxLayout(self)
        heading = QLabel('Deadlock POV Manager')
        heading.setObjectName('title')
        layout.addWidget(heading)
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)

        self.source_tv = SourceTvPanel(self)
        self.remote = PovRemote(self)
        self.camera_roster = CameraRoster(settings)
        self.camera_panels = {role: CameraPanel(role) for role in ('live', 'replay')}
        self.cameras = CameraRouting(settings, self.camera_roster, self.camera_panels, self)
        self.pov = VmixPovPanel(settings, suspended=self.cameras.managed)
        self.cameras.activated.connect(self.pov.suspend)
        self.vdo_panel = VdoRoomPanel(settings)
        self.vdo_import = VdoImport(self.vdo_panel, self.cameras, self)
        self.vdo_publisher = VdoVmixPublisher(self)
        self.vdo_panel.apply_vmix_requested.connect(self._publish)
        self.vdo_publisher.result.connect(self.vdo_panel.vmix_result)
        self.vdo_publisher.position_result.connect(self.vdo_panel.vmix_position_result)
        self.vdo_publisher.finished.connect(self.vdo_panel.vmix_finished)
        self.vdo_import.freshness_changed.connect(self.vdo_panel.set_room_fresh)
        self.vdo_import.freshness_changed.connect(self._room_fresh)
        self.cameras.inputs_claimed.connect(self._claimed)
        self.camera_roster.bind_camera_mapping(lambda: operator_camera_mapping(
            self.camera_roster, self.cameras, self.vdo_import))
        self.companion = CompanionPanel(settings)
        self.companion.take_requested.connect(self._take)
        self.names, self.match_id, self.observed = (), '', None
        self._update_in_progress = False
        self._add_tab(self.vdo_panel, 'VDO Ninja')
        self._add_tab(self._source_page(), 'Матч и позиции')
        for role in ('live', 'replay'):
            self._add_tab(self.camera_panels[role], role.title())
        companion_index = self._add_tab(self.companion, 'Companion')
        self._add_tab(self.cameras.bank_widget, 'Пары и журнал')
        self._add_tab(self.pov, 'POV vMix')
        self.camera_panels['replay'].companion_requested.connect(
            lambda: self.tabs.setCurrentIndex(companion_index))
        self.remote.changed.connect(self._read_source)
        self.remote.status.connect(self.remote_status.setText)
        self.source_tv.roster_changed.connect(self._read_source)
        self.source_tv.target_changed.connect(self._read_source)
        self.camera_roster.changed.connect(self._render_order)
        self.cameras.changed.connect(self._export)
        self.pov.mappings_changed.connect(self._export)
        self.vdo_panel.positions.edited.connect(self._export)
        self.vdo_panel.position_media_changed.connect(self._export)
        self.mode.currentIndexChanged.connect(self._switch_source)
        self.mode.setCurrentIndex(max(0, self.mode.findData(settings.value('povMatchSource', 'match', type=str))))
        self._read_source()

    def _add_tab(self, widget, name):
        area = QScrollArea()
        area.setWidgetResizable(True)
        area.setFrameShape(QScrollArea.Shape.NoFrame)
        area.setWidget(widget)
        return self.tabs.addTab(area, name)

    def _source_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        self.mode = QComboBox()
        self.mode.addItem('По Match ID (SourceTV)', 'match')
        self.mode.addItem('Panorama по сети (HUD Manager)', 'remote')
        layout.addWidget(self.mode)
        self.sources = QStackedWidget()
        self.sources.addWidget(self.source_tv)
        network = QWidget()
        form = QFormLayout(network)
        self.remote_url = QLineEdit(self.settings.value('povHudUrl', '', type=str))
        self.remote_url.setPlaceholderText('Из HUD Manager · Статистика → Копировать URL JSON матча')
        self.remote_url.setEchoMode(QLineEdit.EchoMode.PasswordEchoOnEdit)
        form.addRow('URL JSON матча', self.remote_url)
        buttons = QHBoxLayout()
        connect = QPushButton('Подключить')
        connect.clicked.connect(self._connect_remote)
        self.remote_url.returnPressed.connect(self._connect_remote)
        stop = QPushButton('Отключить')
        stop.clicked.connect(self.remote.stop)
        buttons.addWidget(connect)
        buttons.addWidget(stop)
        form.addRow(buttons)
        self.remote_status = QLabel()
        self.remote_status.setWordWrap(True)
        form.addRow(self.remote_status)
        self.sources.addWidget(network)
        layout.addWidget(self.sources)
        self.order_status = QLabel()
        self.order_status.setWordWrap(True)
        self.order_status.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.order_status)
        layout.addWidget(self.camera_roster)
        prepare = QPushButton('Камеры до матча…')
        prepare.clicked.connect(lambda: self.cameras.edit_preparation(self))
        layout.addWidget(prepare, alignment=Qt.AlignmentFlag.AlignLeft)
        return page

    def _switch_source(self, index):
        self.settings.setValue('povMatchSource', self.mode.currentData())
        self.sources.setCurrentIndex(index)
        if self.mode.currentData() == 'remote':
            self.source_tv.stop()
        else:
            self.remote.stop()
        self._read_source()

    def _connect_remote(self):
        url = self.remote_url.text().strip()
        self.settings.setValue('povHudUrl', url)
        self.remote.set_url(url)

    def _read_source(self, *_):
        net = self.mode.currentData() == 'remote'
        packet = self.remote.snapshot if net else None
        roster = self.source_tv.roster
        if net:
            roster = packet.roster if packet else None
        if not net and self.source_tv.requested_match_id and str((roster or {}).get('matchId')) != self.source_tv.requested_match_id:
            roster = None
        slots = dict(enumerate(packet.names, 1)) if packet else {}
        self._update_in_progress = True
        try:
            self.camera_roster.update_match(roster, {str(i): name for i, name in slots.items()},
                                            packet.observed if packet else None, bool(packet and roster))
        finally:
            self._update_in_progress = False
        self._render_order()

    def _render_order(self):
        if self._update_in_progress:
            return
        packet = self.remote.snapshot if self.mode.currentData() == 'remote' else None
        trusted = self.camera_roster.manual_names()
        match_id = self.camera_roster.match_id or ''
        observed = None
        if packet:
            # Follow the same person when an operator overrides the visual ordering.
            names = trusted or packet.names
            selected = packet.names[packet.observed - 1] if packet.observed else None
            observed = names.index(selected) + 1 if selected in names else None
            source = (f'Ручной порядок · матч {packet.match_id}' if trusted else packet.source)
            match_id = packet.match_id
        elif self.mode.currentData() == 'match':
            roster = self.source_tv.roster
            requested = self.source_tv.requested_match_id
            if requested and str((roster or {}).get('matchId')) != requested:
                roster = None
            match_id = str((roster or {}).get('matchId') or '')
            api = players_by_match_position(roster)
            names = trusted or tuple(api[str(i)] for i in range(1, len(api) + 1))
            source = f'Ручной порядок · матч {match_id}' if trusted else f'SourceTV · матч {match_id} · сверьте порядок по линиям с HUD.'
        else:
            names, source = (), ''
        if not match_id or len(names) != 12 or len({name.strip().casefold() for name in names}) != 12:
            names, source = (), ''
        self.names, self.match_id, self.observed = names, match_id, observed
        self.order_status.setText(source or 'Ожидание позиций игроков.')
        self.vdo_panel.set_hud_order(names, source)
        self.pov.set_hud_slots({str(i): name for i, name in enumerate(names, 1)})
        self.pov.set_observed(observed)
        self._export()

    def _export(self):
        cameras = self.cameras
        slots = {}
        labels = {}
        pov_inputs = {}
        numbers = tuple(field.value() for field in self.vdo_panel.positions.inputs)
        if cameras.managed:
            numbers = tuple(live or direct for live, direct in zip(cameras.input_numbers(), numbers))
        elif self.pov.auto or self.pov.rename or self.pov.copy_mixes or self.pov.player_pages:
            numbers = self.pov.inputs
        for i, name in enumerate(self.names, 1):
            key = str(i)
            account = self.camera_roster.slots.get(i, '')
            bank = cameras.owners.index(account) if account and account in cameras.owners else None
            physical = numbers[i - 1]
            if physical:
                pov_inputs.setdefault(str(physical), []).append(name)
            ready = cameras.routable('replay', account) if cameras.managed and account else bool(
                not cameras.managed and self.pov.targets(i))
            media = self.vdo_panel.position_media(i)
            if cameras.managed:
                has_camera = bool(account and cameras.has_camera(account))
            else:
                has_camera = media == 'live'
            player = self.camera_roster.players.get(account, {})
            slots[key] = dict(name=name, account_id=account, match_id=self.match_id, key='1234567890-='[i - 1],
                              has_camera=has_camera, vdo_video=media, replay_ready=ready, hero=player.get('hero'),
                              hero_id=player.get('heroId'), team=player.get('side'),
                              live_guid=cameras.config['live']['guids'][bank] if bank is not None else '',
                              replay_guid=cameras.config['replay']['guids'][bank] if bank is not None else '')
            labels[key] = name + ('\nНет камеры' if (cameras.managed and not has_camera) or media == 'absent' else
                                  '\nНедоступна' if cameras.managed and not ready else '')
        self.companion.payload = dict(version=1, matchId=self.match_id or None, status='live' if slots else 'waiting',
            hud_slots={key: row['name'] for key, row in slots.items()}, hud_observed_slot=self.observed,
            pov_inputs={key: group[0] for key, group in pov_inputs.items() if len(group) == 1},
            camera_slots=slots, replay_button_labels={str(i): labels.get(str(i), '—') for i in range(1, 13)})

    def _take(self, slot, account, match_id, name):
        row = self.companion.payload.get('camera_slots', {}).get(str(slot), {})
        if not row.get('replay_ready') or (row['account_id'], row['match_id'], row['name']) != (account, match_id, name):
            return
        if self.cameras.managed:
            self.cameras.take('replay', slot)
        else:
            self.pov.take(slot)

    def _room_fresh(self, fresh):
        if not fresh:
            self.vdo_publisher.cancel()

    def _claimed(self, endpoint, guids):
        if self.vdo_publisher.active_endpoint == endpoint:
            self.vdo_publisher.cancel()
        self.vdo_publisher.forget(guids, endpoint=endpoint)

    def _publish(self, host, port, rows):
        publish_room_cameras(self, self.vdo_panel, self.vdo_import, self.vdo_publisher,
                             self.cameras, self.pov, host, port, rows)

    def closeEvent(self, event):
        self.companion.stop()
        self.remote.stop()
        self.source_tv.stop()
        self.vdo_publisher.cancel()
        self.vdo_import.stop()
        self.cameras.close()
        self.pov.shutdown()
        self.source_tv.process.waitForFinished(1500)
        self.settings.sync()
        super().closeEvent(event)


def main(settings=None):
    set_dpi_awareness()
    app = QApplication(sys.argv[:1])
    app.setWindowIcon(QIcon(str(Path(__file__).with_name('assets') / 'dhm.ico')))
    if settings is None:
        from .manager_settings import pov_settings
        settings = pov_settings()
    window = PovManager(settings)
    window.show()
    return app.exec()


if __name__ == '__main__':
    raise SystemExit(main())
