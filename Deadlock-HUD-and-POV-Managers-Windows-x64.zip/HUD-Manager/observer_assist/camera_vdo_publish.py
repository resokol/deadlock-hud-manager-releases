"""Publish one selection of guest URLs and labels to existing vMix browser inputs."""

from collections import Counter, deque
from dataclasses import dataclass, field
from hashlib import sha256
from ipaddress import IPv4Address
from urllib.parse import urlencode
from xml.etree import ElementTree

from PySide6.QtCore import QObject, QTimer, QUrl, Signal
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkProxy, QNetworkReply, QNetworkRequest

from .camera_preparation import camera_identity, camera_page
from .camera_vmix import _read_state, browser_source
from .match_stats import is_lan_address
from .vmix_control import REQUEST_TIMEOUT_MS, _guid


@dataclass
class _Row:
    page: str
    label: str
    number: int
    guid: str = ''
    done: bool = False
    started: bool = False

    @property
    def clear(self):
        return self.page == '' and self.label == '-'


@dataclass
class _Batch:
    address: tuple
    url: QUrl
    rows: list
    validate: object
    authorize: object
    queue: deque = field(default_factory=deque)
    counts: Counter = field(default_factory=Counter)
    preset: str = ''
    cancelling: bool = False


class VdoVmixPublisher(QObject):
    """Finite batches. The private first argument of result identifies the panel row."""

    result = Signal(str, str)
    position_result = Signal(int, str)
    finished = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._network = QNetworkAccessManager(self)
        self._network.setProxy(QNetworkProxy(QNetworkProxy.ProxyType.NoProxy))
        self._batch = None
        self._reply = None
        self._deadline = QTimer(self, singleShot=True)
        self._deadline.timeout.connect(self._timeout)
        self._pages = {}  # (endpoint, GUID) -> digest of acknowledged navigation
        self._presets = {}

    @property
    def busy(self):
        return self._batch is not None

    @property
    def active_endpoint(self):
        return self._batch.address if self._batch is not None else None

    def forget(self, guids, endpoint=None):
        """Invalidate URL acknowledgements when another controller edited these inputs."""
        selected = {_guid(guid) for guid in guids}
        self._pages = {key: digest for key, digest in self._pages.items()
                       if key[1] not in selected or (endpoint is not None and key[0] != endpoint)}

    def start(self, host, port, rows, *, validate=None, authorize=None):
        """An explicit ('', '-', number) clears that browser. validate guards each write."""
        if self.busy:
            return False
        try:
            ip = IPv4Address(host)
            port = int(port)
            if not (is_lan_address(ip) or ip.is_loopback) or not 1 <= port <= 65535:
                raise ValueError
        except (TypeError, ValueError):
            self.finished.emit('Проверьте локальный IP-адрес и порт vMix.')
            return False
        try:
            targets = [_Row(page, label, number) for page, label, number in rows]
            if not 1 <= len(targets) <= 12:
                raise ValueError
            for row in targets:
                if (type(row.number) is not int or row.number < 1 or not isinstance(row.label, str)
                        or not isinstance(row.page, str)):
                    raise ValueError
            numbers = {row.number for row in targets}
            cameras = [row for row in targets if not row.clear]
            guests = {camera_identity(row.page) for row in cameras}
            labels = [row.label.strip().casefold() for row in cameras if row.label.strip()]
            if len(numbers) != len(targets) or len(guests) != len(cameras) or len(set(labels)) != len(labels):
                self.finished.emit('Повторяются гости, Label или номера входов. Проверьте назначения.')
                return False
        except (TypeError, ValueError):
            self.finished.emit('Выберите от 1 до 12 гостей и укажите их номера входов vMix.')
            return False
        url = QUrl(f'http://{ip}:{port}/api/')
        batch = _Batch((str(ip), port), url, targets, validate, authorize)
        self._batch = batch
        self._catalog(batch, self._plan)
        return True

    def cancel(self):
        batch = self._batch
        if batch is None or batch.cancelling:
            return
        batch.cancelling = True
        self._deadline.stop()
        reply, self._reply = self._reply, None
        if reply is not None:
            reply.abort()
        for row in batch.rows:
            if not row.done:
                message = 'Дальнейшая отправка отменена. Проверьте вход в vMix.' if row.started else 'Отменено.'
                self._report(batch, row, 'skip', message)
        self._finish(batch)

    def _finish(self, batch):
        if self._batch is batch:
            self._batch = None
            counts = batch.counts
            prefix = 'Отправка отменена. ' if batch.cancelling else ''
            self.finished.emit(f'{prefix}Готово: {counts["ok"]}. Пропущено: {counts["skip"]}. Ошибок: {counts["error"]}.')

    def _report(self, batch, row, category, message):
        row.done = True
        batch.counts[category] += 1
        text = f'Вход {row.number}: {message}'
        self.result.emit(row.page, text)
        if self._batch is batch:
            self.position_result.emit(row.number, text)

    def _end_remaining(self, batch, category, message):
        for row in batch.rows:
            if self._batch is not batch:
                return
            if not row.done:
                self._report(batch, row, category, message)
        self._finish(batch)

    def _request(self, batch, command, callback):
        url = QUrl(batch.url)
        if command:
            url.setQuery(urlencode(command))
        request = QNetworkRequest(url)
        request.setTransferTimeout(REQUEST_TIMEOUT_MS)
        request.setAttribute(QNetworkRequest.Attribute.RedirectPolicyAttribute,
                             QNetworkRequest.RedirectPolicy.ManualRedirectPolicy)
        reply = self._network.get(request)
        self._reply = reply

        def finished():
            reply.deleteLater()
            if self._reply is not reply or self._batch is not batch:
                return
            self._reply = None
            self._deadline.stop()
            code = reply.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute)
            ok = code == 200 and reply.error() == QNetworkReply.NetworkError.NoError
            error = '' if ok else (f'HTTP {code}' if code else 'нет ответа от Web Controller')
            callback(error, bytes(reply.readAll()) if ok and not command else b'')

        reply.finished.connect(finished)
        self._deadline.start(REQUEST_TIMEOUT_MS)

    def _timeout(self):
        if self._reply is not None:
            self._reply.abort()

    def _catalog(self, batch, callback):
        def receive(error, payload):
            if error:
                self._end_remaining(batch, 'error', f'Не удалось прочитать входы vMix ({error}).')
                return
            try:
                state = _read_state(payload)
            except (ElementTree.ParseError, ValueError):
                self._end_remaining(batch, 'error', 'Web Controller вернул некорректный список входов.')
                return
            previous = self._presets.get(batch.address)
            changed = bool(previous and state.preset and previous != state.preset)
            self._pages = {key: digest for key, digest in self._pages.items()
                           if key[0] != batch.address or (not changed and key[1] in state.browsers)}
            if state.preset:
                self._presets[batch.address] = state.preset
                if batch.preset and batch.preset != state.preset:
                    self._end_remaining(batch, 'skip', 'Пресет изменился. Проверьте номера входов.')
                    return
                batch.preset = state.preset
            callback(batch, state)

        self._request(batch, None, receive)

    def _current(self, batch, row):
        try:
            valid = batch.validate is None or batch.validate(row.page, row.label, row.number)
        except Exception:
            valid = False
        if self._batch is not batch:
            return False
        if not valid:
            self._report(batch, row, 'skip', 'Гость или выбранный вход изменился.')
            return False
        return True

    def _plan(self, batch, state):
        numbers = {info['number']: guid for guid, info in state.inputs.items()}
        for row in batch.rows:
            if self._batch is not batch:
                return
            row.guid = numbers.get(row.number, '')
            url = QUrl(row.page, QUrl.ParsingMode.StrictMode)
            if not row.label.strip() or len(row.label) > 256 or not row.label.isprintable() or '://' in row.label:
                self._report(batch, row, 'skip', 'Нужен корректный Label гостя.')
            elif not row.clear and (not url.isValid() or url.scheme() not in ('http', 'https') or not url.host()):
                self._report(batch, row, 'skip', 'Некорректная ссылка гостя.')
            elif not row.guid:
                self._report(batch, row, 'skip', 'Вход отсутствует в пресете.')
            elif not browser_source(state.inputs[row.guid]):
                self._report(batch, row, 'skip', 'Нужен оригинальный вход Web Browser.')
            elif self._current(batch, row):
                batch.queue.append(row)
        if self._batch is not batch:
            return
        if batch.queue and batch.authorize is not None:
            try:
                approved = batch.authorize({row.guid for row in batch.queue})
            except Exception:
                approved = False
            if self._batch is not batch:
                return
            if not approved:
                self.cancel()
                return
        self._next(batch)

    def _next(self, batch):
        if self._batch is not batch:
            return
        if not batch.queue:
            self._finish(batch)
            return
        # Re-read after operator confirmation and between rows. Input numbers may move.
        self._catalog(batch, self._apply)

    def _apply(self, batch, state, *, navigated=False):
        row = batch.queue[0]
        info = state.inputs.get(row.guid, {})
        if info.get('number') != row.number or not browser_source(info):
            self._report(batch, row, 'skip', 'Вход изменился после проверки пресета.')
        elif self._current(batch, row):
            rendered = camera_page(row.page)
            applied = 'Прозрачный источник с названием «-».' if row.clear else 'Страница и Label применены.'
            key = batch.address, row.guid
            digest = sha256(rendered.encode()).digest()
            if self._pages.get(key) != digest:
                if navigated:
                    self._complete_row(batch, row, 'skip', 'Источник изменился. Повторите проверку входа.')
                    return
                self._pages.pop(key, None)
                row.started = True
                command = dict(Function='BrowserNavigate', Input=row.guid, Value=rendered)

                def after_navigation(error, _):
                    if error:
                        self._complete_row(batch, row, 'error', f'Не удалось открыть страницу ({error}).')
                    else:
                        self._pages[key] = digest
                        # Navigation can also change the current title. Check again before renaming.
                        self._catalog(batch, lambda current, catalog: self._apply(current, catalog, navigated=True))
                self._request(batch, command, after_navigation)
                return
            if info['title'] != row.label:
                row.started = True
                command = dict(Function='SetInputName', Input=row.guid, Value=row.label)

                def renamed(error, _):
                    if error:
                        self._complete_row(batch, row, 'error', f'Страница открыта, ошибка переименования ({error}).')
                    else:
                        self._complete_row(batch, row, 'ok', applied)
                self._request(batch, command, renamed)
                return
            self._report(batch, row, 'ok', applied)
        if self._batch is batch:
            batch.queue.popleft()
            self._next(batch)

    def _complete_row(self, batch, row, category, message):
        batch.queue.popleft()
        self._report(batch, row, category, message)
        self._next(batch)


def publish_room_cameras(parent, panel, room, publisher, cameras, legacy_panel, host, port, rows):
    from PySide6.QtWidgets import QMessageBox

    generation = room.generation

    def current(page, label, number):
        return (room.generation == generation and room.fresh
                and panel.is_current_vmix_row(page, label, number))

    def authorize(guids):
        endpoint = host, port
        roles = cameras.conflicting_modules(endpoint, guids)
        legacy = (not legacy_panel.suspended and legacy_panel.endpoint == endpoint
                  and (legacy_panel.rename or legacy_panel.player_pages) and
                  any(number in legacy_panel.inputs + legacy_panel.virtual_inputs for _, _, number in rows))
        if roles or legacy:
            names = ', '.join([r.title() for r in roles] + (['POV vMix'] if legacy else []))
            choice = QMessageBox.question(parent, 'Передать входы в VDO Ninja',
                f'Этими входами управляет {names}. Остановить это управление и записать камеры из комнаты? '
                'Текущий выбор Program сохранится, изображение изменённых входов обновится.',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
            if choice != QMessageBox.StandardButton.Yes or not all(current(*row) for row in rows):
                return False
            if legacy:
                cameras.managed = True
                cameras.activated.emit()
                cameras.save()
            publisher.forget(guids, endpoint=endpoint)
        cameras.release_inputs(endpoint, guids, roles)
        return True

    if not room.fresh:
        panel.vmix_finished('Дождитесь свежего списка камер из комнаты.')
        return
    publisher.start(host, port, rows, validate=current, authorize=authorize)
