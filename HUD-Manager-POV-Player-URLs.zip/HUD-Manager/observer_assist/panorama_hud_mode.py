"""Serve local HUD web packages and their current Panorama state."""

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from ipaddress import ip_address
import json
from mimetypes import guess_type
from pathlib import Path, PurePosixPath
import re
import sys
from threading import Condition, Thread
from time import monotonic
from urllib.parse import parse_qs, unquote, urlsplit

from .broadcast_tables import BROADCAST_ROUTES, broadcast_rows, mapped_player_rows, observed_hud_slot, players_by_input, players_by_portrait
from .fight_recap import FIGHT_RECAP_ROUTE, FightRecap, example_recap
from .hud_nicknames import clean_aliases, with_display_names
from .hud_packages import WEB_ROOT
from .game_icons import icon_root, refresh
from .hero_stats import HERO_STATS_ROUTE, HeroStatistics, public_telemetry
from .match_stats import STATS_ROUTE, STATS_WEB_FILES, is_stats_asset, match_stats
from .minimap_graphics import SpectatorMinimap, minimap_preview


PORT = 53557
STATS_READERS = {STATS_ROUTE: 'stats', HERO_STATS_ROUTE: 'hero_stats', FIGHT_RECAP_ROUTE: 'fight_recap'}
WEB_FILES = {
    '/hud/': ('active.html', 'text/html; charset=utf-8'),
    '/hud-active.js': ('active.js', 'text/javascript; charset=utf-8'),
    '/hud-client.js': ('client.js', 'text/javascript; charset=utf-8'),
    '/hud-player-status.css': ('player-status.css', 'text/css; charset=utf-8'),
    '/hud-rift.js': ('rift.js', 'text/javascript; charset=utf-8'),
    '/hud-rift.css': ('rift.css', 'text/css; charset=utf-8'),
    '/hud-mid-boss.js': ('mid-boss.js', 'text/javascript; charset=utf-8'),
    '/hud-inventory.js': ('inventory.js', 'text/javascript; charset=utf-8'),
    '/hud-editor/': ('editor/index.html', 'text/html; charset=utf-8'),
    '/hud-editor/editor.css': ('editor/editor.css', 'text/css; charset=utf-8'),
    '/hud-editor/editor.js': ('editor/editor.js', 'text/javascript; charset=utf-8'),
    '/hud-editor/canvas.css': ('editor/canvas.css', 'text/css; charset=utf-8'),
    '/hud-editor/render.js': ('editor/render.js', 'text/javascript; charset=utf-8'),
    '/hud-editor/overlay.html': ('editor/overlay.html', 'text/html; charset=utf-8'),
    '/hud-editor/overlay.js': ('editor/overlay.js', 'text/javascript; charset=utf-8'),
    '/hud-editor/hud_code.js': ('editor/hud_code.js', 'text/javascript; charset=utf-8'),
    **STATS_WEB_FILES,
}
WEB_TYPES = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'text/javascript',
    '.mjs': 'text/javascript',
    '.json': 'application/json',
    '.svg': 'image/svg+xml',
    '.webp': 'image/webp',
}
WEB_POLICY = (
    "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; "
    "img-src 'self' data: blob:; font-src 'self' data:; media-src 'self' blob:; "
    "object-src 'none'; form-action 'none'; base-uri 'self'; frame-ancestors 'self'"
)
STUDIO_POLICY = (WEB_POLICY
                 .replace("img-src 'self' data: blob:", "img-src 'self' data: blob: http: https:")
                 .replace("media-src 'self' blob:", "media-src 'self' blob: http: https:")
                 + "; frame-src 'self' http: https:")
VIDEO_FORMATS = ('video', 'mjpeg', 'iframe')
_FOLLOW_RAW_TELEMETRY = object()


def _player_status(snapshot):
    if not snapshot or not isinstance(snapshot.get('selected'), dict):
        return snapshot
    selected = snapshot['selected']
    hp, maximum = selected.get('hp'), selected.get('maxHp')
    if not selected.get('player') or type(hp) is not int or type(maximum) is not int or maximum <= 0:
        return snapshot
    updated = dict(selected)
    if type(updated.get('lowHp')) is not bool:
        updated['lowHp'] = 0 < hp and hp * 4 <= maximum
    streak = selected.get('killStreak')
    if type(streak) is int and streak >= 0 and type(updated.get('killingSpree')) is not bool:
        updated['killingSpree'] = streak >= 3
    return {**snapshot, 'selected': updated}


def video_origin(url):
    if not isinstance(url, str) or not url or len(url) > 2048:
        return None
    if any(ord(char) < 33 or char in "\\<>'\"" for char in url):
        return None
    try:
        parsed = urlsplit(url)
        host = parsed.hostname
        port = parsed.port
        if parsed.scheme not in ('http', 'https') or not host or parsed.username is not None or port == 0:
            return None
        try:
            address = ip_address(host)
        except ValueError:
            host = host.encode('idna').decode('ascii')
            if not re.fullmatch(r'[a-z0-9](?:[a-z0-9.-]*[a-z0-9.])?', host):
                return None
        else:
            if getattr(address, 'scope_id', None):
                return None
            host = f'[{address}]' if address.version == 6 else str(address)
    except (ValueError, UnicodeError):
        return None
    suffix = f':{port}' if port and port != (443 if parsed.scheme == 'https' else 80) else ''
    return f'{parsed.scheme}://{host}{suffix}'


class PanoramaTelemetryServer:
    def __init__(self, port=PORT, packages=None, game_icons=None, minimap=None):
        self._updates = Condition()
        self._telemetry = None
        self._hud_telemetry = None
        self._player_aliases = {}
        self._match_roster = None
        self._camera_inputs = {}
        self._position_export = None
        self._hero_source = None
        self._hero_statistics = HeroStatistics()
        self._fight_recap = FightRecap()
        self._fight_match = None
        self._broadcast_url = None
        self._pov = '', 'video'
        self._series = None
        self._revision = 0
        self._closing = False
        self.packages = packages
        self._minimap = minimap
        if self._minimap is None and packages and sys.platform == 'win32':
            self._minimap = SpectatorMinimap()
        self._game_icons = Path(game_icons) if game_icons is not None else icon_root()
        self._preview = json.loads((WEB_ROOT / 'preview.json').read_text(encoding='utf-8')) if packages else None
        self._recap_preview = example_recap(self._preview)

        class Request(BaseHTTPRequestHandler):
            def do_GET(request):
                if request.headers.get('Host') not in (
                    f'127.0.0.1:{self.port}', f'localhost:{self.port}',
                ):
                    request.send_error(403)
                    return
                try:
                    path = urlsplit(request.path)
                    stats_reader = STATS_READERS.get(path.path.removesuffix('/events')) if path.path.endswith('/events') else None
                    if stats_reader:
                        preview = parse_qs(path.query).get('preview') == ['1']
                        read = getattr(self, stats_reader)
                        self.events(request, lambda: read(preview))
                        return
                    if path.path == '/hud-editor/events' and self.packages:
                        preview = parse_qs(path.query).get('preview') == ['1']
                        self.events(request, lambda: {
                            'telemetry': self._graphics_telemetry(preview), **self._pov_state(),
                            **({'series': self._series} if self._series is not None else {}),
                        })
                        return
                    if path.path.startswith('/api/v1/huds/') and path.path.endswith('/events'):
                        package_id = path.path.removeprefix('/api/v1/huds/').removesuffix('/events')
                        preview = parse_qs(path.query).get('preview') == ['1']
                        self.events(request, lambda: self._state(package_id, preview))
                        return
                    result = self._route(path)
                except (OSError, ValueError):
                    request.send_error(404)
                    return
                if result is None:
                    request.send_error(404)
                    return
                body, kind = result
                request.send_response(200)
                request.send_header('Content-Type', kind)
                request.send_header('Cache-Control', 'no-store')
                request.send_header('X-Content-Type-Options', 'nosniff')
                request.send_header('Cross-Origin-Resource-Policy', 'same-origin')
                request.send_header('Content-Security-Policy', self._web_policy(path.path))
                request.send_header('Content-Length', str(len(body)))
                request.end_headers()
                try:
                    request.wfile.write(body)
                except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                    pass

            def log_message(request, *args):
                pass

        self._server = ThreadingHTTPServer(('127.0.0.1', port), Request)
        self.port = self._server.server_port
        Thread(target=self._server.serve_forever, kwargs={'poll_interval': 0.1}, daemon=True).start()
        if packages and port and game_icons is None and sys.platform == 'win32':
            from .steam import find_deadlock_citadel

            try:
                refresh(find_deadlock_citadel())
            except (OSError, RuntimeError):
                pass

    @property
    def url(self):
        return f'http://127.0.0.1:{self.port}'

    @property
    def telemetry(self):
        return self._telemetry

    @telemetry.setter
    def telemetry(self, value):
        self.publish(value)

    def publish(self, value, broadcast_url=None, *, hud_value=_FOLLOW_RAW_TELEMETRY, match_id=None):
        value = _player_status(value)
        public = public_telemetry(value)
        graphic = public if hud_value is _FOLLOW_RAW_TELEMETRY else public_telemetry(_player_status(hud_value))
        if match_id is None and broadcast_url:
            match_id = broadcast_url.rsplit('/', 1)[-1].partition('_')[0]
        with self._updates:
            if (value != self._hero_source or graphic != self._hud_telemetry or
                    broadcast_url != self._broadcast_url or match_id != self._fight_match):
                if value != self._hero_source or match_id != self._fight_match:
                    self._fight_recap.observe(value, match_id)
                self._fight_match = match_id
                self._hero_source = value
                self._telemetry = public
                self._hud_telemetry = graphic
                self._broadcast_url = broadcast_url
                self._revision += 1
                self._updates.notify_all()

    def set_match_roster(self, roster, camera_inputs):
        with self._updates:
            if roster != self._match_roster or camera_inputs != self._camera_inputs:
                self._match_roster = roster
                self._camera_inputs = camera_inputs
                self._revision += 1
                self._updates.notify_all()

    def set_positions(self, slots, observed, inputs, routable_slots):
        export = (dict(slots), observed, tuple(inputs), frozenset(routable_slots))
        with self._updates:
            if export != self._position_export:
                self._position_export = export
                self._revision += 1
                self._updates.notify_all()

    def can_take(self, slot):
        with self._updates:
            if not self._position_export:
                return False
            slots, _, _, routable = self._position_export
            return slot in routable and str(slot) in slots

    def set_pov_source(self, url, media_format):
        if not isinstance(url, str) or media_format not in VIDEO_FORMATS or (url and not video_origin(url)):
            raise ValueError('Недопустимый источник видео POV.')
        with self._updates:
            source = url, media_format
            if source != self._pov:
                self._pov = source
                self._revision += 1
                self._updates.notify_all()

    def set_player_aliases(self, aliases):
        aliases = clean_aliases(aliases)
        with self._updates:
            if aliases != self._player_aliases:
                self._player_aliases = aliases
                self._revision += 1
                self._updates.notify_all()

    def set_series(self, best_of, left_wins, right_wins):
        if (any(type(value) is not int for value in (best_of, left_wins, right_wins)) or
                not 1 <= best_of <= 9 or not 0 <= left_wins <= best_of // 2 + 1 or
                not 0 <= right_wins <= best_of // 2 + 1 or left_wins + right_wins > best_of):
            raise ValueError('Проверьте формат и счёт серии.')
        series = {'bestOf': best_of, 'leftWins': left_wins, 'rightWins': right_wins}
        with self._updates:
            if series != self._series:
                self._series = series
                self._revision += 1
                self._updates.notify_all()

    def _graphics_telemetry(self, preview):
        return with_display_names(self._preview if preview else self._hud_telemetry, self._player_aliases)

    def _pov_state(self):
        url, media_format = self._pov
        return {'povUrl': url, 'povFormat': media_format} if url else {}

    def _web_policy(self, path):
        if path in ('/hud-editor/', '/hud-editor/overlay.html'):
            return STUDIO_POLICY
        if path.startswith('/hud/packages/') and self.packages:
            package_id, _, asset = path.removeprefix('/hud/packages/').partition('/')
            if asset in ('', 'index.html'):
                package = self.packages.get(package_id)
                if package and 'studio.json' in package.files:
                    return STUDIO_POLICY
        return WEB_POLICY

    def stats(self, preview=False):
        with self._updates:
            if preview:
                return match_stats(self._preview)
            stats = match_stats(self._telemetry, self._broadcast_url)
            hud_slots = players_by_portrait(stats['teams'])
            if stats['status'] == 'waiting' and self._match_roster:
                stats = match_stats(self._match_roster)
                stats['matchId'] = self._match_roster['matchId']
            if not stats.get('matchId') and self._fight_match:
                stats['matchId'] = self._fight_match
            assigned = players_by_input(stats, self._camera_inputs)
            stats['hud_slots'] = hud_slots
            stats['hud_observed_slot'] = observed_hud_slot(hud_slots, stats.get('selected'))
            stats['pov_inputs'] = {str(slot): entry[1]['name'] if entry else '' for slot, entry in assigned.items()}
            if self._position_export is not None:
                slots, observed, inputs, _ = self._position_export
                stats['hud_slots'] = dict(slots)
                stats['hud_observed_slot'] = observed
                stats['pov_inputs'] = {str(number): slots[str(i)] for i, number in enumerate(inputs, 1)
                                       if number and str(i) in slots}
            return stats

    def hero_stats(self, preview=False):
        with self._updates:
            stats = match_stats(self._preview) if preview else match_stats(self._hero_source, self._broadcast_url)
        return self._hero_statistics.state(stats, preview)

    def fight_recap(self, preview=False):
        with self._updates:
            return self._recap_preview if preview else self._fight_recap.state(self._player_aliases)

    def broadcast_stats(self, table):
        with self._updates:
            stats = match_stats(self._telemetry, self._broadcast_url)
            if table == 'players' and stats['status'] == 'waiting' and self._match_roster:
                cameras = self._camera_inputs
                if self._position_export is not None:
                    from .hud_nicknames import normalize_name
                    cameras = {normalize_name(name): int(slot) for slot, name in self._position_export[0].items()}
                return mapped_player_rows(self._match_roster, cameras)
            heroes = self.hero_stats() if table in ('players', 'lanes') else None
        return broadcast_rows(table, stats, heroes)

    def set_hero_history_enabled(self, enabled):
        with self._updates:
            self._hero_statistics.enable_history(enabled)
            self._revision += 1
            self._updates.notify_all()

    def _state(self, package_id, preview):
        settings = self.packages.settings(package_id) if self.packages else None
        if settings is None:
            return None
        if self._series is not None:
            settings = {**settings, 'series': self._series}
        state = {
            'preview': preview, 'telemetry': self._graphics_telemetry(preview),
            'settings': settings, 'opacity': self.packages.opacity, **self._pov_state(),
        }
        package = self.packages.active(package_id)
        if package and package.get('studio'):
            state['studioRevision'] = package['revision']
        return state

    def stats_asset(self, path):
        if is_stats_asset(path):
            return self._route(urlsplit(path))
        return None

    def events(self, request, state, *, stopped=lambda: False):
        if state() is None:
            request.send_error(404)
            return
        request.connection.settimeout(3)
        request.send_response(200)
        request.send_header('Content-Type', 'text/event-stream; charset=utf-8')
        request.send_header('Cache-Control', 'no-store')
        request.send_header('Cross-Origin-Resource-Policy', 'same-origin')
        request.end_headers()
        previous = None
        heartbeat = monotonic()
        while not self._closing and not stopped():
            with self._updates:
                revision = self._revision
                snapshot = state()
            if snapshot is None:
                return
            payload, _ = self._json(snapshot)
            now = monotonic()
            try:
                if payload != previous:
                    request.wfile.write(b'data: ' + payload + b'\n\n')
                    previous, heartbeat = payload, now
                elif now - heartbeat >= 5:
                    request.wfile.write(b': heartbeat\n\n')
                    heartbeat = now
                request.wfile.flush()
            except OSError:
                return
            with self._updates:
                self._updates.wait_for(lambda: self._closing or stopped() or revision != self._revision, timeout=0.2)

    def _route(self, address):
        path = address.path
        if path == '/doa-telemetry':
            return self._json(self.telemetry)
        if path in STATS_READERS:
            read = getattr(self, STATS_READERS[path])
            return self._json(read(parse_qs(address.query).get('preview') == ['1']))
        if path in BROADCAST_ROUTES:
            return self._json(self.broadcast_stats(BROADCAST_ROUTES[path]))
        if self.packages is None:
            return None
        if path == '/hud-minimap.png':
            settings = self.packages.settings('battle-report')
            if settings is None:
                return None
            colors = (settings.get('leftColor', '#efad45'), settings.get('rightColor', '#94b8ff'))
            if parse_qs(address.query).get('preview') == ['1']:
                data = minimap_preview(colors)
            elif self._minimap is not None and self._hud_telemetry and self._hud_telemetry.get('teams'):
                data = self._minimap.frame(self._fight_match or 'spectator', colors)
            else:
                data = None
            return (data, 'image/png') if data else None
        if path.startswith('/game-icons/'):
            name = path.removeprefix('/game-icons/')
            if name == 'catalog.json':
                return (self._game_icons / name).read_bytes(), 'application/json; charset=utf-8'
            if re.fullmatch(r'icons-[0-9a-f]{16}\.webp', name):
                return (self._game_icons / name).read_bytes(), 'image/webp'
            return None
        if path in WEB_FILES:
            filename, kind = WEB_FILES[path]
            return (WEB_ROOT / filename).read_bytes(), kind
        if path == '/api/v1/huds/active':
            package = parse_qs(address.query).get('package', [None])[0]
            active = self.packages.active(package)
            return self._json(active) if active is not None else None
        if path.startswith('/api/v1/huds/') and path.endswith('/state'):
            package_id = path.removeprefix('/api/v1/huds/').removesuffix('/state')
            preview = parse_qs(address.query).get('preview') == ['1']
            state = self._state(package_id, preview)
            if state is not None:
                return self._json(state)
        if path.startswith('/hud/packages/'):
            package_id, slash, asset = path.removeprefix('/hud/packages/').partition('/')
            if slash:
                name = unquote(asset) or 'index.html'
                data = self.packages.asset(package_id, name)
                if data is not None:
                    kind = WEB_TYPES.get(PurePosixPath(name).suffix.lower()) or guess_type(name)[0]
                    kind = kind or 'application/octet-stream'
                    if kind.startswith('text/') or kind == 'application/json':
                        kind += '; charset=utf-8'
                    return data, kind
        return None

    @staticmethod
    def _json(value):
        return json.dumps(value).encode('utf-8'), 'application/json'

    def close(self):
        with self._updates:
            self._closing = True
            self._updates.notify_all()
        self._server.shutdown()
        self._server.server_close()
