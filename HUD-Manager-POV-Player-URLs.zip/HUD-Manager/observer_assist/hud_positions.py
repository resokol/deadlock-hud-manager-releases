"""Display the live left-to-right order of the spectator's top bar."""

import json

from PySide6.QtCore import Qt, QTimer, QUrl, Signal
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkProxy, QNetworkReply, QNetworkRequest
from PySide6.QtWidgets import (
    QComboBox, QFormLayout, QGroupBox, QHeaderView, QLabel, QLineEdit, QPushButton,
    QTableWidget, QTableWidgetItem, QVBoxLayout,
)

from .broadcast_tables import observed_hud_slot, players_by_match_position, players_by_portrait
from .panorama_hud_mode import video_origin


class PanoramaPositions(QGroupBox):
    slots_changed = Signal(dict)
    observed_changed = Signal(object)
    local_requested = Signal()

    def __init__(self, settings):
        super().__init__('Верхняя полоса наблюдателя')
        self.settings = settings
        self.slots = {}
        self.observed = None
        self.match_roster = None
        self.mode = 'match'
        self.remote = ''
        self.reply = None
        self.network = QNetworkAccessManager(self)
        self.network.setProxy(QNetworkProxy(QNetworkProxy.ProxyType.NoProxy))
        self.timer = QTimer(self, interval=1000)
        self.timer.timeout.connect(self._poll)
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.source = QComboBox()
        self.source.addItem('По ID из раздела «Матч»', 'match')
        self.source.addItem('Panorama на этом ПК', 'local')
        self.source.addItem('Panorama по локальной сети', 'remote')
        self.url = QLineEdit(settings.value('positionsUrl', '', type=str))
        self.url.setPlaceholderText('Необязательно для режима по ID: URL JSON с ПК наблюдателя для автослежения')
        default_mode = 'remote' if settings.value('positionsRemote', False, type=bool) else 'match'
        self.mode = settings.value('positionsMode', default_mode, type=str)
        self.source.setCurrentIndex(max(0, self.source.findData(self.mode)))
        self.mode = self.source.currentData()
        self.url.setEnabled(self.mode != 'local')
        self.source.currentIndexChanged.connect(lambda: self.url.setEnabled(self.source.currentData() != 'local'))
        form.addRow('Источник', self.source)
        form.addRow('URL JSON матча', self.url)
        layout.addLayout(form)
        apply = QPushButton('Подключить')
        apply.clicked.connect(self.connect_source)
        layout.addWidget(apply, alignment=Qt.AlignmentFlag.AlignLeft)
        self.status = QLabel()
        self.status.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.status)
        self.table = QTableWidget(12, 2)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setHorizontalHeaderLabels(['Позиция слева направо', 'Ник в Deadlock'])
        self.table.verticalHeader().hide()
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        for i in range(12):
            self.table.setItem(i, 0, QTableWidgetItem(str(i + 1)))
            self.table.setItem(i, 1, QTableWidgetItem('—'))
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        layout.addWidget(self.table)
        self._show({}, None)
        if self.mode == 'remote' or self.mode == 'match' and self.url.text().strip():
            self.connect_source()

    def stop(self):
        self.timer.stop()
        reply, self.reply = self.reply, None
        if reply:
            reply.abort()

    def connect_source(self):
        mode = self.source.currentData()
        use_remote = mode == 'remote'
        address = self.url.text().strip()
        if (use_remote or mode == 'match' and address) and not video_origin(address):
            self.status.setText('Вставьте полный URL JSON матча с ПК наблюдателя.')
            return
        self.stop()
        self.mode = mode
        self.settings.setValue('positionsMode', mode)
        self.remote = address if mode != 'local' else ''
        self.settings.setValue('positionsUrl', address)
        self.settings.setValue('positionsRemote', use_remote)
        self._show({}, None)
        if mode == 'match':
            self.set_match(self.match_roster)
        if self.remote:
            self.timer.start()
            self._poll()
        elif mode == 'local':
            self.local_requested.emit()

    def set_match(self, roster):
        changed_match = not roster or not self.match_roster or roster['matchId'] != self.match_roster['matchId']
        self.match_roster = roster
        if self.mode == 'match':
            slots = players_by_match_position(roster)
            observed = None if changed_match or slots != self.slots else self.observed
            self._show(slots, observed)

    def observe(self, telemetry, match_id=None):
        telemetry = telemetry or {}
        if self.mode == 'local':
            slots = players_by_portrait(telemetry.get('teams', []))
            self._show(slots, observed_hud_slot(slots, telemetry.get('selected')))
        elif self.mode == 'match' and not self.remote:
            same_match = self.match_roster and match_id and str(match_id) == str(self.match_roster['matchId'])
            selected = telemetry.get('selected') if same_match else None
            self._show(self.slots, observed_hud_slot(self.slots, selected))

    def _poll(self):
        if self.reply is not None:
            return
        request = QNetworkRequest(QUrl(self.remote))
        request.setTransferTimeout(2500)
        request.setAttribute(QNetworkRequest.Attribute.RedirectPolicyAttribute,
                             QNetworkRequest.RedirectPolicy.ManualRedirectPolicy)
        reply = self.network.get(request)
        self.reply = reply
        reply.finished.connect(lambda: self._received(reply))

    def _received(self, reply):
        reply.deleteLater()
        if self.reply is not reply:
            return
        self.reply = None
        try:
            if reply.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute) != 200 or reply.error() != QNetworkReply.NetworkError.NoError:
                raise ValueError
            stats = json.loads(bytes(reply.readAll()))
            if self.mode == 'match':
                same_match = self.match_roster and stats.get('matchId') and str(stats['matchId']) == str(self.match_roster['matchId'])
                selected = stats.get('selected') if same_match else None
                self._show(self.slots, observed_hud_slot(self.slots, selected))
                return
            slots = stats['hud_slots']
            if not isinstance(slots, dict) or slots and (
                set(slots) != {str(i) for i in range(1, 13)} or
                not all(isinstance(name, str) and name.strip() for name in slots.values())
            ):
                raise ValueError
            observed = stats.get('hud_observed_slot', observed_hud_slot(slots, stats.get('selected')))
            self._show(slots, observed if type(observed) is int and str(observed) in slots else None)
        except (KeyError, TypeError, ValueError, AttributeError):
            self._show(self.slots if self.mode == 'match' else {}, None, 'Проверьте URL JSON матча и наличие поля hud_slots на ПК наблюдателя.')

    def _show(self, slots, observed, message=None):
        changed = slots != self.slots
        if changed:
            self.slots = slots
            for i in range(12):
                self.table.item(i, 1).setText(slots.get(str(i + 1), '—'))
            self.slots_changed.emit(slots)
        if observed != self.observed:
            self.observed = observed
            self.observed_changed.emit(observed)
        status = message or ('Ожидание состава и назначенных линий SourceTV.' if self.mode == 'match' else 'Ожидание 12 портретов Panorama.')
        if not message and slots:
            status = (f'Под наблюдением: {observed} · {slots[str(observed)]}' if observed else
                      'Получены 12 позиций. Игрок под наблюдением не выбран.')
        if self.status.text() != status:
            self.status.setText(status)
