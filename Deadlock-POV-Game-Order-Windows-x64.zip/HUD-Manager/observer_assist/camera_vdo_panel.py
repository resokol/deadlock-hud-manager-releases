"""Room director link and discovery status for the camera operator."""

from collections import Counter
from hashlib import sha256
from ipaddress import IPv4Address
import json
import re
from typing import NamedTuple
from urllib.parse import parse_qs, urlsplit

from PySide6.QtCore import QSignalBlocker, Qt, Signal
from PySide6.QtWidgets import (
    QAbstractItemView, QApplication, QCheckBox, QComboBox, QFormLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QPushButton, QSpinBox, QTabBar, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from .camera_vdo_bridge import DEFAULT_POLL_SECONDS, MAX_POLL_SECONDS, poll_seconds
from .camera_vdo_room import parse_director
from .match_stats import is_lan_address


SETTINGS_KEY = 'cameraVdoDirectorUrl'
DIRECTOR_MODE_KEY = 'cameraVdoDirectorMode'
POLL_INTERVAL_KEY = 'cameraVdoPollSeconds'
FORWARD_KEY = 'cameraVdoForwardModules'
HOST_KEY = 'cameraVdoVmixHost'
PORT_KEY = 'cameraVdoVmixPort'
_PRIVATE_LINK = re.compile(r'://|vdo\.ninja[/#?]|[?&](?:director|room|view|password|token)=', re.I)


def _label(text, name=None):
    label = QLabel(text)
    label.setTextFormat(Qt.TextFormat.PlainText)
    label.setWordWrap(True)
    if name:
        label.setObjectName(name)
    return label


class _Guest(NamedTuple):
    label: str
    bank: int | None
    page: str
    identity: str
    issue: str
    video: str


def _settings_map(settings, key):
    try:
        value = json.loads(settings.value(key, '{}', type=str))
    except (TypeError, ValueError):
        return {}
    return value if isinstance(value, dict) else {}


def _guest(row):
    label = str(row.get('label') or '').strip()
    if not label.isprintable() or _PRIVATE_LINK.search(label):
        label = ''
    video = row.get('video')
    if video not in ('live', 'absent'):
        video = 'unknown'
    page = str(row.get('page') or '').strip()
    try:
        url = urlsplit(page)
        query = parse_qs(url.query, keep_blank_values=True)
        options = set(query) | parse_qs(url.fragment.lstrip('?&'), keep_blank_values=True).keys()
        view = query.get('view') or query.get('v') or []
        valid = (url.scheme == 'https' and url.hostname in ('vdo.ninja', 'www.vdo.ninja')
                 and not url.username and not url.password and url.port in (443, None)
                 and len(view) == 1 and view[0] and not options.intersection({'director', 'dir', 'codirector'}))
    except ValueError:
        valid = False
    stream = row.get('streamID') or (view[0] if valid else '')
    if not valid or view[0] != stream:
        return _Guest(label, row.get('bank'), '', '', 'Нет ссылки просмотра', video)
    key = sha256(stream.encode()).hexdigest()
    if not label:
        return _Guest('', row.get('bank'), page, key, 'Нужен игровой ник', video)
    return _Guest(label, row.get('bank'), page, key, '', video)


class _HudRow(NamedTuple):
    name: str
    number: int
    page: str
    title: str
    problem: str
    video: str


class _PositionAssignments(QWidget):
    edited = Signal()
    SETTINGS_KEY = 'cameraVdoPositionInputs'

    def __init__(self, settings, shared_inputs=None):
        super().__init__()
        self.settings = settings
        self.names = ()
        self.source = ''
        self.rows = ()
        self.revision = 0
        self.results = {}
        self._overrides = {}
        self._override_keys = []
        self._reported_media = {}
        self.ready = False
        self.shared_inputs = shared_inputs
        self.selectors = []
        self._selector_options = [None] * 12
        self._automatic = [''] * 12
        self._choices = ['auto'] * 12
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.hint = _label('', 'roomHelp')
        layout.addWidget(self.hint)
        self.table = QTableWidget(12, 5)
        self.table.setAccessibleName('Камеры в порядке верхней полосы HUD')
        self.table.setHorizontalHeaderLabels(['Поз. / клавиша', 'Игрок в HUD', 'Вход vMix', 'Название в vMix', 'Состояние'])
        self.table.verticalHeader().hide()
        self.table.verticalHeader().setDefaultSectionSize(36)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.setMinimumHeight(170)
        self.table.setMaximumHeight(300)
        layout.addWidget(self.table)
        self.override_box = QWidget()
        override_form = QFormLayout(self.override_box)
        override_form.setContentsMargins(0, 0, 0, 0)
        override_form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.override = QComboBox()
        self.override.setAccessibleName('Видео выбранного игрока')
        self.override.setToolTip('Если вместо веб-камеры видна заглушка, выберите игрока и подтвердите отсутствие камеры.')
        self.override.addItem('По данным комнаты', 'unknown')
        self.override.addItem('Подтверждаю видео', 'live')
        self.override.addItem('Подтверждаю отсутствие камеры', 'absent')
        override_form.addRow('Видео выбранного игрока', self.override)
        self.override.currentIndexChanged.connect(self._set_override)
        self.table.currentCellChanged.connect(self._show_override)
        self.override_box.hide()
        layout.addWidget(self.override_box)
        saved = _settings_map(settings, self.SETTINGS_KEY)
        self.inputs = []
        for i, key in enumerate('1234567890-='):
            self.table.setItem(i, 0, QTableWidgetItem(f'{i + 1} / {key}'))
            for col in (1, 3, 4):
                self.table.setItem(i, col, QTableWidgetItem())
            field = QSpinBox(self.table)
            field.setRange(1, 9999)
            field.setAccessibleName(f'Вход vMix для позиции {i + 1}')
            field.setKeyboardTracking(False)
            n = saved.get(str(i + 1))
            field.setValue(n if type(n) is int and 1 <= n <= 9999 else i + 1)
            self.table.setCellWidget(i, 2, field)
            self.inputs.append(field)
            if shared_inputs:
                field.valueChanged.connect(shared_inputs[i].setValue)
                selector = QComboBox(self.table)
                selector.setAccessibleName(f'Гость для входа {i + 1}')
                self.table.setCellWidget(i, 1, selector)
                self.selectors.append(selector)
                selector.currentIndexChanged.connect(self._choose_guest)
            else:
                field.valueChanged.connect(self._save_inputs)
        if shared_inputs:
            self.table.setAccessibleName('Подготовка двенадцати входов vMix')
            self.table.setHorizontalHeaderLabels(['Место', 'Гость комнаты', 'Вход vMix', 'Название в vMix', 'Состояние'])
            for i in range(12):
                self.table.item(i, 0).setText(str(i + 1))

    def _choose_guest(self):
        selector = self.sender()
        self._choices[self.selectors.index(selector)] = selector.currentData()
        self.edited.emit()

    def _choose_room_names(self, guests, issues, busy):
        valid = {g.identity: g for g in guests if g.page not in issues}
        reserved = set(self._choices)
        # Keep returning streams in their current seats when the directory order changes.
        automatic = [key if choice == 'auto' and key in valid and key not in reserved else ''
                     for key, choice in zip(self._automatic, self._choices)]
        ordered = sorted(valid, key=lambda key: valid[key].label.casefold())
        labels = [(valid[key].label, key) for key in ordered]
        available = iter(key for key in ordered if key not in reserved and key not in automatic)
        names = []
        problems = []
        for i, selector in enumerate(self.selectors):
            choice = self._choices[i]
            if choice == 'auto' and not automatic[i]:
                automatic[i] = next(available, '')
            key = automatic[i] if choice == 'auto' else choice
            guest = valid.get(key)
            name = guest.label if guest else ''
            names.append(name)
            problems.append('Гость выбран дважды' if guest and self._choices.count(key) > 1 else '')
            options = [('Авто · ' + (name if choice == 'auto' and name else 'по имени'), 'auto'),
                       ('Без камеры', '')] + labels
            if choice not in ('auto', '') and choice not in valid:
                options.append(('Гость вышел', choice))
            with QSignalBlocker(selector):
                if self._selector_options[i] != options:
                    selector.clear()
                    for text, data in options:
                        selector.addItem(text, data)
                    self._selector_options[i] = options
                selector.setCurrentIndex(selector.findData(choice))
            selector.setEnabled(not busy)
        self._automatic = automatic
        self.names = tuple(names)
        return problems, len(valid) - len({n for n in names if n})

    def room_media(self, guest):
        return self._overrides.get((guest.label.casefold(), guest.identity), guest.video)

    def _override_key(self):
        row = self.table.currentRow()
        return self._override_keys[row] if 0 <= row < len(self._override_keys) else None

    def _show_override(self):
        key = self._override_key()
        self.override.setEnabled(bool(key))
        self.override.model().item(self.override.findData('live')).setEnabled(self._reported_media.get(key) == 'unknown')
        with QSignalBlocker(self.override):
            self.override.setCurrentIndex(self.override.findData(self._overrides.get(key, 'unknown')))

    def _set_override(self):
        key = self._override_key()
        choice = self.override.currentData()
        if not key:
            return
        if choice == 'live' and self._reported_media.get(key) != 'unknown':
            self._show_override()
            return
        if choice == 'unknown':
            self._overrides.pop(key, None)
        else:
            self._overrides[key] = choice
        self.edited.emit()

    def _save_inputs(self):
        self.settings.setValue(self.SETTINGS_KEY, json.dumps({i: f.value() for i, f in enumerate(self.inputs, 1)}))
        self.edited.emit()

    def set_order(self, names, source):
        values = ()
        if (isinstance(names, (list, tuple)) and len(names) == 12
                and all(isinstance(s, str) and s.strip() for s in names)):
            candidates = tuple(s.strip() for s in names)
            if len({s.casefold() for s in candidates}) == 12:
                values = candidates
        source = source if source and not _PRIVATE_LINK.search(source) else ''
        changed = (values, source) != (self.names, self.source)
        if changed:
            if self.source != source:
                self._overrides.clear()
            self.names, self.source = values, source
            self.revision += 1
            self.results.clear()
        return changed

    def refresh(self, guests, issues, fresh, busy, allow_unmatched=False):
        seat_errors, overflow = (self._choose_room_names(guests, issues, busy)
                                 if self.shared_inputs else ([''] * 12, 0))
        by_name = {}
        for g in guests:
            if g.label:
                by_name.setdefault(g.label.casefold(), []).append(g)
        values = [field.value() for field in (self.shared_inputs or self.inputs)]
        numbers = Counter(values)
        rows = []
        self._override_keys = []
        self._reported_media = {}
        for i, field in enumerate(self.inputs):
            field.setEnabled(not busy)
            number = values[i]
            if self.shared_inputs:
                with QSignalBlocker(field):
                    field.setValue(number)
            name = self.names[i] if self.names else ''
            matched = by_name.get(name.casefold(), [])
            page = title = problem = ''
            video = 'unmatched'
            override_key = None
            if not name and not self.shared_inputs:
                problem = 'Ожидание порядка'
            elif not fresh:
                problem = 'Ожидание комнаты'
            elif len(matched) > 1:
                problem = 'Повторяется ник'
            elif matched:
                guest = matched[0]
                problem = issues.get(guest.page, '')
                if not problem:
                    override_key = (name.casefold(), guest.identity)
                    self._reported_media[override_key] = guest.video
                    if guest.video != 'unknown' and self._overrides.get(override_key) == 'live':
                        self._overrides.pop(override_key)
                    video = self._overrides.get(override_key, guest.video)
                    if video == 'live':
                        page, title = guest.page, name
                    elif video == 'absent':
                        title = '-'
            elif issues and (not self.shared_inputs or self._choices[i] != ''):
                # Unidentified guests may occupy these places. Keep their inputs intact.
                video = 'unknown'
            else:
                title = '-'
            if numbers[number] > 1:
                problem = 'Номер входа занят дважды'
            problem = problem or seat_errors[i]
            self._override_keys.append(override_key)
            rows.append(_HudRow(name, number, page, title, problem, video))
        if fresh:
            self._overrides = {k: v for k, v in self._overrides.items() if k in self._override_keys}
        self.override_box.setVisible(any(self._override_keys))
        self.override_box.setEnabled(not busy)
        self._show_override()
        rows = tuple(rows)
        if rows != self.rows:
            self.revision += 1
            self.results.clear()
            self.rows = rows
        matched = sum(bool(row.page) for row in rows)
        clears = sum(row.title == '-' and not row.problem for row in rows)
        verified = any(row.video in ('live', 'absent') for row in rows)
        unknown = sum(row.video == 'unknown' for row in rows)
        was_ready = self.ready
        valid = fresh and all(not row.problem for row in rows)
        confirmed_empty = (allow_unmatched and clears == 12 and not issues
                           and all(g.video in ('live', 'absent') for g in guests))
        self.ready = valid and (verified or confirmed_empty)
        if self.shared_inputs:
            blocked_labels = bool(guests) and all(g.page in issues for g in guests)
            self.ready = valid and not blocked_labels and any(r.title for r in rows)
            if not fresh:
                hint = 'Сначала подключите комнату и дождитесь свежего списка гостей.'
            elif blocked_labels:
                hint = 'В комнате нет гостей с уникальным игровым именем. Проверьте Label.'
            elif not valid:
                hint = 'Исправьте повторяющихся гостей или номера входов.'
            else:
                hint = f'Камер · {matched}   Прозрачных входов · {clears}   Без данных о видео · {unknown}'
                if overflow:
                    hint += f'   Гостей вне выбранных входов · {overflow}'
                if issues:
                    hint += f'   Требуют проверки Label или ссылки · {len(issues)}. Свободные места в режиме «Авто» пропускаются.'
        elif not self.names:
            hint = 'Нужен полный порядок 12 разных игроков. Проверьте данные матча и верхней полосы HUD.'
        elif not fresh:
            hint = 'Дождитесь свежего списка гостей VDO.Ninja.'
        elif not verified and not confirmed_empty and not unknown:
            hint = 'Нет совпадений. Сверьте Label гостей с никами игроков. Отправка заблокирована.'
        elif any(row.problem for row in rows):
            hint = 'Проверьте строки с ошибками. Для отправки нужны однозначные назначения всех 12 входов.'
        elif not verified and not confirmed_empty:
            hint = 'Видео гостей не подтверждено. Выберите игрока в таблице и укажите состояние его камеры.'
        else:
            hint = f'Камер · {matched}  |  Прозрачных входов · {clears}. Для позиций без камеры название входа станет «-».'
            if unknown:
                hint += f' Пропускаются входы без данных о видео · {unknown}.'
        if self.ready != was_ready:
            self.revision += 1
        self.hint.setText(f'{self.source} · {hint}' if self.source else hint)
        for i, row in enumerate(rows):
            default_status = {'live': 'Видео подтверждено', 'unknown': 'Видео не определено · пропуск',
                              'absent': 'Без видео · прозрачно', 'unmatched': 'Нет камеры · прозрачно'}
            status = row.problem or self.results.get(row.number) or default_status[row.video]
            for col, value in ((1, row.name or '—'), (3, row.title or '—'), (4, status)):
                item = self.table.item(i, col)
                if item.text() != value:
                    item.setText(value)
                    item.setToolTip(value)

    def commands(self):
        return [(r.page, r.title, r.number) for r in self.rows if r.title] if self.ready else []


class VdoRoomPanel(QWidget):
    start_requested = Signal(str)
    stop_requested = Signal()
    reopen_requested = Signal()
    apply_vmix_requested = Signal(str, int, object)
    position_media_changed = Signal()
    workflow_changed = Signal()

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.settings = settings
        self._phase = 'idle'
        self._pending_url = ''
        self._room_inputs_key = ''
        self._numbers = {}
        self._results = {}
        self._issues = {}
        self._busy = False
        self._room_fresh = False
        self._position_media = ('unknown',) * 12
        self._submitted_revision = None
        self._submitted = {}
        self._guests = ()
        self.preparation = None
        self._workflow_pages = ()
        self._workflow_state = None
        self._acknowledged = {}
        self._prepared_inputs_key = None
        self._submitted_mode = ''
        self._submitted_count = 0
        self._receipt = None
        previous = _settings_map(settings, 'cameraRoutingV1')
        live = previous.get('live') if isinstance(previous.get('live'), dict) else {}
        replay = previous.get('replay') if isinstance(previous.get('replay'), dict) else {}
        self.setStyleSheet("""
            QLabel#roomTitle { font-size: 14pt; font-weight: 600; color: #ebf2f5; }
            QLabel#roomHelp { color: #b8c6cb; }
            QLabel#roomStatus { font-weight: 600; }
        """)
        combined = QVBoxLayout(self)
        combined.setContentsMargins(0, 0, 0, 0)
        self.room_page = QWidget()
        combined.addWidget(self.room_page)
        layout = QVBoxLayout(self.room_page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        layout.addWidget(_label('Гости комнаты VDO.Ninja', 'roomTitle'))
        layout.addWidget(_label('Укажите игровой ник в имени гостя или в параметре &label= его ссылки. '
                                'Для импорта нужны разные ники.', 'roomHelp'))

        caption = _label('Приватная ссылка Director или Co-Director')
        self.url = QLineEdit(settings.value(SETTINGS_KEY, '', type=str))
        self.url.setEchoMode(QLineEdit.EchoMode.Password)
        self.url.setPlaceholderText('Вставьте ссылку директора комнаты')
        self.url.setAccessibleName(caption.text())
        caption.setBuddy(self.url)
        self.url.returnPressed.connect(self._request_start)
        layout.addWidget(caption)
        layout.addWidget(self.url)
        self.url.setToolTip('После успешного запуска ссылка сохраняется в настройках на этом ПК.')
        self.director_mode = QCheckBox('Открыть как режиссёр (включая гостей вне сцены)')
        self.director_mode.setChecked(settings.value(DIRECTOR_MODE_KEY, True, type=bool))
        self.advanced = QPushButton('Дополнительные настройки')
        self.advanced.setCheckable(True)
        layout.addWidget(self.advanced, alignment=Qt.AlignmentFlag.AlignLeft)
        advanced_page = QWidget()
        advanced_layout = QVBoxLayout(advanced_page)
        advanced_layout.setContentsMargins(0, 0, 0, 0)
        advanced_layout.addWidget(self.director_mode)
        self.mode_hint = _label('', 'roomHelp')
        advanced_layout.addWidget(self.mode_hint)
        self.director_mode.toggled.connect(self._show_mode_hint)
        self._show_mode_hint(self.director_mode.isChecked())

        cadence = QHBoxLayout()
        caption = _label('Интервал обновления списка гостей')
        self.poll_interval = QSpinBox()
        self.poll_interval.setRange(1, MAX_POLL_SECONDS)
        self.poll_interval.setSuffix(' с')
        self.poll_interval.setAccessibleName(caption.text())
        self.poll_interval.setToolTip('Изменение применяется к открытой вкладке комнаты.')
        self.poll_interval.setValue(poll_seconds(settings.value(POLL_INTERVAL_KEY, DEFAULT_POLL_SECONDS)))
        self.poll_interval.valueChanged.connect(lambda value: settings.setValue(POLL_INTERVAL_KEY, value))
        caption.setBuddy(self.poll_interval)
        cadence.addWidget(caption)
        cadence.addWidget(self.poll_interval)
        cadence.addStretch()
        advanced_layout.addLayout(cadence)
        self.forward_to_modules = QCheckBox('Передавать гостей в Live и Replay')
        upgrading = bool(self.url.text() and (live.get('enabled') is True or replay.get('enabled') is True))
        self.forward_to_modules.setChecked(settings.value(FORWARD_KEY, upgrading, type=bool))
        # Freeze the migration decision before this new panel first saves a director URL.
        if not settings.contains(FORWARD_KEY):
            settings.setValue(FORWARD_KEY, self.forward_to_modules.isChecked())
        self.forward_to_modules.toggled.connect(self._set_forwarding)
        advanced_layout.addWidget(self.forward_to_modules)
        advanced_page.hide()
        self.advanced.toggled.connect(advanced_page.setVisible)
        layout.addWidget(advanced_page)

        controls = QHBoxLayout()
        self.connect_button = QPushButton('Подключиться к комнате')
        self.connect_button.setObjectName('primary')
        self.connect_button.clicked.connect(self._request_start)
        self.reopen_button = QPushButton('Открыть вкладку')
        self.reopen_button.setToolTip('Если вкладка закрылась, откройте её снова и оставьте открытой для импорта.')
        self.reopen_button.clicked.connect(self.reopen_requested.emit)
        self.stop_button = QPushButton('Отключить')
        self.stop_button.clicked.connect(self.stop_requested.emit)
        for button in (self.connect_button, self.reopen_button, self.stop_button):
            controls.addWidget(button)
        controls.addStretch()
        layout.addLayout(controls)

        self.status = _label('', 'roomStatus')
        self.summary = _label('')
        layout.addWidget(self.status)
        layout.addWidget(self.summary)
        layout = combined
        self.assignment_tabs = QTabBar()
        self.assignment_tabs.setAccessibleName('Способ назначения входов vMix')
        self.assignment_tabs.setExpanding(False)
        self.assignment_tabs.addTab('Вручную по гостям')
        self.assignment_tabs.addTab('По позициям HUD')
        layout.addWidget(self.assignment_tabs, alignment=Qt.AlignmentFlag.AlignLeft)
        self.table = QTableWidget(0, 4)
        self.table.setAccessibleName('Гости комнаты и входы vMix')
        self.table.setHorizontalHeaderLabels(['Имя гостя', 'Вход vMix', 'Состояние', 'Пара камер'])
        self.table.setColumnHidden(3, not self.forward_to_modules.isChecked())
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.table.verticalHeader().hide()
        self.table.verticalHeader().setDefaultSectionSize(36)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setAlternatingRowColors(True)
        self.table.setMinimumHeight(125)
        self.table.setMaximumHeight(250)
        self.table.hide()
        layout.addWidget(self.table)
        self.copy_button = QPushButton('Копировать ссылку камеры')
        self.copy_button.clicked.connect(self._copy_camera)
        self.copy_button.setEnabled(False)
        self.copy_button.hide()
        layout.addWidget(self.copy_button, alignment=Qt.AlignmentFlag.AlignLeft)
        self.table.itemSelectionChanged.connect(self._update_copy)
        self.positions = _PositionAssignments(settings)
        self.positions.edited.connect(self._refresh_vmix)
        layout.addWidget(self.positions)
        self.endpoint_page = QWidget()
        target = QFormLayout(self.endpoint_page)
        target.setContentsMargins(0, 0, 0, 0)
        target.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.vmix_host = QLineEdit(settings.value(HOST_KEY, live.get('host') or '127.0.0.1', type=str))
        self.vmix_port = QSpinBox()
        self.vmix_host.setAccessibleName('IPv4 компьютера с vMix')
        self.vmix_port.setAccessibleName('Порт Web Controller')
        self.vmix_port.setRange(1, 65535)
        saved_port = settings.value(PORT_KEY, live.get('port', 8088))
        try:
            port = int(saved_port)
        except (TypeError, ValueError):
            port = 8088
        self.vmix_port.setValue(port if 1 <= port <= 65535 else 8088)
        target.addRow('IPv4 компьютера с vMix', self.vmix_host)
        target.addRow('Порт Web Controller', self.vmix_port)
        layout.addWidget(self.endpoint_page)
        layout.addWidget(_label('Выберите номера существующих входов Web Browser. '
                                'За один раз можно применить до 12 камер.', 'roomHelp'))
        self.apply_vmix = QPushButton('Применить в vMix')
        self.apply_vmix.setObjectName('primary')
        self.apply_vmix.clicked.connect(self._apply_vmix)
        layout.addWidget(self.apply_vmix, alignment=Qt.AlignmentFlag.AlignLeft)
        self.apply_positions = QPushButton('Применить по позициям HUD в vMix')
        self.apply_positions.setObjectName('primary')
        self.apply_positions.clicked.connect(self._apply_vmix)
        layout.addWidget(self.apply_positions, alignment=Qt.AlignmentFlag.AlignLeft)
        self.assignment_tabs.currentChanged.connect(self._switch_view)
        self.vmix_message = _label('')
        layout.addWidget(self.vmix_message)
        self.vmix_host.textChanged.connect(self._destination_changed)
        self.vmix_port.valueChanged.connect(self._destination_changed)
        self.url.textChanged.connect(self._update_controls)
        self._switch_view()
        self.stop()

    def enable_workflow(self):
        """Expose persistent room, preparation and distribution pages for the POV assistant."""
        if self._workflow_pages:
            return self._workflow_pages
        self.room_page.layout().addStretch()
        self.room_page.findChild(QLabel, 'roomTitle').hide()
        self.preparation = _PositionAssignments(self.settings, shared_inputs=self.positions.inputs)
        self.preparation.edited.connect(self._refresh_vmix)
        self.apply_preparation = QPushButton('Подготовить 12 входов в vMix')
        self.apply_preparation.setObjectName('primary')
        self.apply_preparation.clicked.connect(self._apply_vmix)
        self.preparation_message = _label('')
        prep_page = QWidget()
        prep_layout = QVBoxLayout(prep_page)
        prep_layout.setContentsMargins(0, 0, 0, 0)
        prep_layout.addWidget(self.endpoint_page)
        prep_layout.addWidget(_label('Выберите 12 существующих входов Web Browser. Пустые места получат прозрачную страницу с именем «-».', 'roomHelp'))
        prep_layout.addWidget(self.preparation)
        prep_layout.addWidget(self.apply_preparation, alignment=Qt.AlignmentFlag.AlignLeft)
        prep_layout.addWidget(self.preparation_message)
        distribution = QWidget()
        dist_layout = QVBoxLayout(distribution)
        dist_layout.setContentsMargins(0, 0, 0, 0)
        self.positions.table.setHorizontalHeaderItem(0, QTableWidgetItem('Позиция'))
        for i, field in enumerate(self.positions.inputs):
            self.positions.table.item(i, 0).setText(str(i + 1))
            field.setReadOnly(True)
            field.setButtonSymbols(QSpinBox.ButtonSymbols.NoButtons)
            field.setToolTip('Номер задаётся при подготовке 12 входов.')
        self.apply_positions.setText('Применить порядок в vMix')
        dist_layout.addWidget(self.positions)
        dist_layout.addWidget(self.apply_positions, alignment=Qt.AlignmentFlag.AlignLeft)
        dist_layout.addWidget(self.vmix_message)
        for assignments in (self.preparation, self.positions):
            assignments.table.setMaximumHeight(16777215)
        self._workflow_pages = self.room_page, prep_page, distribution
        for page in self._workflow_pages:
            page.setStyleSheet(self.styleSheet())
        self._switch_view()
        return self._workflow_pages

    @property
    def preparation_ready(self):
        return bool(self.preparation and self.preparation.ready and not self._busy)

    @property
    def distribution_ready(self):
        return self.positions.ready and not self._busy

    def _plan_key(self, table):
        return table.revision, self._room_inputs_key, self.vmix_host.text().strip(), self.vmix_port.value()

    def _input_key(self):
        return (self._room_inputs_key, self.vmix_host.text().strip(), self.vmix_port.value(),
                tuple(field.value() for field in self.positions.inputs))

    @property
    def preparation_complete(self):
        return bool(self.preparation and self._acknowledged.get('preparation') == self._plan_key(self.preparation))

    @property
    def distribution_complete(self):
        return self._acknowledged.get('positions') == self._plan_key(self.positions)

    def publish_positions(self):
        return self._submit('positions')

    @property
    def submitted_mode(self):
        return self._submitted_mode

    def _show_mode_hint(self, director):
        if director:
            self.mode_hint.setText('Если главный Director уже открыт, разрешите Co-Director в Room Settings '
                                   'и используйте приглашение второго режиссёра.')
        else:
            self.mode_hint.setText('Режим сцены показывает подключённых к ней гостей. Главный Director может '
                                   'оставаться открытым. Приглашение Co-Director включает режим режиссёра автоматически.')

    def _update_controls(self):
        idle = self._phase == 'idle'
        self.url.setReadOnly(not idle)
        self.director_mode.setEnabled(idle)
        self.connect_button.setVisible(idle)
        self.connect_button.setEnabled(idle and bool(self.url.text().strip()))
        self.reopen_button.setVisible(self._phase == 'running')
        self.stop_button.setVisible(not idle)

    def _request_start(self):
        if self._phase != 'idle':
            return
        link = self.url.text().strip()
        if not link:
            return
        self._phase = 'starting'
        self._pending_url = link
        self.status.setText('Открываем комнату в браузере…')
        self.summary.hide()
        self._update_controls()
        self.start_requested.emit(link)

    def started(self):
        if self._phase != 'starting':
            return
        try:
            room = parse_director(self._pending_url)
        except ValueError as exc:
            self.start_failed(str(exc))
            return
        self._room_inputs_key = f'cameraVdoInputNumbers/{room.key}'
        self._numbers = {key: n for key, n in _settings_map(self.settings, self._room_inputs_key).items()
                         if type(n) is int and 0 <= n <= 9999}
        self.settings.setValue(SETTINGS_KEY, self._pending_url)
        self.settings.setValue(DIRECTOR_MODE_KEY, self.director_mode.isChecked())
        self._pending_url = ''
        self._phase = 'running'
        self.status.setText('Ожидаем список гостей. Оставьте вкладку браузера открытой.')
        self._update_controls()

    def start_failed(self, reason):
        self.stop()
        message = reason.strip()
        self.status.setText(message if message and not _PRIVATE_LINK.search(message)
                            else 'Не удалось подключиться. Проверьте ссылку директора и повторите попытку.')

    def show_result(self, guests_count, summary):
        if self._phase != 'running':
            return
        self.status.setText(f'Видимых гостей · {guests_count}')
        message = summary.strip()
        if _PRIVATE_LINK.search(message):
            message = 'Список гостей обновлён.'
        self.summary.setText(message)
        self.summary.setVisible(bool(message) and (self.forward_to_modules.isChecked() or not self._guests))

    def show_stale(self):
        if self._phase == 'running':
            self.set_room_fresh(False)
            self.status.setText('Список гостей не обновляется. Нажмите «Открыть вкладку» и проверьте комнату в браузере.')
            self.summary.clear()
            self.summary.hide()
            self.set_guests([])

    def _selected_page(self):
        selected = self.table.selectionModel().selectedRows()
        return self._guests[selected[0].row()].page if selected else ''

    def _update_copy(self):
        self.copy_button.setEnabled(bool(self._selected_page()))

    def _copy_camera(self):
        page = self._selected_page()
        if page:
            QApplication.clipboard().setText(page)

    def _set_forwarding(self, enabled):
        self.settings.setValue(FORWARD_KEY, enabled)
        self.table.setColumnHidden(3, not enabled)
        self.summary.setVisible(enabled and bool(self.summary.text()))

    def set_guests(self, rows):
        """Update current guests; never reuse a stream's assignment in another room."""
        guests = tuple(_guest(row) for row in rows) if self._phase == 'running' else ()
        if guests == self._guests:
            return
        selected = self._selected_page()
        previous_guests = {g.page: (g.label, g.video) for g in self._guests}
        self._guests = guests
        names = Counter(g.label.casefold() for g in guests)
        identities = Counter(g.identity for g in guests)
        self._issues = {}
        before = dict(self._numbers)
        for g in guests:
            issue = g.issue
            if not issue and identities[g.identity] > 1:
                issue = 'Повторяется Stream ID'
            if not issue and names[g.label.casefold()] > 1:
                issue = 'Повторяется ник'
            if issue:
                self._issues[g.page] = issue
        present = set(identities)
        valid = [g for g in guests if g.page not in self._issues]
        assigned = sum(bool(self._numbers.get(g.identity)) for g in valid)
        for g in valid:
            if g.identity in self._numbers or assigned >= 12:
                continue
            current = {self._numbers.get(key) for key in present}
            free = [n for n in range(1, 13) if n not in current]
            if not free:
                break
            # Leave absent guests' assignments intact until all unused physical inputs are taken.
            number = next((n for n in free if n not in self._numbers.values()), free[0])
            self._claim_number(g.identity, number, present)
            assigned += 1
        if self._numbers != before:
            self._save_numbers()
        self._results = {g.page: self._results[g.page] for g in guests
                         if g.page in self._results and previous_guests.get(g.page) == (g.label, g.video)}
        with QSignalBlocker(self.table):
            self.table.setRowCount(len(guests))
            self.table.setCurrentCell(-1, -1)
            self.table.clearSelection()
            for i, g in enumerate(guests):
                self.table.setItem(i, 0, QTableWidgetItem(g.label or 'Без имени'))
                field = self.table.cellWidget(i, 1)
                if field is None:
                    field = QSpinBox(self.table)
                    field.setRange(0, 9999)
                    field.setSpecialValueText('Пропустить')
                    field.setKeyboardTracking(False)
                    field.valueChanged.connect(self._number_edited)
                    self.table.setCellWidget(i, 1, field)
                field.setProperty('guestRow', i)
                field.setAccessibleName(f'Вход vMix для гостя {g.label or i + 1}')
                with QSignalBlocker(field):
                    field.setValue(self._numbers.get(g.identity, 0) if g.page not in self._issues else 0)
                self.table.setItem(i, 2, QTableWidgetItem())
                self.table.setItem(i, 3, QTableWidgetItem(str(g.bank) if g.bank is not None else 'Не назначена'))
                if selected and g.page == selected:
                    self.table.selectRow(i)
        self._update_copy()
        manual = not self._workflow_pages and self.assignment_tabs.currentIndex() == 0
        self.table.setVisible(manual and bool(guests))
        self.copy_button.setVisible(manual and bool(guests))
        self._refresh_vmix()

    def _switch_view(self):
        positions = bool(self._workflow_pages) or self.assignment_tabs.currentIndex() == 1
        self.positions.setVisible(positions)
        self.table.setVisible(not positions and bool(self._guests))
        self.copy_button.setVisible(not positions and bool(self._guests))
        self.apply_vmix.setVisible(not positions)
        self.apply_positions.setVisible(positions)
        self._refresh_vmix()

    def set_hud_order(self, names, source=''):
        if self.positions.set_order(names, source):
            self._refresh_vmix()

    def set_room_fresh(self, fresh):
        self._room_fresh = bool(fresh) and self._phase == 'running'
        self._refresh_vmix()

    def _save_numbers(self):
        if self._room_inputs_key:
            self.settings.setValue(self._room_inputs_key, json.dumps(self._numbers))

    def _claim_number(self, identity, number, present):
        if number:
            for key in list(self._numbers):
                if key not in present and self._numbers[key] == number:
                    del self._numbers[key]
        self._numbers[identity] = number

    def _number_edited(self, number):
        field = self.sender()
        row = field.property('guestRow')
        if not 0 <= row < len(self._guests) or self.table.cellWidget(row, 1) is not field:
            return
        guest = self._guests[row]
        self._claim_number(guest.identity, number, {g.identity for g in self._guests})
        self._save_numbers()
        self._results.pop(guest.page, None)
        self.vmix_message.clear()
        self._refresh_vmix()

    def _destination_changed(self):
        self._results.clear()
        self.positions.results.clear()
        self._acknowledged.clear()
        self._prepared_inputs_key = None
        if self.preparation:
            self.preparation.results.clear()
            self.preparation_message.clear()
        self.vmix_message.clear()
        self._refresh_vmix()

    def _manual_guests(self):
        return [(g, self._numbers[g.identity]) for g in self._guests
                if g.page not in self._issues and self._numbers.get(g.identity)]

    def _selected_inputs(self):
        return [('', '-', n) if g.video == 'absent' else (g.page, g.label, n) for g, n in self._manual_guests()]

    def position_media(self, slot):
        """Last resolved media state for a one-based HUD position."""
        return self._position_media[slot - 1] if type(slot) is int and 1 <= slot <= 12 else 'unknown'

    def _refresh_position_media(self):
        rows = self.positions.rows
        linked = self.positions.ready or any(not r.problem and r.video in ('live', 'absent') for r in rows)
        media = []
        for row in rows:
            state = row.video
            if row.problem:
                state = 'unknown'
            elif state == 'unmatched':
                state = 'absent' if linked else 'unknown'
            media.append(state)
        if tuple(media) != self._position_media:
            self._position_media = tuple(media)
            self.position_media_changed.emit()

    def _refresh_vmix(self):
        position_guests = self._guests
        if self.preparation:
            self.preparation.refresh(self._guests, self._issues, self._room_fresh, self._busy)
            self.apply_preparation.setEnabled(self.preparation_ready)
            position_guests = [g._replace(video=self.preparation.room_media(g)) for g in self._guests]
        configured = bool(self.preparation and self._prepared_inputs_key == self._input_key())
        self.positions.refresh(position_guests, self._issues, self._room_fresh, self._busy, allow_unmatched=configured)
        self.apply_positions.setEnabled(self.positions.ready and not self._busy)
        self.assignment_tabs.setEnabled(not self._busy)
        chosen = self._selected_inputs()
        counts = Counter(row[2] for row in chosen)
        valid = bool(chosen) and len(chosen) <= 12 and max(counts.values(), default=0) <= 1
        self.apply_vmix.setEnabled(self._phase == 'running' and valid and not self._busy)
        self.vmix_host.setEnabled(not self._busy)
        self.vmix_port.setEnabled(not self._busy)
        for i, g in enumerate(self._guests):
            number = self._numbers.get(g.identity, 0)
            issue = self._issues.get(g.page)
            self.table.cellWidget(i, 1).setEnabled(not issue and not self._busy)
            if not issue and number and counts[number] > 1:
                issue = 'Номер занят дважды'
            if not issue and number and len(chosen) > 12:
                issue = 'Лимит 12 камер'
            state = {'live': 'Видео подтверждено', 'absent': 'Без видео · прозрачно',
                     'unknown': 'Видео не определено · ручной вывод'}.get(g.video)
            if not number:
                state = 'Пропущен'
            self.table.item(i, 2).setText(issue or self._results.get(g.page) or state)
        self._refresh_position_media()
        if self.preparation:
            state = (self._phase, self._room_fresh, self._busy, self.preparation.revision, self.positions.revision,
                     self.preparation_ready, self.preparation_complete, self.distribution_ready, self.distribution_complete)
            if self._workflow_state != state:
                self._workflow_state = state
                self.workflow_changed.emit()

    def _apply_vmix(self):
        if self.sender() is self.apply_positions:
            self.publish_positions()
        else:
            self._submit('preparation' if self.preparation and self.sender() is self.apply_preparation else 'manual')

    def _submit(self, mode):
        table = {'preparation': self.preparation, 'positions': self.positions}.get(mode)
        ready = table.ready if table else self.apply_vmix.isEnabled()
        if not ready or self._busy:
            return False
        message = self.preparation_message if mode == 'preparation' else self.vmix_message
        try:
            host = IPv4Address(self.vmix_host.text().strip())
            if not host.is_loopback and not is_lan_address(host):
                raise ValueError
        except ValueError:
            message.setText('Укажите локальный IPv4 компьютера с vMix или 127.0.0.1.')
            self.vmix_host.setFocus()
            return False
        rows = table.commands() if table else self._selected_inputs()
        self.settings.setValue(HOST_KEY, str(host))
        self.settings.setValue(PORT_KEY, self.vmix_port.value())
        self._submitted_revision = table.revision if table else None
        self._submitted_mode = mode
        self._submitted_count = len(rows)
        self._receipt = None
        self._acknowledged.pop(mode, None)
        if mode == 'preparation':
            self._acknowledged.pop('positions', None)
        if table:
            self._results.clear()
            table.results = {n: 'В очереди' for _, _, n in rows}
        else:
            self.positions.results.clear()
            self._submitted = {number: (g.page, command) for (g, number), command in zip(self._manual_guests(), rows)}
            self._results = {page: 'В очереди' for page, _ in self._submitted.values()}
        self._busy = True
        message.setText('Применяем назначения в vMix…')
        self._refresh_vmix()
        self.apply_vmix_requested.emit(str(host), self.vmix_port.value(), rows)
        return True

    def _submitted_table(self):
        return {'preparation': self.preparation, 'positions': self.positions}.get(self._submitted_mode)

    def is_current_vmix_row(self, page, label, number):
        if self._submitted_revision is not None:
            table = self._submitted_table()
            return (table is not None and table.revision == self._submitted_revision
                    and (page, label, number) in table.commands())
        rows = self._selected_inputs()
        return (self._phase == 'running' and len(rows) <= 12 and (page, label, number) in rows
                and sum(row[2] == number for row in rows) == 1)

    def vmix_result(self, page, message):
        if page and self._busy:
            for number, (_, command) in self._submitted.items():
                if command[0] == page:
                    self.vmix_position_result(number, message)
                    break

    def vmix_position_result(self, number, message):
        if not self._busy:
            return
        message = 'Получен ответ vMix' if _PRIVATE_LINK.search(message) else message
        table = self._submitted_table()
        if table and table.revision == self._submitted_revision:
            table.results[number] = message
        elif number in self._submitted:
            page, command = self._submitted[number]
            if not self.is_current_vmix_row(*command) or self._results.get(page) == message:
                return
            self._results[page] = message
        else:
            return
        self._refresh_vmix()

    def vmix_counts(self, successful, skipped, errors):
        if self._busy:
            self._receipt = successful, skipped, errors

    def vmix_finished(self, message):
        if self._busy:
            table = self._submitted_table()
            if table:
                table.results = {k: v for k, v in table.results.items() if v != 'В очереди'}
                if self._receipt == (self._submitted_count, 0, 0) and self._submitted_revision == table.revision:
                    self._acknowledged[self._submitted_mode] = self._plan_key(table)
                    if self._submitted_mode == 'preparation':
                        self._prepared_inputs_key = self._input_key()
            status = self.preparation_message if self._submitted_mode == 'preparation' else self.vmix_message
            self._busy = False
            self._submitted.clear()
            self._submitted_mode = ''
            self._submitted_revision = None
            self.positions.results = {k: v for k, v in self.positions.results.items() if v != 'В очереди'}
            self._results = {k: v for k, v in self._results.items() if v != 'В очереди'}
            status.setText('Ответ vMix получен.' if _PRIVATE_LINK.search(message) else message)
            self._refresh_vmix()

    def stop(self):
        self._phase = 'idle'
        self._pending_url = ''
        self.status.setText('Комната отключена.')
        self._results.clear()
        self._room_fresh = False
        self._acknowledged.clear()
        self._prepared_inputs_key = None
        self._submitted_mode = ''
        if self.preparation:
            self.preparation._overrides.clear()
            self.preparation._automatic = [''] * 12
            self.preparation._choices = ['auto'] * 12
            self.preparation.results.clear()
            self.preparation_message.clear()
        self.positions._overrides.clear()
        self._submitted_revision = None
        self.positions.results.clear()
        self.vmix_message.clear()
        self.summary.clear()
        self.summary.hide()
        self.set_guests([])
        self._busy = False
        self._submitted.clear()
        self._refresh_vmix()
        self._update_controls()
