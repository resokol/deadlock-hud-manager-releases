"""Standalone production camera workspace. Match acquisition is optional before camera setup."""
import sys
from pathlib import Path
from secrets import token_urlsafe

from PySide6.QtCore import QTimer, Qt, Signal
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QFormLayout, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QMessageBox,
    QPushButton, QScrollArea, QSpinBox, QStackedWidget, QTabWidget, QVBoxLayout, QWidget,
)

from .broadcast_tables import players_by_match_position
from .camera_mapping import operator_camera_mapping
from .camera_panel import CameraPanel
from .camera_roster import CameraRoster
from .camera_routing import CameraRouting, endpoint_key
from .camera_vdo import VdoImport
from .camera_vdo_panel import VdoRoomPanel
from .camera_vdo_publish import VdoVmixPublisher, publish_room_cameras
from .camera_vdo_virtual import VirtualCopiesPanel
from .hud_pov import VmixPovPanel
from .live_stats_panel import lan_interfaces
from .match_stats import STATS_PORT, StatsLanServer
from .pov_remote import PovRemote
from .source_tv_panel import SourceTvPanel
from .ui import STYLE
from .win32 import set_dpi_awareness


class CompanionPanel(QWidget):
    """Publish completed Qt snapshots; deliver replay requests back to the GUI thread."""
    take_requested = Signal(int, str, str, str, str, int)

    def __init__(self, settings):
        super().__init__()
        self.settings = settings
        self.server = None
        self.payload = {}
        form = QFormLayout(self)
        self.share = QCheckBox('Доступ для Companion')
        self.network = QComboBox()
        for name, addr in lan_interfaces():
            self.network.addItem(f'{name} · {addr.ip}', str(addr))
        self.network.addItem('На этом ПК · 127.0.0.1', '127.0.0.1/8')
        selected = self.network.findData(settings.value('statsExportAddress', '', type=str))
        self.network.setCurrentIndex(max(0, selected))
        self.port = QSpinBox()
        self.port.setRange(1, 65535)
        self.port.setValue(settings.value('povCompanionPort', STATS_PORT + 1, type=int))
        self.port.setKeyboardTracking(False)
        self.copy = QPushButton('Копировать URL JSON для Companion')
        self.copy.clicked.connect(self._copy_json)
        self.slot = QSpinBox()
        self.slot.setRange(1, 12)
        post = QHBoxLayout()
        post.addWidget(self.slot)
        self.copy_post = QPushButton('Копировать URL POST для Replay')
        self.copy_post.clicked.connect(self._copy_post)
        post.addWidget(self.copy_post)
        self.status = QLabel()
        self.status.setWordWrap(True)
        form.addRow(self.share)
        form.addRow('Сетевой интерфейс', self.network)
        form.addRow('Порт', self.port)
        form.addRow(self.copy)
        form.addRow('Позиция кнопки', post)
        form.addRow(self.status)
        self.share.setChecked(settings.value('statsExportEnabled', False, type=bool))
        self.share.toggled.connect(self._configure)
        self.network.currentIndexChanged.connect(self._configure)
        self.port.valueChanged.connect(self._configure)
        self._configure()

    def _configure(self):
        self.stop()
        s = self.settings
        s.setValue('statsExportEnabled', self.share.isChecked())
        address = self.network.currentData()
        s.setValue('statsExportAddress', address)
        s.setValue('povCompanionPort', self.port.value())
        text = ''
        if self.share.isChecked():
            def token(key):
                value = s.value(key, '', type=str) or token_urlsafe(24)
                s.setValue(key, value)
                return value

            try:
                self.server = StatsLanServer(address, token('statsExportToken'), lambda: self.payload,
                                            port=self.port.value(), take=self._queue_take,
                                            control_token=token('povControlToken'))
                text = f'Доступно · {self.server.address}:{self.server.port}'
            except (ValueError, OSError) as exc:
                text = f'Подключение недоступно. {exc}'
        self.status.setText(text)
        for item in (self.copy, self.slot, self.copy_post):
            item.setEnabled(self.server is not None)

    def _queue_take(self, slot):
        row = self.payload.get('camera_slots', {}).get(str(slot), {})
        if row.get('replay_ready'):
            self.take_requested.emit(slot, row.get('account_id') or '', row['match_id'], row['name'],
                                     row['replay_guid'], row['replay_mix'])
            return True
        return False

    def _copy_json(self):
        if self.server:
            QApplication.clipboard().setText(self.server.url)

    def _copy_post(self):
        if self.server:
            QApplication.clipboard().setText(self.server.program_url(self.slot.value()))

    def stop(self):
        if self.server:
            self.server.close()
            self.server = None


class PovManager(QWidget):
    def __init__(self, settings):
        super().__init__()
        self.settings = settings
        self.setWindowTitle('Deadlock POV Manager')
        self.setStyleSheet(STYLE + '''
            QLabel#title { font-size: 17pt; color: #d8e6ea; }
            QLabel#workflowTitle { font-size: 19pt; font-weight: 600; color: #f2f7f8; }
            QLabel#roomHelp { color: #b7c7cc; }
            QTableWidget { background: #192229; alternate-background-color: #1f2a32;
                color: #e8eef2; gridline-color: #35424c; border: 1px solid #35424c;
                selection-background-color: #31544f; selection-color: white; }
            QHeaderView::section { background: #26323c; color: #dae5e9;
                border: 0; padding: 5px 7px; font-weight: 600; }
            QScrollArea { border: 0; }
        ''')
        self.setMinimumSize(600, 420)
        self.resize(1120, 760)
        layout = QVBoxLayout(self)
        heading = QLabel('Deadlock POV Manager')
        heading.setObjectName('title')
        header = QHBoxLayout()
        header.addWidget(heading)
        header.addStretch()
        self.tools_button = QPushButton('Инструменты')
        self.tools_button.setCheckable(True)
        header.addWidget(self.tools_button)
        layout.addLayout(header)
        self.workspaces = QStackedWidget()
        layout.addWidget(self.workspaces, 1)
        self.tabs = QTabWidget()
        self.steps = QStackedWidget()
        self._pending_connection = None
        self._received_match = None
        self._from_wizard = False
        self._publishing_positions = False
        self._position_receipt = None
        self._check_timer = QTimer(self, singleShot=True, interval=0)
        self._check_timer.timeout.connect(self._maybe_distribute)

        self.source_tv = SourceTvPanel(self)
        self.remote = PovRemote(self)
        self.camera_roster = CameraRoster(settings, right_to_left=settings.value('povPositionsFromRight', False, type=bool))
        self.camera_panels = {role: CameraPanel(role) for role in ('live', 'replay')}
        self.cameras = CameraRouting(settings, self.camera_roster, self.camera_panels, self)
        self.pov = VmixPovPanel(settings, suspended=self.cameras.managed)
        self.cameras.activated.connect(self.pov.suspend)
        self.vdo_panel = VdoRoomPanel(settings)
        self.vdo_panel.setParent(self)
        self.vdo_panel.hide()
        self.vdo_import = VdoImport(self.vdo_panel, self.cameras, self)
        self.vdo_publisher = VdoVmixPublisher(self)
        self.vdo_panel.apply_vmix_requested.connect(self._publish)
        self.vdo_publisher.result.connect(self.vdo_panel.vmix_result)
        self.vdo_publisher.position_result.connect(self.vdo_panel.vmix_position_result)
        self.vdo_publisher.batch_completed.connect(self.vdo_panel.vmix_counts)
        self.vdo_publisher.finished.connect(self.vdo_panel.vmix_finished)
        self.vdo_import.freshness_changed.connect(self.vdo_panel.set_room_fresh)
        self.vdo_import.freshness_changed.connect(self._room_fresh)
        self.cameras.inputs_claimed.connect(self._claimed)
        self.camera_roster.bind_camera_mapping(self._account_map)
        self.companion = CompanionPanel(settings)
        self.companion.take_requested.connect(self._take)
        self.names, self.match_id, self.observed = (), '', None
        self._update_in_progress = False
        room, inputs, distribution = self.vdo_panel.enable_workflow()
        self.virtual = VirtualCopiesPanel(settings, authorize=self._authorize_virtual,
                                          authorize_automatic=self._unclaimed_virtual, parent=self)
        self._virtual_session = False
        for page in (room, inputs, self._source_page(), distribution, self._virtual_page()):
            self.steps.addWidget(self._scroll(page))
        self.workspaces.addWidget(self._wizard())
        self.workspaces.addWidget(self.tabs)
        self.tools_button.toggled.connect(self._show_tools)
        self._add_tab(self._roster_tools(), 'Игроки')
        for role in ('live', 'replay'):
            self._add_tab(self.camera_panels[role], role.title())
        self._companion_index = self._add_tab(self.companion, 'Companion')
        self._add_tab(self.cameras.bank_widget, 'Пары и журнал')
        self._add_tab(self.pov, 'POV vMix')
        self.camera_panels['replay'].companion_requested.connect(self._show_companion)
        self.remote.changed.connect(self._read_source)
        self.remote.status.connect(self.remote_status.setText)
        self.source_tv.roster_changed.connect(self._read_source)
        self.source_tv.target_changed.connect(self._source_target)
        self.vdo_panel.workflow_changed.connect(self._refresh_steps)
        self.vdo_import.freshness_changed.connect(self._refresh_steps)
        self.camera_roster.changed.connect(self._render_order)
        self.cameras.changed.connect(self._export)
        self.virtual.changed.connect(self._export)
        self.vdo_panel.workflow_changed.connect(self._update_virtual)
        self.vdo_publisher.finished.connect(self._published)
        self.pov.mappings_changed.connect(self._export)
        self.vdo_panel.positions.edited.connect(self._export)
        self.vdo_panel.position_media_changed.connect(self._export)
        self.mode.currentIndexChanged.connect(self._switch_source)
        self.mode.setCurrentIndex(max(0, self.mode.findData(settings.value('povMatchSource', 'match', type=str))))
        self._read_source()
        self._refresh_steps()

    @staticmethod
    def _scroll(widget):
        area = QScrollArea()
        area.setWidgetResizable(True)
        area.setFrameShape(QScrollArea.Shape.NoFrame)
        area.setWidget(widget)
        return area

    def _add_tab(self, widget, name):
        return self.tabs.addTab(self._scroll(widget), name)

    def _wizard(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        self.step_title = QLabel()
        self.step_title.setObjectName('workflowTitle')
        layout.addWidget(self.step_title)
        layout.addWidget(self.steps, 1)
        self.step_note = QLabel()
        self.step_note.setWordWrap(True)
        layout.addWidget(self.step_note)
        nav = QHBoxLayout()
        self.back = QPushButton('Назад')
        self.back.clicked.connect(self._navigation_clicked)
        nav.addWidget(self.back)
        nav.addStretch()
        self.next = QPushButton('Далее')
        self.next.setObjectName('primary')
        self.next.clicked.connect(self._navigation_clicked)
        nav.addWidget(self.next)
        layout.addLayout(nav)
        self.steps.currentChanged.connect(self._refresh_steps)
        return page

    def _show_tools(self, opened):
        self._cancel_connection()
        self.workspaces.setCurrentIndex(1 if opened else 0)
        self.tools_button.setText('Вернуться к камерам' if opened else 'Инструменты')

    def _account_map(self):
        return operator_camera_mapping(self.camera_roster, self.cameras, self.vdo_import)

    def _show_companion(self):
        self.tools_button.setChecked(True)
        self.tabs.setCurrentIndex(self._companion_index)

    def _navigation_clicked(self):
        delta = 1 if self.sender() is self.next else -1
        self._cancel_connection()
        self.step_note.clear()
        self.steps.setCurrentIndex(self.steps.currentIndex() + delta)

    def _refresh_steps(self, *_):
        i = self.steps.currentIndex()
        title = ('Комната VDO.Ninja', 'Входы vMix', 'Источник позиций', 'Камеры по позициям', 'Виртуальные копии')[i]
        self.step_title.setText(f'Шаг {i + 1} из 5 · {title}')
        self.back.setVisible(i > 0)
        self.next.setVisible(i < 4)
        self.next.setEnabled((i == 0 and self.vdo_import.fresh) or
                             (i == 1 and self.vdo_panel.preparation_complete) or
                             (i == 2 and bool(self.names)) or
                             (i == 3 and self._applied_positions() is not None))
        if self._pending_connection and self._received_match:
            self._check_timer.start()

    def _cancel_connection(self):
        self._pending_connection = self._received_match = None
        self._check_timer.stop()

    def _arm_connection(self, expected=''):
        self._cancel_connection()
        self.step_note.clear()
        if (self.steps.currentIndex() == 2 and not self.tools_button.isChecked()
                and self.vdo_panel.preparation_complete):
            self._pending_connection = self.vdo_import.generation, expected

    def _source_target(self):
        requested = self.source_tv.requested_match_id
        if requested and self.mode.currentData() == 'match':
            self._arm_connection(requested)
        else:
            self._cancel_connection()
        # A cached roster for a reconnect is not a new snapshot.
        self._read_source(fresh_packet=False)

    def _maybe_distribute(self):
        if not self._pending_connection or not self._received_match:
            return
        generation, expected = self._pending_connection
        if (generation != self.vdo_import.generation or self.tools_button.isChecked()
                or (expected and self._received_match != expected)
                or (self.match_id and self.match_id != self._received_match)):
            self._cancel_connection()
            return
        if not self.names or self.match_id != self._received_match:
            return
        if self.steps.currentIndex() == 2:
            self.steps.setCurrentIndex(3)
        if not self.vdo_panel.distribution_ready or not self.vdo_import.fresh:
            self.step_note.setText('Ожидание готовых назначений камер.')
            return
        self._cancel_connection()
        self._from_wizard = True
        try:
            self.step_note.clear()
            self.vdo_panel.publish_positions()
        finally:
            self._from_wizard = False

    def _source_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        self.mode = QComboBox()
        self.mode.addItem('По Match ID (SourceTV)', 'match')
        self.mode.addItem('Panorama по сети (HUD Manager)', 'remote')
        layout.addWidget(self.mode)
        self.direction = QComboBox()
        self.direction.addItem('Слева направо · 1 = клавиша 1', False)
        self.direction.addItem('Справа налево · 1 = клавиша «=»', True)
        self.direction.setCurrentIndex(int(self.camera_roster.right_to_left))
        self.direction.setToolTip('Чтобы изменить порядок во время матча, сначала отключите источник позиций.')
        direction_form = QFormLayout()
        direction_form.addRow('Нумерация позиций', self.direction)
        layout.addLayout(direction_form)
        self.direction.currentIndexChanged.connect(self._change_direction)
        self.sources = QStackedWidget()
        self.source_tv.players.hide()
        self.sources.addWidget(self.source_tv)
        network = QWidget()
        form = QFormLayout(network)
        self.remote_url = QLineEdit(self.settings.value('povHudUrl', '', type=str))
        self.remote_url.setPlaceholderText('Из HUD Manager · Статистика → Копировать URL JSON матча')
        self.remote_url.setEchoMode(QLineEdit.EchoMode.PasswordEchoOnEdit)
        form.addRow('URL JSON матча', self.remote_url)
        buttons = QHBoxLayout()
        connect = QPushButton('Подключить')
        connect.clicked.connect(self._connect_remote)
        self.remote_url.returnPressed.connect(self._connect_remote)
        stop = QPushButton('Отключить')
        stop.clicked.connect(self._stop_remote)
        buttons.addWidget(connect)
        buttons.addWidget(stop)
        form.addRow(buttons)
        self.remote_status = QLabel()
        self.remote_status.setWordWrap(True)
        form.addRow(self.remote_status)
        self.sources.addWidget(network)
        layout.addWidget(self.sources)
        self.order_status = QLabel()
        self.order_status.setWordWrap(True)
        self.order_status.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.order_status)
        layout.addStretch()
        return page

    def _virtual_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.addWidget(self.virtual)
        row = QHBoxLayout()
        row.addWidget(QLabel('Mix для Replay'))
        self.replay_mix = QSpinBox()
        self.replay_mix.setRange(1, 99)
        self.replay_mix.setValue(self.settings.value('povVirtualReplayMix', 2, type=int))
        self.replay_mix.valueChanged.connect(self._mix_changed)
        row.addWidget(self.replay_mix)
        row.addStretch()
        layout.addLayout(row)
        grid = QGridLayout()
        self.replay_buttons = []
        for slot in range(1, 13):
            button = QPushButton(str(slot))
            button.setEnabled(False)
            button.clicked.connect(self._replay_clicked)
            grid.addWidget(button, (slot - 1) // 6, (slot - 1) % 6)
            self.replay_buttons.append(button)
        layout.addLayout(grid)
        self.virtual_status = QLabel()
        self.virtual_status.setWordWrap(True)
        layout.addWidget(self.virtual_status)
        return page

    def _replay_clicked(self):
        self._take_virtual(self.replay_buttons.index(self.sender()) + 1)

    def _mix_changed(self, value):
        self.settings.setValue('povVirtualReplayMix', value)
        self._export()

    def _applied_positions(self):
        receipt = self.vdo_publisher.last_receipt
        if (receipt is not None and receipt is self._position_receipt and len(receipt.rows) == 12
                and self.vdo_panel.distribution_complete):
            return receipt
        return None

    def _published(self, *_):
        self._position_receipt = self.vdo_publisher.last_receipt if self._publishing_positions else None
        self._publishing_positions = False
        self._update_virtual()
        self._refresh_steps()

    def _update_virtual(self, *_):
        receipt = self._applied_positions()
        if receipt is None:
            self.virtual.set_distribution(None)
        else:
            self.virtual.set_distribution(receipt, self.vdo_panel.positions.revision)

    def _unclaimed_virtual(self, endpoint, guids):
        return not (self.cameras.conflicting_modules(endpoint, guids) or
                    (not self.pov.suspended and self.pov.endpoint == endpoint
                     and (self.pov.rename or self.pov.player_pages)))

    def _authorize_virtual(self, endpoint, guids):
        roles = self.cameras.conflicting_modules(endpoint, guids)
        legacy = (not self.pov.suspended and self.pov.endpoint == endpoint
                  and (self.pov.rename or self.pov.player_pages))
        if roles or legacy:
            names = ', '.join([r.title() for r in roles] + (['POV vMix'] if legacy else []))
            result = QMessageBox.question(self, 'Управление входами',
                f'Входами управляет {names}. Передать их помощнику виртуальных копий?',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
            if result != QMessageBox.StandardButton.Yes:
                return False
            if legacy:
                self.cameras.managed = True
                self.cameras.activated.emit()
                self.cameras.save()
        self.cameras.release_inputs(endpoint, guids, roles)
        return True

    def _mix_conflict(self):
        receipt = self._applied_positions()
        if not receipt:
            return False
        mix = self.replay_mix.value()
        if (not self.pov.suspended and self.pov.endpoint == receipt.endpoint and
                (self.pov.auto and mix in self.pov.original_mixes or mix in self.pov.copy_mixes)):
            return True
        return any(cfg['enabled'] and cfg['mode'] == 'program' and cfg['mix'] == mix
                   and endpoint_key(cfg) == receipt.endpoint for cfg in self.cameras.config.values())

    def _take_virtual(self, slot):
        if not self._mix_conflict() and self.virtual.route(slot):
            self.virtual.take(slot, self.replay_mix.value())

    def _roster_tools(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.addWidget(self.camera_roster)
        prepare = QPushButton('Камеры до матча…')
        prepare.clicked.connect(self._edit_preparation)
        layout.addWidget(prepare, alignment=Qt.AlignmentFlag.AlignLeft)
        return page

    def _edit_preparation(self):
        self.cameras.edit_preparation(self)

    def _change_direction(self):
        self._cancel_connection()
        reverse = self.direction.currentData()
        self.settings.setValue('povPositionsFromRight', reverse)
        self.camera_roster.set_direction(reverse)
        self._read_source(fresh_packet=False)

    def _switch_source(self, index):
        self._cancel_connection()
        self.settings.setValue('povMatchSource', self.mode.currentData())
        self.sources.setCurrentIndex(index)
        if self.mode.currentData() == 'remote':
            self.source_tv.stop()
        else:
            self.remote.stop()
        self._read_source()

    def _connect_remote(self):
        url = self.remote_url.text().strip()
        self.settings.setValue('povHudUrl', url)
        self._cancel_connection()
        if self.remote.set_url(url):
            self._arm_connection()

    def _stop_remote(self):
        self._cancel_connection()
        self.remote.stop()

    def _read_source(self, *_, fresh_packet=True):
        net = self.mode.currentData() == 'remote'
        packet = self.remote.snapshot if net else None
        roster = self.source_tv.roster
        if net:
            roster = packet.roster if packet else None
        if not net and self.source_tv.requested_match_id and str((roster or {}).get('matchId')) != self.source_tv.requested_match_id:
            roster = None
        slots = dict(enumerate(packet.names, 1)) if packet else {}
        self._update_in_progress = True
        try:
            self.camera_roster.update_match(roster, {str(i): name for i, name in slots.items()},
                                            packet.observed if packet else None, bool(packet and roster))
        finally:
            self._update_in_progress = False
        self._render_order()
        if self._pending_connection and fresh_packet and self.names:
            if self._received_match and self._received_match != self.match_id:
                self._cancel_connection()
            else:
                self._received_match = self.match_id
                self._check_timer.start()

    def _render_order(self):
        if self._update_in_progress:
            return
        packet = self.remote.snapshot if self.mode.currentData() == 'remote' else None
        trusted = self.camera_roster.manual_names()
        match_id = self.camera_roster.match_id or ''
        observed = None
        if packet:
            # Follow the same person when an operator overrides the visual ordering.
            names = trusted or self.camera_roster.orient(packet.names)
            selected = packet.names[packet.observed - 1] if packet.observed else None
            observed = names.index(selected) + 1 if selected in names else None
            source = (f'Ручной порядок · матч {packet.match_id}' if trusted else f'Panorama по сети · {self.camera_roster.direction_text} · матч {packet.match_id}')
            match_id = packet.match_id
        elif self.mode.currentData() == 'match':
            roster = self.source_tv.roster
            requested = self.source_tv.requested_match_id
            if requested and str((roster or {}).get('matchId')) != requested:
                roster = None
            match_id = str((roster or {}).get('matchId') or '')
            api = players_by_match_position(roster)
            names = trusted or self.camera_roster.orient(tuple(api[str(i)] for i in range(1, len(api) + 1)))
            source = f'Ручной порядок · матч {match_id}' if trusted else f'SourceTV · матч {match_id} · сверьте порядок по линиям с HUD.'
        else:
            names, source = (), ''
        if not match_id or len(names) != 12 or len({name.strip().casefold() for name in names}) != 12:
            names, source = (), ''
        self.names, self.match_id, self.observed = names, match_id, observed
        self.direction.setEnabled(not match_id)
        self.order_status.setText(source or 'Ожидание позиций игроков.')
        self.vdo_panel.set_hud_order(names, source)
        self.pov.set_hud_slots({str(i): name for i, name in enumerate(names, 1)})
        self.pov.set_observed(observed)
        self._export()
        self._refresh_steps()

    def _export(self):
        cameras = self.cameras
        if self.virtual.complete:
            self._virtual_session = True
        direct = self.virtual.complete
        direct_owner = direct or self._virtual_session
        mix_conflict = direct and self._mix_conflict()
        self.virtual_status.setText('Этот Mix занят другим модулем. Выберите свободный Mix.' if mix_conflict else '')
        slots = {}
        replay_inputs = {}
        labels = {}
        pov_inputs = {}
        numbers = tuple(field.value() for field in self.vdo_panel.positions.inputs)
        if cameras.managed:
            numbers = tuple(live or direct for live, direct in zip(cameras.input_numbers(), numbers))
        elif self.pov.auto or self.pov.rename or self.pov.copy_mixes or self.pov.player_pages:
            numbers = self.pov.inputs
        for i, name in enumerate(self.names, 1):
            key = str(i)
            account = self.camera_roster.slots.get(i, '')
            bank = cameras.owners.index(account) if account and account in cameras.owners else None
            physical = numbers[i - 1]
            ready = cameras.routable('replay', account) if cameras.managed and account else bool(
                not cameras.managed and self.pov.targets(i))
            media = self.vdo_panel.position_media(i)
            if cameras.managed:
                has_camera = bool(account and cameras.has_camera(account))
            else:
                has_camera = media == 'live'
            source_guid = cameras.config['live']['guids'][bank] if bank is not None else ''
            replay_guid = cameras.config['replay']['guids'][bank] if bank is not None else ''
            replay_number = None
            mix = cameras.config['replay']['mix'] if cameras.managed else 0
            route = self.virtual.route(i) if direct else None
            if direct_owner:
                ready = bool(route and not route['empty'] and not mix_conflict)
                replay_guid = route['virtual_guid'] if route else ''
                mix = self.replay_mix.value()
                if route:
                    replay_number = replay_inputs[key] = route['virtual_number']
                    source_guid = route['original_guid']
                    physical = route['original_number']
                    has_camera = not route['empty']
            if physical:
                pov_inputs.setdefault(str(physical), []).append(name)
            player = self.camera_roster.players.get(account, {})
            slots[key] = dict(name=name, account_id=account, match_id=self.match_id, key=self.camera_roster.position_keys[i - 1],
                              has_camera=has_camera, vdo_video=media, replay_ready=ready, hero=player.get('hero'),
                              hero_id=player.get('heroId'), team=player.get('side'),
                              live_guid=source_guid, replay_guid=replay_guid, replay_input=replay_number,
                              replay_mix=mix)
            labels[key] = name + ('\nНет камеры' if (cameras.managed and not has_camera) or media == 'absent' else
                                  '\nНедоступна' if cameras.managed and not ready else '')
        for pos, button in enumerate(self.replay_buttons, 1):
            item = slots.get(str(pos), {})
            button.setText(f"{pos} · {item.get('name') or '—'}")
            button.setEnabled(direct and item.get('replay_ready') is True)
        self.companion.payload = dict(version=1, replay_inputs=replay_inputs, matchId=self.match_id or None, status='live' if slots else 'waiting',
            hud_slots={key: row['name'] for key, row in slots.items()}, hud_observed_slot=self.observed,
            pov_inputs={key: group[0] for key, group in pov_inputs.items() if len(group) == 1},
            camera_slots=slots, replay_button_labels={str(i): labels.get(str(i), '—') for i in range(1, 13)})

    def _take(self, slot, account, match_id, name, guid, mix):
        row = self.companion.payload.get('camera_slots', {}).get(str(slot), {})
        if not row.get('replay_ready') or (row['account_id'], row['match_id'], row['name'],
                row['replay_guid'], row['replay_mix']) != (account, match_id, name, guid, mix):
            return
        if self._virtual_session:
            self._take_virtual(slot)
        elif self.cameras.managed:
            self.cameras.take('replay', slot)
        else:
            self.pov.take(slot)

    def _room_fresh(self, fresh):
        if not fresh:
            self.vdo_publisher.cancel()

    def _claimed(self, endpoint, guids):
        if self.vdo_publisher.active_endpoint == endpoint:
            self.vdo_publisher.cancel()
        if self._virtual_session and self.cameras.config['replay']['enabled']:
            # An explicit Replay setup takes ownership back from the direct wizard.
            self._virtual_session = False
        self.virtual.invalidate_claim(endpoint, guids)
        self.vdo_publisher.forget(guids, endpoint=endpoint)
        self._update_virtual()

    def _publish(self, host, port, rows):
        self._publishing_positions = self.vdo_panel.submitted_mode == 'positions'
        self._position_receipt = None
        self._update_virtual()
        publish_room_cameras(self, self.vdo_panel, self.vdo_import, self.vdo_publisher,
                             self.cameras, self.pov, host, port, rows,
                             on_auto_conflict=self.step_note.setText if self._from_wizard else None)

    def closeEvent(self, event):
        self._cancel_connection()
        self.camera_roster.bind_camera_mapping(dict)
        self.virtual.close_session()
        self.companion.stop()
        self.remote.stop()
        self.source_tv.stop()
        self.vdo_publisher.cancel()
        self.vdo_import.stop()
        self.cameras.close()
        self.pov.shutdown()
        self.source_tv.process.waitForFinished(1500)
        self.settings.sync()
        super().closeEvent(event)


def main(settings=None):
    set_dpi_awareness()
    app = QApplication(sys.argv[:1])
    app.setWindowIcon(QIcon(str(Path(__file__).with_name('assets') / 'dhm.ico')))
    from PySide6.QtWidgets import QMessageBox
    from .pov_instance import PovInstance

    try:
        instance = PovInstance()
        if not instance.acquire():
            return 0
    except OSError as exc:
        QMessageBox.warning(None, 'Deadlock POV Manager', str(exc))
        return 1
    if settings is None:
        from .manager_settings import pov_settings
        settings = pov_settings()
    window = PovManager(settings)
    def activate():
        if window.isMinimized():
            window.showNormal()
        window.raise_()
        window.activateWindow()

    instance.activate.connect(activate)
    window.show()
    try:
        return app.exec()
    finally:
        instance.close()


if __name__ == '__main__':
    raise SystemExit(main())
