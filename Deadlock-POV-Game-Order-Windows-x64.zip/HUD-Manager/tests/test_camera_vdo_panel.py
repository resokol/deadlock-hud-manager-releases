import json
import os
from weakref import ref

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

import pytest
from PySide6.QtCore import QSettings
from PySide6.QtWidgets import QApplication, QLineEdit

from observer_assist.camera_vdo_panel import POLL_INTERVAL_KEY, SETTINGS_KEY, VdoRoomPanel


DIRECTOR = 'https://vdo.ninja/?director=example&password=private-room-password'


@pytest.fixture
def panel(tmp_path):
    app = QApplication.instance() or QApplication([])
    settings = QSettings(str(tmp_path / 'camera.ini'), QSettings.Format.IniFormat)
    result = VdoRoomPanel(settings)
    result.show()
    yield result
    result.close()


def test_blank_or_whitespace_never_starts(panel):
    starts = []
    panel.start_requested.connect(starts.append)
    panel.url.setText('   ')
    panel.connect_button.click()
    panel.url.returnPressed.emit()
    assert not starts
    assert not panel.connect_button.isEnabled()


def test_saves_only_on_success_and_keeps_links_private(panel):
    starts = []
    panel.start_requested.connect(starts.append)
    panel.url.setText(DIRECTOR)
    panel.connect_button.click()
    panel.url.returnPressed.emit()
    assert starts == [DIRECTOR]
    assert not panel.settings.contains(SETTINGS_KEY)
    panel.start_failed('Ошибка подключения к ' + DIRECTOR)
    assert 'private-room-password' not in panel.status.text()
    assert not panel.settings.contains(SETTINGS_KEY)
    assert not panel.url.isReadOnly()
    panel.connect_button.click()
    panel.started()
    assert panel.settings.value(SETTINGS_KEY) == DIRECTOR
    assert panel.url.isReadOnly()
    reopened = VdoRoomPanel(panel.settings)
    assert reopened.url.text() == DIRECTOR
    assert reopened.url.echoMode() == QLineEdit.EchoMode.Password
    assert 'private-room-password' not in reopened.url.displayText()


def test_reopen_stop_and_discovery_feedback(panel):
    stops, reopens = [], []
    panel.stop_requested.connect(lambda: stops.append(True))
    panel.reopen_requested.connect(lambda: reopens.append(True))
    panel.url.setText(DIRECTOR)
    panel.connect_button.click()
    panel.started()
    panel.show_result(5, 'Назначено 2. Без имени 1. Конфликт имён 2.')
    assert panel.status.text().endswith('5')
    assert 'Конфликт' in panel.summary.text()
    assert panel.reopen_button.isVisible()
    panel.reopen_button.click()
    assert reopens == [True]
    panel.show_result(0, 'Недоступна ссылка ' + DIRECTOR)
    assert 'private-room-password' not in panel.summary.text()
    panel.stop_button.click()
    assert stops == [True]
    panel.stop()
    panel.show_result(10, 'Устаревший ответ')
    assert not panel.reopen_button.isVisible()
    assert panel.connect_button.isVisible()
    assert not panel.summary.isVisible()
    assert 'отключена' in panel.status.text()


def test_late_start_after_stop_does_not_save(panel):
    panel.url.setText(DIRECTOR)
    panel.connect_button.click()
    panel.stop()
    panel.started()
    assert not panel.settings.contains(SETTINGS_KEY)
    assert not panel.url.isReadOnly()


def test_director_default_and_explicit_scene_preference_survives_success_only(panel):
    assert panel.director_mode.isChecked()
    assert 'Co-Director' in panel.mode_hint.text()
    assert 'Room Settings' in panel.mode_hint.text()
    panel.director_mode.setChecked(False)
    assert 'Режим сцены' in panel.mode_hint.text()
    panel.url.setText(DIRECTOR)
    panel.connect_button.click()
    assert not panel.director_mode.isEnabled()
    panel.start_failed('Попробуйте снова.')
    assert VdoRoomPanel(panel.settings).director_mode.isChecked()
    assert panel.director_mode.isEnabled()
    panel.connect_button.click()
    panel.started()
    assert not VdoRoomPanel(panel.settings).director_mode.isChecked()


def test_poll_interval_default_bounds_and_saved_choice(panel):
    assert panel.poll_interval.value() == 3
    assert (panel.poll_interval.minimum(), panel.poll_interval.maximum()) == (1, 60)
    panel.poll_interval.setValue(15)
    assert VdoRoomPanel(panel.settings).poll_interval.value() == 15
    panel.settings.setValue(POLL_INTERVAL_KEY, 'invalid')
    assert VdoRoomPanel(panel.settings).poll_interval.value() == 3


def test_heartbeat_timeout_clears_previous_guests_and_recovers(panel):
    panel.url.setText(DIRECTOR)
    panel.connect_button.click()
    panel.started()
    panel.show_result(7, 'Назначено 7.')
    panel.show_stale()
    assert '7' not in panel.status.text()
    assert not panel.summary.isVisible()
    assert panel.reopen_button.isVisible()
    panel.show_result(3, 'Назначено 3.')
    assert panel.status.text() == 'Видимых гостей · 3'
    assert panel.summary.isVisible()


def test_guest_table_preserves_selection_and_copies_only_the_selected_viewer_url(panel):
    panel.url.setText(DIRECTOR)
    panel.connect_button.click()
    panel.started()
    first = dict(label='Fox', bank=7, page='https://vdo.ninja/?view=first&token=private')
    second = dict(label='', bank=None, page='https://vdo.ninja/?view=second')
    clipboard = QApplication.clipboard()
    clipboard.setText('до выбора')
    panel.set_guests([first, second])
    assert panel.table.rowCount() == 2
    assert panel.table.item(0, 0).text() == 'Fox'
    assert panel.table.cellWidget(0, 1).value() == 1
    assert panel.table.item(0, 3).text() == '7' and panel.table.isColumnHidden(3)
    assert panel.table.item(1, 0).text() == 'Без имени'
    assert not panel.table.cellWidget(1, 1).isEnabled()
    assert panel.table.item(1, 3).text() == 'Не назначена'
    assert not panel.copy_button.isEnabled()
    panel.table.selectRow(0)
    original_cell = panel.table.item(0, 0)
    panel.set_guests([dict(first), dict(second)])
    assert panel.table.item(0, 0) is original_cell
    panel.set_guests([second, dict(first, bank=8)])
    assert panel.table.currentRow() == 1
    assert clipboard.text() == 'до выбора'
    panel.copy_button.click()
    assert clipboard.text() == first['page']
    panel.set_guests([second])
    assert not panel.copy_button.isEnabled()
    panel.show_stale()
    assert panel.table.rowCount() == 0
    assert not panel.table.isVisible()
    panel.set_guests([second])
    assert panel.table.rowCount() == 1
    panel.stop()
    assert panel.table.rowCount() == 0
    assert not panel.copy_button.isVisible()


def connect_room(panel, url=DIRECTOR):
    panel.url.setText(url)
    panel.connect_button.click()
    panel.started()


def guest(i, label=None):
    return dict(label=f'Player {i}' if label is None else label, bank=100-i, video='live',
                page=f'https://vdo.ninja/?view=stream-{i}&solo=1&password=test-key', streamID=f'stream-{i}')


def test_vmix_assignments_ignore_routing_banks_and_survive_room_reconnects(panel):
    connect_room(panel)
    a, b, c = [guest(i) for i in (1, 2, 3)]
    panel.set_guests([a, b])
    panel.table.cellWidget(0, 1).setValue(42)
    panel.set_guests([b, c, a])
    assert [panel.table.cellWidget(i, 1).value() for i in range(3)] == [2, 1, 42]
    keys = [k for k in panel.settings.allKeys() if k.startswith('cameraVdoInputNumbers/')]
    assert len(keys) == 1
    assert all(len(key) == 64 for key in json.loads(panel.settings.value(keys[0])))
    assert 'stream-1' not in panel.settings.value(keys[0])
    other = VdoRoomPanel(panel.settings)
    connect_room(other)
    other.set_guests([a])
    assert other.table.cellWidget(0, 1).value() == 42
    other.stop()
    connect_room(other, 'https://vdo.ninja/?director=other')
    other.set_guests([a])
    assert other.table.cellWidget(0, 1).value() == 1


def test_only_current_valid_unique_vmix_inputs_are_sent(panel):
    connect_room(panel)
    rows = [guest(1), guest(2), guest(3, ''), guest(4, 'Duplicate'), guest(5, 'DuPlicate')]
    panel.set_guests(rows)
    calls = []
    panel.apply_vmix_requested.connect(lambda h, p, r: calls.append((h, p, r)))
    panel.table.cellWidget(1, 1).setValue(1)
    assert not panel.apply_vmix.isEnabled()
    assert 'дважды' in panel.table.item(1, 2).text()
    panel.table.cellWidget(1, 1).setValue(21)
    assert not panel.table.cellWidget(2, 1).isEnabled()
    assert 'Повторяется' in panel.table.item(3, 2).text()
    panel.vmix_host.setText('8.8.8.8')
    panel.apply_vmix.click()
    assert not calls
    panel.vmix_host.setText('10.1.2.3')
    panel.apply_vmix.click()
    assert calls == [('10.1.2.3', 8088, [(rows[0]['page'], 'Player 1', 1), (rows[1]['page'], 'Player 2', 21)])]
    assert not panel.apply_vmix.isEnabled() and not panel.table.cellWidget(0, 1).isEnabled()
    assert panel.is_current_vmix_row(rows[0]['page'], 'Player 1', 1)
    panel.vmix_result(rows[0]['page'], 'Готово')
    assert panel.table.item(0, 2).text() == 'Готово'
    panel.vmix_result(rows[1]['page'], rows[1]['page'])
    assert 'test-key' not in panel.table.item(1, 2).text()
    panel.set_guests(rows[1:])
    assert not panel.is_current_vmix_row(rows[0]['page'], 'Player 1', 1)
    panel.vmix_finished('Обновлено')
    assert panel.apply_vmix.isEnabled() and panel.vmix_message.text() == 'Обновлено'
    panel.show_stale()
    assert not panel.apply_vmix.isEnabled()
    assert not panel.is_current_vmix_row(rows[1]['page'], 'Player 2', 21)


def test_default_limit_and_manual_overflow(panel):
    connect_room(panel)
    rows = [guest(i) for i in range(20)]
    panel.set_guests(rows)
    assert [panel.table.cellWidget(i, 1).value() for i in range(20)] == list(range(1, 13)) + [0] * 8
    panel.table.cellWidget(12, 1).setValue(99)
    assert not panel.apply_vmix.isEnabled()
    panel.table.cellWidget(0, 1).setValue(0)
    assert panel.apply_vmix.isEnabled()


def test_vmix_endpoint_and_forwarding_upgrade(tmp_path, panel):
    previous = QSettings(str(tmp_path / 'upgrade.ini'), QSettings.Format.IniFormat)
    previous.setValue('cameraRoutingV1', json.dumps({'live': {'host': '192.168.4.7', 'port': 8100, 'enabled': True}}))
    previous.setValue(SETTINGS_KEY, DIRECTOR)
    upgraded = VdoRoomPanel(previous)
    assert upgraded.forward_to_modules.isChecked()
    assert upgraded.vmix_host.text() == '192.168.4.7' and upgraded.vmix_port.value() == 8100
    upgraded.forward_to_modules.setChecked(False)
    assert not VdoRoomPanel(previous).forward_to_modules.isChecked()
    assert not panel.forward_to_modules.isChecked()


def test_same_room_accepts_twelve_replacements_and_late_return(panel):
    connect_room(panel)
    old = [guest(i) for i in range(12)]
    new = [guest(i + 100) for i in range(12)]
    panel.set_guests(old)
    panel.set_guests(new)
    assert [panel.table.cellWidget(i, 1).value() for i in range(12)] == list(range(1, 13))
    # All current numbers are taken. The returning former holder must not collide.
    panel.set_guests([old[0], *new])
    assert panel.table.cellWidget(0, 1).value() == 0
    panel.set_guests([old[0], *new[1:]])
    assert panel.table.cellWidget(0, 1).value() == 1
    assert panel.apply_vmix.isEnabled()
    panel.table.cellWidget(0, 1).setValue(2)
    assert not panel.apply_vmix.isEnabled()
    panel.set_guests(list(reversed([old[0], *new[1:]])))
    assert not panel.apply_vmix.isEnabled()


def test_short_disconnect_and_distinct_internal_spaces(panel):
    connect_room(panel)
    a, b, c = guest(1, 'Soul  King'), guest(2, 'Soul King'), guest(3)
    panel.set_guests([a, b])
    panel.set_guests([b, c])
    assert [panel.table.cellWidget(i, 1).value() for i in range(2)] == [2, 3]
    panel.set_guests([b, a, c])
    assert [panel.table.cellWidget(i, 1).value() for i in range(3)] == [2, 1, 3]
    assert panel.apply_vmix.isEnabled()


def test_editor_reorder_and_deferred_teardown_in_event_loop(panel):
    from PySide6.QtCore import QCoreApplication, QEvent, QEventLoop, QTimer

    connect_room(panel)
    a, b = guest(1), guest(2)
    panel.set_guests([a, b])
    first_editor = panel.table.cellWidget(0, 1)
    panel.set_guests([b, a])
    assert panel.table.cellWidget(0, 1) is first_editor
    first_editor.setValue(17)
    assert panel.is_current_vmix_row(b['page'], b['label'], 17)
    assert panel.is_current_vmix_row(a['page'], a['label'], 1)
    panel.show_stale()
    panel.set_guests([a])
    QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
    loop = QEventLoop()
    QTimer.singleShot(0, loop.quit)
    loop.exec()
    assert panel.is_current_vmix_row(a['page'], a['label'], 1)


def test_hud_position_preview_and_explicit_apply_clear_only_unmatched_rows(panel):
    connect_room(panel)
    panel.assignment_tabs.setCurrentIndex(1)
    names = [f'Player {i}' for i in range(1, 13)]
    panel.set_hud_order(names, 'Источник · Panorama')
    panel.set_guests([guest(12, 'player 12'), guest(3, 'PLAYER 3')])
    assert not panel.apply_positions.isEnabled()
    panel.set_room_fresh(True)
    assert panel.apply_positions.isEnabled()
    assert panel.positions.table.item(2, 3).text() == 'Player 3'
    assert panel.positions.table.item(3, 3).text() == '-'
    assert 'Прозрачных входов · 10' in panel.positions.hint.text()
    panel.positions.inputs[2].setValue(33)
    assert panel.table.cellWidget(1, 1).value() == 2
    reopened = VdoRoomPanel(panel.settings)
    assert reopened.positions.inputs[2].value() == 33
    calls = []
    panel.apply_vmix_requested.connect(lambda host, port, rows: calls.append(rows))
    panel.apply_positions.click()
    rows, = calls
    assert len(rows) == 12 and rows[2] == (guest(3)['page'], 'Player 3', 33)
    assert rows[11] == (guest(12)['page'], 'Player 12', 12)
    assert rows[0] == ('', '-', 1) and rows[1] == ('', '-', 2)
    assert all(panel.is_current_vmix_row(*r) for r in rows)
    assert not panel.positions.inputs[2].isEnabled()
    panel.vmix_position_result(1, 'Очищен')
    assert panel.positions.table.item(0, 4).text() == 'Очищен'
    assert panel.positions.table.item(1, 4).text() != 'Очищен'
    panel.set_hud_order(names[::-1], 'Источник · Panorama')
    assert not any(panel.is_current_vmix_row(*r) for r in rows)
    panel.vmix_finished('Остановлено')
    panel.set_guests([guest(12)])
    assert 'Прозрачных входов · 11' in panel.positions.hint.text()
    panel.set_room_fresh(False)
    assert not panel.apply_positions.isEnabled()
    assert panel.positions.table.item(0, 3).text() == '—'


def test_hud_positions_block_unknown_order_ambiguous_guests_and_all_empty_plan(panel):
    connect_room(panel)
    panel.assignment_tabs.setCurrentIndex(1)
    names = ['Soul  King', 'Other Player'] + [f'Player {i}' for i in range(3, 13)]
    panel.set_room_fresh(True)
    panel.set_guests([guest(90, 'SOUL KING')])
    panel.set_hud_order(names, 'Вручную')
    assert not panel.apply_positions.isEnabled() and 'Нет совпадений' in panel.positions.hint.text()
    panel.set_guests([guest(90, 'Soul  King'), guest(91, 'soul  king'), guest(3)])
    assert not panel.apply_positions.isEnabled()
    assert 'Повторяется ник' in panel.positions.table.item(0, 4).text()
    panel.set_guests([guest(91, 'SOUL  KING')])
    assert panel.apply_positions.isEnabled()
    panel.positions.inputs[11].setValue(1)
    assert not panel.apply_positions.isEnabled()
    panel.positions.inputs[11].setValue(12)
    for invalid in (names[:-1], names + [''], ['Soul  King'] * 12, [], 'abcdefghijkl'):
        panel.set_hud_order(invalid, '')
        assert not panel.apply_positions.isEnabled()
        assert panel.positions.table.item(0, 1).text() == '—'
    panel.set_hud_order(names, 'Вручную')
    panel.set_guests([])
    assert not panel.apply_positions.isEnabled()


def test_same_players_in_different_match_invalidate_inflight_and_old_results(panel):
    connect_room(panel)
    names = [f'Player {i}' for i in range(1, 13)]
    panel.assignment_tabs.setCurrentIndex(1)
    panel.set_hud_order(names, 'Panorama · матч 101')
    panel.set_guests([guest(1)])
    panel.set_room_fresh(True)
    panel.apply_positions.click()
    panel.vmix_position_result(1, 'Готово')
    assert panel.positions.table.item(0, 4).text() == 'Готово'
    panel.set_hud_order(names, 'Panorama · матч 202')
    assert panel.positions.table.item(0, 4).text() == 'Видео подтверждено'
    assert not panel.is_current_vmix_row(guest(1)['page'], names[0], 1)
    assert not panel.is_current_vmix_row('', '-', 2)
    panel.set_hud_order(names, 'Panorama · матч 101')
    assert not panel.is_current_vmix_row('', '-', 2)
    panel.vmix_position_result(2, 'Опоздавший ответ')
    assert panel.positions.table.item(1, 4).text() != 'Опоздавший ответ'


def test_position_media_evidence_preserves_hud_identity_and_unknown_inputs(panel):
    connect_room(panel)
    names = ['obikym'] + [f'Player {i}' for i in range(2, 13)]
    panel.assignment_tabs.setCurrentIndex(1)
    panel.set_hud_order(names, 'Panorama · матч 255')
    panel.set_room_fresh(True)
    no_video = dict(guest(1, 'ObiKym'), video='absent')
    unknown = dict(guest(2), video='unknown')
    panel.set_guests([no_video, unknown, guest(3)])
    commands = panel.positions.commands()
    assert ('', '-', 1) in commands
    assert not any(number == 2 for _, _, number in commands)
    assert (guest(3)['page'], names[2], 3) in commands
    assert panel.positions.table.item(0, 1).text() == 'obikym'
    assert panel.positions.table.item(0, 3).text() == '-'
    assert 'пропуск' in panel.positions.table.item(1, 4).text()
    panel.set_guests([no_video] + [dict(guest(i), video='absent') for i in range(2, 13)])
    assert panel.apply_positions.isEnabled()
    assert panel.positions.commands() == [('', '-', i) for i in range(1, 13)]
    panel.set_room_fresh(False)
    assert not panel.positions.commands()


def test_legacy_unknown_can_be_confirmed_per_stream_and_expires(panel):
    connect_room(panel)
    names = [f'Player {n}' for n in range(1, 13)]
    panel.assignment_tabs.setCurrentIndex(1)
    panel.set_hud_order(names, 'Match 42')
    panel.set_room_fresh(True)
    unknown = guest(1)
    del unknown['video']
    panel.set_guests([unknown])
    assert not panel.apply_positions.isEnabled()
    panel.positions.table.selectRow(0)
    panel.positions.override.setCurrentIndex(panel.positions.override.findData('absent'))
    assert panel.positions.commands() == [('', '-', i) for i in range(1, 13)]
    panel.positions.override.setCurrentIndex(panel.positions.override.findData('live'))
    assert panel.positions.commands()[0] == (unknown['page'], names[0], 1)
    panel.set_guests([dict(unknown, video='absent')])
    assert panel.positions.commands()[0] == ('', '-', 1)
    panel.set_guests([unknown])
    assert not panel.apply_positions.isEnabled()
    panel.set_guests([guest(1), guest(2)])
    panel.set_guests([unknown, guest(2)])
    assert not any(row[2] == 1 for row in panel.positions.commands())


def test_manual_status_clears_named_audio_only_guest(panel):
    connect_room(panel)
    panel.set_guests([dict(guest(1, 'obikym'), video='absent'), dict(guest(2), video='absent')])
    batches = []
    panel.apply_vmix_requested.connect(lambda h, port, rows: batches.append(rows))
    panel.apply_vmix.click()
    assert batches == [[('', '-', 1), ('', '-', 2)]]
    panel.vmix_position_result(2, 'Очищено')
    assert panel.table.item(1, 2).text() == 'Очищено'
    assert panel.table.item(0, 2).text() == 'В очереди'


def test_operator_marks_black_placeholder_and_can_reset_on_same_stream(panel):
    connect_room(panel)
    panel.set_hud_order(['obikym'] + [f'Player {i}' for i in range(2, 13)], 'Матч 1')
    panel.set_room_fresh(True)
    panel.assignment_tabs.setCurrentIndex(1)
    observed = []
    owner = ref(panel)
    panel.position_media_changed.connect(lambda: observed.append(owner().position_media(1)))
    camera = guest(1, 'obikym')
    panel.set_guests([camera])
    assert panel.position_media(1) == 'live' and panel.position_media(2) == 'absent'
    panel.positions.table.selectRow(0)
    override = panel.positions.override
    override.setCurrentIndex(override.findData('absent'))
    assert panel.positions.commands()[0] == ('', '-', 1)
    assert panel.positions.table.item(0, 1).text() == 'obikym'
    panel.show_stale()
    assert panel.position_media(1) == 'unknown'
    panel.set_guests([camera])
    panel.set_room_fresh(True)
    assert observed == ['live', 'absent', 'unknown', 'absent']
    panel.positions.table.selectRow(0)
    override.setCurrentIndex(override.findData('unknown'))
    assert panel.position_media(1) == 'live'
    override.setCurrentIndex(override.findData('absent'))
    panel.set_guests([guest(99, 'obikym')])
    assert panel.position_media(1) == 'live'
    override.setCurrentIndex(override.findData('absent'))
    panel.set_hud_order(panel.positions.names, 'Матч 2')
    assert panel.position_media(1) == 'live'
    panel.set_guests([dict(guest(99, 'obikym'), video='absent')])
    assert not override.model().item(override.findData('live')).isEnabled()
    override.setCurrentIndex(override.findData('live'))
    assert panel.position_media(1) == 'absent'


def test_workflow_uses_one_set_of_physical_inputs_before_and_after_match(panel):
    room, preparation, distribution = panel.enable_workflow()
    assert (room, preparation, distribution) == panel.enable_workflow()
    assert room.isAncestorOf(panel.url) and not panel.advanced.isChecked()
    assert preparation.isAncestorOf(panel.vmix_host) and preparation.isAncestorOf(panel.apply_preparation)
    assert distribution.isAncestorOf(panel.apply_positions)
    assert panel.positions.table.horizontalHeaderItem(0).text() == 'Позиция'
    assert not panel.preparation_ready and not panel.distribution_ready
    snapshots = []
    panel.apply_vmix_requested.connect(lambda host, port, rows: snapshots.append(rows))
    connect_room(panel)
    a, b = guest(1, 'Anna'), guest(2, 'Bob')
    panel.set_guests([b, a])
    panel.set_room_fresh(True)
    panel.preparation.inputs[0].setValue(90)
    panel.preparation.inputs[1].setValue(52)
    assert [s.value() for s in panel.positions.inputs[:2]] == [90, 52]
    assert panel.preparation_ready and not panel.distribution_ready and not snapshots
    panel.apply_preparation.click()
    expected = [(a['page'], 'Anna', 90), (b['page'], 'Bob', 52)] + [('', '-', i) for i in range(3, 13)]
    assert snapshots == [expected] and all(panel.is_current_vmix_row(*row) for row in expected)
    panel.vmix_counts(11, 1, 0)
    panel.vmix_finished('Не все входы готовы')
    assert not panel.preparation_complete
    panel.apply_preparation.click()
    panel.vmix_counts(12, 0, 0)
    panel.vmix_finished('Готово')
    assert panel.preparation_complete and panel.preparation_message.text() == 'Готово'
    panel.set_hud_order(['Bob', 'Anna'] + [f'P{i}' for i in range(3, 13)], 'Матч 1')
    assert panel.distribution_ready and panel.publish_positions()
    assert snapshots[-1][:2] == [(b['page'], 'Bob', 90), (a['page'], 'Anna', 52)]
    panel.vmix_counts(12, 0, 0)
    panel.vmix_finished('Выполнено')
    assert panel.distribution_complete and panel.preparation_complete
    panel.apply_preparation.click()
    assert not panel.distribution_complete


def test_workflow_guests_extras_conflicts_and_unknown_corrections(panel):
    panel.enable_workflow()
    connect_room(panel)
    guests = [guest(i, f'P{i:02d}') for i in range(1, 14)]
    guests[0] = dict(guests[0], video='unknown')
    guests[1] = dict(guests[1], video='absent')
    panel.set_guests(guests[::-1])
    panel.set_room_fresh(True)
    prep = panel.preparation
    assert prep.rows[0].name == 'P01' and prep.rows[0].title == ''
    assert prep.rows[1].name == 'P02' and prep.rows[1].title == '-'
    assert len(prep.commands()) == 11 and 'вне выбранных входов · 1' in prep.hint.text()
    prep.table.selectRow(0)
    prep.override.setCurrentIndex(prep.override.findData('live'))
    assert prep.commands()[0] == (guests[0]['page'], 'P01', 1)
    panel.set_hud_order([g['label'] for g in guests[:12]], 'Матч 1')
    assert panel.positions.commands()[0] == (guests[0]['page'], 'P01', 1)
    slot0, slot1 = prep.selectors[:2]
    slot0.setCurrentIndex(slot0.findText('P13'))
    assert prep.commands()[0] == (guests[-1]['page'], 'P13', 1)
    slot1.setCurrentIndex(slot1.findText('P13'))
    assert not panel.preparation_ready and 'дважды' in prep.rows[0].problem
    slot1.setCurrentIndex(slot1.findText('Без камеры'))
    assert panel.preparation_ready and prep.rows[1].title == '-'
    panel.set_guests(guests)
    assert prep.rows[0].name == 'P13'
    panel.apply_preparation.click()
    old = prep.commands()[0]
    panel.set_room_fresh(False)
    assert not panel.is_current_vmix_row(*old)
    panel.set_room_fresh(True)
    assert not panel.is_current_vmix_row(*old)
    panel.vmix_counts(11, 0, 0)
    panel.vmix_finished('Отменено')
    assert not panel.preparation_complete
    panel.set_guests([guest(1, 'twins'), guest(2, 'TWINS')])
    assert not panel.preparation_ready
    panel.set_guests([])
    assert prep.commands() == [('', '-', i) for i in range(1, 13)]
    panel.show_stale()
    assert not prep.commands()


def test_guided_position_plan_can_clear_all_when_validated_players_are_outside_room(panel):
    panel.enable_workflow()
    connect_room(panel)
    panel.set_guests([guest(99, 'Caster')])
    panel.set_room_fresh(True)
    panel.set_hud_order([f'Player {i}' for i in range(12)], 'Матч 17')
    assert not panel.distribution_ready
    panel.apply_preparation.click()
    panel.vmix_counts(12, 0, 0)
    panel.vmix_finished('Готово')
    clear_all = [('', '-', i) for i in range(1, 13)]
    assert panel.positions.commands() == clear_all
    assert 'Камер · 0' in panel.positions.hint.text() and 'Прозрачных входов · 12' in panel.positions.hint.text()
    assert all(panel.position_media(i) == 'absent' for i in range(1, 13))
    assert panel.publish_positions()
    assert all(panel.is_current_vmix_row(*row) for row in clear_all)
    panel.set_guests([dict(guest(99, 'Caster'), video='unknown')])
    assert not panel.is_current_vmix_row(*clear_all[0])
    panel.vmix_finished('Остановлено')
    assert not panel.distribution_ready
    panel.set_guests([guest(99, 'Caster'), guest(100, 'CASTER')])
    assert not panel.distribution_ready
    panel.set_guests([])
    assert panel.positions.commands() == clear_all
    panel.show_stale()
    assert not panel.distribution_ready and panel.position_media(1) == 'unknown'
