"""Camera process works before Deadlock starts and accepts either match data source."""
from urllib.request import urlopen
import json

import pytest
from PySide6.QtCore import QCoreApplication, QEvent, QSettings

from observer_assist.pov_manager import PovManager
from test_camera_workflow import MATCH, Mixer, snapshot
from test_vmix_control import app, fake_api, wait_for


@pytest.fixture
def pov(app, tmp_path):
    settings = QSettings(str(tmp_path / 'pov.ini'), QSettings.Format.IniFormat)
    window = PovManager(settings)
    try:
        yield window
    finally:
        window.close()
        window.deleteLater()
        QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)


def test_source_switch_clears_all_old_slots_and_exposes_confirmed_remote_order(pov, fake_api):
    panel = pov.vdo_panel
    names = [f'Player {i}' for i in range(1, 13)]
    snapshot(pov, names)
    assert pov.names == tuple(names)
    assert not pov.camera_roster.slots  # SourceTV estimates require confirmation for account-based routing.
    assert 'SourceTV' in panel.positions.hint.text()
    pov.camera_roster.apply.click()
    assert pov.camera_roster.slots[1] == '501'
    assert 'Ручной порядок' in panel.positions.hint.text()
    pov.mode.setCurrentIndex(1)
    assert not pov.names and not pov.camera_roster.slots
    assert pov.companion.payload['pov_inputs'] == {}

    slots = {str(i): name for i, name in enumerate(reversed(names), 1)}
    remote = dict(version=1, status='live', panorama_match_id='999',
                  panorama_slots=slots, panorama_observed_slot=3)
    fake_api.answer = lambda _: (200, {}, json.dumps(remote).encode())
    pov.remote_url.setText(f'http://127.0.0.1:{fake_api.server_port}/api/v1/stats?token=test')
    pov._connect_remote()
    wait_for(lambda: pov.names == tuple(reversed(names)))
    assert pov.companion.payload['hud_slots'] == slots
    assert pov.companion.payload['hud_observed_slot'] == 3
    assert pov.companion.payload['camera_slots']['1']['account_id'] == ''
    pov.mode.setCurrentIndex(0)
    assert not pov.names and not pov.remote.snapshot


def test_pov_room_can_apply_before_match_and_companion_uses_own_port(pov, fake_api):
    vmix = Mixer(fake_api, 1200)
    panel = pov.vdo_panel
    pov.vdo_import.open_url = lambda _: True
    panel.url.setText('https://vdo.ninja/?director=room')
    panel.connect_button.click()
    pov.vdo_import._accept(pov.vdo_import.generation, [dict(streamID='cam-player', label='Player One', video='live')])
    panel.vmix_host.setText('127.0.0.1')
    panel.vmix_port.setValue(vmix.port)
    panel.apply_vmix.click()
    wait_for(lambda: vmix.names[1] == 'Player One' and not pov.vdo_publisher.busy)
    assert not pov.names and not pov.source_tv.roster
    assert pov.companion.port.value() == 53559
    pov.companion.network.setCurrentIndex(pov.companion.network.findData('127.0.0.1/8'))
    pov.companion.share.setChecked(True)
    server = pov.companion.server
    assert server is not None
    with urlopen(server.url, timeout=2) as response:
        assert json.load(response)['status'] == 'waiting'
    snapshot(pov, [f'Player {i}' for i in range(1, 13)])
    panel.positions.inputs[1].setValue(21)
    with urlopen(server.url, timeout=2) as response:
        data = json.load(response)
    assert data['pov_inputs']['21'] == 'Player 2'
    assert '2' not in data['pov_inputs']
    assert 'cam-player' not in json.dumps(data)
    assert not hasattr(pov, 'hud_library') and not hasattr(pov, '_telemetry')


def test_remote_observer_drives_live_and_companion_drives_replay(pov, fake_api, monkeypatch):
    from urllib.request import Request
    from observer_assist import camera_vmix
    from observer_assist.pov_match_data import RemoteMatch
    from test_camera_workflow import configure

    monkeypatch.setattr(camera_vmix, 'POLL_MS', 60)
    mixer = Mixer(fake_api, 1500)
    names = [f'Player {i}' for i in range(1, 13)]
    src = [dict(side=side, players=[dict(name=names[i], accountId=str(100 + i)) for i in indices])
           for side, indices in [(2, range(6)), (3, range(6, 12))]]
    before = pov.cameras.preparation_rows()
    draft = list(before)
    for i in range(2):
        draft[i] = (str(100 + i), names[i], f'https://vdo.ninja/?view=test{i}')
    pov.cameras.save_preparation(before, draft)
    configure(pov, 'live', mixer)
    configure(pov, 'replay', mixer)
    pov.mode.setCurrentIndex(1)
    pov.remote.snapshot = RemoteMatch(MATCH, tuple(names), 2, dict(matchId=MATCH, teams=src))
    pov.remote.changed.emit(pov.remote.snapshot)
    wait_for(lambda: mixer.active[1] == 2 and pov.companion.payload['camera_slots']['1']['replay_ready'])
    pov.companion.network.setCurrentIndex(pov.companion.network.findData('127.0.0.1/8'))
    pov.companion.share.setChecked(True)
    server = pov.companion.server
    with urlopen(Request(server.program_url(1), method='POST'), timeout=2) as response:
        assert response.status == 202
    wait_for(lambda: mixer.active[2] == 3)
    assert mixer.active[1] == 2 and 'test0' not in json.dumps(pov.companion.payload)


def test_steps_prepare_fixed_inputs_then_one_distribution_per_match_connect(pov, fake_api, monkeypatch):
    from test_vmix_control import process_events

    vmix = Mixer(fake_api, 5300, pairs=12)
    panel = pov.vdo_panel
    names = [f'P{i:02d}' for i in range(1, 13)]
    pov.vdo_import.open_url = lambda _: True
    panel.url.setText('https://vdo.ninja/?director=room')
    panel.connect_button.click()
    guests = [dict(streamID=f'cam-{name}', label=name, video='live') for name in names]
    pov.vdo_import._accept(pov.vdo_import.generation, guests)
    assert pov.steps.currentIndex() == 0 and pov.next.isEnabled()
    pov.next.click()
    assert pov.steps.currentIndex() == 1
    panel.vmix_host.setText('127.0.0.1')
    panel.vmix_port.setValue(vmix.port)
    assert not pov.next.isEnabled()
    panel.apply_preparation.click()
    wait_for(lambda: not pov.vdo_publisher.busy and pov.next.isEnabled())
    assert [vmix.names[i] for i in range(1, 13)] == names
    pov.next.click()
    assert pov.steps.currentIndex() == 2
    before = len(vmix.commands)
    # A roster from a prior session must not arm automatic publishing.
    snapshot(pov, names)
    process_events(80)
    assert vmix.commands[before:] == [] and pov.steps.currentIndex() == 2

    match_names = names[4:] + names[:4]

    def start(match):
        pov.source_tv._match_id = match
        pov.source_tv._clear_players()
    monkeypatch.setattr(pov.source_tv, '_start', start)
    pov.source_tv.url.setText(MATCH)
    pov.source_tv.connect_button.click()
    snapshot(pov, match_names)
    wait_for(lambda: panel.distribution_complete and not pov.vdo_publisher.busy)
    assert pov.steps.currentIndex() == 3
    assert [vmix.names[i] for i in range(1, 13)] == match_names
    assert pov.companion.payload['camera_slots']['1']['key'] == '1'
    # Select virtual 19 for position 1 without moving an input. Remaining pairs are 1:1.
    pov.next.click()
    assert pov.steps.currentIndex() == 4
    copies = [19, 14, 15, 16, 17, 18, 13, 20, 21, 22, 23, 24]
    wait_for(lambda: pov.virtual.choices[0].findData(vmix.keys[19]) >= 0)
    for choice, number in zip(pov.virtual.choices, copies):
        choice.setCurrentIndex(choice.findData(vmix.keys[number]))
    pov.virtual.apply_button.click()
    wait_for(lambda: pov.virtual.complete)
    assert vmix.names[19] == match_names[0]
    assert pov.companion.payload['replay_inputs']['1'] == 19
    assert pov.companion.payload['camera_slots']['1']['replay_guid'] == vmix.keys[19]
    assert not vmix.writes('ActiveInput')
    pov.replay_buttons[0].click()
    wait_for(lambda: vmix.active[2] == 19)
    assert vmix.active[1] == 25
    from urllib.request import Request
    pov.companion.network.setCurrentIndex(pov.companion.network.findData('127.0.0.1/8'))
    pov.companion.share.setChecked(True)
    with urlopen(Request(pov.companion.server.program_url(2), method='POST'), timeout=2) as reply:
        assert reply.status == 202
    wait_for(lambda: vmix.active[2] == 14)
    complete = list(vmix.commands)
    snapshot(pov, names[::-1])
    process_events(100)
    assert complete == vmix.commands


def test_game_keys_and_saved_reverse_choice_match_both_ends_of_roster(pov):
    names = ['kapten', 'balaclava', 'zxcbobi', 'rey', 'oses', 'Tas',
             'cantsaymeow', 'arzo', 'pom', 'IREZUMI', 'saintmxsm', 'lorence']
    for reversed_order in (False, True):
        pov.direction.setCurrentIndex(int(reversed_order))
        snapshot(pov, names)
        expected = names[::-1] if reversed_order else names
        assert list(pov.names) == expected
        assert [pov.camera_roster.table.item(i, 1).text() for i in range(12)] == expected
        keys = '1234567890-='
        for i, nick in enumerate(expected, 1):
            row = pov.companion.payload['camera_slots'][str(i)]
            assert row['name'] == nick
            assert row['key'] == keys[names.index(nick)] == pov.camera_roster.table.item(i-1, 0).text()
        assert not pov.direction.isEnabled()
        pov.source_tv.stop()
        assert pov.direction.isEnabled()
    assert pov.settings.value('povPositionsFromRight', type=bool)
