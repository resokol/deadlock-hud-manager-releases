"""POV Manager's read-only subscriber to the HUD Manager on the observer PC."""

import json

from PySide6.QtCore import QObject, QTimer, QUrl, Signal
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkProxy, QNetworkReply, QNetworkRequest

from .match_stats import STATS_ROUTE
from .panorama_hud_mode import video_origin
from .pov_match_data import POV_MATCH_ROUTE, RemoteMatch, read_pov_snapshot


class PovRemote(QObject):
    changed = Signal(object)
    status = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.snapshot: RemoteMatch | None = None
        self._network = QNetworkAccessManager(self)
        self._network.setProxy(QNetworkProxy(QNetworkProxy.ProxyType.NoProxy))
        self._timer = QTimer(self, interval=1000)
        self._timer.timeout.connect(self._poll)
        self._deadline = QTimer(self, singleShot=True, interval=3000)
        self._deadline.timeout.connect(self._timeout)
        self._url = QUrl()
        self._legacy = False
        self._reply = None

    def set_url(self, address):
        self.stop()
        url = QUrl(address.strip(), QUrl.ParsingMode.StrictMode)
        if (not url.isValid() or not video_origin(address.strip()) or url.hasFragment()
                or url.path() not in (STATS_ROUTE, POV_MATCH_ROUTE)):
            self.status.emit('Вставьте ссылку из «Статистика → Копировать URL JSON матча» на ПК наблюдателя.')
            return False
        self._url = url
        self._legacy = False
        self.status.emit('Подключение к HUD Manager…')
        self._timer.start()
        self._poll()
        return True

    def _poll(self):
        if self._reply is not None or self._url.isEmpty():
            return
        url = QUrl(self._url)
        url.setPath(STATS_ROUTE if self._legacy else POV_MATCH_ROUTE)
        request = QNetworkRequest(url)
        request.setTransferTimeout(2500)
        request.setAttribute(QNetworkRequest.Attribute.RedirectPolicyAttribute, QNetworkRequest.RedirectPolicy.ManualRedirectPolicy)
        reply = self._network.get(request)
        self._reply = reply
        def finished():
            QObject.disconnect(connection)
            self._received(reply)
        connection = reply.finished.connect(finished)
        self._deadline.start()

    def _timeout(self):
        if self._reply is not None:
            self._reply.abort()

    def _set_snapshot(self, value):
        if self.snapshot != value:
            self.snapshot = value
            self.changed.emit(value)

    def _received(self, reply):
        reply.deleteLater()
        if self._reply is not reply:
            return
        self._reply = None
        self._deadline.stop()
        code = reply.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute)
        if code == 404 and not self._legacy and self._url.path() == STATS_ROUTE:
            self._legacy = True
            self._poll()
            return
        if code != 200 or reply.error() != QNetworkReply.NetworkError.NoError:
            self._legacy = False
            self._set_snapshot(None)
            self.status.emit('HUD Manager недоступен. Проверьте адрес и доступ по сети. Повторяем подключение.')
            return
        try:
            data = json.loads(bytes(reply.readAll()))
            snapshot = read_pov_snapshot(data, legacy=self._legacy)
        except (UnicodeError, ValueError, RecursionError):
            snapshot = None
        self._set_snapshot(snapshot)
        self.status.emit(snapshot.source if snapshot else 'Ожидание 12 портретов текущего матча из Panorama.')

    def stop(self):
        self._timer.stop()
        self._deadline.stop()
        self._url = QUrl()
        reply, self._reply = self._reply, None
        if reply is not None:
            reply.abort()
        self._set_snapshot(None)
        self.status.emit('HUD Manager отключён.')
