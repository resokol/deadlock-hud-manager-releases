from pathlib import Path
import os
import shutil
import sys
import tempfile

from launcher import main

def install_resources(source, destination):
    destination.mkdir(parents=True, exist_ok=True)
    for resource in source.iterdir():
        target = destination / resource.name
        if target.exists():
            continue
        with tempfile.NamedTemporaryFile(delete=False, dir=destination) as f:
            tmp = Path(f.name)
        try:
            shutil.copyfile(resource, tmp)
            try:
                tmp.rename(target)
            except FileExistsError:
                pass
        finally:
            tmp.unlink(missing_ok=True)

if __name__ == '__main__':
    base = Path(__file__).resolve().parent
    qt = base / 'runtime' / 'Lib' / 'site-packages' / 'PySide6'
    os.environ['PATH'] = os.pathsep.join((str(base / 'runtime'), str(qt), os.environ.get('PATH', '')))
    destination = Path(os.environ['LOCALAPPDATA']) / 'DeadlockHUDManager'
    for folder in ('GameIcons', 'HUDs'):
        install_resources(base / 'Resources' / folder, destination / folder)
    sys.exit(main())
