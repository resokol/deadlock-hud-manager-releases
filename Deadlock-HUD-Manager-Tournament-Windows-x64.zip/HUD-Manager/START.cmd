@echo off
setlocal
cd /d "%~dp0"
if exist "runtime\python.exe" goto deps
echo Downloading Python for Windows x64...
powershell.exe -NoProfile -Command "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $tmp=Join-Path (Get-Location).Path ('.python-'+[guid]::NewGuid()); [void][IO.Directory]::CreateDirectory($tmp); try { $zip=Join-Path $tmp 'python.zip'; (New-Object Net.WebClient).DownloadFile('https://api.nuget.org/v3-flatcontainer/python/3.12.10/python.3.12.10.nupkg',$zip); if ((Get-FileHash -Algorithm SHA256 -LiteralPath $zip).Hash -ne '0eb85c2dfccccf1b17352de4c397f69194035b7d37149eacc16f1147d93de3b8') { throw 'Python checksum mismatch' }; Add-Type -AssemblyName System.IO.Compression.FileSystem; [IO.Compression.ZipFile]::ExtractToDirectory($zip,$tmp); [IO.Directory]::Move((Join-Path $tmp 'tools'),(Join-Path (Get-Location).Path 'runtime')) } finally { Remove-Item -LiteralPath $tmp -Recurse -Force }"
if errorlevel 1 goto failed
:deps
"runtime\python.exe" -E -s setup_runtime.py
if errorlevel 1 goto failed
start "" "%~dp0DeadlockHUDManager.exe"
exit /b 0
:failed
echo Setup was interrupted. Check the error above, then run START.cmd again.
pause
exit /b 1
