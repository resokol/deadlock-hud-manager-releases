import os
from types import SimpleNamespace

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

import pytest
from PySide6.QtCore import QSettings
from PySide6.QtWidgets import QApplication

from observer_assist.camera_mapping import operator_camera_mapping
from observer_assist.camera_roster import CameraRoster
from observer_assist.hud_manager import HudManager


@pytest.fixture
def app():
    return QApplication.instance() or QApplication([])


def test_first_four_sections_are_independent_and_companion_opens_stats(app, tmp_path):
    settings = QSettings(str(tmp_path / 'manager.ini'), QSettings.Format.IniFormat)
    manager = HudManager(settings, hud_directory=tmp_path / 'huds')
    try:
        names = [manager.compact_navigation.itemText(i) for i in range(manager.sections.count())]
        assert names[:4] == ['Match', 'VDO Ninja', 'Live', 'Replay']
        assert set(names[4:]) == {'Позиции Panorama', 'Статистика', 'HUD', 'Модули', 'POV vMix'}
        assert manager.match_tabs.indexOf(manager.vdo_panel) == -1
        manager.show()
        manager._sections.button(1).click()
        assert manager.vdo_panel.isVisible() and not manager.camera_roster.isVisible()
        manager.camera_panels['replay'].companion_requested.emit()
        assert manager.sections.currentIndex() == names.index('Статистика')
        assert manager.compact_navigation.currentIndex() == manager.sections.currentIndex()
    finally:
        manager.close()


def test_table_tracks_accounts_across_slot_changes_and_masks_private_links(app, tmp_path):
    settings = QSettings(str(tmp_path / 'operator.ini'), QSettings.Format.IniFormat)
    panel = CameraRoster(settings)
    accounts = {str(i): f'Player {i}' for i in range(1, 13)}
    roster = dict(matchId='42', teams=[
        dict(side=side, players=[dict(name=accounts[str(i)], hero=f'H{i}', accountId=i) for i in group])
        for side, group in ((2, range(1, 7)), (3, range(7, 13)))])
    slots = dict(accounts)
    panel.update_match(roster, slots, 1, True)
    page = 'https://vdo.ninja/?view=stream%2B1&password=operator-private'
    panel.set_page('1', page)
    cfg = {role: dict(enabled=True, guids=['', guid] + [''] * 10)
           for role, guid in [('live', 'original-guid'), ('replay', 'virtual-guid')]}
    cameras = SimpleNamespace(owners=['', '1'] + [''] * 10, config=cfg,
                              routable=lambda role, a: role == 'live' and a == '1',
                              vdo_bank_status=lambda a: 'Label сопоставлен' if a == '1' else '')
    room = SimpleNamespace(fresh=True)
    panel.bind_camera_mapping(lambda: operator_camera_mapping(panel, cameras, room))
    panel.table.selectRow(0)
    slots['1'], slots['12'] = slots['12'], slots['1']
    panel.update_match(roster, slots, 12, True)
    values = {panel.table.horizontalHeaderItem(i).text(): panel.table.item(11, i).text()
              for i in range(panel.table.columnCount())}
    assert values['Позиция'] == '12' and values['Клавиша'] == '='
    assert values['Account ID'] == '1' and values['Игрок'] == 'Player 1' and values['Герой'] == 'H1'
    assert values['Пара'] == '2' and values['Stream ID'] == 'stream+1'
    assert values['GUID оригинала'] == 'original-guid' and values['GUID копии'] == 'virtual-guid'
    assert 'Label сопоставлен' in values['Состояние камеры']
    assert 'Replay не готов' in values['Состояние камеры']
    assert values['URL камеры'] == 'Задан'
    for i in range(panel.table.columnCount()):
        cell = panel.table.item(11, i)
        assert 'operator-private' not in cell.text() + cell.toolTip()
    clipboard = QApplication.clipboard()
    clipboard.setText('unchanged')
    assert panel.table.currentRow() == 11
    assert clipboard.text() == 'unchanged'
    panel.copy_page.click()
    assert clipboard.text() == page
    room.fresh = False
    assert 'Нет свежих данных' in operator_camera_mapping(panel, cameras, room)['1'][-1]
