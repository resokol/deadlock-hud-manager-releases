import os

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

import pytest
from PySide6.QtCore import QSettings
from PySide6.QtWidgets import QApplication, QLineEdit

from observer_assist.camera_vdo_panel import POLL_INTERVAL_KEY, SETTINGS_KEY, VdoRoomPanel


DIRECTOR = 'https://vdo.ninja/?director=example&password=private-room-password'


@pytest.fixture
def panel(tmp_path):
    app = QApplication.instance() or QApplication([])
    settings = QSettings(str(tmp_path / 'camera.ini'), QSettings.Format.IniFormat)
    result = VdoRoomPanel(settings)
    result.show()
    yield result
    result.close()


def test_blank_or_whitespace_never_starts(panel):
    starts = []
    panel.start_requested.connect(starts.append)
    panel.url.setText('   ')
    panel.connect_button.click()
    panel.url.returnPressed.emit()
    assert not starts
    assert not panel.connect_button.isEnabled()


def test_saves_only_on_success_and_keeps_links_private(panel):
    starts = []
    panel.start_requested.connect(starts.append)
    panel.url.setText(DIRECTOR)
    panel.connect_button.click()
    panel.url.returnPressed.emit()
    assert starts == [DIRECTOR]
    assert not panel.settings.contains(SETTINGS_KEY)
    panel.start_failed('Ошибка подключения к ' + DIRECTOR)
    assert 'private-room-password' not in panel.status.text()
    assert not panel.settings.contains(SETTINGS_KEY)
    assert not panel.url.isReadOnly()
    panel.connect_button.click()
    panel.started()
    assert panel.settings.value(SETTINGS_KEY) == DIRECTOR
    assert panel.url.isReadOnly()
    reopened = VdoRoomPanel(panel.settings)
    assert reopened.url.text() == DIRECTOR
    assert reopened.url.echoMode() == QLineEdit.EchoMode.Password
    assert 'private-room-password' not in reopened.url.displayText()


def test_reopen_stop_and_discovery_feedback(panel):
    stops, reopens = [], []
    panel.stop_requested.connect(lambda: stops.append(True))
    panel.reopen_requested.connect(lambda: reopens.append(True))
    panel.url.setText(DIRECTOR)
    panel.connect_button.click()
    panel.started()
    panel.show_result(5, 'Назначено 2. Без имени 1. Конфликт имён 2.')
    assert panel.status.text().endswith('5')
    assert 'Конфликт' in panel.summary.text()
    assert panel.reopen_button.isVisible()
    panel.reopen_button.click()
    assert reopens == [True]
    panel.show_result(0, 'Недоступна ссылка ' + DIRECTOR)
    assert 'private-room-password' not in panel.summary.text()
    panel.stop_button.click()
    assert stops == [True]
    panel.stop()
    panel.show_result(10, 'Устаревший ответ')
    assert not panel.reopen_button.isVisible()
    assert panel.connect_button.isVisible()
    assert not panel.summary.isVisible()
    assert 'отключена' in panel.status.text()


def test_late_start_after_stop_does_not_save(panel):
    panel.url.setText(DIRECTOR)
    panel.connect_button.click()
    panel.stop()
    panel.started()
    assert not panel.settings.contains(SETTINGS_KEY)
    assert not panel.url.isReadOnly()


def test_director_default_and_explicit_scene_preference_survives_success_only(panel):
    assert panel.director_mode.isChecked()
    assert 'Co-Director' in panel.mode_hint.text()
    assert 'Room Settings' in panel.mode_hint.text()
    panel.director_mode.setChecked(False)
    assert 'Режим сцены' in panel.mode_hint.text()
    panel.url.setText(DIRECTOR)
    panel.connect_button.click()
    assert not panel.director_mode.isEnabled()
    panel.start_failed('Попробуйте снова.')
    assert VdoRoomPanel(panel.settings).director_mode.isChecked()
    assert panel.director_mode.isEnabled()
    panel.connect_button.click()
    panel.started()
    assert not VdoRoomPanel(panel.settings).director_mode.isChecked()


def test_poll_interval_default_bounds_and_saved_choice(panel):
    assert panel.poll_interval.value() == 3
    assert (panel.poll_interval.minimum(), panel.poll_interval.maximum()) == (1, 60)
    panel.poll_interval.setValue(15)
    assert VdoRoomPanel(panel.settings).poll_interval.value() == 15
    panel.settings.setValue(POLL_INTERVAL_KEY, 'invalid')
    assert VdoRoomPanel(panel.settings).poll_interval.value() == 3


def test_heartbeat_timeout_clears_previous_guests_and_recovers(panel):
    panel.url.setText(DIRECTOR)
    panel.connect_button.click()
    panel.started()
    panel.show_result(7, 'Назначено 7.')
    panel.show_stale()
    assert '7' not in panel.status.text()
    assert not panel.summary.isVisible()
    assert panel.reopen_button.isVisible()
    panel.show_result(3, 'Назначено 3.')
    assert panel.status.text() == 'Видимых гостей · 3'
    assert panel.summary.isVisible()


def test_guest_table_preserves_selection_and_copies_only_the_selected_viewer_url(panel):
    panel.url.setText(DIRECTOR)
    panel.connect_button.click()
    panel.started()
    first = dict(label='Fox', bank=7, page='https://vdo.ninja/?view=first&token=private')
    second = dict(label='', bank=None, page='https://vdo.ninja/?view=second')
    clipboard = QApplication.clipboard()
    clipboard.setText('до выбора')
    panel.set_guests([first, second])
    assert panel.table.rowCount() == 2
    assert panel.table.item(0, 0).text() == 'Fox'
    assert panel.table.item(0, 1).text() == '7'
    assert panel.table.item(1, 0).text() == 'Без имени'
    assert panel.table.item(1, 1).text() == 'Не назначена'
    assert not panel.copy_button.isEnabled()
    panel.table.selectRow(0)
    original_cell = panel.table.item(0, 0)
    panel.set_guests([dict(first), dict(second)])
    assert panel.table.item(0, 0) is original_cell
    panel.set_guests([second, dict(first, bank=8)])
    assert panel.table.currentRow() == 1
    assert clipboard.text() == 'до выбора'
    panel.copy_button.click()
    assert clipboard.text() == first['page']
    panel.set_guests([second])
    assert not panel.copy_button.isEnabled()
    panel.show_stale()
    assert panel.table.rowCount() == 0
    assert not panel.table.isVisible()
    panel.set_guests([second])
    assert panel.table.rowCount() == 1
    panel.stop()
    assert panel.table.rowCount() == 0
    assert not panel.copy_button.isVisible()
