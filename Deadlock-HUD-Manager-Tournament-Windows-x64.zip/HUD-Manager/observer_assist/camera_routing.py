"""Match accounts own camera pairs. HUD positions only select accounts."""
import json
from collections import Counter
from hashlib import sha256
from datetime import datetime
from ipaddress import IPv4Address
from uuid import UUID
from unicodedata import category

from PySide6.QtCore import QObject, QTimer, Signal
from PySide6.QtWidgets import (
    QComboBox, QFormLayout, QGroupBox, QLabel, QMessageBox, QPlainTextEdit, QPushButton,
)

from .camera_vmix import CameraEndpoint, browser_source, virtual_source
from .camera_preparation import CameraPreparation, camera_identity, camera_page
from .camera_roster import _account, _page_valid
from .match_stats import is_lan_address

ROLES = ('live', 'replay')


def _digest(text):
    return sha256(text.encode('utf-8')).hexdigest()


def _guest_marker(value):
    if isinstance(value, dict) and all(isinstance(value.get(k), str) for k in ('room', 'stream', 'owner', 'page')):
        return {**{k: value[k] for k in ('room', 'stream', 'owner', 'page')},
                'allocated': value.get('allocated') is True,
                'state': value.get('state', 'active'), 'label': value.get('label', '')}
    return None


def _camera_name(value):
    return value.strip().casefold() if isinstance(value, str) else ''


def _guest_identity(label, players, rows):
    """Director labels are always game nicknames, including all-digit nicknames."""
    name = _camera_name(label)
    accounts = {account for account, player in players.items() if _camera_name(player['name']) == name}
    banks = [i for i, (account, nick, _) in enumerate(rows)
             if (account and account in accounts) or _camera_name(nick) == name]
    accounts.update(rows[i][0] for i in banks if rows[i][0])
    if len(accounts) > 1 or len(banks) > 1:
        return None
    return next(iter(accounts), ''), next(iter(banks), None)


def defaults(role):
    return dict(enabled=False, host='127.0.0.1', port=8088, mix=1 if role == 'live' else 2,
                mode='program', target='', layer=1, follow=False, guids=[''] * 12, sources=[''] * 12)


def endpoint_key(config):
    return config['host'], config['port']


def destination(config):
    if config['mode'] == 'layer':
        return 'layer', config['target'], config['layer']
    return 'mix', config['mix']


def validate_config(role, draft, other):
    config = defaults(role)
    config.update({k: v for k, v in draft.items() if k in config})
    address = IPv4Address(config['host'])
    if not (is_lan_address(address) or address.is_loopback):
        raise ValueError('Укажите локальный адрес vMix.')
    config['host'] = str(address)
    if not 1 <= config['port'] <= 65535 or not 1 <= config['mix'] or not 1 <= config['layer'] <= 10:
        raise ValueError('Проверьте порт, Mix и номер слоя.')
    if config['mode'] not in ('program', 'layer') or role == 'replay' and config['mode'] != 'program':
        raise ValueError('Проверьте способ вывода камеры.')
    def guid(value):
        return str(UUID(value.strip())) if value else ''
    try:
        for key in ('guids', 'sources'):
            if len(config[key]) != 12:
                raise ValueError
            config[key] = [guid(ref) for ref in config[key]]
        config['target'] = guid(config['target'])
    except (TypeError, ValueError, AttributeError):
        raise ValueError('Выберите существующие входы по GUID.') from None
    if config['enabled'] and config['mode'] == 'layer' and not config['target']:
        raise ValueError('Выберите целевой вход для слоя.')
    if role == 'live':
        config['sources'] = [''] * 12
    live, replay = (config, other) if role == 'live' else (other, config)
    shared = endpoint_key(live) == endpoint_key(replay)
    if shared and live['enabled'] and replay['enabled'] and destination(live) == destination(replay):
        raise ValueError('Этот выход уже закреплён за другим модулем.')
    originals = list(replay['sources'])
    if shared:
        for idx, ref in enumerate(live['guids']):
            if originals[idx] and ref and originals[idx] != ref:
                raise ValueError(f'У пары {idx + 1} заданы два разных оригинала на одном vMix.')
            originals[idx] = originals[idx] or ref
    for refs in (live['guids'], originals + replay['guids']):
        assigned = [ref for ref in refs if ref]
        if len(assigned) != len(set(assigned)):
            raise ValueError('Каждому входу нужна своя пара. Проверьте повторяющиеся GUID.')
    if live['mode'] == 'layer' and live['target'] and live['target'] in (
            live['guids'] + (originals + replay['guids'] if shared else [])):
        raise ValueError('Целевой вход слоя должен отличаться от источников камер.')
    return config


class CameraRouting(QObject):
    changed = Signal()
    activated = Signal()

    def __init__(self, settings, roster, panels, parent=None, factory=CameraEndpoint):
        super().__init__(parent)
        self.settings, self.roster, self.panels = settings, roster, panels
        self.factory = factory
        self.endpoints, self.discovery = {}, {}
        self.config = {r: defaults(r) for r in ROLES}
        self.owners = [''] * 12
        self.labels = {}
        self.pending_pages = {}
        self.guest_banks = [None] * 12
        self._camera_sources = None
        self._duplicates = set()
        self._continuous_vdo = set()
        self._last_vdo = set()
        self.manual_banks = set()
        self.managed = False
        self.closed = False
        self.armed_observer = None
        self.last_observer = None
        self.observer_match = None
        self.pending_choices = {}
        self.queued_observer = None
        self.status = dict.fromkeys(ROLES, '')
        self.available = {r: set() for r in ROLES}
        self._export = None
        self.last_tally = {}
        self.last_assignment_view = None
        self._render_timer = QTimer(self, singleShot=True, interval=0)
        self._render_timer.timeout.connect(self.refresh)
        self.bank_widget = QGroupBox('Пары камер и журнал')
        layout = QFormLayout(self.bank_widget)
        self.owner_box = QComboBox()
        self.bank_box = QComboBox()
        self.assign = QPushButton('Назначить игроку пару')
        self.assign.clicked.connect(self._assign)
        layout.addRow('Игрок', self.owner_box)
        layout.addRow('Пара входов', self.bank_box)
        layout.addRow(self.assign)
        self.note = QLabel()
        self.note.setWordWrap(True)
        layout.addRow(self.note)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumBlockCount(250)
        self.log.setMaximumHeight(140)
        layout.addRow('Журнал', self.log)
        try:
            saved = json.loads(settings.value('cameraRoutingV1', '{}', type=str))
            if saved:
                for role in ROLES:
                    self.config[role] = validate_config(role, saved[role], self.config[self._other(role)])
                owners = saved['owners']
                if len(owners) != 12 or len(set(filter(None, owners))) != sum(bool(v) for v in owners):
                    raise ValueError
                self.labels = {k: v for k, v in saved.get('labels', {}).items() if isinstance(v, str)}
                self.pending_pages = {k: v for k, v in saved.get('pendingPages', {}).items()
                                      if k.startswith('nick:') and _page_valid(v)}
                markers = saved.get('vdoBanks')
                if isinstance(markers, list) and len(markers) == 12:
                    self.guest_banks = [_guest_marker(marker) for marker in markers]
                self.owners = list(owners)
                if isinstance(saved.get('manualBanks'), list):
                    self.manual_banks = {i for i in saved['manualBanks'] if type(i) is int and 0 <= i < 12}
                else:
                    # Older settings do not distinguish pinned pairs from automatic roster allocations.
                    self.manual_banks = {i for i, owner in enumerate(owners) if owner and
                                         not (self.guest_banks[i] and self.guest_banks[i]['allocated'])}
                self.managed = True
                if saved.get('labelMatching') != 2:
                    self._migrate_camera_names()
                    self.save()
        except (ValueError, KeyError, TypeError):
            self.managed = settings.contains('cameraRoutingV1')
            self.config = {r: defaults(r) for r in ROLES}
            self.record('Сохранённые настройки камер требуют проверки.')
        for role, panel in panels.items():
            panel.set_config(self.config[role])
            panel.apply_requested.connect(lambda draft, r=role: self.apply(r, draft))
            panel.take_requested.connect(lambda slot, r=role: self.take(r, slot))
            panel.repair_requested.connect(lambda r=role: self.restore_pages(r))
            panel.discover_requested.connect(lambda host, port, r=role: self.discover(r, host, port))
        roster.changed.connect(self.schedule)
        self.schedule()

    def _migrate_camera_names(self):
        # Older provisional keys folded internal whitespace. Rebuild them from the saved
        # operator-visible spelling, and require fresh director evidence for old imports.
        names = {owner: 'nick:' + _camera_name(self.labels.get(owner) or owner[5:])
                 for owner in self.owners if owner.startswith('nick:')}
        if len(set(names.values())) != len(names):
            self.owners = [''] * 12
            self.pending_pages = {}
            self.guest_banks = [None] * 12
            raise ValueError('Конфликт сохранённых ников камер.')
        self.owners = [names.get(owner, owner) for owner in self.owners]
        self.labels = {names.get(owner, owner): nick for owner, nick in self.labels.items()}
        self.pending_pages = {names.get(owner, owner): page for owner, page in self.pending_pages.items()}
        for marker in self.guest_banks:
            if marker:
                marker['owner'] = names.get(marker['owner'], marker['owner'])
                if marker['state'] == 'active':
                    marker['state'] = 'conflict'

    @staticmethod
    def _other(role):
        return 'live' if role == 'replay' else 'replay'

    def record(self, text):
        self.log.appendPlainText(f'{datetime.now():%H:%M:%S}  {text}')

    def save(self):
        saved = dict(self.config, owners=self.owners, labels=self.labels, pendingPages=self.pending_pages,
                     vdoBanks=self.guest_banks, manualBanks=sorted(self.manual_banks), labelMatching=2)
        self.settings.setValue('cameraRoutingV1', json.dumps(saved))
        self.settings.sync()

    def schedule(self):
        if not self.closed:
            self._render_timer.start()

    def _endpoint(self, key):
        ep = self.endpoints.get(key)
        if ep is None:
            ep = self.factory(self)
            self.endpoints[key] = ep
            ep.changed.connect(self.schedule)
            ep.event.connect(lambda message: self._message(key, message))
        return ep

    def _message(self, key, message):
        self.record(f'{key[0]}:{key[1]} · {message}')
        for role, cfg in self.config.items():
            if endpoint_key(cfg) == key:
                self.status[role] = message
        self.schedule()

    def restore_pages(self, role):
        cfg = self.config[role]
        ep = self.endpoints.get(endpoint_key(cfg))
        if not cfg['enabled'] or not ep or not ep.online:
            self.status[role] = 'Для восстановления нужна связь с включённым vMix.'
            self.schedule()
            return
        if QMessageBox.question(self.panels[role], 'Восстановление URL',
                'Повторно открыть страницы настроенных камер в этом vMix? '
                'Картинка может пропасть на время подключения VDO.Ninja, в том числе на общем выходе.'
                ) == QMessageBox.StandardButton.Yes:
            ep.forget_pages(set(filter(None, self._originals(role))))
            self.record(f'{role}: оператор запросил повторное подключение браузеров.')
            self.schedule()

    def discover(self, role, host, port):
        try:
            key = (str(IPv4Address(host)), port)
            validate_config(role, dict(defaults(role), host=key[0], port=port), defaults(self._other(role)))
        except (ValueError, TypeError):
            self.status[role] = 'Для поиска укажите локальный IPv4 и порт.'
        else:
            self.discovery[role] = key
            self._endpoint(key)
        self.schedule()

    def apply(self, role, draft):
        try:
            cfg = validate_config(role, draft, self.config[self._other(role)])
        except (ValueError, TypeError) as exc:
            self.status[role] = str(exc)
            self.record(f'{role}: {exc}')
            self.schedule()
            return False
        old = self.config[role]
        ep = self.endpoints.get(endpoint_key(old))
        if ep and old['enabled']:
            ep.cancel_take(old['mix'], old['target'] if old['mode'] == 'layer' else '', old['layer'])
        self.pending_choices.pop(role, None)
        if role == 'live':
            self.queued_observer = None
        if endpoint_key(old) != endpoint_key(cfg) or destination(old) != destination(cfg):
            self.last_tally.pop(role, None)
        self.discovery.pop(role, None)
        self.config[role] = cfg
        if role == 'live':
            self.armed_observer = self.roster.observed if cfg['enabled'] and cfg['follow'] else None
            self.last_observer = self.roster.observed
        if not self.managed:
            self.managed = True
            self.activated.emit()
        self.save()
        self.record(f'{role}: настройки сохранены, модуль ' + ('включён' if cfg['enabled'] else 'выключен'))
        self.status[role] = ''
        self.refresh()
        return True

    def _originals(self, role):
        live, replay = self.config['live'], self.config['replay']
        if role == 'live':
            return live['guids']
        if endpoint_key(live) == endpoint_key(replay):
            return [a or b for a, b in zip(replay['sources'], live['guids'])]
        return replay['sources']

    def _replaceable(self, bank):
        # Check both configured destinations, including a disabled module holding its last output.
        for role, cfg in self.config.items():
            refs = {self._originals(role)[bank], cfg['guids'][bank]} - {''}
            if not refs:
                continue
            ep = self.endpoints.get(endpoint_key(cfg))
            requested = {v[1] for v in self.pending_choices.values() if v[0] == endpoint_key(cfg)}
            if (not ep or not ep.online or not ep.protection_known or refs & (ep.protected | requested)
                    or not refs <= ep.inputs.keys()):
                return False
        return True

    def _empty_bank(self, rows):
        for bank, (account, nick, _) in enumerate(rows):
            if account or nick:
                continue
            on_air = False
            for role, cfg in self.config.items():
                key = endpoint_key(cfg)
                refs = {self._originals(role)[bank], cfg['guids'][bank]} - {''}
                ep = self.endpoints.get(key)
                pending = {choice[1] for choice in self.pending_choices.values() if choice[0] == key}
                if refs & pending or (ep and ep.online and refs & ep.protected):
                    on_air = True
                    break
            if not on_air:
                return bank
        return None

    def _retired_guest_bank(self, markers, rows, reserved=()):
        current = self.roster.players
        for i, marker in enumerate(markers):
            account, nick, page = rows[i]
            if (i in self.manual_banks or i in reserved or not marker or marker['state'] != 'absent' or page
                    or not marker['owner'] or marker['owner'] != self.owners[i] or account in current):
                continue
            if not account and any(_camera_name(p['name']) == _camera_name(nick) for p in current.values()):
                continue
            if self._replaceable(i):
                return i
        return None

    def _source(self, owner):
        if not owner:
            return ''
        if owner.startswith('nick:'):
            return self.pending_pages.get(owner, '')
        return self.roster.pages.get(owner, '')

    def _duplicate_cameras(self):
        records = tuple(self.roster.pages.items()), tuple(self.pending_pages.items())
        if records != self._camera_sources:
            identities = {key: camera_identity(page) for group in records for key, page in group if page}
            counts = Counter(identities.values())
            self._duplicates = {key for key, identity in identities.items() if counts[identity] > 1}
            self._camera_sources = records
        return self._duplicates

    def _label_conflicts(self, owner):
        if owner not in self.owners:
            return False
        bank = self.owners.index(owner)
        marker = self.guest_banks[bank]
        if not marker or not self._owns_guest(bank):
            return False
        if marker['state'] == 'conflict':
            return True
        # A new SourceTV roster can introduce a conflicting nickname between director polls.
        label = marker.get('label') or _camera_name(self.labels.get(owner, ''))
        accounts = {a for a, p in self.roster.players.items() if label == _camera_name(p['name'])}
        if any(label == _camera_name(p['name']) for p in getattr(self.roster, '_unidentified', ())):
            return True
        if owner.startswith('nick:'):
            return len(accounts) > 1
        if accounts:
            return accounts != {owner}
        return owner in self.roster.players and (marker['room'], marker['stream']) not in self._last_vdo

    def has_camera(self, account):
        return bool(self._source(account)) and account not in self._duplicate_cameras() and not self._label_conflicts(account)

    def preparation_rows(self):
        rows = []
        for owner in self.owners:
            account = '' if owner.startswith('nick:') else owner
            name = self.roster.players.get(owner, {}).get('name') or self.labels.get(owner, '')
            rows.append((account, name, self._source(owner)))
        return rows

    def edit_preparation(self, parent):
        releasing = {}

        def save(original, edited):
            confirmed = {i for i, expected in releasing.items() if edited[i] == expected}
            self.save_preparation(original, edited, release_vdo=confirmed)

        dialog = CameraPreparation(self.preparation_rows(), save, parent)
        release = QPushButton('Освободить пары VDO.Ninja')
        release.setEnabled(any(self._owns_guest(i) for i in range(12)))

        def edit_imported():
            draft = [(dialog.table.item(i, 0).text().strip(), dialog.table.item(i, 1).text().strip(),
                      field.text().strip()) for i, field in enumerate(dialog.fields)]
            cleared = self.released_vdo_rows(draft)
            current = self.preparation_rows()
            for bank, (before, after) in enumerate(zip(draft, cleared)):
                if before == current[bank] and self._owns_guest(bank):
                    releasing[bank] = after
                if before != after:
                    dialog.table.item(bank, 0).setText(after[0])
                    dialog.table.item(bank, 1).setText(after[1])
                    dialog.fields[bank].setText(after[2])
            dialog.message.setText('Проверьте изменённые пары и нажмите «Сохранить камеры». '
                                   'Для смены состава остановите импорт из прежней комнаты.')

        release.clicked.connect(edit_imported)
        dialog.layout().insertWidget(dialog.layout().count() - 1, release)
        dialog.exec()
        dialog.deleteLater()

    def released_vdo_rows(self, draft):
        current = self.preparation_rows()
        rows = list(draft)
        for i, marker in enumerate(self.guest_banks):
            account, nick, page = current[i]
            if self._owns_guest(i) and current[i] == rows[i]:
                rows[i] = ('', '', '') if marker['allocated'] else (account, nick, '')
        return rows

    def save_preparation(self, original, edited, *, from_vdo=False, release_vdo=()):
        if len(original) != 12 or len(edited) != 12:
            raise ValueError('Для настройки нужны 12 пар.')
        current = self.preparation_rows()
        owners, labels, pending, updates = [], self.labels.copy(), {}, {}
        for bank, (before, draft, now) in enumerate(zip(original, edited, current), 1):
            if before != draft and before != now and draft != now:
                raise ValueError(f'Пара {bank} изменилась в матче. Откройте таблицу заново.')
            account, nick, page = now if before == draft else draft
            owner = _account(account) if account else ('nick:' + _camera_name(nick) if nick.strip() else '')
            if account and not owner or page and (not owner or not _page_valid(page)):
                raise ValueError(f'Пара {bank}: проверьте Account ID или ник и полный URL просмотра.')
            if owner and owner in owners:
                raise ValueError(f'Пара {bank}: этот игрок уже назначен другой паре.')
            owners.append(owner)
            if owner:
                labels[owner] = nick
                if owner.startswith('nick:'):
                    if page:
                        pending[owner] = page
                else:
                    updates[owner] = page
        if not from_vdo:
            all_pages = {**self.roster.pages, **updates, **pending}
            seen = {}
            for owner, page in all_pages.items():
                if page:
                    identity = camera_identity(page)
                    other = seen.get(identity)
                    if other and (page != self._source(owner) or all_pages[other] != self._source(other)):
                        raise ValueError('Одна камера назначена двум игрокам. Проверьте ссылки просмотра.')
                    seen[identity] = owner

        if from_vdo:
            # Departures and their replacements may arrive in one snapshot.
            updates.update({account: '' for account, _, _ in current if account and account not in owners})
        else:
            for bank, (before, after, now) in enumerate(zip(original, edited, current)):
                if before != after and now != after:
                    if owners[bank]:
                        self.manual_banks.add(bank)
                    else:
                        self.manual_banks.discard(bank)
                if before != after and now != after and self.guest_banks[bank]:
                    # Clearing an automatically provisioned account also releases its imported URL.
                    marker = self.guest_banks[bank]
                    account, _, page = now
                    if (not any(after) and account and account not in owners and marker['owner'] == account
                            and marker['page'] == _digest(page)):
                        updates[account] = ''
                    marker['owner'] = ''
                if bank in release_vdo and before == now:
                    self.guest_banks[bank] = None
        self.owners, self.labels, self.pending_pages = owners, labels, pending
        self.roster.update_pages(updates)
        if not self.managed:
            self.managed = True
            self.activated.emit()
        self.save()
        self.record('Состав камер обновлён по списку гостей VDO.Ninja.' if from_vdo else
                    'Предматчевые назначения камер сохранены.')
        self.refresh()

    def _owns_guest(self, bank):
        marker = self.guest_banks[bank]
        owner = self.owners[bank]
        return bool(marker and owner and marker['owner'] == owner and marker['page'] == _digest(self._source(owner)))

    def vdo_guest_bank(self, room_key, stream_id):
        if not isinstance(room_key, str) or not room_key or not isinstance(stream_id, str) or not stream_id:
            return None
        room, stream = _digest(room_key), _digest(stream_id)
        return next((i + 1 for i, m in enumerate(self.guest_banks)
                     if m and m['room'] == room and m['stream'] == stream and m['state'] == 'active'
                     and self._owns_guest(i) and self.has_camera(m['owner'])), None)

    def vdo_bank_status(self, account):
        if not account or account not in self.owners:
            return ''
        bank = self.owners.index(account)
        if account in self._duplicate_cameras():
            return 'Камера назначена дважды'
        if not self._owns_guest(bank):
            return ''
        if self.guest_banks[bank]['state'] == 'active' and self._label_conflicts(account):
            return 'Конфликт Label'
        return {'active': 'Label сопоставлен', 'absent': 'Гость вышел',
                'conflict': 'Конфликт Label'}.get(self.guest_banks[bank]['state'], '')

    def end_vdo_session(self):
        """A later director connection must establish identity from the current roster again."""
        self._continuous_vdo = set()

    def import_vdo_guests(self, room_key, guests, *, observed_streams=None):
        """Apply a complete director snapshot. An unavailable director must not call this with []."""
        if not isinstance(room_key, str) or not room_key or not isinstance(guests, list):
            return 'Список гостей недоступен. Назначения сохранены.'
        room = _digest(room_key)
        entries = {}
        labels = Counter()
        duplicates = set()
        incomplete = False
        issues = 0
        for guest in guests:
            stream_id = guest.get('streamID') if isinstance(guest, dict) else None
            if not isinstance(stream_id, str) or not stream_id.strip():
                incomplete = True
                issues += 1
                continue
            stream = _digest(stream_id)
            if stream in entries:
                duplicates.add(stream)
            raw = guest.get('label')
            label = raw.strip() if isinstance(raw, str) else ''
            if len(label) > 256 or '://' in label or any(not ch.isprintable() and category(ch) != 'Zs' for ch in label):
                label = ''
            entries[stream] = label, guest.get('page')
            labels[_camera_name(label)] += 1

        observed = set(entries) if observed_streams is None else {
            _digest(stream) for stream in observed_streams if isinstance(stream, str)}
        previous = self.preparation_rows()
        rows = list(previous)
        markers = [m.copy() if m else None for m in self.guest_banks]
        linked = {m['stream']: bank for bank, m in enumerate(markers) if m and m['room'] == room}

        # Only the room that issued this snapshot can signal a departure. Verify ownership
        # and the last auto-applied URL before making a source transparent.
        cleared_banks = []
        for stream, bank in linked.items():
            m = markers[bank]
            if stream in entries or incomplete or not m['owner']:
                continue
            account, nick, page = rows[bank]
            if self.owners[bank] != m['owner'] or _digest(page) != m['page']:
                m['owner'] = ''
                continue
            m['state'] = 'absent'
            if page:
                rows[bank] = account, nick, ''
                m['page'] = _digest('')
                cleared_banks.append(bank)

        identities = {stream: _guest_identity(label, self.roster.players, rows)
                      for stream, (label, _) in entries.items() if label}
        claims = Counter(identity for identity in identities.values() if identity and identity != ('', None))
        reserved = {value[1] for value in identities.values() if value and value[1] is not None}
        sources = {stream: camera_identity(page) for stream, (_, page) in entries.items() if _page_valid(page)}
        source_counts = Counter(sources.values())
        saved_sources = {}
        for key, url in [*self.roster.pages.items(), *self.pending_pages.items()]:
            if url:
                saved_sources.setdefault(camera_identity(url), set()).add(key)
        continuous = set()
        full = connected = 0
        # Existing streams always keep first claim on their banks, regardless of director order.
        unknown_names = {_camera_name(p['name']) for p in getattr(self.roster, '_unidentified', ())}
        for stream in sorted(entries, key=lambda key: key not in linked):
            if stream not in observed:
                # The bridge retains guests briefly while verifying a departure. Preserve
                # the source during that interval, but do not renew the guest's identity.
                continue
            label, page = entries[stream]
            nick_key = _camera_name(label)
            identity = identities.get(stream)
            identified = bool(nick_key and nick_key not in unknown_names and labels[nick_key] == 1 and
                              stream not in duplicates and stream in sources and source_counts[sources[stream]] == 1 and identity is not None and
                              claims[identity] <= 1)
            old_bank = linked.get(stream)
            recycled = False
            if old_bank is not None and identified:
                old = markers[old_bank]
                target = identity[0]
                recycled = (old['state'] == 'absent' and old['owner'] and old['owner'] == self.owners[old_bank]
                            and old['owner'] != target and target in self.roster.players and not rows[old_bank][2]
                            and _camera_name(self.roster.players[target]['name']) == nick_key)
            if old_bank is not None and not recycled:
                bank = old_bank
                m = markers[bank]
                if not m['owner'] or self.owners[bank] != m['owner'] or _digest(rows[bank][2]) != m['page']:
                    m['owner'] = ''
                    issues += 1
                    continue
                account, nick, _ = rows[bank]
                if identified and saved_sources.get(sources[stream], set()) - {m['owner']}:
                    identified = False
                if identified:
                    claimed_account, claimed_bank = identity
                    if account:
                        # The game can rename an account while its guest remains in the room.
                        # An unchanged, uninterrupted label may follow that account only while
                        # nobody else claims the old name and the source has never gone absent.
                        renamed = (identity == ('', None) and account in self.roster.players and
                                   m['state'] == 'active' and m.get('label') == nick_key and
                                   (room, stream) in self._continuous_vdo)
                        identified = renamed or (claimed_account == account and claimed_bank == bank)
                    else:
                        identified = claimed_bank is None or claimed_bank == bank
                        if self.roster.players and _camera_name(nick) != nick_key:
                            identified = False
                if not identified:
                    # A VDO stream ID can be reused by a different person. Keep this bank
                    # reserved but stop exposing its image under the former player's identity.
                    m.update(page=_digest(''), state='conflict')
                    rows[bank] = account, nick, ''
                    issues += 1
                    continue
                if not account:
                    nick = label
            else:
                if not identified:
                    issues += 1
                    continue
                account, bank = identity
                allowed = {account} if bank is None else {account, self.owners[bank]}
                if saved_sources.get(sources[stream], set()) - allowed:
                    issues += 1
                    continue
                if bank is not None:
                    marker = markers[bank]
                    if marker:
                        # A room switch or a reconnect may provide a new stream ID. A single
                        # exact identity can reclaim its own unchanged camera only.
                        can_replace = (marker['owner'] and marker['owner'] == self.owners[bank]
                                       and _digest(rows[bank][2]) == marker['page']
                                       and (marker['room'] != room or not incomplete and marker['stream'] not in entries))
                        if not can_replace:
                            issues += 1
                            continue
                    elif rows[bank][2] or account and self.roster.pages.get(account):
                        issues += 1
                        continue
                    allocated = marker['allocated'] if marker else bank not in self.manual_banks
                    account, nick, _ = rows[bank]
                else:
                    if account and self.roster.pages.get(account):
                        issues += 1
                        continue
                    bank = self._empty_bank(rows)
                    if bank is None and not incomplete:
                        bank = self._retired_guest_bank(markers, rows, reserved)
                    if bank is None:
                        full += 1
                        continue
                    allocated = True
                    nick = self.roster.players.get(account, {}).get('name') or label
                markers[bank] = dict(room=room, stream=stream, owner='', page='', allocated=allocated)

            if recycled and old_bank != bank:
                # Keep the previous player's silent bank, but only the newly verified owner
                # may refer to this reissued stream ID on subsequent snapshots.
                markers[old_bank]['stream'] = ''
            rows[bank] = (account, nick, page)
            markers[bank]['owner'] = account or ('nick:' + _camera_name(nick))
            markers[bank].update(page=_digest(page), state='active', label=nick_key)
            continuous.add((room, stream))
            connected += 1

        previous_evidence = self._continuous_vdo, self._last_vdo
        self._continuous_vdo = continuous
        held = {(m['room'], m['stream']) for m in markers if m and m['state'] == 'active'
                and (m['room'] != room or m['stream'] in entries and m['stream'] not in observed)}
        self._last_vdo = continuous | (held & self._last_vdo)
        if markers != self.guest_banks or rows != previous:
            former = self.guest_banks
            self.guest_banks = markers
            if rows != previous:
                try:
                    self.save_preparation(previous, rows, from_vdo=True)
                except ValueError:
                    self.guest_banks = former
                    self._continuous_vdo, self._last_vdo = previous_evidence
                    return 'Назначения изменились. Проверьте пары камер и повторите импорт.'
            else:
                self.save()
        result = f'Камеры гостей · {connected} из {len(guests) if observed_streams is None else len(observed)}.'
        departed = sum(not rows[i][2] for i in cleared_banks)
        if departed:
            result += f' Переведено в прозрачный режим · {departed}.'
        if full:
            result += f' Все 12 пар заняты, ожидают · {full}. Освободите пары в «Камеры до матча».'
        if issues:
            result += f' Требуют проверки · {issues}. Проверьте подписи и ручные назначения.'
        return result

    def _allocate(self):
        slots = self.roster.slots
        if not self.managed or len(slots) != 12 or len(set(slots.values())) != 12:
            return
        current = set(slots.values())
        updated = False
        matches = {}
        for account in current:
            matches.setdefault('nick:' + _camera_name(self.roster.players[account]['name']), []).append(account)
        for bank, pending in enumerate(self.owners):
            candidates = matches.get(pending, [])
            if len(candidates) == 1 and candidates[0] not in self.owners:
                account = candidates[0]
                self.owners[bank] = account
                self.labels.pop(pending, None)
                page = self.pending_pages.pop(pending, '')
                marker = self.guest_banks[bank]
                saved_page = self.roster.pages.get(account, '')
                if marker and marker['owner'] == pending:
                    marker['owner'] = account
                    if saved_page:
                        # A previously configured account URL wins over the provisional director link.
                        marker['owner'] = ''
                        page = saved_page
                self.roster.update_pages({account: page})
                self.record(f'Пара {bank + 1}: подтверждён Account ID {account}.')
                updated = True
        for pos, account in sorted(slots.items()):
            if account in self.owners or not self.has_camera(account):
                continue
            rows = self.preparation_rows()
            bank = self._empty_bank(rows)
            if bank is None:
                bank = self._retired_guest_bank(self.guest_banks, rows)
            if bank is None:
                bank = next((i for i, owner in enumerate(self.owners)
                             if owner and i not in self.manual_banks and not owner.startswith('nick:')
                             and owner not in current and not self.guest_banks[i] and self._replaceable(i)), None)
            if bank is not None:
                self.guest_banks[bank] = None
                self.owners[bank] = account
                self.record(f'Пара {bank + 1} закреплена за Account ID {account}.')
                updated = True
        for account in current.intersection(self.owners):
            nick = self.roster.players[account]['name']
            if self.labels.get(account) != nick:
                self.labels[account] = nick
                updated = True
        if updated:
            self.save()

    def _assign(self):
        account = self.owner_box.currentData()
        bank = self.bank_box.currentIndex()
        if not account or bank < 0 or self.owners[bank] == account:
            return
        if QMessageBox.question(self.bank_widget, 'Назначение камеры',
                f'Закрепить пару {bank + 1} за {self.roster.players[account]["name"]}? '
                'Изменение браузерного источника может сразу появиться в эфире.') != QMessageBox.StandardButton.Yes:
            return
        if account in self.owners:
            old = self.owners.index(account)
            self.owners[old] = self.owners[bank]
            if self.owners[old]:
                self.manual_banks.add(old)
            else:
                self.manual_banks.discard(old)
            if self.guest_banks[old]:
                self.guest_banks[old]['owner'] = ''
        self.owners[bank] = account
        self.manual_banks.add(bank)
        if self.guest_banks[bank]:
            self.guest_banks[bank]['owner'] = ''
        if not self.managed:
            self.managed = True
            self.activated.emit()
        self.save()
        self.record(f'Оператор назначил пару {bank + 1} аккаунту {account}.')
        self.refresh()

    def _view_banks(self):
        players = self.roster.players
        state = tuple((acc, p['name']) for acc, p in players.items()), tuple(self.owners)
        if state != self.last_assignment_view:
            self.last_assignment_view = state
            selected, bank = self.owner_box.currentData(), self.bank_box.currentIndex()
            self.owner_box.clear()
            for account, p in players.items():
                self.owner_box.addItem(f"{p['name']} · {account}", account)
            self.owner_box.setCurrentIndex(max(0, self.owner_box.findData(selected)))
            self.bank_box.clear()
            for i, account in enumerate(self.owners, 1):
                name = players.get(account, {}).get('name') or self.labels.get(account) or account
                self.bank_box.addItem(f'{i} · {name or "свободна"}')
            self.bank_box.setCurrentIndex(max(0, bank))
            missing = [p['name'] for a,p in players.items() if a not in self.owners]
            self.note.setText('Ожидают назначения: ' + ', '.join(missing) if missing else '')
        self.assign.setEnabled(bool(players))

    def _sync(self):
        desired = {}
        for role, cfg in self.config.items():
            if not cfg['enabled']:
                continue
            key = endpoint_key(cfg)
            ep = self._endpoint(key)
            names, pages = desired.setdefault(key, ({}, {}))
            for bank, original in enumerate(self._originals(role)):
                account = self.owners[bank]
                nick = self.roster.players.get(account, {}).get('name') or self.labels.get(account) or account
                page = self._source(account) if self.has_camera(account) else ''
                if original and browser_source(ep.inputs.get(original, {})):
                    names[original] = nick if page else '-'
                    pages[original] = camera_page(page)
                copy = cfg['guids'][bank]
                if role == 'replay' and copy and virtual_source(ep.inputs.get(copy, {})):
                    names[copy] = nick + ' (Virtual)' if page else '-'
        for key, ep in self.endpoints.items():
            enabled = key in desired or key in self.discovery.values()
            ep.configure(*key, enabled)
            if enabled:
                ep.sync(*desired.get(key, ({}, {})))

    def _routing_bank(self, role, account):
        if account in self.owners:
            return self.owners.index(account)
        if role != 'live' or self._source(account):
            return None
        # A transparent Live take can use a vacant bank without reserving it for this player.
        return next((i for i, owner in enumerate(self.owners) if not owner and self.config[role]['guids'][i]), None)

    def routable(self, role, account):
        cfg = self.config[role]
        ep = self.endpoints.get(endpoint_key(cfg))
        if (not cfg['enabled'] or not ep or not ep.online
                or (role == 'replay' or self._source(account)) and not self.has_camera(account)):
            return False
        bank = self._routing_bank(role, account)
        if bank is None:
            return False
        original = self._originals(role)[bank]
        guid = cfg['guids'][bank]
        page = camera_page(self._source(account))
        if not ep.ready(original, page) or guid not in ep.inputs:
            return False
        if role == 'replay' and not virtual_source(ep.inputs[guid]):
            return False
        return cfg['target'] in ep.inputs if cfg['mode'] == 'layer' else cfg['mix'] in ep.mixes

    def take(self, role, slot, *, automatic=False):
        account = self.roster.slots.get(slot)
        if not account or not self.routable(role, account):
            return False
        cfg = self.config[role]
        bank = self._routing_bank(role, account)
        guid = cfg['guids'][bank]
        if role == 'live':
            self.armed_observer = None
            self.last_observer = self.roster.observed
            self.queued_observer = account if automatic else None
        key = endpoint_key(cfg)
        accepted = self.endpoints[key].take(
            guid, cfg['mix'], cfg['target'] if cfg['mode'] == 'layer' else '', cfg['layer'],
            original=self._originals(role)[bank], page=camera_page(self._source(account)))
        if accepted:
            self.pending_choices[role] = (key, guid, account)
            self.record(f"{role}: клавиша {slot}, Account ID {account}, пара {bank + 1}.")
        return accepted

    def refresh(self):
        if self.closed:
            return
        for role, (key, guid, account) in list(self.pending_choices.items()):
            ep, cfg = self.endpoints[key], self.config[role]
            lost_observer = role == 'live' and self.queued_observer and self.queued_observer != self.roster.observed
            bank = self._routing_bank(role, account)
            if (not ep.online or lost_observer or account not in self.roster.slots.values() or bank is None
                    or cfg['guids'][bank] != guid or not self.routable(role, account)):
                ep.cancel_take(cfg['mix'], cfg['target'] if cfg['mode'] == 'layer' else '', cfg['layer'])
                self.pending_choices.pop(role, None)
            elif (ep.layers.get((cfg['target'], cfg['layer'])) if cfg['mode'] == 'layer' else ep.mixes.get(cfg['mix'])) == guid:
                self.pending_choices.pop(role, None)
        self._allocate()
        self._view_banks()
        self._sync()
        names = {pos: self.roster.players[a]['name'] for pos, a in self.roster.slots.items()}
        for role, cfg in self.config.items():
            ep = self.endpoints.get(endpoint_key(cfg))
            discovered = self.endpoints.get(self.discovery.get(role)) or ep
            self.available[role] = {s for s, a in self.roster.slots.items() if self.routable(role, a)}
            actual = None
            if ep and ep.online:
                actual = (ep.layers.get((cfg['target'], cfg['layer'])) if cfg['mode'] == 'layer'
                          else ep.mixes.get(cfg['mix']))
            active = ep.inputs.get(actual, {}).get('title', '') if actual and ep else ''
            if ep and ep.online:
                self.last_tally[role] = active
            elif self.last_tally.get(role):
                active = self.last_tally[role] + ' (последнее подтверждение)'
            state = 'Выкл.' if not cfg['enabled'] else ('Подключено' if ep and ep.online else 'Ожидание vMix')
            ready = self.available[role]
            guidance = ''
            if cfg['enabled'] and ep and ep.online:
                if cfg['mode'] == 'program' and cfg['mix'] not in ep.mixes:
                    guidance = f"В пресете отсутствует Mix {cfg['mix']}."
                elif cfg['mode'] == 'layer' and cfg['target'] not in ep.inputs:
                    guidance = 'Целевой вход слоя отсутствует в пресете.'
                elif not names:
                    guidance = 'Ожидание подтверждённого порядка в разделе Match.'
                elif self._duplicate_cameras().intersection(self.roster.slots.values()):
                    guidance = 'Одна камера назначена нескольким игрокам. Проверьте URL просмотра.'
                elif role == 'replay' and any(not self._source(account) for account in self.roster.slots.values()):
                    guidance = f'Готовы {len(ready)} из {len(names)}. Для Replay нужна камера игрока.'
                elif len(ready) < len(names):
                    guidance = f'Готовы {len(ready)} из {len(names)}. Проверьте назначение пар, GUID и URL игроков.'
            self.panels[role].render(discovered.inputs if discovered else {}, names, ready, active,
                                     ' · '.join(filter(None, (state, self.status[role], guidance))),
                                     catalog_endpoint=self.discovery.get(role) or endpoint_key(cfg))
            active_slot = None
            if actual and actual in cfg['guids']:
                owner = self.owners[cfg['guids'].index(actual)]
                active_slot = next((s for s, a in self.roster.slots.items() if a == owner), None)
            self.panels[role].mark_active(active_slot)
        cfg = self.config['live']
        if self.roster.match_id and self.observer_match != self.roster.match_id:
            self.observer_match = self.roster.match_id
            self.last_observer = None
        if not self.roster.observed:
            self.armed_observer = None
        elif self.last_observer != self.roster.observed:
            self.last_observer = self.roster.observed
            self.armed_observer = self.roster.observed if cfg['enabled'] and cfg['follow'] else None
        if self.armed_observer:
            slot = next((pos for pos, a in self.roster.slots.items() if a == self.armed_observer), None)
            if slot in self.available['live']:
                self.take('live', slot, automatic=True)
        state = (self.roster.match_id, names, frozenset(self.available['replay']), self.roster.observed, self.input_numbers(),
                 self.roster.players.copy(), tuple(self.owners), frozenset(self.roster.pages) - self._duplicate_cameras(),
                 tuple((m['owner'], m['state']) if m else None for m in self.guest_banks),
                 self.config['replay']['enabled'],
                 tuple(tuple(self.config[r]['guids']) for r in ROLES))
        if state != self._export:
            self._export = state
            self.changed.emit()

    def input_numbers(self):
        cfg = self.config['live']
        ep = self.endpoints.get(endpoint_key(cfg))
        refs = {owner: cfg['guids'][i] for i, owner in enumerate(self.owners) if owner}
        return tuple(ep.inputs.get(refs.get(self.roster.slots.get(i)), {}).get('number', 0) if ep else 0
                     for i in range(1, 13))

    def close(self):
        self.closed = True
        self._render_timer.stop()
        for ep in self.endpoints.values():
            ep.close()
