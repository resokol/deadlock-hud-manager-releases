"""Deliver room snapshots from the loopback bridge to camera routing on the Qt thread."""
from math import ceil
from time import monotonic

from PySide6.QtCore import QObject, QTimer, QUrl, Signal
from PySide6.QtGui import QDesktopServices

from .camera_vdo_bridge import VdoRoomBridge
from .camera_vdo_room import parse_director


class VdoImport(QObject):
    received = Signal(int, object)
    freshness_changed = Signal(bool)

    def __init__(self, panel, cameras, parent=None, *, bridge_factory=VdoRoomBridge, open_url=QDesktopServices.openUrl):
        super().__init__(parent)
        self.panel, self.cameras = panel, cameras
        self.bridge_factory, self.open_url = bridge_factory, open_url
        self.bridge = self.room = None
        self.generation = 0
        self.last_response = 0
        self._fresh = False
        self._session_open = False
        self.known = {}
        self.missing_since = {}
        self.seen_nonempty = False
        self.interval = panel.poll_interval.value()
        self.timer = QTimer(self, singleShot=True)
        self.timer.timeout.connect(self._check_connection)
        self.received.connect(self._accept)
        panel.start_requested.connect(self.start)
        panel.reopen_requested.connect(self.reopen)
        panel.stop_requested.connect(self.stop)
        panel.poll_interval.valueChanged.connect(self._set_interval)

    def start(self, raw):
        self.stop(reset_panel=False)
        try:
            self.room = parse_director(raw)
        except ValueError as exc:
            self.panel.start_failed(str(exc))
            return
        generation = self.generation
        try:
            as_director = self.panel.director_mode.isChecked() or self.room.codirector
            self.bridge = self.bridge_factory(raw, lambda guests: self.received.emit(generation, guests),
                                              scene=not as_director, interval=self.interval)
            if not self.open_url(QUrl(self.bridge.url)):
                raise OSError
        except (OSError, ValueError):
            self.stop(reset_panel=False)
            self.panel.start_failed('Не удалось открыть локальную вкладку. Проверьте браузер по умолчанию.')
            return
        self.last_response = monotonic()
        self._session_open = True
        self.panel.started()
        self._check_connection()

    @property
    def stale_after(self):
        return max(20, 3 * self.interval + 2)

    @property
    def fresh(self):
        return self._fresh and monotonic() - self.last_response < self.stale_after

    def _set_fresh(self, value):
        if self._fresh != value:
            self._fresh = value
            self.freshness_changed.emit(value)

    def _end_session(self):
        if self._session_open:
            self._session_open = False
            self.cameras.end_vdo_session()

    def _set_interval(self, seconds):
        self.interval = seconds
        self.missing_since.clear()
        if self.bridge:
            self.bridge.set_interval(seconds)
            self._check_connection()

    def reopen(self):
        if self.bridge and self.open_url(QUrl(self.bridge.url)):
            self._end_session()
            self.missing_since.clear()
            self._set_fresh(False)

    def _accept(self, generation, guests):
        if not self.bridge or generation != self.generation:
            return
        now = monotonic()
        if now - self.last_response >= self.stale_after:
            self._end_session()
            self.missing_since.clear()
        self.last_response = now
        self.timer.start(self.stale_after * 1000)
        live = {g['streamID']: g for g in guests}
        if len(live) != len(guests):
            self.missing_since.clear()
            self._set_fresh(False)
            self.panel.show_result(len(guests), 'В списке повторяется Stream ID. Назначения камер сохранены.')
            return
        if live:
            self.seen_nonempty = True
        if not self.seen_nonempty:
            # The Director DOM can return {} even before room authorization is complete.
            self.panel.set_guests([])
            self.panel.show_result(0, 'Ожидание гостей. Проверьте вход в комнату во вкладке браузера.')
            return
        for sid in self.known.keys() - live.keys():
            since = self.missing_since.setdefault(sid, now)
            if now - since >= 2 * self.interval:
                del self.known[sid]
                self.missing_since.pop(sid, None)
        for sid, guest in live.items():
            self.known[sid] = dict(streamID=sid, label=guest['label'], page=self.room.viewer(sid))
            self.missing_since.pop(sid, None)
        self._session_open = True
        summary = self.cameras.import_vdo_guests(self.room.key, list(self.known.values()),
                                                observed_streams=set(live))
        rows = [dict(label=self.known[sid]['label'], page=self.known[sid]['page'],
                     bank=self.cameras.vdo_guest_bank(self.room.key, sid)) for sid in live]
        self.panel.set_guests(sorted(rows, key=lambda row: (row['bank'] or 13, row['label'].casefold())))
        self.panel.show_result(len(live), summary)
        self._set_fresh(True)

    def _check_connection(self):
        if not self.bridge:
            return
        remaining = self.last_response + self.stale_after - monotonic()
        if remaining <= 0:
            self._end_session()
            self.panel.show_stale()
            self.missing_since.clear()
            self._set_fresh(False)
        else:
            self.timer.start(ceil(remaining * 1000))

    def stop(self, *, reset_panel=True):
        self.timer.stop()
        self.generation += 1
        bridge, self.bridge = self.bridge, None
        if bridge:
            bridge.close()
        self._end_session()
        self.room = None
        self.known.clear()
        self.missing_since.clear()
        self.seen_nonempty = False
        self._set_fresh(False)
        if reset_panel:
            self.panel.stop()
