from test_camera_workflow import snapshot
from test_pov_manager import NativeMixer, pov
from test_vmix_control import app, fake_api, wait_for


def test_confirmed_match_can_apply_labels_without_room_and_retry(pov, fake_api):
    mixer = NativeMixer(fake_api, 9400)
    panel = pov.vdo_panel
    panel.vmix_host.setText('127.0.0.1')
    panel.vmix_port.setValue(mixer.port)
    names = ['mazaG', 'MikaelS', '❄', 'TheHeavy™', 'Deaf Blind Mute', 'Joker',
             'Бибизяный', '33', 'yasinzeinab', 'SoulLink', 'fargareko', 'Sla1ke s0 v les']
    snapshot(pov, names)
    assert not pov.sync_button.isHidden()
    assert not pov.sync_button.isEnabled()
    pov.camera_roster.apply.click()
    assert pov.sync_button.text() == 'Применить к vMix' and pov.sync_button.isEnabled()
    pov.sync_button.click()
    wait_for(lambda: '24/24' in pov.sync_result.text())
    assert [mixer.titles[g] for g in mixer.order[:24]] == names + [n + ' - Virtual' for n in names]
    assert len(mixer.commands) == 24 and all(cmd['Function'] == 'SetInputName' for cmd in mixer.commands)
    pov.sync_button.click()
    wait_for(lambda: '24/24' in pov.sync_result.text())
    assert len(mixer.commands) == 24


def test_vdo_caption_for_assigned_guest_preserves_other_game_names(pov, fake_api):
    from test_pop_outputs import room
    mixer = NativeMixer(fake_api, 9100)
    room(pov, mixer, ['Guest cam'])
    names = ['mazaG'] + [f'Игрок {n}' for n in range(2, 13)]
    snapshot(pov, names)
    pov.match_cameras.select(pov._room_key(), pov.bindings.receipt)
    pov.match_cameras.save({'id.501': mixer.keys[1]})
    pov.camera_roster.apply.click()
    wait_for(lambda: pov._fixed and pov.native.ready)
    pov.vdo_captions.click()
    wait_for(lambda: pov.native.ready and mixer.titles[mixer.keys[13]] == 'Guest cam - Virtual')
    assert pov.companion.payload['camera_slots']['1']['name'] == 'mazaG'
    assert mixer.titles[mixer.keys[1]] == 'Guest cam'
    assert [mixer.titles[g] for g in mixer.order[1:12]] == names[1:]
    pov.sync_button.click()
    wait_for(lambda: '24/24' in pov.sync_result.text())
    assert mixer.titles[mixer.keys[1]] == 'Guest cam'
    pov.vdo_captions.click()
    wait_for(lambda: pov.native.ready and mixer.titles[mixer.keys[13]] == 'mazaG - Virtual')


def test_failed_rename_can_resume_without_resending_confirmed_labels(pov, fake_api):
    from urllib.parse import parse_qs, urlsplit
    mixer = NativeMixer(fake_api, 9500)
    def reject(path):
        query = parse_qs(urlsplit(path).query)
        if query.get('Function') == ['SetInputName'] and query['Input'] == [mixer.keys[13]]:
            return 500, {}, b''
        return mixer.answer(path)
    fake_api.answer = reject
    pov.vdo_panel.vmix_host.setText('127.0.0.1')
    pov.vdo_panel.vmix_port.setValue(mixer.port)
    snapshot(pov, [f'Игрок {n}' for n in range(12)])
    pov.camera_roster.apply.click()
    pov.sync_button.click()
    wait_for(lambda: '12/24' in pov.sync_result.text())
    assert 'Вход 13' in pov.sync_result.text()
    fake_api.answer = mixer.answer
    pov.sync_button.click()
    wait_for(lambda: '24/24' in pov.sync_result.text())
    assert len(mixer.commands) == 24


def test_wrong_virtual_parent_stops_before_rename(pov, fake_api):
    mixer = NativeMixer(fake_api, 9600)
    mixer.order[12], mixer.order[13] = mixer.order[13], mixer.order[12]
    pov.vdo_panel.vmix_host.setText('127.0.0.1')
    pov.vdo_panel.vmix_port.setValue(mixer.port)
    snapshot(pov, [f'Name{n}' for n in range(12)])
    pov.camera_roster.apply.click()
    pov.sync_button.click()
    wait_for(lambda: '0/24' in pov.sync_result.text())
    assert 'пары' in pov.sync_result.text() and not mixer.commands


def test_empty_connected_room_keeps_all_match_captions(pov, fake_api):
    mixer = NativeMixer(fake_api, 9300)
    names = [f'Player {n}' for n in range(12)]
    panel = pov.vdo_panel
    panel.vmix_host.setText('127.0.0.1')
    panel.vmix_port.setValue(mixer.port)
    pov.vdo_import.open_url = lambda _: True
    panel.url.setText('https://vdo.ninja/?director=room')
    panel.connect_button.click()
    pov.vdo_import._accept(pov.vdo_import.generation, [])
    snapshot(pov, names)
    pov.camera_roster.apply.click()
    pov.sync_button.click()
    wait_for(lambda: '24/24' in pov.sync_result.text())
    assert [mixer.titles[k] for k in mixer.order[:12]] == names
    before = len(mixer.commands)
    pov.vdo_import._accept(pov.vdo_import.generation, [dict(streamID='cam', label=names[0], video='live')])
    wait_for(lambda: pov._fixed and pov.native.ready)
    assert [mixer.titles[k] for k in mixer.order[:24]] == names + [n + ' - Virtual' for n in names]
    assert all(c['Value'] != '-' for c in mixer.commands[before:] if c['Function'] == 'SetInputName')
