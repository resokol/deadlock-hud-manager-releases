"""Two separate operator processes, each with local settings, against one vMix Web Controller."""
import json
import os
from pathlib import Path
import subprocess
import sys
from time import monotonic, sleep


def operator(folder, port, mix, position, bank):
    from PySide6.QtCore import QSettings, QTimer
    from PySide6.QtWidgets import QApplication
    from observer_assist.pov_manager import PovManager

    app = QApplication([])
    settings = QSettings(str(folder / f'desk-{mix}.ini'), QSettings.Format.IniFormat)
    settings.setValue('popAttachedMode', True)
    settings.setValue('popAttachedRunning', True)
    settings.setValue('popAttachedHost', '127.0.0.1')
    settings.setValue('popAttachedPort', port)
    settings.setValue('popAttachedOutputMixes', json.dumps([dict(mix=mix, enabled=True, bank=bank, follow=False)]))
    panel = PovManager(settings)
    clicked = False

    def watch():
        nonlocal clicked
        if not panel.remote_bank.ready or not panel.outputs.rows:
            return
        button = panel.outputs.rows[0].buttons[position - 1]
        if not button.isEnabled():
            return
        if not clicked:
            (folder / f'ready-{mix}').touch()
            if (folder / 'take').exists():
                clicked = True
                button.click()
        elif button.property('onProgram') and not panel.remote_bank.busy:
            app.exit(0)

    timer = QTimer(interval=30)
    timer.timeout.connect(watch)
    timer.start()
    QTimer.singleShot(15000, lambda: app.exit(3))
    exit_code = app.exec()
    panel.close()
    return exit_code


def test_two_operator_processes_control_only_their_mix(fake_api, tmp_path):
    from test_pop_remote_bank import owner_preset

    mixer = owner_preset()
    fake_api.answer = mixer.answer
    root = Path(__file__).resolve().parents[1]
    env = dict(os.environ, PYTHONPATH=str(root), QT_QPA_PLATFORM='offscreen')
    desks = []
    try:
        for mix, position, bank in [(1, 7, 'live'), (2, 4, 'replay')]:
            desks.append(subprocess.Popen(
                [sys.executable, str(Path(__file__).resolve()), str(tmp_path), str(fake_api.server_port),
                 str(mix), str(position), bank], cwd=root, env=env, stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT, text=True))
        deadline = monotonic() + 12
        while monotonic() < deadline and not all((tmp_path / f'ready-{n}').exists() for n in (1, 2)):
            if any(p.poll() is not None for p in desks):
                break
            sleep(0.04)
        (tmp_path / 'take').touch()
        for p in desks:
            output, _ = p.communicate(timeout=20)
            assert p.returncode == 0, output
        assert (tmp_path / 'ready-1').exists() and (tmp_path / 'ready-2').exists()
        assert mixer.active == {1: mixer.pairs[6].original_guid, 2: mixer.pairs[3].virtual_guid}
        assert sorted((c['Function'], c['Mix'], c['Input']) for c in mixer.writes) == [
            ('ActiveInput', '0', mixer.pairs[6].original_guid), ('ActiveInput', '1', mixer.pairs[3].virtual_guid)]
    finally:
        for p in desks:
            if p.poll() is None:
                p.kill()
            p.wait()


if __name__ == '__main__':
    arg_folder, arg_port, arg_mix, arg_slot, arg_bank = sys.argv[1:]
    sys.exit(operator(Path(arg_folder), int(arg_port), int(arg_mix), int(arg_slot), arg_bank))
else:
    from test_vmix_control import app, fake_api, wait_for

def test_owner_prepares_and_remote_operator_sees_new_match_and_conflicts(app, fake_api, tmp_path):
    from observer_assist.pov_manager import PovManager
    from observer_assist.pov_match_data import RemoteMatch
    from test_pov_manager import NativeMixer
    from test_pop_remote_workstation import assign, connect_remote, dispose, local_settings

    mixer = NativeMixer(fake_api, 34000)
    main = PovManager(local_settings(tmp_path, 'camera-owner'))
    replay = PovManager(local_settings(tmp_path, 'camera-client'))
    try:
        main.vdo_panel.vmix_host.setText('127.0.0.1')
        main.vdo_panel.vmix_port.setValue(mixer.port)
        main.vdo_import.open_url = lambda _: True
        main.vdo_panel.url.setText('https://vdo.ninja/?director=testroom')
        main.vdo_panel.connect_button.click()
        names = tuple(f'Guest{i:02}' for i in range(12))
        main.vdo_import._accept(main.vdo_import.generation, [
            dict(label=name, streamID='web-'+name, video='live') for name in names[:8]])
        wait_for(lambda: main.room_routes.ready and len(mixer.writes('BrowserNavigate')) >= 8)
        main.outputs.rows[0].enabled.setChecked(True)
        main.outputs.rows[1].enabled.setChecked(False)
        connect_remote(replay, mixer)
        replay.remote_bank._poll.setInterval(50)
        row = assign(replay, 2, 'replay')
        assert names[0] in row.buttons[0].text()
        row.buttons[0].click()
        wait_for(lambda: mixer.active_guids[2] == mixer.keys[13] and not replay.remote_bank.busy)
        main.mode.setCurrentIndex(main.mode.findData('remote'))
        match_order = names[6:] + names[:6]
        packet = RemoteMatch('140372810', match_order, None, None)
        main.remote.snapshot = packet
        main.remote.changed.emit(packet)
        wait_for(lambda: main._fixed and main.native.ready)
        wait_for(lambda: replay.remote_bank.ready and replay.remote_bank.route(1)['title'] == names[6])
        wait_for(lambda: row.buttons[0].isEnabled())
        row.buttons[0].click()
        wait_for(lambda: mixer.active_guids[2] == mixer.keys[19] and not replay.remote_bank.busy)
        assert mixer.active_guids[1] == mixer.keys[25]
        assert len(mixer.writes('ActiveInput')) == 2
        main.outputs.rows[1].enabled.setChecked(True)
        wait_for(lambda: not row.buttons[0].isEnabled() and not main.outputs.rows[1].buttons[0].isEnabled())
        assert 'другом' in row.status.text()
        assert main.outputs.rows[0].buttons[0].isEnabled()
        main.outputs.rows[1].enabled.setChecked(False)
        wait_for(lambda: row.buttons[0].isEnabled())
    finally:
        dispose(replay)
        dispose(main)
