from functools import partial
from ipaddress import IPv4Interface
import json
from urllib.request import urlopen

from PySide6.QtCore import QEvent, QSettings

from observer_assist import hud_manager, live_stats_panel
from observer_assist.hud_manager import HudManager
from observer_assist.match_stats import StatsLanServer
from observer_assist.panorama_health import PanoramaHealthLog
from observer_assist.panorama_hud_mode import PanoramaTelemetryServer
from observer_assist.pov_match_data import POV_MATCH_ROUTE, read_pov_snapshot
from observer_assist.pov_remote import PovRemote
from test_vmix_control import app, wait_for


def test_automatic_json_and_full_mode_share_one_live_endpoint(app, tmp_path, monkeypatch):
    monkeypatch.setattr(hud_manager, 'PanoramaTelemetryServer', partial(PanoramaTelemetryServer, port=0))
    monkeypatch.setattr(live_stats_panel, 'StatsLanServer', partial(StatsLanServer, port=0))
    monkeypatch.setattr(live_stats_panel, 'lan_interfaces', lambda: [('Test', IPv4Interface('127.0.0.1/8'))])
    s = QSettings(str(tmp_path/'hud.ini'), QSettings.Format.IniFormat)
    w = HudManager(s, tmp_path/'huds', auto_modes=True)
    subscriber = PovRemote(by_position=True)
    try:
        assert w.mode_box.currentData() == 'json' and w.live_stats._export
        url = w.live_stats._export.url
        path = tmp_path/'console.log'
        path.touch()
        w._health_log = PanoramaHealthLog(path)
        names = [f'Nickname {n}' for n in range(12)]
        teams = [dict(side=side, players=[dict(name=names[i], portraitX=40*i) for i in range(a,a+6)])
                 for side, a in ((2,0),(3,6))]
        def feed(match, selected):
            packet = dict(version=1, teams=teams, selected=dict(player=selected, hp=50, maxHp=100))
            with path.open('a') as log:
                log.write(f'[DOA-MATCH-ID] {match}\n[DOA-TELEMETRY] '+json.dumps(packet)+'\n')
            w._poll_panorama_health()
            with urlopen(url, timeout=2) as r:
                return json.load(r)
        # The console can publish the top bar before it identifies the match.
        feed('', names[0])
        pov_url = url.replace('/api/v1/stats', POV_MATCH_ROUTE)
        with urlopen(pov_url, timeout=2) as response:
            live = json.load(response)
        assert read_pov_snapshot(live, by_position=True).names == tuple(names)
        assert live['panorama_match_id'] is None and read_pov_snapshot(live) is None
        first = feed('143169416', names[6])
        assert first['hud_slots']['7'] == names[6] and first['matchId'] == '143169416'
        assert first['hud_observed_slot'] is None and not first['selected']
        w.mode_box.setCurrentIndex(w.mode_box.findData('full'))
        assert feed('143169416', names[8])['hud_observed_slot'] == 9
        w.mode_box.setCurrentIndex(w.mode_box.findData('json'))
        assert subscriber.set_url(url)
        wait_for(lambda: subscriber.snapshot and subscriber.snapshot.match_id == '143169416')
        assert subscriber.snapshot.names == tuple(names)
        with path.open('a') as log:
            log.write('[DOA-MATCH-ID] 143169417\n')
        w._poll_panorama_health()
        subscriber._poll()
        wait_for(lambda: subscriber.snapshot and subscriber.snapshot.match_id == '143169417')
        assert subscriber.snapshot.names == ()
        names.reverse()
        for t in teams:
            for p in t['players']:
                p['name'] = names[p['portraitX']//40]
        second = feed('143169417', names[0])
        assert second['hud_slots']['1'] == names[0] and second['hud_observed_slot'] is None
        assert second['matchId'] == '143169417' and w.live_stats._export.url == url
        subscriber._poll()
        wait_for(lambda: subscriber.snapshot and subscriber.snapshot.names == tuple(names))
    finally:
        subscriber.stop()
        w.close()
        w.deleteLater()
        app.sendPostedEvents(None, QEvent.Type.DeferredDelete)


def test_manager_launch_supplies_dev_logging_and_normal_sampler(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from unittest.mock import Mock
    from observer_assist import panorama_mount, steam
    exe = tmp_path/'steam.exe'
    launch = Mock()
    mount = Mock()
    monkeypatch.setattr(steam, 'sys', SimpleNamespace(platform='win32'))
    monkeypatch.setattr(steam, 'find_steam', lambda: exe)
    monkeypatch.setattr(steam, 'find_deadlock_citadel', lambda: tmp_path)
    monkeypatch.setattr(steam, 'is_deadlock_running', lambda: False)
    monkeypatch.setattr(steam.subprocess, 'Popen', launch)
    monkeypatch.setattr(panorama_mount, 'mount', mount)
    steam.launch_deadlock(False, panorama_health=True, dev=True)
    mount.assert_called_once_with(tmp_path, minimap_only=False)
    launch.assert_called_once_with([str(exe), '-applaunch', '1422450', '-dev', '-condebug'], cwd=exe.parent)


def test_new_map_waits_for_roster_and_accepts_it_before_clock_or_selection(tmp_path):
    path = tmp_path/'console.log'
    path.touch()
    log = PanoramaHealthLog(path)
    packet = json.dumps(dict(kind='roster', version=1, stream='game', teams=[dict(side=2, players=[])]))
    with path.open('a') as out:
        out.write('[DOA-MATCH-ID] 143169416\n[DOA-TELEMETRY] '+packet+'\n')
    log.poll()
    assert log.telemetry(allow_clockless_roster=True)['teams'] and log.match_id == '143169416'
    with path.open('a') as out:
        out.write('[DOA-MATCH-ID] 143169417\n')
    log.poll()
    assert log.match_id == '143169417' and log.telemetry(allow_clockless_roster=True) is None


def test_prepare_normal_preserves_present_pack_and_skips_running_game(monkeypatch, tmp_path):
    from observer_assist import panorama_mount, steam
    normal = tmp_path/'normal.vpk'
    normal.write_bytes(b'sampler')
    monkeypatch.setattr(panorama_mount, 'packs', lambda: (normal, None))
    running = True
    monkeypatch.setattr(steam, 'is_deadlock_running', lambda: running)
    installed = tmp_path/'addons'/'pak88_dir.vpk'
    panorama_mount.prepare_normal(tmp_path)
    assert not installed.exists()
    running = False
    panorama_mount.prepare_normal(tmp_path)
    assert installed.read_bytes() == b'sampler'
    installed.write_bytes(b'another pack')
    panorama_mount.prepare_normal(tmp_path)
    assert installed.read_bytes() == b'another pack'

def test_json_mode_selection_frames_cannot_keep_expired_portraits_alive(tmp_path, monkeypatch):
    from observer_assist import panorama_health
    now = 100
    monkeypatch.setattr(panorama_health.time, 'monotonic', lambda: now)
    log = PanoramaHealthLog(tmp_path/'console.log')
    team = dict(side=2, players=[dict(name='Guest', portraitX=100)])
    log._accept(dict(kind='roster', stream='s', teams=[team]), now)
    assert log.recent_portraits()['teams'] == [team]
    now += 5
    log._accept(dict(kind='frame', stream='s', selected=dict(player='Guest', hp=1, maxHp=2)), now)
    assert log.recent_portraits() is None
