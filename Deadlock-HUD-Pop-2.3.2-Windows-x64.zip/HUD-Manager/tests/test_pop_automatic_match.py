from observer_assist.pov_match_data import RemoteMatch
from test_pov_manager import NativeMixer, pov
from test_vmix_control import app, fake_api, process_events, wait_for


def test_match_rotates_both_banks_and_replaces_only_departed_players_camera(pov, fake_api):
    mixer = NativeMixer(fake_api, 7100)
    panel = pov.vdo_panel
    panel.vmix_host.setText('127.0.0.1')
    panel.vmix_port.setValue(mixer.port)
    pov.vdo_import.open_url = lambda _: True
    panel.url.setText('https://vdo.ninja/?director=fixture')
    panel.connect_button.click()
    names = tuple(f'Player{i:02}' for i in range(12))

    def room(guests):
        pov.vdo_import._accept(pov.vdo_import.generation,
                               [dict(streamID='web-' + n, label=n, video='live') for n in guests])

    def match(order, match_id='531'):
        packet = RemoteMatch(match_id, order, None, None)
        pov.remote.snapshot = packet
        pov.remote.changed.emit(packet)
        wait_for(lambda: pov._fixed and pov._fixed.match == match_id and pov.native.ready
                 and tuple(p.name for p in pov._fixed.pairs) == order)

    room(names)
    wait_for(lambda: pov.prematch.ready and len(mixer.writes('BrowserNavigate')) == 12)
    pov.mode.setCurrentIndex(pov.mode.findData('remote'))
    match(names)
    order = names[6:] + names[:6]
    match(order)
    assert mixer.order[:12] == [mixer.keys[names.index(name) + 1] for name in order]
    assert mixer.order[12:24] == [mixer.keys[names.index(name) + 13] for name in order]
    assert not mixer.writes('ActiveInput') and len(mixer.writes('BrowserNavigate')) == 12
    previous = mixer.commands[:]
    match(order)
    process_events(220)
    assert mixer.commands == previous
    pov.remote.snapshot = None
    pov.remote.changed.emit(None)
    assert pov._fixed.match == '531' and pov.companion.payload['replay_inputs']['7'] == 19

    # Player06 is still in the directory; the new owner must never inherit their URL.
    substitute_order = ('Substitute',) + order[1:]
    match(substitute_order, '532')
    guid = mixer.order[0]
    assert pov._fixed_meta['aliases'][guid] == 'Substitute'
    assert pov._media_sources()[guid][0] == 'absent'
    wait_for(lambda: any(c['Input'] == guid and c['Value'] == 'about:blank'
                         for c in mixer.writes('BrowserNavigate')))
    room(substitute_order)
    wait_for(lambda: any(c['Input'] == guid and 'web-Substitute' in c['Value']
                         for c in mixer.writes('BrowserNavigate')))
    assert not mixer.writes('ActiveInput')


def test_late_account_ids_identify_a_renamed_player_without_reopening_the_camera(pov, fake_api):
    mixer = NativeMixer(fake_api, 9100)
    panel = pov.vdo_panel
    panel.vmix_host.setText('127.0.0.1')
    panel.vmix_port.setValue(mixer.port)
    pov.vdo_import.open_url = lambda _: True
    panel.url.setText('https://vdo.ninja/?director=fixture')
    panel.connect_button.click()
    names = tuple(f'Guest{i:02}' for i in range(12))
    pov.vdo_import._accept(pov.vdo_import.generation,
                           [dict(streamID='cam-'+n, label=n, video='live') for n in names])
    wait_for(lambda: pov.prematch.ready and len(mixer.writes('BrowserNavigate')) == 12)
    pov.mode.setCurrentIndex(pov.mode.findData('remote'))

    def send(order, identities):
        roster = None
        if identities:
            teams = [dict(side=k+2, players=[dict(name=order[i], accountId=str(800+i))
                          for i in range(6*k, 6*k+6)]) for k in range(2)]
            roster = dict(matchId='701', teams=teams)
        packet = RemoteMatch('701', order, 7, roster)
        pov.remote.snapshot = packet
        pov.remote.changed.emit(packet)

    send(names, False)
    wait_for(lambda: pov._fixed and pov.native.ready)
    send(names, True)
    assert pov._fixed_meta['accounts'][0] == '800'
    game_names = ('UpdatedName',) + names[1:]
    send(game_names, True)
    wait_for(lambda: pov._fixed.pairs[0].name == 'UpdatedName' and pov.native.ready)
    assert mixer.titles[mixer.keys[1]] == 'UpdatedName'
    assert mixer.titles[mixer.keys[13]] == 'UpdatedName - Virtual'
    assert 'cam-Guest00' in pov._media_sources()[mixer.keys[1]][1]
    assert len(mixer.writes('BrowserNavigate')) == 12 and not mixer.writes('ActiveInput')


def test_opening_vdo_hands_same_vmix_from_previous_modules_to_one_fixed_bank(pov, fake_api):
    from test_camera_workflow import configure

    mixer = NativeMixer(fake_api, 9900)
    panel = pov.vdo_panel
    panel.vmix_host.setText('127.0.0.1')
    panel.vmix_port.setValue(mixer.port)
    configure(pov, 'live', mixer)
    configure(pov, 'replay', mixer)
    assert all(cfg['enabled'] for cfg in pov.cameras.config.values())
    pov.vdo_import.open_url = lambda _: True
    panel.url.setText('https://vdo.ninja/?director=fixture')
    panel.connect_button.click()
    pov.vdo_import._accept(pov.vdo_import.generation, [dict(label='Player', streamID='one', video='live')])
    wait_for(lambda: pov.room_routes.ready)
    assert not any(cfg['enabled'] for cfg in pov.cameras.config.values())
    assert mixer.titles[mixer.keys[1]] == 'Player'
    assert not mixer.writes('ActiveInput')
