from urllib.parse import parse_qsl, urlsplit
from uuid import UUID
from xml.etree import ElementTree as ET

import pytest
from PySide6.QtCore import QSettings

from observer_assist.camera_native_setup import NativePoolSetup
from test_vmix_control import app, fake_api, wait_for


def guid(number):
    return str(UUID(int=number))


class Show:
    def __init__(self, fake_api, count=12, *, adjacent=False, opaque=False):
        self.order = [guid(i) for i in range(1, count + 1)]
        self.parents = {guid(i): guid(i-12) for i in range(13, count+1)}
        self.kind = {g: 'Browser' for g in self.order}
        self.writes = []
        self.adjacent = adjacent
        self.opaque = opaque
        self.rejected = False
        self.lost = False
        self.endpoint = ('127.0.0.1', fake_api.server_port)
        fake_api.answer = self.answer

    def answer(self, path):
        command = dict(parse_qsl(urlsplit(path).query))
        if command:
            self.writes.append(command)
            source = command['Input']
            if self.rejected:
                return 500, {}, b''
            if command['Function'] == 'CreateVirtualInput':
                copy = guid(len(self.order) + 1)
                assert source not in self.parents.values()
                self.parents[copy] = source
                self.kind[copy] = 'Browser'
                index = self.order.index(source) + 1 if self.adjacent else len(self.order)
                self.order.insert(index, copy)
            elif command['Function'] == 'MoveInput':
                self.order.remove(source)
                self.order.insert(int(command['Value'])-1, source)
            else:
                return 400, {}, b''
            return (500 if self.lost else 200), {}, b''
        root = ET.Element('vmix')
        ET.SubElement(root, 'preset').text = 'Tour'
        inputs = ET.SubElement(root, 'inputs')
        for i, g in enumerate(self.order, 1):
            attrs = dict(type=self.kind[g], number=str(i), key=g, title=str(i))
            if not self.opaque and g in self.parents:
                attrs.update(virtual='True', originalKey=self.parents[g])
            ET.SubElement(inputs, 'input', attrs)
        ET.SubElement(root, 'active').text = '1'
        return 200, {}, ET.tostring(root)


@pytest.fixture
def setup(app, tmp_path):
    return NativePoolSetup(QSettings(str(tmp_path/'setup.ini'), QSettings.Format.IniFormat))


def run(controller, show, **opts):
    outcome = []
    def done(ok, message):
        outcome.append((ok, message))
    controller.finished.connect(done)
    try:
        controller.start(show.endpoint, **opts)
        wait_for(lambda: bool(outcome))
        return outcome[0]
    finally:
        controller.finished.disconnect(done)


def test_create_twelve_once_then_restart_with_opaque_xml(setup, fake_api):
    show = Show(fake_api, opaque=True)
    ok, msg = run(setup, show)
    assert ok, msg
    assert [c['Function'] for c in show.writes] == ['CreateVirtualInput'] * 12
    assert [c['Input'] for c in show.writes] == show.order[:12]
    show.writes.clear()
    assert run(NativePoolSetup(setup.settings), show)[0]
    assert show.writes == []


def test_one_missing_native_copy_inserted_next_to_source(setup, fake_api):
    show = Show(fake_api, 23, adjacent=True)
    ok, msg = run(setup, show)
    assert ok, msg
    assert show.order == [guid(i) for i in range(1, 25)]
    assert show.writes[0] == {'Function': 'CreateVirtualInput', 'Input': guid(12)}
    assert all(c['Input'] == guid(24) and c['Function'] == 'MoveInput' for c in show.writes[1:])


def test_existing_opaque_copy_is_adopted_by_position_and_is_never_duplicated(setup, fake_api):
    show = Show(fake_api, 13, opaque=True)
    assert run(setup, show)[0]
    assert len(show.writes) == 11
    assert guid(1) not in [c['Input'] for c in show.writes]


def test_foreign_input_in_bank_stops_before_creation(setup, fake_api):
    show = Show(fake_api, 17)
    show.kind[guid(17)] = 'Mix'
    assert not run(setup, show)[0]
    assert not show.writes


def test_ack_lost_reconciles_opaque_creation_by_catalog_delta(setup, fake_api):
    show = Show(fake_api, 23, opaque=True)
    show.lost = True
    assert run(setup, show)[0]
    assert len(show.order) == 24
    assert run(setup, show)[0]
    assert len(show.writes) == 1


def test_failed_create_reopened_reconciles_before_retry(setup, fake_api):
    show = Show(fake_api, 23)
    show.rejected = True
    assert not run(setup, show)[0]
    assert len(show.writes) == 1
    show.rejected = False
    assert run(setup, show)[0]
    assert len(show.writes) == 2


def test_manually_repaired_complete_pool_aligns_native_bank_without_touching_extras(setup, fake_api):
    show = Show(fake_api, 23)
    show.rejected = True
    assert not run(setup, show)[0]
    show.rejected = False
    show.order.extend([guid(24), guid(25)])
    show.parents[guid(24)] = guid(12)
    show.kind[guid(24)] = 'Browser'
    show.kind[guid(25)] = 'Mix'
    show.order[12], show.order[23] = show.order[23], show.order[12]
    show.writes.clear()
    assert run(setup, show)[0]
    assert show.order == [guid(i) for i in range(1, 26)]
    assert show.writes and all(c['Function'] == 'MoveInput' and c['Input'] in show.order[12:24] for c in show.writes)

def test_opaque_full_bank_adopted_and_shuffled_saved_pairs_follow_guids(setup, fake_api):
    show = Show(fake_api, 24, opaque=True)
    assert run(setup, show)[0]
    assert not show.writes
    show.order[12], show.order[13] = show.order[13], show.order[12]
    assert run(NativePoolSetup(setup.settings), show)[0]
    assert show.order == [guid(i) for i in range(1, 25)]
    assert show.writes == [{'Function': 'MoveInput', 'Input': guid(13), 'Value': '13'}]


def test_contradictory_parent_aborts_before_any_write(setup, fake_api):
    show = Show(fake_api, 24)
    assert run(setup, show)[0]
    show.parents[guid(13)], show.parents[guid(14)] = guid(2), guid(1)
    assert not run(setup, show)[0]
    assert not show.writes


def test_saved_opaque_copy_cannot_be_adopted_as_an_original(setup, fake_api):
    show = Show(fake_api, 24, opaque=True)
    assert run(setup, show)[0]
    show.order[0], show.order[12] = show.order[12], show.order[0]
    assert not run(setup, show)[0]
    assert not show.writes
