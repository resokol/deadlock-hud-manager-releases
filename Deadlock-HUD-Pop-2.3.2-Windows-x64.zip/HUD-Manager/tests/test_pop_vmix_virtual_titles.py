from urllib.parse import urlsplit
from xml.etree import ElementTree as ET

from observer_assist.pov_match_data import RemoteMatch
from observer_assist.pop_remote_bank import AttachedBank
from test_pov_manager import NativeMixer, pov
from test_vmix_control import app, fake_api, wait_for


def test_decorated_vmix_titles_allow_preparation_match_and_second_desk(pov, fake_api):
    mixer = NativeMixer(fake_api, 7500)
    def decorated(path):
        status, headers, data = mixer.answer(path)
        if not urlsplit(path).query:
            xml = ET.fromstring(data)
            for entry in xml.findall('./inputs/input'):
                if entry.get('type') == 'Virtual':
                    entry.set('title', 'Virtual - ' + entry.get('title'))
            data = ET.tostring(xml)
        return status, headers, data
    fake_api.answer = decorated
    vdo = pov.vdo_panel
    vdo.vmix_host.setText('127.0.0.1')
    vdo.vmix_port.setValue(mixer.port)
    pov.vdo_import.open_url = lambda _: True
    vdo.url.setText('https://vdo.ninja/?director=test')
    vdo.connect_button.click()
    pov.vdo_import._accept(pov.vdo_import.generation, [dict(streamID='one', label='irezumi', video='live')])
    wait_for(lambda: pov.prematch.ready)
    names = ('mazaG', 'MikaelS', '❄', 'TheHeavy™', 'Deaf Blind Mute', 'Joker', 'Бибизяный',
             '33', 'yasinzeinab', 'SoulLink', 'fargareko', 'Sla1ke s0 v les')
    pov.mode.setCurrentIndex(pov.mode.findData('remote'))
    pov.remote.snapshot = RemoteMatch('143142541', names, None, None)
    pov.remote.changed.emit(pov.remote.snapshot)
    wait_for(lambda: pov._fixed and pov.native.ready)
    assert [mixer.titles[g] for g in mixer.order[:12]] == list(names)
    assert [mixer.titles[g] for g in mixer.order[12:24]] == [name + ' - Virtual' for name in names]
    client = AttachedBank(pov, settings=pov.settings)
    try:
        client.start(('127.0.0.1', mixer.port))
        wait_for(lambda: client.ready)
        assert client.route(1)['title'] == 'mazaG' and not mixer.writes('ActiveInput')
    finally:
        client.cancel()


def test_rollback_restores_exact_decorated_titles_after_a_later_write_fails(app, fake_api):
    from observer_assist.camera_native_sync import NativePairSync
    from test_camera_native_sync import NativePreset, finished

    preset = NativePreset()
    original_xml = preset.xml
    def wrapped_xml():
        xml = ET.fromstring(original_xml())
        for entry in xml.findall('./inputs/input'):
            if entry.get('virtual') == 'True':
                entry.set('title', 'Virtual - ' + entry.get('title'))
        return ET.tostring(xml)

    fake_api.answer = preset.answer
    preset.xml = wrapped_xml
    preset.reject = ('SetInputName', preset.pairs[1].original_guid)
    before = wrapped_xml()
    sync = NativePairSync()
    endpoint = '127.0.0.1', fake_api.server_port
    try:
        assert sync.start(endpoint, preset.preset, preset.pairs)
        finished(sync)
        assert not sync.ready and not sync.has_recovery(endpoint, preset.preset)
        assert before == wrapped_xml()
    finally:
        sync.cancel()


def test_confirmed_order_shows_failed_vmix_input_in_match_tab(pov, fake_api):
    mixer = NativeMixer(fake_api, 8100)
    def reject_copy(path):
        from urllib.parse import parse_qs
        q = parse_qs(urlsplit(path).query)
        if q.get('Function') == ['SetInputName'] and q.get('Input') == [mixer.keys[13]]:
            return 500, {}, b''
        return mixer.answer(path)
    fake_api.answer = reject_copy
    panel = pov.vdo_panel
    panel.vmix_host.setText('127.0.0.1')
    panel.vmix_port.setValue(mixer.port)
    pov.vdo_import.open_url = lambda _: True
    panel.url.setText('https://vdo.ninja/?director=test')
    panel.connect_button.click()
    pov.vdo_import._accept(pov.vdo_import.generation, [dict(streamID='one', label='mazaG', video='live')])
    pov.mode.setCurrentIndex(pov.mode.findData('remote'))
    names = ('mazaG',) + tuple(f'Player{i}' for i in range(2, 13))
    pov.remote.snapshot = RemoteMatch('143142541', names, None, None)
    pov.remote.changed.emit(pov.remote.snapshot)
    wait_for(lambda: 'не подтвердил переименование входа 13' in pov.sync_hint.text())
    assert not pov.native.ready and not mixer.writes('ActiveInput')
