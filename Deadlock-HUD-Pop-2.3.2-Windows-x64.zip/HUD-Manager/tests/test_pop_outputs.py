import json
from urllib.parse import parse_qs, urlsplit

from PySide6.QtCore import QCoreApplication, QEvent, QSettings
from PySide6.QtWidgets import QApplication

from observer_assist.pop_outputs import OUTPUTS_KEY, OutputMixPanel
from observer_assist.pov_match_data import RemoteMatch
from test_camera_workflow import MATCH
from test_pov_manager import NativeMixer, pov
from test_vmix_control import app, fake_api, wait_for


def test_migrate_persist_and_reject_duplicate_mix(app, tmp_path):
    settings = QSettings(str(tmp_path / 'rows.ini'), QSettings.Format.IniFormat)
    settings.setValue('popLiveMix', 4)
    settings.setValue('popLiveEnabled', True)
    settings.setValue('popLiveFollow', True)
    settings.setValue('popReplayEnabled', False)
    panel = OutputMixPanel(settings)
    try:
        first, second = panel.rows
        assert first.config() == dict(mix=4, bank='live', enabled=True, follow=True)
        assert second.config() == dict(mix=2, bank='replay', enabled=False, follow=False)
        panel.add.click()
        third = panel.rows[-1]
        third.mix.setValue(4)
        assert third.number == third.mix.value() == 1 and 'уже добавлен' in panel.hint.text()
        third.bank.setCurrentIndex(third.bank.findData('replay'))
        second.remove_requested.emit()
        saved = json.loads(settings.value(OUTPUTS_KEY))
        assert saved == [first.config(), third.config()]
        restored = OutputMixPanel(settings)
        assert [row.config() for row in restored.rows] == saved
        for row in list(restored.rows):
            row.remove_requested.emit()
        assert json.loads(settings.value(OUTPUTS_KEY)) == []
        restored.deleteLater()
    finally:
        panel.deleteLater()
        QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)


def room(pov, mixer, names):
    for row in pov.outputs.rows:
        assert not row.enabled.isChecked()
        row.enabled.setChecked(True)
    panel = pov.vdo_panel
    panel.vmix_host.setText('127.0.0.1')
    panel.vmix_port.setValue(mixer.port)
    pov.vdo_import.open_url = lambda _: True
    panel.url.setText('https://vdo.ninja/?director=room')
    panel.connect_button.click()
    pov.vdo_import._accept(pov.vdo_import.generation, [
        dict(streamID=f'cam-{i}', label=name, video='live') for i, name in enumerate(names)])
    wait_for(lambda: pov.room_routes.ready and pov.outputs.rows[0].buttons[0].isEnabled())


def test_four_physical_outputs_before_match_manual_and_direct_companion(pov, fake_api):
    mixer = NativeMixer(fake_api, 7400)
    mixer.active_guids.update({3: mixer.keys[25], 5: mixer.keys[25]})
    # Room preparation aligns physical originals and copies before any player selection.
    mixer.order[12], mixer.order[13] = mixer.order[13], mixer.order[12]
    room(pov, mixer, ('A1', 'A2', 'A3', 'A4'))
    assert not pov.match_id and not pov._fixed
    pov.outputs.add.click()
    pov.outputs.add.click()
    live, replay, other_live, other_replay = pov.outputs.rows
    other_replay.bank.setCurrentIndex(other_replay.bank.findData('replay'))
    other_live.enabled.setChecked(True)
    other_replay.enabled.setChecked(True)
    assert [r.number for r in pov.outputs.rows] == [1, 2, 3, 5]
    assert '№ 13 · A1' in replay.buttons[0].text()
    assert not mixer.writes('ActiveInput')
    live.buttons[0].click()
    replay.buttons[1].click()
    other_live.buttons[2].click()
    other_replay.buttons[3].click()
    targets = {1: mixer.keys[1], 2: mixer.keys[14], 3: mixer.keys[3], 5: mixer.keys[16]}
    wait_for(lambda: mixer.active_guids == targets and not pov.room_routes.busy)
    for index, row in enumerate(pov.outputs.rows):
        assert row.buttons[index].property('onProgram')
    assert len(mixer.writes('ActiveInput')) == 4
    live.bank.setCurrentIndex(live.bank.findData('replay'))
    replay.enabled.setChecked(False)
    other_live.follow.setChecked(True)
    assert mixer.active_guids == targets
    live.buttons[0].click()
    wait_for(lambda: mixer.active_guids[1] == mixer.keys[13] and not pov.room_routes.busy)
    assert mixer.active_guids == targets | {1: mixer.keys[13]}
    assert pov.companion.payload['camera_slots']['1']['replay_mix'] == 1
    pov.companion.direct_mix.setCurrentIndex(pov.companion.direct_mix.findData(5))
    pov.companion.direct_position.setValue(12)
    pov.companion.direct_copy.click()
    url = urlsplit(QApplication.clipboard().text())
    assert url.port == mixer.port
    assert parse_qs(url.query) == dict(Function=['ActiveInput'], Input=['24'], Mix=['4'])
    pov.companion.direct_mix.setCurrentIndex(pov.companion.direct_mix.findData(3))
    pov.companion.direct_copy.click()
    assert parse_qs(urlsplit(QApplication.clipboard().text()).query) == dict(
        Function=['ActiveInput'], Input=['12'], Mix=['2'])
    assert len(mixer.writes('ActiveInput')) == 5


def test_follow_updates_independent_mixes_and_keeps_manual_mix(pov, fake_api):
    mixer = NativeMixer(fake_api, 8500)
    mixer.active_guids[3] = mixer.keys[25]
    names = tuple(f'Guest{i:02}' for i in range(1, 13))
    room(pov, mixer, names)
    pov.mode.setCurrentIndex(pov.mode.findData('remote'))

    def observe(slot):
        packet = RemoteMatch(MATCH, names, slot, None)
        pov.remote.snapshot = packet
        pov.remote.changed.emit(packet)

    observe(1)
    pov.sync_button.click()
    wait_for(lambda: pov.native.ready and pov._fixed)
    pov.outputs.add.click()
    live, replay, manual = pov.outputs.rows
    manual.enabled.setChecked(True)
    live.follow.setChecked(True)
    replay.follow.setChecked(True)
    manual.buttons[10].click()
    wait_for(lambda: mixer.active_guids[3] == mixer.keys[11] and not pov.native.busy)
    for number in (2, 7, 5, 12):
        observe(number)
        wait_for(lambda: mixer.active_guids == {1: mixer.keys[number], 2: mixer.keys[12+number],
                                                 3: mixer.keys[11]} and not pov.native.busy)
    observe(6)
    observe(9)
    wait_for(lambda: mixer.active_guids == {1: mixer.keys[9], 2: mixer.keys[21], 3: mixer.keys[11]}
             and not pov.native.busy)
    replay.follow.setChecked(False)
    observe(4)
    wait_for(lambda: mixer.active_guids[1] == mixer.keys[4] and not pov.native.busy)
    assert mixer.active_guids[2] == mixer.keys[21] and mixer.active_guids[3] == mixer.keys[11]
