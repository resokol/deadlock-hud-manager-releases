"""Camera process works before Deadlock starts and accepts either match data source."""
from urllib.request import urlopen
import json

import pytest
from PySide6.QtCore import QCoreApplication, QEvent, QSettings

from observer_assist.pov_manager import PovManager
from test_camera_workflow import MATCH, Mixer, snapshot
from test_vmix_control import app, fake_api, wait_for


@pytest.fixture
def pov(app, tmp_path):
    settings = QSettings(str(tmp_path / 'pov.ini'), QSettings.Format.IniFormat)
    window = PovManager(settings)
    window.mode.setCurrentIndex(window.mode.findData("match"))
    try:
        yield window
    finally:
        window.close()
        window.deleteLater()
        QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)


def test_source_switch_clears_all_old_slots_and_exposes_confirmed_remote_order(pov, fake_api):
    panel = pov.vdo_panel
    names = [f'Player {i}' for i in range(1, 13)]
    snapshot(pov, names)
    assert pov.names == tuple(names)
    assert not pov.camera_roster.slots  # SourceTV estimates require confirmation for account-based routing.
    assert 'SourceTV' in panel.positions.hint.text()
    pov.camera_roster.apply.click()
    assert pov.camera_roster.slots[1] == '501'
    assert 'Ручной порядок' in panel.positions.hint.text()
    pov.mode.setCurrentIndex(1)
    assert not pov.names and not pov.camera_roster.slots
    assert pov.companion.payload['pov_inputs'] == {}

    slots = {str(i): name for i, name in enumerate(reversed(names), 1)}
    remote = dict(version=1, status='live', panorama_match_id='999',
                  panorama_slots=slots, panorama_observed_slot=3)
    fake_api.answer = lambda _: (200, {}, json.dumps(remote).encode())
    pov.remote_url.setText(f'http://127.0.0.1:{fake_api.server_port}/api/v1/stats?token=test')
    pov._connect_remote()
    wait_for(lambda: pov.names == tuple(reversed(names)))
    assert pov.companion.payload['hud_slots'] == slots
    assert pov.companion.payload['hud_observed_slot'] == 3
    assert pov.companion.payload['camera_slots']['1']['account_id'] == ''
    pov.mode.setCurrentIndex(0)
    assert not pov.names and not pov.remote.snapshot


def test_pov_room_can_apply_before_match_and_companion_uses_own_port(pov, fake_api):
    vmix = NativeMixer(fake_api, 1200, lineage=False)
    panel = pov.vdo_panel
    pov.vdo_import.open_url = lambda _: True
    panel.url.setText('https://vdo.ninja/?director=room')
    panel.vmix_host.setText('127.0.0.1')
    panel.vmix_port.setValue(vmix.port)
    panel.connect_button.click()
    pov.vdo_import._accept(pov.vdo_import.generation, [dict(streamID='cam-player', label='Player One', video='live')])
    wait_for(lambda: pov.prematch.ready and bool(vmix.writes('BrowserNavigate')))
    assert vmix.titles[vmix.keys[1]] == 'Player One'
    assert vmix.titles[vmix.keys[13]] == 'Player One - Virtual'
    assert pov.bindings.mapping()[vmix.keys[1]] == vmix.keys[13]
    assert not vmix.writes('MoveInput') and not vmix.writes('CreateVirtualInput')
    assert not pov.names and not pov.source_tv.roster
    assert pov.companion.port.value() == 53559
    pov.companion.network.setCurrentIndex(pov.companion.network.findData('127.0.0.1/8'))
    pov.companion.share.setChecked(True)
    server = pov.companion.server
    assert server is not None
    with urlopen(server.url, timeout=2) as response:
        assert json.load(response)['status'] == 'waiting'
    snapshot(pov, [f'Player {i}' for i in range(1, 13)])
    assert not panel.preparation.inputs and not panel.positions.inputs
    assert panel.positions.input_numbers == tuple(range(1, 13))
    with urlopen(server.url, timeout=2) as response:
        data = json.load(response)
    assert data['hud_slots']['2'] == 'Player 2'
    assert data['pov_inputs']['1'] == 'Player One'
    assert data['replay_inputs']['1'] == 13
    assert 'cam-player' not in json.dumps(data)
    assert not hasattr(pov, 'hud_library') and not hasattr(pov, '_telemetry')


def test_remote_observer_drives_live_and_companion_drives_replay(pov, fake_api, monkeypatch):
    from urllib.request import Request
    from observer_assist import camera_vmix
    from observer_assist.pov_match_data import RemoteMatch
    from test_camera_workflow import configure

    monkeypatch.setattr(camera_vmix, 'POLL_MS', 60)
    mixer = Mixer(fake_api, 1500)
    names = [f'Player {i}' for i in range(1, 13)]
    src = [dict(side=side, players=[dict(name=names[i], accountId=str(100 + i)) for i in indices])
           for side, indices in [(2, range(6)), (3, range(6, 12))]]
    before = pov.cameras.preparation_rows()
    draft = list(before)
    for i in range(2):
        draft[i] = (str(100 + i), names[i], f'https://vdo.ninja/?view=test{i}')
    pov.cameras.save_preparation(before, draft)
    configure(pov, 'live', mixer)
    configure(pov, 'replay', mixer)
    pov.mode.setCurrentIndex(1)
    pov.remote.snapshot = RemoteMatch(MATCH, tuple(names), 2, dict(matchId=MATCH, teams=src))
    pov.remote.changed.emit(pov.remote.snapshot)
    wait_for(lambda: mixer.active[1] == 2 and pov.companion.payload['camera_slots']['1']['replay_ready'])
    pov.companion.network.setCurrentIndex(pov.companion.network.findData('127.0.0.1/8'))
    pov.companion.share.setChecked(True)
    server = pov.companion.server
    with urlopen(Request(server.program_url(1), method='POST'), timeout=2) as response:
        assert response.status == 202
    wait_for(lambda: mixer.active[2] == 3)
    assert mixer.active[1] == 2 and 'test0' not in json.dumps(pov.companion.payload)


class NativeMixer(Mixer):
    """vMix XML numbers change with MoveInput; Program and sources stay bound to GUIDs."""
    def __init__(self, server, offset, *, lineage=True):
        super().__init__(server, offset, pairs=12)
        self.order = list(self.keys.values())
        self.lineage = lineage
        self.titles = {guid: f'Input {i}' for i, guid in self.keys.items()}
        self.active_guids = {1: self.keys[25], 2: self.keys[25]}

    def answer(self, path):
        from urllib.parse import parse_qsl, urlsplit
        from xml.etree import ElementTree as ET
        command = dict(parse_qsl(urlsplit(path).query))
        if command:
            guid = command['Input']
            self.commands.append(command)
            if command['Function'] == 'MoveInput':
                self.order.remove(guid)
                self.order.insert(int(command['Value']) - 1, guid)
            if command['Function'] == 'SetInputName':
                self.titles[guid] = command['Value']
            elif command['Function'] == 'ActiveInput':
                self.active_guids[int(command['Mix'])+1] = guid
            return 200, {}, b''
        root = ET.Element('vmix')
        ET.SubElement(root, 'preset').text = 'Show'
        inputs = ET.SubElement(root, 'inputs')
        for i, guid in enumerate(self.order, 1):
            original = next(n for n, g in self.keys.items() if g == guid)
            kind = 'Browser' if original <= 12 else 'Virtual' if original <= 24 else 'Colour'
            attrs = dict(type=kind, key=guid, number=str(i), title=self.titles[guid])
            if self.lineage and kind == 'Virtual':
                attrs['originalKey'] = self.keys[original-12]
            entry = ET.SubElement(inputs, 'input', attrs)
            ET.SubElement(entry, 'position', zoomX='1.5' if kind == 'Browser' else '1', zoomY='1',
                          panX='0', panY='0', cropX1='0', cropX2='1', cropY1='0', cropY2='1')
        ET.SubElement(root, 'active').text = str(self.order.index(self.active_guids[1])+1)
        for number, guid in self.active_guids.items():
            if number != 1:
                ET.SubElement(ET.SubElement(root, 'mix', number=str(number)), 'active').text = str(self.order.index(guid)+1)
        ET.SubElement(ET.SubElement(root, 'outputs'), 'output', type='Output', number='2', source='Mix', mix='1')
        return 200, {}, ET.tostring(root)


@pytest.mark.parametrize('live', (0, 11))
def test_preparation_keeps_verified_12_originals_with_unknown_video(pov, fake_api, live):
    vmix = NativeMixer(fake_api, 3600)
    panel = pov.vdo_panel
    pov.vdo_import.open_url = lambda _: True
    panel.url.setText('https://vdo.ninja/?director=room')
    panel.connect_button.click()
    guests = [dict(streamID=f'cam-{i}', label=f'P{i:02}', video='live' if i < live else 'unknown')
              for i in range(12)]
    pov.vdo_import._accept(pov.vdo_import.generation, guests)
    panel.vmix_host.setText('127.0.0.1')
    panel.vmix_port.setValue(vmix.port)
    wait_for(lambda: pov.prematch.ready)
    wait_for(lambda: len(vmix.writes('BrowserNavigate')) == live)
    assert len(panel.prepared_originals) == 12 and pov.bindings.confirmed
    assert len(vmix.writes('BrowserNavigate')) == live
    assert not vmix.writes('MoveInput') and not vmix.writes('ActiveInput')


def test_sync_automatically_moves_native_pairs_when_source_order_is_confirmed(pov, fake_api, monkeypatch):
    from test_vmix_control import process_events
    from urllib.request import Request

    vmix = NativeMixer(fake_api, 5300)
    panel = pov.vdo_panel
    names = [f'P{i:02d}' for i in range(1, 13)]
    pov.vdo_import.open_url = lambda _: True
    panel.url.setText('https://vdo.ninja/?director=room')
    panel.connect_button.click()
    guests = [dict(streamID=f'cam-{name}', label=name, video='live') for name in names]
    pov.vdo_import._accept(pov.vdo_import.generation, guests)
    panel.vmix_host.setText('127.0.0.1')
    panel.vmix_port.setValue(vmix.port)
    wait_for(lambda: pov.prematch.ready and len(vmix.writes("BrowserNavigate")) == 12)
    assert pov.bindings.confirmed
    assert [vmix.titles[vmix.keys[i]] for i in range(1, 13)] == names
    pov.main_tabs.setCurrentIndex(1)

    def start(match):
        pov.source_tv._match_id = match
        pov.source_tv._clear_players()
    monkeypatch.setattr(pov.source_tv, '_start', start)
    pov.source_tv.url.setText(MATCH)
    pov.source_tv.connect_button.click()
    match_names = names[4:] + names[:4]
    snapshot(pov, match_names)
    before = list(vmix.commands)
    assert pov.main_tabs.currentIndex() == 1 and not pov.sync_button.isEnabled()
    process_events(100)
    assert vmix.commands == before
    pov.camera_roster.apply.click()
    wait_for(lambda: pov.native.ready)
    origins = [vmix.keys[names.index(name) + 1] for name in match_names]
    copies = [vmix.keys[names.index(name) + 13] for name in match_names]
    assert vmix.order[:24] == origins + copies
    assert [vmix.titles[g] for g in origins] == match_names
    assert [vmix.titles[g] for g in copies] == [name + ' - Virtual' for name in match_names]
    assert not vmix.writes('ActiveInput')
    assert len(vmix.writes('BrowserNavigate')) == 12
    assert pov.companion.payload['camera_slots']['1']['replay_guid'] == vmix.keys[17]
    assert pov.companion.payload['replay_inputs']['1'] == 13
    pov.main_tabs.setCurrentIndex(2)
    pov.outputs.rows[1].enabled.setChecked(True)
    pov.outputs.rows[1].buttons[0].click()
    wait_for(lambda: vmix.active_guids[2] == vmix.keys[17] and not pov.native.busy)
    assert vmix.active_guids[1] == vmix.keys[25]
    pov.companion.network.setCurrentIndex(pov.companion.network.findData('127.0.0.1/8'))
    pov.companion.share.setChecked(True)
    with urlopen(Request(pov.companion.server.program_url(2), method='POST'), timeout=2) as reply:
        assert reply.status == 202
    wait_for(lambda: vmix.active_guids[2] == vmix.keys[18])
    # An updated draft and loss of its source must never reorder the confirmed physical bank.
    confirmed_order = list(vmix.order)
    snapshot(pov, names[::-1])
    pov.camera_roster.reset.click()
    process_events(50)
    assert vmix.order == confirmed_order and pov.companion.payload['hud_slots']['1'] == match_names[0]
    pov.source_tv.stop()
    assert pov.companion.payload['replay_inputs']['1'] == 13
    assert pov.outputs.rows[1].buttons[0].isEnabled()
    assert 'Сохранена раскладка' in pov.sync_hint.text()
    for live_enabled in (True, False):
        for replay_enabled in (True, False):
            pov.outputs.rows[0].enabled.setChecked(live_enabled)
            pov.outputs.rows[1].enabled.setChecked(replay_enabled)
            assert pov.outputs.rows[0].buttons[1].isEnabled() == live_enabled
            assert pov.outputs.rows[1].buttons[1].isEnabled() == replay_enabled
    pov.outputs.rows[0].enabled.setChecked(True)
    pov.outputs.rows[0].buttons[0].click()
    wait_for(lambda: vmix.active_guids[1] == origins[0] and not pov.native.busy)
    assert vmix.active_guids[2] == copies[1]
    assert len(vmix.writes('BrowserNavigate')) == 12


def test_legacy_reverse_choice_does_not_change_match_positions(app, tmp_path):
    names = ['kapten', 'balaclava', 'zxcbobi', 'rey', 'oses', 'Tas',
             'cantsaymeow', 'arzo', 'pom', 'IREZUMI', 'saintmxsm', 'lorence']
    settings = QSettings(str(tmp_path / 'migration.ini'), QSettings.Format.IniFormat)
    settings.setValue('povPositionsFromRight', True)
    pov = PovManager(settings)
    try:
        pov.mode.setCurrentIndex(pov.mode.findData('match'))
        snapshot(pov, names)
        assert list(pov.names) == names
        for i, nick in enumerate(names, 1):
            row = pov.companion.payload['camera_slots'][str(i)]
            assert row['name'] == nick and row['key'] == '1234567890-='[i-1]
            assert pov.preview.item(i-1, 0).text() == f"{i} / {row['key']}"
    finally:
        pov.close()


def test_restart_recovers_verified_layout_and_follow_uses_locked_identity(pov, fake_api):
    from observer_assist.pov_match_data import RemoteMatch
    from test_vmix_control import process_events

    mixer = NativeMixer(fake_api, 8100)
    panel = pov.vdo_panel
    panel.vmix_host.setText('127.0.0.1')
    panel.vmix_port.setValue(mixer.port)
    pov.vdo_import.open_url = lambda _: True
    panel.url.setText('https://vdo.ninja/?director=room')
    panel.connect_button.click()
    names = tuple(f'Guest{i:02}' for i in range(1, 13))
    guests = [dict(streamID=f'cam-{i}', label=n, video='live') for i,n in enumerate(names)]
    pov.vdo_import._accept(pov.vdo_import.generation, guests)
    wait_for(lambda: pov.prematch.ready and len(mixer.writes('BrowserNavigate')) == 12)
    pov.mode.setCurrentIndex(pov.mode.findData('remote'))
    def observe(window, order, index):
        packet = RemoteMatch(MATCH, order, index, None)
        window.remote.snapshot = packet
        window.remote.changed.emit(packet)
    observe(pov, names, 1)
    wait_for(lambda: pov.native.ready and pov._fixed)
    assert pov.companion.payload['replay_inputs']['12'] == 24
    for row in pov.outputs.rows:
        row.enabled.setChecked(True)
    pov.close()
    before = mixer.commands[:]
    restored = PovManager(pov.settings)
    restored.vdo_import.open_url = lambda _: True
    try:
        wait_for(lambda: restored.native.ready and restored.outputs.rows[1].buttons[0].isEnabled())
        assert restored.names == () and restored.companion.payload['hud_slots']['12'] == names[-1]
        assert not restored.room_monitor.isChecked() or not restored.vdo_import.fresh
        assert mixer.commands == before  # Read-only verify; no game or room connection needed.
        restored.outputs.rows[0].follow.setChecked(True)
        order = names[::-1]
        observe(restored, order, 2)
        process_events(50)
        assert mixer.commands == before
        observe(restored, order, 1)  # Last original in the locked order, first on the new HUD.
        wait_for(lambda: mixer.active_guids[1] == mixer.keys[12])
        assert mixer.active_guids[2] == mixer.keys[25]
        assert len(mixer.writes('ActiveInput')) == 1
        assert 'другой состав или порядок' in restored.sync_hint.text()
        restored.outputs.rows[0].enabled.setChecked(False)
        observe(restored, order, 3)
        process_events(50)
        assert len(mixer.writes('ActiveInput')) == 1
        restored.room_monitor.setChecked(False)
        assert restored.outputs.rows[1].buttons[5].isEnabled()
    finally:
        restored.close()


def test_manual_game_camera_match_uses_account_id_guid_and_never_assigns_twice():
    from observer_assist.camera_originals import CameraOriginal
    from observer_assist.pop_match_mapping import camera_matches

    originals = tuple(CameraOriginal(i+1, f'Camera{i+1}', f'guid-{i}', i+1, 'live', '') for i in range(12))
    names = ['renamed'] + [f'CaMeRa{i}' for i in range(2, 13)]
    assert camera_matches(names, {1:'80'}, originals, (), {})[0].guid == 'guid-0'
    rows = camera_matches(names, {1:'80'}, originals, (), {'id.80': 'guid-0'})
    assert rows[0].name == 'renamed' and rows[0].guid == 'guid-0'
    assert len({r.guid for r in rows}) == 12
    assert not camera_matches(names, {1:'80'}, originals, (), {'id.80': 'guid-1'})
