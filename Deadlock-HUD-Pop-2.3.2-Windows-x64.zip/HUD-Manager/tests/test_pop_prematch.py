"""Prematch discovery may write only the twelve proved physical camera pairs."""

from urllib.parse import parse_qs, urlsplit
from unittest.mock import Mock
from weakref import ref
from xml.etree import ElementTree

import pytest
from PySide6.QtCore import QCoreApplication, QEvent, QSettings
from PySide6.QtWidgets import QWidget

from observer_assist.camera_native_monitor import NativeCameraMonitor
from observer_assist.camera_native_pairs_panel import NativePairBindings
from observer_assist.camera_vdo import VdoImport
from observer_assist.camera_vdo_panel import VdoRoomPanel
from observer_assist.camera_vdo_publish import VdoVmixPublisher
from observer_assist.pop_prematch import NativePrematch
from test_pov_manager import NativeMixer
from test_vmix_control import app, fake_api, process_events, wait_for


class AlphaMixer(NativeMixer):
    def __init__(self, server, *, lineage=True):
        super().__init__(server, 16000, lineage=lineage)
        self.opacity = {g: 178 if i <= 12 else 213 for i, g in self.keys.items()}
        self.wrong_type = False
        self.generated_titles = False

    def answer(self, path):
        query = parse_qs(urlsplit(path).query)
        if query.get('Function') == ['CreateVirtualInput']:
            source = self.order.index(query['Input'][0])
            copy = self.keys[source + 13]
            assert copy not in self.order
            self.order.append(copy)
        code, headers, data = super().answer(path)
        if query:
            if query.get('Function') == ['SetAlpha']:
                self.opacity[query['Input'][0]] = int(query['Value'][0])
            if self.generated_titles and query.get('Function') == ['BrowserNavigate']:
                self.titles[query['Input'][0]] = 'Browser'
        else:
            xml = ElementTree.fromstring(data)
            for item in xml.findall('./inputs/input'):
                item.set('alpha', str(self.opacity[item.get('key')]))
                if not self.lineage and item.get('type') == 'Virtual':
                    item.set('type', 'Browser')
                if self.wrong_type and item.get('number') == '1':
                    item.set('type', 'Video')
            data = ElementTree.tostring(xml)
        return code, headers, data


@pytest.fixture
def setup(app, tmp_path, fake_api):
    mixer = AlphaMixer(fake_api)
    settings = QSettings(str(tmp_path / 'studio.ini'), QSettings.Format.IniFormat)
    owner = QWidget()
    panel = VdoRoomPanel(settings, owner)
    for page in panel.enable_workflow():
        page.setParent(owner)
    panel.use_native_inputs()
    panel.vmix_port.setValue(mixer.port)
    room = VdoImport(panel, Mock(), owner, bridge_factory=Mock(return_value=Mock(url='http://127.0.0.1:1/')),
                     open_url=lambda url: True)
    room.freshness_changed.connect(panel.set_room_fresh)
    bindings = NativePairBindings(settings, owner)
    pub = VdoVmixPublisher(owner)
    monitor = NativeCameraMonitor(pub, owner, settings=settings)
    prematch = NativePrematch(panel, room, bindings, pub, owner, monitor=monitor)
    panel.url.setText('https://vdo.ninja/?director=Broadcast')
    panel.connect_button.click()
    yield mixer, panel, room, bindings, prematch, monitor
    prematch.stop()
    room.stop()
    bindings.http.cancel()
    process_events(15)
    owner.deleteLater()
    QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)


def guest(name, video='live'):
    return dict(label=name, streamID='webcam-' + name, video=video)


def test_late_arrival_dropout_reentry_and_suspension_keep_owned_stream(setup):
    mixer, panel, room, bindings, prematch, monitor = setup
    a, b = guest('Alpha'), guest('Bravo')
    accept = lambda guests: room._accept(room.generation, guests)
    accept([a])
    first, copy = mixer.keys[1], mixer.keys[13]
    wait_for(lambda: prematch.ready and any(c['Input'] == first for c in mixer.writes('BrowserNavigate')))
    assert mixer.titles[first] == 'Alpha' and mixer.titles[copy] == 'Alpha - Virtual'
    assert all(c['Input'] in set(mixer.keys[i] for i in range(1,13)) for c in mixer.writes('BrowserNavigate'))
    accept([b, a])
    wait_for(lambda: prematch.ready and any(c['Input'] == mixer.keys[2] for c in mixer.writes('BrowserNavigate')))
    assert mixer.titles[mixer.keys[14]] == 'Bravo - Virtual'
    desired = dict(a, video='absent')
    accept([desired, b])
    wait_for(lambda: mixer.opacity[first] == mixer.opacity[copy] == 0)
    count = len(mixer.writes('BrowserNavigate'))
    accept([b, a])
    wait_for(lambda: mixer.opacity[first] == 178 and mixer.opacity[copy] == 213)
    assert count == len(mixer.writes('BrowserNavigate'))
    assert mixer.titles[first] == 'Alpha' and mixer.titles[copy] == 'Alpha - Virtual'
    wait_for(lambda: all(mixer.opacity[mixer.keys[n]] == 0 for n in (*range(3,13), *range(15,25)))
             and mixer.opacity[mixer.keys[2]] == 178 and mixer.opacity[mixer.keys[14]] == 213)
    before = mixer.commands.copy()
    accept([a, b])
    process_events(100)
    assert mixer.commands == before
    prematch.set_suspended(True)
    accept([a, b, guest('Charlie')])
    process_events(110)
    assert not prematch.ready and not monitor.active and mixer.commands == before
    assert not mixer.writes('ActiveInput') and not mixer.writes('MoveInput')


def test_wrong_original_blocks_writes_then_opaque_fixed_bank_works_without_controls(setup):
    mixer, panel, room, bindings, prematch, monitor = setup
    mixer.wrong_type = True
    room._accept(room.generation, [guest('Alpha')])
    wait_for(lambda: 'оригинал' in prematch.message.casefold())
    assert not mixer.commands

    mixer.wrong_type, mixer.lineage = False, False
    prematch.refresh()
    wait_for(lambda: prematch.ready and bool(mixer.writes('BrowserNavigate')))
    assert bindings.confirmed and bindings.mapping()[mixer.keys[1]] == mixer.keys[13]
    assert not mixer.writes('MoveInput') and not mixer.writes('CreateVirtualInput')


def test_generated_browser_title_is_repaired_without_reopening_viewer(setup):
    mixer, _, room, _, prematch, _ = setup
    mixer.generated_titles = True
    owner, permitted = ref(prematch), []
    def check_pending_ack():
        current = owner()
        if current and current.monitor.active and 'Обновляем названия' in current.message:
            permitted.append(current._monitor_valid())
    prematch.changed.connect(check_pending_ack)
    room._accept(room.generation, [guest('Alpha'), guest('Bravo')])
    wait_for(lambda: prematch.ready and len(mixer.writes('BrowserNavigate')) >= 2
             and [mixer.titles[mixer.keys[i]] for i in (1, 2)] == ['Alpha', 'Bravo'])
    assert len(mixer.writes('BrowserNavigate')) == 2, mixer.writes('BrowserNavigate')
    assert permitted and all(permitted)
    assert [mixer.titles[mixer.keys[i]] for i in (13, 14)] == ['Alpha - Virtual', 'Bravo - Virtual']


def test_room_alias_distinguishes_equal_labels_and_keeps_the_existing_original(setup):
    mixer, panel, room, bindings, prematch, monitor = setup
    twin_a = dict(label='Twin', streamID='private-stream-a', video='live')
    twin_b = dict(label='Twin', streamID='private-stream-b', video='live')
    panel.room_guests_changed.connect(panel.update)
    room._accept(room.generation, [twin_a])
    wait_for(lambda: prematch.ready and any(c['Input'] == mixer.keys[1] for c in mixer.writes('BrowserNavigate')))
    room._accept(room.generation, [twin_b, twin_a, guest('Third')])
    wait_for(lambda: mixer.titles[mixer.keys[2]] == 'Third')
    assert all(g.issue for g in panel.room_guests if g.label == 'Twin')
    assert not panel.set_guest_alias('private-stream-b', 'Third')
    assert panel.set_guest_alias('private-stream-a', 'Original')
    wait_for(lambda: mixer.titles[mixer.keys[1]] == 'Original' and mixer.titles[mixer.keys[15]] == 'Twin - Virtual')
    rows = {r.guid: r for r in panel.prepared_originals}
    assert rows[mixer.keys[1]].name == 'Original' and 'private-stream-a' in rows[mixer.keys[1]].page
    assert rows[mixer.keys[3]].name == 'Twin' and 'private-stream-b' in rows[mixer.keys[3]].page
    assert {c['Input'] for c in mixer.writes('BrowserNavigate') if 'private-stream-a' in c['Value']} == {mixer.keys[1]}
    assert 'private-stream-a' not in panel.settings.value(panel._aliases_key)
    assert panel.room_guests[1].stream_id == 'private-stream-a'
    assert panel.guest_label('private-stream-a', 'Twin') == 'Original'
    room._accept(room.generation, [twin_a])
    current = {r.guid: r for r in panel.prepared_originals}
    assert current[mixer.keys[1]].name == 'Original'

def test_connect_provisions_missing_copy_then_publishes_pages(setup):
    mixer, _, room, bindings, prematch, _ = setup
    mixer.lineage = False
    mixer.order = mixer.order[:23]
    mixer.active_guids = {1: mixer.keys[1], 2: mixer.keys[2]}
    room._accept(room.generation, [guest('Alpha')])
    wait_for(lambda: prematch.ready and bool(mixer.writes('BrowserNavigate')))
    assert bindings.confirmed and bindings.mapping()[mixer.keys[12]] == mixer.keys[24]
    assert [command['Input'] for command in mixer.writes('CreateVirtualInput')] == [mixer.keys[12]]
    assert mixer.titles[mixer.keys[13]] == 'Alpha - Virtual'
