"""Rehearse a side swap, lost video and two independent outputs on the same Web Controller."""
from urllib.parse import parse_qsl, urlsplit
from uuid import UUID
from xml.etree import ElementTree as ET

from PySide6.QtCore import QCoreApplication, QEvent, QObject

from test_vmix_control import app, fake_api, wait_for
from observer_assist.camera_native_monitor import NativeCameraMonitor
from observer_assist.camera_native_sync import NativePair, NativePairSync
from observer_assist.camera_preparation import TRANSPARENT_PAGE, camera_page
from observer_assist.camera_vdo_publish import VdoVmixPublisher


def test_move_pairs_then_drop_and_restore_the_shared_camera(app, fake_api):
    keys = [str(UUID(int=i)) for i in range(1, 25)]
    originals, copies = keys[:12], keys[12:]
    players = [f'Player {i}' for i in range(1, 13)]
    players[0] = 'ghoul'
    names = dict(zip(keys, players + [name + ' - Virtual' for name in players]))
    pairs = [NativePair(source, copy, name) for source, copy, name in zip(originals, copies, players)]
    match_order = pairs[6:] + pairs[:6]
    numbers = list(keys)
    program = {1: originals[0], 2: copies[-1]}
    pages = {guid: camera_page('https://vdo.ninja/?view=cam' + str(i))
             for i, guid in enumerate(originals)}
    videos = {guid: ('live', 'https://vdo.ninja/?view=cam' + str(i))
              for i, guid in enumerate(originals)}
    initial_program = dict(program)
    commands = []

    def controller(path):
        command = dict(parse_qsl(urlsplit(path).query))
        if command:
            commands.append(command)
            guid = command['Input']
            function = command['Function']
            if function == 'MoveInput':
                numbers.remove(guid)
                numbers.insert(int(command['Value']) - 1, guid)
            elif function == 'ActiveInput':
                program[int(command['Mix']) + 1] = guid
            elif function == 'BrowserNavigate':
                pages[guid] = command['Value']
            else:
                return 400, {}, b'Unexpected command'
            return 200, {}, b''
        xml = ET.Element('vmix')
        ET.SubElement(xml, 'preset').text = 'Match'
        inputs = ET.SubElement(xml, 'inputs')
        for i, guid in enumerate(numbers, 1):
            source = guid in originals
            attributes = {} if source else {'originalKey': originals[copies.index(guid)]}
            entry = ET.SubElement(inputs, 'input', key=guid, number=str(i), title=names[guid],
                                  type='Browser' if source else 'Virtual', **attributes)
            ET.SubElement(entry, 'position', panX='0.4' if source else '0', panY='0',
                          zoomX='1', zoomY='1', cropX1='0.2' if source else '0',
                          cropY1='0', cropX2='1', cropY2='1')
        ET.SubElement(xml, 'active').text = str(numbers.index(program[1]) + 1)
        mix = ET.SubElement(xml, 'mix', number='2')
        ET.SubElement(mix, 'active').text = str(numbers.index(program[2]) + 1)
        outputs = ET.SubElement(xml, 'outputs')
        ET.SubElement(outputs, 'output', number='2', type='output', source='Mix', mix='2')
        return 200, {}, ET.tostring(xml)

    fake_api.answer = controller
    endpoint = ('127.0.0.1', fake_api.server_port)
    owner = QObject()
    sync = NativePairSync(owner)
    publisher = VdoVmixPublisher(owner)
    monitor = NativeCameraMonitor(publisher, owner)
    for guid, page in pages.items():
        publisher.record_page(endpoint, 'Match', guid, page)
    try:
        assert sync.start(endpoint, 'Match', match_order)
        wait_for(lambda: sync.ready)
        assert program == initial_program
        assert {cmd['Function'] for cmd in commands} == {'MoveInput'}
        assert numbers == [p.original_guid for p in match_order] + [p.virtual_guid for p in match_order]
        assert sync.route(7)['virtual_guid'] == copies[0]
        assert monitor.start(endpoint, 'Match', match_order, media=lambda: videos, validate=lambda: sync.ready)
        viewer = videos[originals[0]]
        videos[originals[0]] = ('absent', '')
        monitor.refresh()
        wait_for(lambda: pages[originals[0]] == TRANSPARENT_PAGE)
        assert program == initial_program
        assert sync.take(7, 2)
        wait_for(lambda: program[2] == copies[0])
        videos[originals[0]] = viewer
        monitor.refresh()
        wait_for(lambda: pages[originals[0]] == camera_page(viewer[1]))
        assert program == {1: originals[0], 2: copies[0]}
        assert [cmd['Input'] for cmd in commands if cmd['Function'] == 'BrowserNavigate'] == [originals[0]] * 2
        assert names[copies[0]] == 'ghoul - Virtual'
    finally:
        monitor.stop()
        sync.cancel()
        owner.deleteLater()
        QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
