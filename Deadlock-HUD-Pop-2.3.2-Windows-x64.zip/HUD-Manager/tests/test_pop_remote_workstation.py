"""Independent operator workstations control the prepared bank on a third vMix host."""
import json
from urllib.parse import parse_qs, urlsplit

from PySide6.QtCore import QCoreApplication, QEvent, QSettings
from PySide6.QtWidgets import QApplication

from observer_assist.pop_outputs import OUTPUTS_KEY
from observer_assist.pov_manager import PovManager
from observer_assist.pov_match_data import RemoteMatch
from test_pov_manager import NativeMixer
from test_vmix_control import app, fake_api, process_events, wait_for


def local_settings(tmp_path, name):
    return QSettings(str(tmp_path / (name + '.ini')), QSettings.Format.IniFormat)


def studio(server):
    mixer = NativeMixer(server, 25000)
    names = tuple(f'Camera{i:02}' for i in range(1, 13))
    for i, name in enumerate(names, 1):
        mixer.titles[mixer.keys[i]] = name
        mixer.titles[mixer.keys[12 + i]] = name + ' - Virtual'
    return mixer, names


def connect_remote(window, mixer):
    window.workstation.setCurrentIndex(1)
    assert window.attached_mode and not window.outputs.rows
    window.attach_host.setText('127.0.0.1')
    window.attach_port.setValue(mixer.port)
    window.attach_connect.click()
    wait_for(lambda: window.remote_bank.ready)
    assert window.main_tabs.currentIndex() == 2
    assert not window.main_tabs.isTabVisible(0) and not window.main_tabs.isTabVisible(1)
    assert window.tabs.isTabVisible(window._companion_index) and not window.tabs.isTabVisible(0)
    assert not window.vdo_import.room and window._fixed is None


def assign(window, mix, bank):
    window.outputs.add.click()
    row = window.outputs.rows[-1]
    assert not row.enabled.isChecked()
    row.mix.setValue(mix)
    row.bank.setCurrentIndex(row.bank.findData(bank))
    row.enabled.setChecked(True)
    return row


def dispose(window):
    window.close()
    window.deleteLater()
    QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)


def test_two_workstations_take_original_and_copy_independently_and_restore(app, tmp_path, fake_api):
    mixer, names = studio(fake_api)
    observer_settings = local_settings(tmp_path, 'observer')
    replay_settings = local_settings(tmp_path, 'replay')
    observer = PovManager(observer_settings)
    replay = PovManager(replay_settings)
    try:
        connect_remote(observer, mixer)
        connect_remote(replay, mixer)
        live = assign(observer, 1, 'live')
        copy = assign(replay, 2, 'replay')
        assert not mixer.commands
        assert names[0] in live.buttons[0].text() and names[-1] in copy.buttons[-1].text()
        assert 'Нет данных' in copy.buttons[2].text()
        live.buttons[3].click()
        copy.buttons[9].click()
        wait_for(lambda: not observer.remote_bank.busy and not replay.remote_bank.busy
                 and mixer.active_guids == {1: mixer.keys[4], 2: mixer.keys[22]})
        assert [cmd['Function'] for cmd in mixer.commands] == ['ActiveInput', 'ActiveInput']
        assert {cmd['Mix'] for cmd in mixer.commands} == {'0', '1'}
        assert replay.companion.payload['camera_slots']['10']['replay_guid'] == mixer.keys[22]
        replay.companion.direct_position.setValue(10)
        replay.companion.direct_copy.click()
        url = urlsplit(QApplication.clipboard().text())
        assert url.port == mixer.port and parse_qs(url.query) == dict(Function=['ActiveInput'], Input=['22'], Mix=['1'])
        observer.attach_stop.click()
        assert not live.buttons[0].isEnabled() and replay.outputs.rows[0].buttons[0].isEnabled()
        assert not observer.remote_bank.ready and not observer_settings.value('popAttachedRunning', True, type=bool)
        # A closed workstation returns to its enabled Mix without issuing any take.
        dispose(replay)
        replay = PovManager(replay_settings)
        wait_for(lambda: replay.remote_bank.ready)
        assert [r.config() for r in replay.outputs.rows] == [dict(mix=2, bank='replay', enabled=True, follow=False)]
        assert not replay.vdo_import.room and replay._fixed is None
        assert len(mixer.commands) == 2
        replay.outputs.rows[0].buttons[0].click()
        wait_for(lambda: mixer.active_guids == {1: mixer.keys[4], 2: mixer.keys[13]} and not replay.remote_bank.busy)
        assert all(cmd['Function'] == 'ActiveInput' for cmd in mixer.commands)
    finally:
        dispose(observer)
        dispose(replay)


def test_client_starts_with_legacy_owner_settings_and_never_runs_preparation(app, tmp_path, fake_api):
    mixer, names = studio(fake_api)
    settings = local_settings(tmp_path, 'legacy')
    settings.setValue('popRoomRunning', True)
    settings.setValue('popAttachedMode', True)
    settings.setValue('popAttachedRunning', True)
    settings.setValue('popAttachedHost', '127.0.0.1')
    settings.setValue('popAttachedPort', mixer.port)
    settings.setValue(OUTPUTS_KEY, json.dumps([dict(mix=2, bank='replay', enabled=True, follow=True)]))
    settings.setValue('popLastMatchLayout', json.dumps(dict(endpoint=['127.0.0.1', mixer.port], preset='Show')))
    window = PovManager(settings)
    try:
        wait_for(lambda: window.remote_bank.ready)
        assert not window.outputs.rows and not window.vdo_import.room and not window._room_resume.isActive()
        assert window.pov.suspended and not window.monitor.active and window._fixed is None
        assert not mixer.commands
        window.attach_stop.click()
        window.workstation.setCurrentIndex(0)
        assert not window.attached_mode and window.main_tabs.isTabVisible(0)
        assert window.outputs.rows[0].number == 2 and window.outputs.rows[0].follow.isChecked()
    finally:
        dispose(window)


def test_client_follow_requires_matching_panorama_and_never_reorders(app, tmp_path, fake_api):
    mixer, names = studio(fake_api)
    window = PovManager(local_settings(tmp_path, 'follow'))
    try:
        connect_remote(window, mixer)
        row = assign(window, 2, 'replay')
        assert not row.follow.isEnabled()

        def observe(order, index):
            packet = RemoteMatch('10000001', order, index, None)
            window.remote.snapshot = packet
            window.remote.changed.emit(packet)

        observe(names, 1)
        assert row.follow.isEnabled()
        row.follow.setChecked(True)
        observe(names, 8)
        wait_for(lambda: mixer.active_guids[2] == mixer.keys[20] and not window.remote_bank.busy)
        observe(names[::-1], 9)
        assert not row.follow.isEnabled()
        assert window.companion.payload['hud_observed_slot'] is None and not window.companion.payload['matchId']
        process_events(60)
        assert len(mixer.commands) == 1 and mixer.commands[0]['Function'] == 'ActiveInput'
    finally:
        dispose(window)
