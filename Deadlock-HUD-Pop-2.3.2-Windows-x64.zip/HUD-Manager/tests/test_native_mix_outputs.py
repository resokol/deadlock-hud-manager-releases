from dataclasses import replace
from threading import Event
from xml.etree import ElementTree

from test_camera_native_sync import finished, native
from test_camera_vdo_publish import guid
from test_vmix_control import app, fake_api, wait_for


def prepare_room(service, api, endpoint):
    rows = tuple(replace(row, name='' if i % 2 else row.name) for i, row in enumerate(api.pairs))
    assert service.verify_room(endpoint, api.preset, rows)
    finished(service)
    assert service.ready and not api.writes
    return rows


def test_prepared_partial_room_takes_by_guid_before_match(native):
    service, api, endpoint = native
    api.order[12:24] = reversed(api.order[12:24])
    api.pos[guid(14)]['panX'] = '.35'
    prepare_room(service, api, endpoint)
    assert service.route(2)['virtual_number'] == 23
    assert service.take_live(3, 1)
    finished(service)
    assert api.active == {1: guid(3), 2: guid(13)}
    assert service.take(2, 2)
    finished(service)
    assert api.active[2] == guid(13)
    assert service.take(3, 1, allow_main=True)
    finished(service)
    assert api.active == {1: guid(15), 2: guid(13)}
    assert all(q['Function'] == 'ActiveInput' for q in api.writes)


def test_newest_click_per_mix_and_authority_checked_after_xml(native, fake_api):
    service, api, endpoint = native
    prepare_room(service, api, endpoint)
    read_started, release = Event(), Event()
    def delayed(path):
        if path == '/api/':
            read_started.set()
            release.wait(2)
        return api.answer(path)
    fake_api.answer = delayed
    valid = [True]
    try:
        assert service.take_live(1, 1)
        wait_for(read_started.is_set)
        assert service.take_live(2, 1)
        assert service.take_live(7, 1)
        assert service.take(3, 2, validate=lambda: valid[0])
        valid[0] = False
    finally:
        release.set()
    finished(service)
    assert api.writes == [dict(Function='ActiveInput', Input=guid(7), Mix='0')]
    assert service.ready and api.active == service.mixes


def test_slow_mix_does_not_block_another_mix_or_reorder_writes(native, fake_api):
    service, api, endpoint = native
    prepare_room(service, api, endpoint)
    started, release = Event(), Event()
    def delayed(path):
        if 'Mix=0' in path and guid(3) in path:
            started.set()
            release.wait(3)
        return api.answer(path)
    fake_api.answer = delayed
    try:
        assert service.take_live(3, 1)
        wait_for(started.is_set)
        assert service.take_live(4, 1)
        assert service.take_live(6, 1)
        assert service.take(4, 2)
        wait_for(lambda: api.active[2] == guid(16))
        assert api.active[1] == guid(5)
    finally:
        release.set()
    finished(service)
    assert [q['Input'] for q in api.writes if q['Mix'] == '0'] == [guid(3), guid(6)]
    assert service.mixes == api.active == {1: guid(6), 2: guid(16)}


def test_mutated_pair_and_ambiguous_mix_never_switch_program(native, fake_api):
    service, api, endpoint = native
    prepare_room(service, api, endpoint)
    def duplicated_mix(path):
        if path == '/api/':
            root = ElementTree.fromstring(api.xml())
            mix = ElementTree.SubElement(root, 'mix', number='2')
            ElementTree.SubElement(mix, 'active').text = '7'
            return 200, {}, ElementTree.tostring(root)
        return api.answer(path)
    fake_api.answer = duplicated_mix
    assert service.take(2)
    finished(service)
    assert not api.writes
    fake_api.answer = api.answer
    api.inputs[guid(13)]['originalKey'] = guid(4)
    assert service.take_live(2)
    finished(service)
    assert not service.ready and not api.writes


def test_third_mix_readback_reports_controller_ignoring_command(native, fake_api):
    service, api, endpoint = native
    api.active[3] = guid(25)
    def third_mix(path):
        if path == '/api/':
            root = ElementTree.fromstring(api.xml())
            mix = ElementTree.SubElement(root, 'mix', number='3')
            ElementTree.SubElement(mix, 'active').text = str(api.order.index(api.active[3]) + 1)
            return 200, {}, ElementTree.tostring(root)
        return api.answer(path)
    fake_api.answer = third_mix
    prepare_room(service, api, endpoint)
    confirmations = []
    service.finished.connect(lambda ok, message: confirmations.append(ok))
    api.apply_command = False
    assert service.take_live(3, 3)
    finished(service)
    assert confirmations == [False] and service.ready
    assert service.mixes == {1: guid(5), 2: guid(13), 3: guid(25)}
    api.apply_command = True
    assert service.take(5, 3)
    finished(service)
    assert confirmations == [False, True] and service.mixes == {1: guid(5), 2: guid(13), 3: guid(17)}
    assert api.writes == [dict(Function='ActiveInput', Input=guid(3), Mix='2'),
                          dict(Function='ActiveInput', Input=guid(17), Mix='2')]
