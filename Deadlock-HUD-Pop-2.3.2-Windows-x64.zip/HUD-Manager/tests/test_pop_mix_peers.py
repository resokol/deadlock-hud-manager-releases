"""Mix ownership is scoped to a controller and lasts only while peers advertise it."""
import json

from PySide6.QtTest import QSignalSpy

from observer_assist.pop_mix_peers import LEASE_SECONDS, PopMixPeers
from test_vmix_control import app, wait_for


VMIX = ('192.168.7.20', 8088)
OTHER_PORT = (VMIX[0], 8090)
SENDER = '192.168.7.30'


def message(seq, mixes, *, endpoint=VMIX, sorting=False, nonce='a' * 32):
    return json.dumps(dict(popMixPeers=1, instance=nonce, sequence=seq, endpoint=endpoint,
                           mixes=mixes, sorting=sorting)).encode()


def test_lease_refresh_expiry_and_stale_withdraw_packets(app, monkeypatch):
    clock = [0.0]
    peers = PopMixPeers(clock=lambda: clock[0])
    sent = []
    monkeypatch.setattr(peers, '_announce', lambda *args: sent.append(args) or True)
    try:
        peers.set_claims(VMIX, [2])
        changes = QSignalSpy(peers.changed)
        peers._receive(message(1, [2, 3]), SENDER)
        assert peers.conflicts(VMIX, 2) and not peers.conflicts(OTHER_PORT, 2)
        assert not peers.conflicts(VMIX, 1) and changes.count() == 1
        clock[0] += LEASE_SECONDS - 1
        peers._receive(message(2, [2, 3]), SENDER)
        assert changes.count() == 1
        clock[0] += LEASE_SECONDS - 1
        assert peers.conflicts(VMIX, 3)
        peers._receive(message(3, [], sorting=True), SENDER)
        peers._receive(message(2, [2, 3]), SENDER)
        assert peers.remote_sorting(VMIX) and not peers.conflicts(VMIX, 2)
        assert not peers.remote_sorting(OTHER_PORT)
        peers._receive(message(4, []), SENDER)
        assert not peers.remote_sorting(VMIX)
        peers._receive(message(3, [], sorting=True), SENDER)
        assert not peers.remote_sorting(VMIX)
        peers._receive(message(5, [2], sorting=True), SENDER)
        clock[0] += LEASE_SECONDS + 0.01
        assert not peers.conflicts(VMIX, 2) and not peers.remote_sorting(VMIX)
        num = changes.count()
        peers._heartbeat()
        assert changes.count() == num + 1
        peers.set_claims(None, ())
        assert sent[-1] == (VMIX, (), False)
    finally:
        peers.close()


def test_other_endpoints_invalid_claims_and_remote_loopback_ignored(app, monkeypatch):
    peers = PopMixPeers()
    monkeypatch.setattr(peers, '_announce', lambda *args: True)
    peers.set_claims(VMIX, [1])
    try:
        for payload in [b'invalid', b'[]', message(1, [True]), message(-1, [1]),
                        message(1, [1], nonce=peers._nonce), message(1, [1], sorting='true'),
                        message(1, [1], endpoint=['invalid', 1]), message(1, [1], endpoint=['127.0.0.1', 8088])]:
            peers._receive(payload, SENDER)
        peers._receive(message(1, [1]), '203.0.113.2')
        assert not peers._peers
        peers._receive(message(1, [1], endpoint=OTHER_PORT), SENDER)
        assert not peers.conflicts(VMIX, 1)
        peers._receive(message(2, [1]), SENDER)
        assert peers.conflicts(VMIX, 1) and not peers.conflicts(OTHER_PORT, 1)
        peers._receive(message(3, [1], endpoint=OTHER_PORT), SENDER)
        assert not peers.conflicts(VMIX, 1)
    finally:
        peers.close()


def test_two_udp_instances_discover_duplicates_sorting_and_release(app, monkeypatch):
    controller = ('127.0.0.1', 8088)
    a = PopMixPeers(port=0)
    a.set_claims(controller, [1])
    b = PopMixPeers(port=a._socket.localPort())
    received = []
    read = b._receive

    def inspect(payload, sender):
        received.append(json.loads(payload))
        read(payload, sender)

    monkeypatch.setattr(b, '_receive', inspect)
    try:
        assert a.available
        b.set_claims(controller, [2])
        wait_for(lambda: a.conflicts(controller, 2) and b.conflicts(controller, 1))
        assert all(set(packet) == {'popMixPeers', 'instance', 'sequence', 'endpoint', 'mixes', 'sorting'}
                   for packet in received)
        assert not a.conflicts(controller, 1) and not b.conflicts(controller, 2)
        b.set_claims(controller, [1, 2])
        wait_for(lambda: a.conflicts(controller, 1) and b.conflicts(controller, 1))
        b.set_claims(controller, [], sorting=True)
        wait_for(lambda: not a.conflicts(controller, 1) and a.remote_sorting(controller))
        b.close()
        wait_for(lambda: not a.remote_sorting(controller))
    finally:
        a.close()
        b.close()

def test_unavailable_discovery_does_not_invent_conflicts(app, monkeypatch):
    peers = PopMixPeers()
    monkeypatch.setattr(peers, '_announce', lambda *args: False)
    try:
        peers.set_claims(VMIX, [5])
        assert not peers.available
        assert not peers.conflicts(VMIX, 5) and not peers.remote_sorting(VMIX)
    finally:
        peers.close()
