from PySide6.QtCore import QSettings

from observer_assist.pop_remote_bank import AttachedBank
from test_camera_native_sync import NativePreset
from test_camera_vdo_publish import guid
from test_vmix_control import app, fake_api, wait_for


def owner_preset():
    api = NativePreset()
    for i, pair in enumerate(api.pairs, 1):
        name = pair.name if i <= 8 else '-'
        api.inputs[pair.original_guid]['title'] = name
        api.inputs[pair.virtual_guid]['title'] = name + ' - Virtual' if name != '-' else '-'
    return api


def test_remote_client_routes_without_owner_state_and_reconnects(app, fake_api, tmp_path):
    api = owner_preset()
    active = api.active.copy()
    settings = QSettings(str(tmp_path / 'client.ini'), QSettings.Format.IniFormat)
    client = AttachedBank(settings=settings)
    client._poll.setInterval(25)
    fake_api.answer = lambda _: (503, {}, b'')
    endpoint = ('127.0.0.1', fake_api.server_port)
    try:
        assert client.start(endpoint)
        wait_for(lambda: not client.busy)
        assert not client.ready and not client.take(3)
        fake_api.answer = api.answer
        wait_for(lambda: client.ready)
        assert client.route(3)['title'] == 'Игрок 3'
        assert client.media(3) == 'unknown' and client.media(9) == 'absent'
        assert client.mixes == active and not api.writes
        assert client.take(3, 2)
        wait_for(lambda: not client.busy)
        assert api.active == {1: active[1], 2: guid(15)}
        assert api.writes == [dict(Function='ActiveInput', Input=guid(15), Mix='1')]
        assert not settings.allKeys()
        assert not client.verify(endpoint, api.preset, api.pairs)
    finally:
        client.cancel()


def test_inflight_click_after_owner_reorder_rejected_then_adopted(app, fake_api, tmp_path):
    api = owner_preset()
    fake_api.answer = api.answer
    client = AttachedBank(settings=QSettings(str(tmp_path / 'client.ini'), QSettings.Format.IniFormat))
    client._poll.setInterval(50)
    try:
        assert client.start(('127.0.0.1', fake_api.server_port))
        wait_for(lambda: client.ready)
        for a, b in [(0, 1), (12, 13)]:
            api.order[a], api.order[b] = api.order[b], api.order[a]
        assert client.take_live(1, 1)
        wait_for(lambda: not client.ready)
        assert not api.writes
        wait_for(lambda: client.ready)
        assert client.route(1)['title'] == 'Игрок 2'
        assert client.take_live(1, 1)
        wait_for(lambda: not client.busy)
        assert api.writes == [dict(Function='ActiveInput', Input=guid(2), Mix='0')]
        api.inputs[guid(2)]['title'] = 'https://vdo.ninja/?private=secret'
        assert client.take(1, 2)
        wait_for(lambda: not client.ready)
        assert 'secret' not in client.message and len(api.writes) == 1
        api.inputs[guid(2)]['title'] = 'Новый игрок'
        api.inputs[guid(14)]['title'] = 'Новый игрок - Virtual'
        wait_for(lambda: client.ready)
        assert client.route(1)['title'] == 'Новый игрок'
    finally:
        client.cancel()


def test_hidden_lineage_remembers_real_guid_pair_through_empty_slots(app, fake_api, tmp_path):
    api = owner_preset()
    for row in api.pairs:
        del api.inputs[row.virtual_guid]['originalKey']
    fake_api.answer = api.answer
    client = AttachedBank(settings=QSettings(str(tmp_path / 'hidden.ini'), QSettings.Format.IniFormat))
    client._poll.setInterval(25)
    try:
        assert client.start(('127.0.0.1', fake_api.server_port))
        wait_for(lambda: client.ready)
        api.order[20], api.order[21] = api.order[21], api.order[20]
        assert client.take(9)
        wait_for(lambda: not client.ready)
        assert not api.writes
        api.order[8], api.order[9] = api.order[9], api.order[8]
        wait_for(lambda: client.ready)
        assert client.route(9)['virtual_guid'] == guid(22) and not api.writes
    finally:
        client.cancel()


def test_remote_rejects_contradictory_lineage_and_never_claims_visible_video(app, fake_api, tmp_path):
    api = owner_preset()
    api.inputs[guid(13)]['originalKey'] = guid(2)
    fake_api.answer = api.answer
    client = AttachedBank(settings=QSettings(str(tmp_path / 'remote.ini'), QSettings.Format.IniFormat))
    client._poll.setInterval(25)
    try:
        assert client.start(('127.0.0.1', fake_api.server_port))
        wait_for(lambda: not client.busy)
        assert not client.ready and not client.take_live(1)
        api.inputs[guid(13)]['originalKey'] = guid(1)
        for key in (guid(1), guid(13)):
            api.inputs[key]['alphaByte'] = '0'
        for key in (guid(2), guid(14)):
            api.inputs[key]['alphaByte'] = '255'
        wait_for(lambda: client.ready)
        assert client.media(1) == 'absent' and client.media(2) == 'unknown'
        assert not api.writes
    finally:
        client.cancel()
