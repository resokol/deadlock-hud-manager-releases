"""Write-ahead records for the vMix input edits that can be verified and reversed."""

from copy import deepcopy
from dataclasses import asdict, dataclass
from hashlib import sha256
import json
from math import isfinite


@dataclass(frozen=True)
class ConfirmedLayout:
    endpoint: tuple
    preset: str
    match_id: str
    pairs: tuple


def safe_title(title):
    # Browser titles can be full URLs, including private room credentials.
    if '://' in title or title.casefold().startswith(('data:', 'file:')):
        return {'digest': sha256(title.encode()).hexdigest()}
    return title


def snapshot(state, evidence):
    by_number = sorted(state.inputs, key=lambda g: state.inputs[g]['number'])
    return dict(order=by_number[:24], titles={g: safe_title(state.inputs[g]['title']) for g in by_number[:24]},
                outside={g: state.inputs[g]['number'] for g in by_number[24:]},
                geometry={g: dict(evidence.positions.get(g, {})) for g in by_number[:24]},
                mixes={str(k): v for k, v in evidence.mixes.items()}, external2=evidence.external2)


class NativeLayoutStore:
    def __init__(self, settings=None):
        self.settings = settings
        self.memory = {}

    def _key(self, endpoint, preset):
        digest = sha256(json.dumps([*endpoint, preset], ensure_ascii=True).encode()).hexdigest()
        return f'nativeCameraLayoutV1/{digest}'

    def _load(self, endpoint, preset):
        key = self._key(endpoint, preset)
        raw = self.settings.value(key, '', type=str) if self.settings is not None else self.memory.get(key)
        if not raw:
            return dict(version=1, endpoint=list(endpoint), preset=preset)
        try:
            data = json.loads(raw)
            if data['version'] == 1 and data['endpoint'] == list(endpoint) and data['preset'] == preset:
                return data
        except (KeyError, ValueError, TypeError):
            pass
        raise ValueError('Повреждена запись о состоянии входов. Сверьте пресет перед восстановлением.')

    def read(self, endpoint, preset, kind):
        return self._load(endpoint, preset).get(kind)

    def _save(self, endpoint, preset, data):
        key = self._key(endpoint, preset)
        raw = json.dumps(data, ensure_ascii=False, separators=(',', ':'))
        if self.settings is None:
            self.memory[key] = raw
        else:
            self.settings.setValue(key, raw)
            self.settings.sync()
            if self.settings.status() != self.settings.Status.NoError:
                raise ValueError('Не удалось сохранить журнал изменений на диск.')

    def write(self, endpoint, preset, kind, value):
        data = self._load(endpoint, preset)
        data[kind] = value
        self._save(endpoint, preset, data)

    def remove(self, endpoint, preset, kind):
        data = self._load(endpoint, preset)
        data.pop(kind, None)
        self._save(endpoint, preset, data)

    def confirmed(self, endpoint, preset, match_id, pairs):
        data = self._load(endpoint, preset)
        data['confirmed'] = dict(match_id=match_id, pairs=[asdict(row) for row in pairs])
        data.pop('pending', None)
        self._save(endpoint, preset, data)


_FIELDS = {'SetPanX': ('panX',), 'SetPanY': ('panY',), 'SetZoom': ('zoomX', 'zoomY'),
           'SetCrop': ('cropX1', 'cropY1', 'cropX2', 'cropY2')}
for _field in _FIELDS['SetCrop']:
    _FIELDS['Set' + _field[0].upper() + _field[1:]] = (_field,)


def _number(value):
    try:
        numeric = float(value)
        return numeric if isfinite(numeric) else None
    except (ValueError, TypeError, OverflowError):
        return None


def _same(a, b):
    left, right = _number(a), _number(b)
    return a == b or (left is not None and right is not None and abs(left - right) <= 1e-7)


def title_matches(actual, expected, *, virtual):
    # The vMix display title of a Virtual Input may include its type prefix.
    # Scope the alternate echo to a known copy and the exact requested label.
    return actual == expected or (virtual and isinstance(expected, str) and actual == 'Virtual - ' + expected)


def compatible(before, current, command):
    """Permit exactly the old state or the one-command change we put on the wire."""
    if before == current:
        return True
    if not command:
        return False
    kind, guid, value = command['Function'], command['Input'], command['Value']
    expected = deepcopy(before)
    if kind == 'MoveInput':
        keys = expected['order']
        index, dest = keys.index(guid), int(value) - 1
        if not 0 <= dest < len(keys) or index // 12 != dest // 12:
            return False
        keys[index], keys[dest] = keys[dest], keys[index]
        if expected == current:
            return True
        keys[:] = before['order']
        keys.insert(dest, keys.pop(index))
    elif kind == 'SetInputName':
        actual = current['titles'][guid]
        if not title_matches(actual, value, virtual=guid in before['order'][12:24]):
            return False
        expected['titles'][guid] = actual
    elif kind in _FIELDS:
        fields = _FIELDS[kind]
        values = value.split(',') if kind == 'SetCrop' else [value] * len(fields)
        after = current['geometry'][guid]
        prior = expected['geometry'][guid]
        for field, target in zip(fields, values):
            # Implementations may omit defaults or publish them only after setting.
            if field not in after:
                prior.pop(field, None)
            elif _same(after[field], target) or _same(after[field], prior.get(field)):
                prior[field] = after[field]
    else:
        return False
    return expected == current


def record_command(journal, observed, command):
    entry = dict(command)
    if entry['Function'] == 'SetInputName':
        entry['Value'] = safe_title(entry['Value'])
    journal['checkpoint'] = observed
    journal['pending'] = entry
    if entry['Function'] in _FIELDS:
        touched = journal['touched'].setdefault(entry['Input'], [])
        for field in _FIELDS[entry['Function']]:
            if field not in touched:
                touched.append(field)


def geometry_undo(journal, observed):
    """Only restore fields for which the API exposes a valid previous value and a setter."""
    manual = False
    for guid, touched in journal['touched'].items():
        baseline = journal['before']['geometry'][guid]
        current = observed['geometry'][guid]
        for kind in ('SetPanX', 'SetPanY', 'SetZoom', 'SetCropX1', 'SetCropY1', 'SetCropX2', 'SetCropY2'):
            fields = _FIELDS[kind]
            if not set(fields).intersection(touched):
                continue
            previous = [baseline.get(field) for field in fields]
            if any(_number(v) is None for v in previous):
                manual = True
                continue
            if all(_same(current.get(field), value) for field, value in zip(fields, previous)):
                continue
            if len(previous) == 2 and not _same(*previous):
                manual = True  # vMix SetZoom sets X and Y together.
                continue
            return dict(Function=kind, Input=guid, Value=str(previous[0])), manual
    return None, manual
