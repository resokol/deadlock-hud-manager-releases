"""One polled vMix Web Controller, shared by routes on the same endpoint."""

from collections import defaultdict
from dataclasses import dataclass
from urllib.parse import urlencode
from xml.etree import ElementTree

from PySide6.QtCore import QObject, QTimer, QUrl, Signal
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkProxy, QNetworkReply, QNetworkRequest

from .vmix_control import REQUEST_TIMEOUT_MS, _guid


POLL_MS = 1000
_BROWSER = {'browser', 'webbrowser', 'web browser'}


def browser_source(info):
    return info.get('type', '').casefold() in _BROWSER and not info.get('virtual') and 'virtual_parent' not in info


def virtual_source(info, *, verified=False):
    if info.get('virtual') or info.get('type', '').casefold() == 'virtual':
        return True
    # Some presets expose a browser clone only as Browser. An operator can bind
    # its GUID manually after inspecting the source in vMix.
    return (not verified and 'virtual' not in info
            and info.get('type', '').casefold() in _BROWSER)


def _number(value, fallback=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return fallback


@dataclass
class _State:
    preset: str
    inputs: dict
    browsers: set
    mixes: dict
    layers: dict
    protected: set
    protection_known: bool


def _read_state(xml):
    root = ElementTree.fromstring(xml)
    if root.tag != 'vmix' or root.find('inputs') is None:
        raise ValueError('vMix XML')
    entries = root.findall('./inputs/input')
    inputs, numbers, browsers = {}, {}, set()
    for entry in entries:
        guid = _guid(entry.get('key'))
        number = _number(entry.get('number'))
        if not guid or number < 1 or guid in inputs or number in numbers:
            raise ValueError('Ambiguous input')
        inputs[guid] = dict(number=number, title=entry.get('shortTitle') or entry.get('title', ''),
                            type=entry.get('type', ''))
        if entry.get('virtual', '').casefold() in ('true', 'false'):
            inputs[guid]['virtual'] = entry.get('virtual').casefold() == 'true'
        numbers[number] = guid
        if browser_source(inputs[guid]):
            browsers.add(guid)

    def resolve(value):
        value = (value or '').strip()
        guid = _guid(value)
        return guid if guid in inputs else numbers.get(_number(value))

    for entry in entries:
        guid = _guid(entry.get('key'))
        info = inputs[guid]
        attrs = {k.casefold(): v for k, v in entry.attrib.items()}
        # A public vMix XML snapshot often omits virtual lineage entirely. Input
        # numbers or title suffixes by themselves do not identify an original.
        fields = {'originalkey', 'originalinputkey', 'virtualsourcekey', 'virtualsource'}
        if info.get('virtual') or info['type'].casefold() == 'virtual':
            fields.update(('sourcekey', 'parentkey', 'originalinput', 'sourceinput', 'parentinput'))
            # Generic attributes can instead describe a device or URL. Only
            # interpret them as identifiers when their value is an input reference.
            fields.update(k for k in ('original', 'parent', 'source') if k in attrs
                          and (_guid(attrs[k]) or attrs[k].strip().isdecimal()))
        declared = [resolve(attrs[k]) for k in fields if k in attrs]
        if declared:
            info['virtual_parent'] = declared[0] if len(set(declared)) == 1 and declared[0] else ''
            browsers.discard(guid)

    def active(element):
        entries = element.findall('active')
        return (resolve(entries[0].text) or '') if len(entries) == 1 else ''

    mixes = {1: active(root)}
    mix_nodes = set()
    protected = set()
    outputs = root.findall('./outputs/output')
    known = any(out.get('type', '').casefold() == 'output' and out.get('number') == '1'
                for out in outputs)
    for mix in root.findall('mix'):
        number = _number(mix.get('number'))
        if number < 1:
            known = False
            continue
        program = active(mix)
        if number in mix_nodes or (number == 1 and root.find('active') is not None and program != mixes[1]):
            program = ''
        mixes[number] = program
        mix_nodes.add(number)
    for guid in mixes.values():
        if guid:
            protected.add(guid)
        else:
            known = False

    for overlay in root.findall('./overlays/overlay') + root.findall('./mix/overlays/overlay'):
        value = overlay.get('key') or (overlay.text or '').strip()
        if value and value != '0':
            guid = resolve(value)
            if guid:
                protected.add(guid)
            else:
                known = False
    for output in outputs:
        source = output.get('source', '').casefold()
        if source in ('output', 'program'):
            guid = mixes[1]
        elif source == 'preview':
            guid = resolve(root.findtext('preview'))
        elif source == 'input':
            guid = resolve(output.get('key') or output.get('input') or output.get('inputNumber'))
        elif source == 'mix':
            guid = mixes.get(_number(output.get('mix'), -1) + 1)
        else:
            guid = resolve(source)
        if guid:
            protected.add(guid)
        else:
            known = False

    layers, unknown, children = {}, set(), defaultdict(set)
    for entry in entries:
        parent = _guid(entry.get('key'))
        for overlay in entry.findall('overlay'):
            index = _number(overlay.get('index'), -1)
            child = resolve(overlay.get('key') or overlay.get('input') or overlay.text)
            if index < 0 or not child or (parent, index + 1) in layers:
                unknown.add(parent)
                continue
            layers[parent, index + 1] = child
            children[parent].add(child)
        if entry.get('virtual', '').casefold() == 'true' or inputs[parent]['type'].casefold() in (
                'virtual', 'output', 'preview', 'multiview'):
            unknown.add(parent)

    frontier = list(protected)
    while frontier:
        parent = frontier.pop()
        if parent in unknown:
            known = False
        for child in children[parent] - protected:
            protected.add(child)
            frontier.append(child)
    return _State((root.findtext('preset') or '').strip(), inputs, browsers, mixes, layers, protected, known)


class CameraEndpoint(QObject):
    changed = Signal()
    event = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.online = False
        self.inputs = {}
        self.mixes = {}
        self.layers = {}
        self.protected = set()
        self._known = False
        self._routing = False
        self._browsers = set()
        self._network = QNetworkAccessManager(self)
        self._network.setProxy(QNetworkProxy(QNetworkProxy.ProxyType.NoProxy))
        self._timer = QTimer(self, singleShot=True)
        self._timer.timeout.connect(self._poll)
        self._dispatch = QTimer(self, singleShot=True, interval=0)
        self._dispatch.timeout.connect(self._pump)
        self._url = QUrl()
        self._enabled = False
        self._reply = None
        self._need_poll = False
        self._snapshot = 0
        self._preset = ''
        self._names = {}
        self._pages = {}
        self._applied = {}
        self._attempted = set()
        self._takes = {}
        self._last_problem = ''

    def configure(self, host, port, enabled):
        url = QUrl()
        url.setScheme('http')
        url.setHost(str(host).strip().strip('[]'))
        port = _number(port)
        valid = 1 <= port <= 65535 and bool(url.host())
        if valid:
            url.setPort(port)
        url.setPath('/api/')
        enabled = bool(enabled and valid and url.isValid())
        if (self._url, self._enabled) == (url, enabled):
            return
        self.close()
        if self._url != url:
            self._applied.clear()
            self._preset = ''
        self._url, self._enabled = url, enabled
        if enabled:
            self._poll()

    def close(self):
        self._enabled = False
        self._timer.stop()
        self._dispatch.stop()
        reply, self._reply = self._reply, None
        if reply is not None:
            reply.abort()
        self._offline()

    def _offline(self):
        notify = self.online
        self.online = False
        self.inputs, self.mixes, self.layers = {}, {}, {}
        self.protected, self._known, self._routing = set(), False, False
        self._browsers.clear()
        self._takes.clear()
        self._need_poll = False
        if notify:
            self.changed.emit()

    def sync(self, names, pages):
        names = {key: value for guid, value in names.items() if value and (key := _guid(guid))}
        pages = {key: value for guid, value in pages.items() if value and (key := _guid(guid))}
        if (names, pages) == (self._names, self._pages):
            return
        self._names, self._pages = names, pages
        if self.online:
            self._dispatch.start()

    def ready(self, guid, page):
        guid = _guid(guid)
        return bool(self.online and page and self._pages.get(guid) == page and self._applied.get(guid) == page)

    def forget_pages(self, guids):
        """Explicitly restore selected browser URLs after reloading a preset with the same keys."""
        selected = {_guid(guid) for guid in guids}
        for guid in selected:
            self._applied.pop(guid, None)
        self._attempted = {job for job in self._attempted if job[0] != 'BrowserNavigate' or job[1] not in selected}
        if self.online:
            self._dispatch.start()
            self.changed.emit()

    @property
    def protection_known(self):
        return self._known and not self._takes and not self._routing

    def layer_source(self, target, layer):
        return self.layers.get((_guid(target), _number(layer)))

    def take(self, guid, mix=1, target='', layer=1, *, original='', page=''):
        """Queue a choice for fresh XML validation. Only poll readback changes the tally."""
        guid = _guid(guid)
        destination = self._destination(mix, target, layer)
        if not self._valid_take(guid, destination, original, page):
            return False
        was_known = self.protection_known
        self._takes[destination] = (guid, self._snapshot + 1, original, page)
        self._dispatch.start()
        if was_known:
            self.changed.emit()
        return True

    @staticmethod
    def _destination(mix, target, layer):
        return ('layer', _guid(target), _number(layer)) if target else ('mix', _number(mix))

    def _valid_take(self, guid, dest, original, page):
        if not self.online or guid not in self.inputs:
            return False
        if guid in self._pages and not self.ready(guid, self._pages[guid]):
            return False
        if (original or page) and not self.ready(original, page):
            return False
        if dest[0] == 'mix':
            return dest[1] in self.mixes
        return dest[1] in self.inputs and dest[1] != guid and 1 <= dest[2] <= 10

    def cancel_take(self, mix=1, target='', layer=1):
        removed = self._takes.pop(self._destination(mix, target, layer), None)
        if removed and self.protection_known:
            self.changed.emit()

    def cancel_takes(self):
        had_takes = bool(self._takes)
        self._takes.clear()
        if had_takes and self.protection_known:
            self.changed.emit()

    def _poll(self):
        self._need_poll = True
        self._dispatch.start()

    def _pump(self):
        if not self._enabled or self._reply is not None:
            return
        if self._need_poll:
            self._need_poll = False
            self._request()
            return
        while self.online and self._takes:
            dest = next(iter(self._takes))
            guid, required, original, page = self._takes[dest]
            if self._snapshot < required:
                self._request()
                return
            del self._takes[dest]
            if self._valid_take(guid, dest, original, page):
                self._routing = True
                if dest[0] == 'mix':
                    command = dict(Function='ActiveInput', Input=guid, Mix=dest[1] - 1)
                else:
                    command = dict(Function='SetLayer', Input=dest[1], Value=f'{dest[2]},{self.inputs[guid]["number"]}')
                self._request(command)
                return
            if self.protection_known:
                self.changed.emit()
        if self.online:
            self._sync_next()

    def _sync_next(self):
        for function, desired in [('BrowserNavigate', self._pages), ('SetInputName', self._names)]:
            for guid, value in desired.items():
                entry = self.inputs.get(guid)
                job = function, guid, value
                if not entry or job in self._attempted:
                    continue
                if function == 'BrowserNavigate':
                    if guid not in self._browsers or self._applied.get(guid) == value:
                        continue
                elif entry['title'] == value:
                    continue
                self._attempted.add(job)
                self._request(dict(Function=function, Input=guid, Value=value))
                if function == 'BrowserNavigate' and self._applied.pop(guid, None):
                    self.changed.emit()
                return

    def _request(self, command=None):
        url = QUrl(self._url)
        if command:
            url.setQuery(urlencode(command))
        request = QNetworkRequest(url)
        request.setTransferTimeout(REQUEST_TIMEOUT_MS)
        request.setAttribute(QNetworkRequest.Attribute.RedirectPolicyAttribute,
                             QNetworkRequest.RedirectPolicy.ManualRedirectPolicy)
        reply = self._network.get(request)
        self._reply = reply
        reply.finished.connect(lambda: self._finished(reply, command))

    def _finished(self, reply, command):
        reply.deleteLater()
        if self._reply is not reply:
            return
        self._reply = None
        status = reply.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute)
        ok = reply.error() == QNetworkReply.NetworkError.NoError and status == 200
        if command is None:
            try:
                if not ok:
                    raise ValueError
                state = _read_state(bytes(reply.readAll()))
            except (ElementTree.ParseError, ValueError):
                self._offline()
                self._problem(f'vMix: нет данных Web Controller (HTTP {status or "—"}).')
            else:
                self._publish(state)
            if self._enabled:
                self._timer.start(POLL_MS)
        elif not ok:
            self._problem(f'vMix: {command["Function"]}, HTTP {status or "—"}.')
            if status is None:
                self._offline()
            elif self._routing:
                if status >= 500:
                    self._takes.clear()
                self._need_poll = True
            if not self.online:
                self._timer.start(POLL_MS)
        elif command['Function'] == 'BrowserNavigate':
            self._applied[command['Input']] = command['Value']
            self.changed.emit()
        elif command['Function'] in ('ActiveInput', 'SetLayer'):
            self.event.emit(f'vMix принял {command["Function"]}.')
            self._need_poll = True
        if self._enabled:
            self._dispatch.start()

    def _problem(self, message):
        if self._last_problem != message:
            self._last_problem = message
            self.event.emit(message)

    def _publish(self, state):
        was_online = self.online
        new_preset = bool(self._preset and state.preset and state.preset != self._preset)
        if new_preset:
            self._applied.clear()
            self._takes.clear()
        if state.preset:
            self._preset = state.preset
        browsers_changed = self._browsers != state.browsers
        self._browsers = state.browsers
        self._applied = {guid: page for guid, page in self._applied.items() if guid in self._browsers}
        previous = self.inputs, self.mixes, self.layers, self.protected, self.protection_known
        self.inputs, self.mixes, self.layers, self.protected = state.inputs, state.mixes, state.layers, state.protected
        self._known, self._routing = state.protection_known, False
        current = self.inputs, self.mixes, self.layers, self.protected, self.protection_known
        self._snapshot += 1
        self._attempted.clear()
        self._last_problem = ''
        self.online = True
        if not was_online:
            self.event.emit('vMix подключён.')
        if new_preset:
            self.event.emit('Пресет vMix изменился.')
        if not was_online or new_preset or browsers_changed or previous != current:
            self.changed.emit()
