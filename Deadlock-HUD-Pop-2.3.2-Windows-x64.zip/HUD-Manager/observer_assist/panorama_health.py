"""Tail observer samples from Deadlock console.log."""

from dataclasses import dataclass
import json
from pathlib import Path
import re
import time


MARKER = '[DOA-HEALTH] '
TELEMETRY_MARKER = '[DOA-TELEMETRY] '
PART_MARKER = '[DOA-TELEMETRY-PART] '
MINIMAP_MARKER = '[DOA-MINIMAP-LOCAL] '
HOST_MARKER = '[HostStateManager] Host activate:'
MATCH_MARKER = '[DOA-MATCH-ID]'
MINIMAP_LIFETIME_MS = 600
RIFT_LIFETIME = 1.5
MID_BOSS_LIFETIME = 1.5
WORLD_FEED_LIFETIME = 3
BROADCAST = re.compile(
    r'Playing Broadcast \((https?://(?:[a-z0-9-]+\.)?steamcontent\.com/tv/[0-9]+(?:_[0-9]+)?)',
    re.IGNORECASE,
)


@dataclass(frozen=True)
class MinimapMarker:
    key: str
    side: int
    x: int
    y: int
    width: int
    height: int
    client_pixels: bool = False


def _parse_minimap_line(line):
    _, _, payload = line.partition(MINIMAP_MARKER)
    if len(payload) > 590:
        return None
    try:
        frame = json.loads(payload)
    except (ValueError, RecursionError):
        return None
    if not isinstance(frame, dict) or type(frame.get('version')) is not int or frame['version'] != 1:
        return None
    at, rows = frame.get('at'), frame.get('markers')
    space = frame.get('space', 'normalized')
    if type(at) is not int or not isinstance(rows, list) or len(rows) > 12 or space not in ('normalized', 'client'):
        return None
    maximum = 20000 if space == 'client' else 10000
    markers = []
    keys = set()
    for row in rows:
        if not isinstance(row, list) or len(row) != 6:
            return None
        key, side, x, y, width, height = row
        if (not isinstance(key, str) or len(key) != 1 or key not in '1234567890-=' or key in keys
                or any(type(value) is not int for value in row[1:])
                or side not in (0, 1) or not 0 <= x <= maximum or not 0 <= y <= maximum
                or not 0 < width <= 1500 or not 0 < height <= 1500):
            return None
        keys.add(key)
        markers.append(MinimapMarker(key, side, x, y, width, height, space == 'client'))
    return at, tuple(markers)


def _broadcast(line):
    match = BROADCAST.search(line)
    return match[1] if match else None


def _session_metadata(path, size):
    native_match = None
    with path.open('rb') as log:
        while size > 0:
            start = max(0, size - 1024 * 1024)
            log.seek(start)
            if start:
                log.readline()
            lines = log.read(max(0, size - log.tell()) + 512).splitlines()
            for raw in reversed(lines):
                if HOST_MARKER.encode() in raw:
                    return _broadcast(raw.decode('ascii', errors='ignore')), native_match
                if native_match is None and MATCH_MARKER.encode() in raw:
                    native_match = _native_match(raw.decode('ascii', errors='ignore'))
            size = start
    return None, native_match


def _native_match(line):
    value = line.partition(MATCH_MARKER)[2].strip()
    return value if re.fullmatch(r'[1-9][0-9]{7,19}', value) else ''


def parse_health_line(line):
    _, marker, payload = line.partition(MARKER)
    if not marker or len(payload) > 4096:
        return None
    try:
        sample = json.loads(payload)
    except ValueError:
        return None
    return _health_sample(sample)


def _health_sample(sample):
    if not isinstance(sample, dict):
        return None
    name, hp, maximum = sample.get('player'), sample.get('hp'), sample.get('maxHp')
    if (not isinstance(name, str) or not name.strip() or len(name) > 256
            or type(hp) is not int or type(maximum) is not int
            or not 0 <= hp <= 1_000_000 or not 0 < maximum <= 1_000_000):
        return None
    return name.strip(), hp, maximum


def parse_telemetry_line(line):
    _, marker, payload = line.partition(TELEMETRY_MARKER)
    if not marker or len(payload) > 24000:
        return None
    try:
        snapshot = json.loads(payload)
    except ValueError:
        return None
    if not isinstance(snapshot, dict) or snapshot.get('version') != 1:
        return None
    return snapshot


def _rift_state(value):
    if not isinstance(value, dict):
        return None
    identifier, phase, spawned = value.get('id'), value.get('phase'), value.get('spawnedAt')
    if (not isinstance(identifier, str) or not re.fullmatch(r'[0-9A-Za-z:_-]{1,96}', identifier)
            or phase not in ('warning', 'spawned') or spawned is not None and
            (phase != 'spawned' or type(spawned) is not int or not 0 < spawned < 2**53)):
        return None
    state = {'id': identifier, 'phase': phase, 'spawnedAt': spawned}
    for key, limit in (('gameClock', 32), ('location', 100)):
        text = value.get(key)
        if isinstance(text, str) and 0 < len(text) <= limit:
            state[key] = text
    seconds = value.get('secondsUntil')
    if phase == 'warning' and type(seconds) is int and 0 <= seconds <= 300:
        state['secondsUntil'] = seconds
        if value.get('estimated') is True:
            state['estimated'] = True
    return state


def _world_feed(events):
    if not isinstance(events, list) or len(events) > 12:
        return None
    result = []
    ids = set()
    for row in events:
        if not isinstance(row, dict) or row.get('kind') not in ('kill', 'urnPickup', 'urnDelivery'):
            continue
        identifier, at = row.get('id'), row.get('at')
        if (not isinstance(identifier, str) or not re.fullmatch(r'[0-9A-Za-z:_-]{1,96}', identifier) or
                identifier in ids or type(at) is not int or not 0 < at < 2**53):
            continue
        ids.add(identifier)
        event = {'id': identifier, 'kind': row['kind'], 'at': at}
        for field, limit in (('actor', 256), ('target', 256), ('gameClock', 32)):
            value = row.get(field)
            if isinstance(value, str) and 0 < len(value) <= limit:
                event[field] = value
        for field in ('actorSide', 'targetSide'):
            if type(row.get(field)) is int and row[field] in (2, 3):
                event[field] = row[field]
        for field, limit in (('souls', 1_000_000), ('durationSeconds', 24 * 3600)):
            value = row.get(field)
            if type(value) is int and 0 <= value <= limit:
                event[field] = value
        result.append(event)
    return result


def _mid_boss_state(value):
    if not isinstance(value, dict):
        return None
    identifier = value.get('id')
    if not isinstance(identifier, str) or not re.fullmatch(r'[0-9A-Za-z:_-]{1,96}', identifier):
        return None
    state = {'id': identifier}
    for side_key, time_key in (('killedBy', 'killedAt'), ('claimedBy', 'claimedAt')):
        side, when = value.get(side_key), value.get(time_key)
        if side is not None and (type(side) is not int or side not in (2, 3)):
            return None
        if when is not None and (side is None or type(when) is not int or not 0 < when < 2**53):
            return None
        state[side_key], state[time_key] = side, when
    if 'claimId' in value:
        claim_id = value['claimId']
        if (state['claimedBy'] is None or not isinstance(claim_id, str)
                or not re.fullmatch(r'[0-9A-Za-z:_-]{1,96}', claim_id)):
            return None
        state['claimId'] = claim_id
    return state if state['killedBy'] or state['claimedBy'] else None


class _RespawnCountdowns:
    def __init__(self):
        self._clock = None
        self._roster = None
        self._deadlines = {}
        self._displayed = None

    def project(self, teams, game_clock):
        clock = re.fullmatch(r'([0-9]{1,4}):([0-5][0-9])', game_clock) if isinstance(game_clock, str) else None
        if clock is None:
            self._clock = self._roster = self._displayed = None
            self._deadlines.clear()
            return teams
        seconds = int(clock[1]) * 60 + int(clock[2])
        fresh = teams is not self._roster
        if not fresh and seconds == self._clock:
            return self._displayed
        if self._clock is not None and seconds < self._clock:
            self._deadlines.clear()

        deadlines = {} if fresh else self._deadlines
        displayed = []
        for team in teams:
            if (not isinstance(team, dict) or type(team.get('side')) is not int or
                    not isinstance(team.get('players'), list)):
                displayed.append(team)
                continue
            players = []
            for slot, player in enumerate(team['players']):
                value = player.get('respawn') if isinstance(player, dict) else None
                if not isinstance(value, str) or not re.fullmatch(r'[0-9]{1,3}', value) or int(value) == 0:
                    players.append(player)
                    continue
                key = team['side'], slot
                if fresh:
                    identity = player.get('name'), player.get('hero')
                    remaining = int(value)
                    deadline = seconds + remaining
                    previous = self._deadlines.get(key)
                    # The two integer labels are sampled independently. Ignore a one-second
                    # phase difference while retaining actual extensions and major corrections.
                    if previous and previous[0] == identity and remaining <= previous[1]:
                        # The stock label can remain at one even after the game clock advances.
                        if remaining == previous[1] or abs(deadline - previous[2]) <= 1:
                            deadline = previous[2]
                    deadlines[key] = (identity, remaining, deadline)
                if key in deadlines:
                    remaining = deadlines[key][2] - seconds
                    player = {**player, 'respawn': str(remaining) if remaining > 0 else None}
                players.append(player)
            displayed.append({**team, 'players': players})
        self._deadlines = deadlines
        self._clock, self._roster, self._displayed = seconds, teams, displayed
        return displayed


class PanoramaHealthLog:
    def __init__(self, path):
        self.path = Path(path)
        self._offset = None
        self._file = None
        self._pending = b''
        self._last = None
        self._time = None
        self.broadcast_url = None
        self._native_match = None
        self._telemetry = self._telemetry_time = None
        self._camera_switch_since = None
        self._rift = self._rift_time = None
        self._mid_boss = self._mid_boss_time = self._roster_time = None
        self._world_events = self._world_feed_time = None
        self._minimap = None
        self._fragments = {}
        self._respawns = _RespawnCountdowns()
        self._stream = self._roster = self._frame = self._frame_time = None
        try:
            initial = self.path.stat()
            self.broadcast_url, self._native_match = _session_metadata(self.path, initial.st_size)
        except OSError:
            pass
        else:
            self._offset = initial.st_size
            self._file = initial.st_ino

    @property
    def match_id(self):
        if self.broadcast_url:
            return self.broadcast_url.rsplit('/', 1)[-1].partition('_')[0]
        return self._native_match or None

    @property
    def match_roster(self):
        """The latest roster packet for this stream, independent of camera freshness."""
        return self._roster if self._roster_time is not None else None

    def poll(self, *, include_telemetry=True, include_minimap=False):
        now = time.monotonic()
        if not include_minimap:
            self._minimap = None
        try:
            stat = self.path.stat()
            if self._offset is None or stat.st_ino != self._file or stat.st_size < self._offset:
                self._offset, self._file = 0, stat.st_ino
                self._pending = b''
                self.broadcast_url = None
                self._native_match = None
                self._minimap = None
                self._clear()
            if stat.st_size > self._offset:
                with self.path.open('rb') as log:
                    start = max(self._offset, stat.st_size - 64 * 1024)
                    log.seek(start)
                    chunk = log.read(64 * 1024)
                    if start > self._offset:
                        self._pending = b''
                        chunk = chunk.partition(b'\n')[2]
                    self._offset = log.tell()
                *lines, self._pending = (self._pending + chunk).split(b'\n')
                if len(self._pending) > 24000:
                    self._pending = b''
                for line in lines:
                    text = line.decode('utf-8', errors='replace')
                    if HOST_MARKER in text:
                        self.broadcast_url = _broadcast(text)
                        self._native_match = None
                        self._minimap = None
                        self._clear()
                    elif MATCH_MARKER in text:
                        native = _native_match(text)
                        if native != self._native_match and self._native_match:
                            self._clear()
                        self._native_match = native
                    elif MINIMAP_MARKER in text:
                        if include_minimap:
                            frame = _parse_minimap_line(text)
                            if frame is not None and self._fresh_minimap(frame[0]):
                                self._minimap = frame
                    elif not include_telemetry:
                        continue
                    elif MARKER in text:
                        sample = parse_health_line(text)
                        if sample is not None:
                            self._last, self._time = sample, now
                    elif PART_MARKER in text:
                        snapshot = self._read_part(text)
                        if snapshot is not None:
                            self._accept(snapshot, now)
                    elif TELEMETRY_MARKER in text:
                        snapshot = parse_telemetry_line(text)
                        if snapshot is not None:
                            self._accept(snapshot, now)
        except OSError:
            self.broadcast_url = self._native_match = None
            self._last = self._time = None
            self._telemetry = self._telemetry_time = None
            self._camera_switch_since = None
            self._rift = self._rift_time = None
            self._mid_boss = self._mid_boss_time = self._roster_time = None
            self._world_events = self._world_feed_time = None
            self._frame = self._frame_time = None
            self._minimap = None
            self._respawns = _RespawnCountdowns()
        if self._time is None or now - self._time > 1.25:
            return None
        return self._last

    @staticmethod
    def _fresh_minimap(at):
        return -250 <= time.time_ns() // 1_000_000 - at <= MINIMAP_LIFETIME_MS

    def minimap_markers(self):
        if self._minimap is not None and self._fresh_minimap(self._minimap[0]):
            return self._minimap[1]
        return ()

    def recent_portraits(self):
        """A new selection frame must never renew an old roster in JSON mode."""
        if self._stream is None:
            packet = self._current_telemetry()
        elif self._roster_time is not None and time.monotonic() - self._roster_time <= 4:
            packet = self._roster
        else:
            packet = None
        if packet is not None:
            return {'version': 1, 'teams': packet.get('teams', []), 'selected': {}}
        return None

    def telemetry(self, *, allow_clockless_roster=False):
        snapshot = self._current_telemetry()
        now = time.monotonic()
        objectives = {}
        if self._rift_time is not None and now - self._rift_time <= RIFT_LIFETIME:
            objectives['rift'] = self._rift
        if self._mid_boss_time is not None and now - self._mid_boss_time <= MID_BOSS_LIFETIME:
            objectives['midBoss'] = self._mid_boss
        if self._world_feed_time is not None and now - self._world_feed_time <= WORLD_FEED_LIFETIME:
            objectives['events'] = self._world_events
        if snapshot is None and self._roster_time is not None and now - self._roster_time <= MID_BOSS_LIFETIME:
            clock = self._roster.get('gameClock')
            if clock is not None or allow_clockless_roster:
                snapshot = {'version': 1, 'selected': {}, 'gameClock': clock,
                            'midBossTimer': self._roster.get('midBossTimer'),
                            'teams': self._respawns.project(self._roster['teams'], clock)}
        if objectives:
            return {**(snapshot or {'version': 1, 'teams': [], 'selected': {}}), **objectives}
        return snapshot

    def _current_telemetry(self):
        lifetime = 0.65 if self._stream is not None else 2
        fresh_since = self._camera_switch_since if self._camera_switch_since is not None else self._telemetry_time
        if fresh_since is None or time.monotonic() - fresh_since > lifetime:
            return None
        return self._telemetry

    def _clear(self):
        self._last = self._time = None
        self._telemetry = self._telemetry_time = None
        self._camera_switch_since = None
        self._rift = self._rift_time = None
        self._mid_boss = self._mid_boss_time = self._roster_time = None
        self._world_events = self._world_feed_time = None
        self._stream = self._roster = self._frame = self._frame_time = None
        self._fragments.clear()
        self._respawns = _RespawnCountdowns()

    def _accept(self, packet, now):
        kind = packet.get('kind')
        if kind not in ('frame', 'roster', 'rift', 'midboss', 'world-feed'):
            self._camera_switch_since = None
            self._telemetry, self._telemetry_time = packet, now
            return
        stream = packet.get('stream')
        if not isinstance(stream, str) or not stream or len(stream) > 64:
            return
        if stream != self._stream:
            self._clear()
            self._stream = stream
        if kind == 'rift':
            if 'rift' in packet:
                state = _rift_state(packet['rift'])
                if state is not None or packet['rift'] is None:
                    self._rift = state
                    self._rift_time = now if state is not None else None
            return
        if kind == 'midboss':
            if 'midBoss' in packet:
                state = _mid_boss_state(packet['midBoss'])
                if state is not None or packet['midBoss'] is None:
                    self._mid_boss = state
                    self._mid_boss_time = now if state is not None else None
            return
        if kind == 'world-feed':
            events = _world_feed(packet.get('events'))
            if events is not None:
                self._world_events = events
                self._world_feed_time = now if events else None
            return
        if kind == 'roster':
            if not isinstance(packet.get('teams'), list):
                return
            self._roster = packet
            self._roster_time = now
        else:
            selected = packet.get('selected')
            if selected is None and packet.get('switching') is True:
                # Hold the complete previous frame once while the new camera settles.
                if self._camera_switch_since is None and self._frame is not None and self._current_telemetry() is not None:
                    self._camera_switch_since = now
                return
            self._camera_switch_since = None
            hp = _health_sample(selected)
            self._frame = packet if hp else None
            self._frame_time = now if self._frame is not None else None
            self._last, self._time = hp, now if hp else None
            if self._frame is None:
                self._telemetry = self._telemetry_time = None
        if self._roster is None or self._frame is None:
            return
        selected = self._frame['selected']
        details = self._roster.get('details', {})
        legacy = {'abilities': [], 'items': []}
        if (isinstance(details, dict) and details.get('player') == selected['player'] and
                details.get('selection') == self._frame.get('selection')):
            legacy.update({key: details[key] for key in legacy if key in details})
        clock = self._frame.get('gameClock')
        self._telemetry = {
            'version': 1,
            'gameClock': clock,
            'midBossTimer': self._roster.get('midBossTimer'),
            'teams': self._respawns.project(self._roster['teams'], clock),
            'sampledAt': self._frame.get('sampledAt'),
            'selection': self._frame.get('selection'),
            'selected': {**legacy, **selected},
        }
        self._telemetry_time = self._frame_time

    def _read_part(self, line):
        _, _, payload = line.partition(PART_MARKER)
        try:
            data = json.loads(payload)
            session, sequence = data['session'], data['sequence']
            index, total, part = data['index'], data['total'], data['part']
        except (ValueError, TypeError, KeyError):
            return None
        if (not isinstance(session, str) or len(session) > 64 or type(sequence) is not int
                or type(index) is not int or type(total) is not int or not 0 <= index < total <= 36
                or not isinstance(part, str) or len(part) > 650):
            return None
        key = session, sequence
        if len(self._fragments) >= 4 and key not in self._fragments:
            del self._fragments[next(iter(self._fragments))]
        expected, parts = self._fragments.setdefault(key, (total, {}))
        if expected != total:
            return None
        parts[index] = part
        if len(parts) != total:
            return None
        del self._fragments[key]
        return parse_telemetry_line(TELEMETRY_MARKER + ''.join(parts[i] for i in range(total)))
