"""Apply a confirmed match roster to the existing vMix banks without room data."""
from ipaddress import IPv4Address
from xml.etree.ElementTree import ParseError

from PySide6.QtCore import QObject, QTimer, Signal

from .camera_native_recovery import title_matches
from .camera_native_setup import fixed_bank
from .camera_native_sync import NativePair, check_native_layout, read_native_catalog
from .camera_vdo_publish import VmixRequest
from .match_stats import is_lan_address


class MatchLabels(QObject):
    finished = Signal(str)
    writing = Signal()

    def __init__(self, settings, parent):
        super().__init__(parent)
        self.settings = settings
        self.http = VmixRequest(self)
        self.retry = QTimer(self, singleShot=True, interval=120)
        self.retry.timeout.connect(self._read)
        self.busy = False

    def start(self, endpoint, names, valid):
        if self.busy:
            return
        self.bank = None
        self.confirmed = 0
        self.writes = 0
        host, port = endpoint
        try:
            ip = IPv4Address(host)
            if not (ip.is_loopback or is_lan_address(ip)) or not 1 <= port <= 65535:
                raise ValueError
        except ValueError:
            self.finished.emit('Проверьте IP и порт Web Controller во вкладке VDO Ninja.')
            return
        self.endpoint = endpoint
        self.url = f'http://{ip}:{port}/api/'
        self.names = tuple(names)
        self.valid = valid
        self.pending = None
        self.confirmed = self.polls = 0
        self.sent = False
        self.busy = True
        self._read()

    def cancel(self):
        self.busy = False
        self.http.cancel()
        self.retry.stop()

    def _finish(self, message):
        self.cancel()
        self.finished.emit(f'{message} Подтверждено входов: {self.confirmed}/24.')

    def _read(self):
        if self.busy:
            self.http.send(self.url, None, self._received)

    def _received(self, error, xml):
        if error:
            self._finish(f'vMix {self.endpoint[0]}:{self.endpoint[1]}: {error}.')
            return
        try:
            state, parents = read_native_catalog(xml)
            order, mapping = fixed_bank(self.settings, self.endpoint, state, parents)
            keys = tuple(order[:24])
            if len(keys) != 24 or [mapping.get(g) for g in keys[:12]] != list(keys[12:]):
                raise ValueError('Проверьте пары оригиналов 1–12 и копий 13–24.')
            pairs = tuple(NativePair(g, mapping[g], name, operator_verified=True)
                          for g, name in zip(keys[:12], self.names))
            check_native_layout(state, parents, pairs)
            if self.bank is not None and self.bank != (state.preset, keys):
                raise ValueError('Пресет или порядок входов изменился. Повторите применение.')
            self.bank = state.preset, keys
            if not self.valid(state.preset, set(keys)):
                raise ValueError('Матч, адрес или управление входами изменились. Проверьте состояние и повторите.')
        except (ValueError, ParseError) as exc:
            self._finish(str(exc))
            return
        titles = self.names + tuple(name + ' - Virtual' for name in self.names)
        missing = [i for i, g in enumerate(keys)
                   if not title_matches(state.inputs[g]['title'], titles[i], virtual=i >= 12)]
        self.confirmed = 24 - len(missing)
        if not missing:
            self._finish('Ники матча применены.')
            return
        if self.pending in missing:
            self.polls += 1
            if self.polls >= 8:
                self._finish(f'vMix не подтвердил название входа {self.pending + 1}. Повторите применение.')
            else:
                self.retry.start()
            return
        if self.writes >= 24:
            self._finish('Названия меняются во время записи. Проверьте управление входами и повторите применение.')
            return
        self.writes += 1
        self.pending = i = missing[0]
        self.polls = 0
        if not self.sent:
            self.sent = True
            self.writing.emit()
        self.http.send(self.url, dict(Function='SetInputName', Input=keys[i], Value=titles[i]), self._written)

    def _written(self, error, _):
        if error:
            self._finish(f'Вход {self.pending + 1}: {error}. Повторите применение.')
        else:
            self._read()
