"""Best-effort Pop Manager coordination over local IPv4 broadcast.

Workstations advertise their controller endpoint, enabled Mix numbers and physical sorting
activity. A missed or filtered broadcast can leave a peer undiscovered. Direct vMix clients
do not participate. No workstation names, room information or credentials are transmitted.
"""

from dataclasses import dataclass
from ipaddress import IPv4Address
import json
import re
from time import monotonic
from uuid import uuid4

from PySide6.QtCore import QObject, QTimer, Signal
from PySide6.QtNetwork import QAbstractSocket, QHostAddress, QNetworkInterface, QUdpSocket

from .match_stats import is_lan_address


PORT = 53560
HEARTBEAT_MS = 2000
LEASE_SECONDS = 8
MAX_DATAGRAM = 65507  # Maximum IPv4 UDP payload.
MAX_PEERS = 512
MAX_MIX = 2**31 - 1


def _endpoint(raw):
    if not isinstance(raw, (list, tuple)) or len(raw) != 2:
        return None
    host, port = raw
    if not isinstance(host, str) or type(port) is not int or not 1 <= port <= 65535:
        return None
    try:
        ip = IPv4Address(host.strip())
    except ValueError:
        return None
    return (str(ip), port) if ip.is_loopback or is_lan_address(ip) else None


def _destinations(endpoint):
    # Keep loopback claims on this computer. Workstations using the same external
    # controller also exchange advertisements on each private IPv4 interface.
    targets = {'127.255.255.255'}
    if IPv4Address(endpoint[0]).is_loopback:
        return targets
    for interface in QNetworkInterface.allInterfaces():
        if not interface.flags() & QNetworkInterface.InterfaceFlag.IsUp:
            continue
        for entry in interface.addressEntries():
            if (entry.ip().protocol() == QAbstractSocket.NetworkLayerProtocol.IPv4Protocol
                    and 0 < entry.prefixLength() <= 30 and not entry.broadcast().isNull()
                    and is_lan_address(IPv4Address(entry.ip().toString()))):
                targets.add(entry.broadcast().toString())
    return targets


@dataclass(frozen=True)
class _Advertisement:
    sequence: int
    endpoint: tuple
    mixes: frozenset
    sorting: bool
    expires: float


class PopMixPeers(QObject):
    """Independent, renewable claims. Duplicate enabled Mixes stay claimed by both peers."""
    changed = Signal()

    def __init__(self, parent=None, *, port=PORT, clock=monotonic):
        super().__init__(parent)
        self._clock = clock
        self._port = port
        self._nonce = uuid4().hex
        self._sequence = 0
        self._endpoint = None
        self._mixes = frozenset()
        self._sorting = False
        self._peers = {}
        self._visible = (frozenset(), False, False)
        self.available = False
        self._closed = False
        self._socket = QUdpSocket(self)
        self._socket.readyRead.connect(self._read)
        self._timer = QTimer(self, interval=HEARTBEAT_MS)
        self._timer.timeout.connect(self._heartbeat)
        self._timer.start()

    def set_claims(self, endpoint, mixes, *, sorting=False):
        """Advertise every enabled local destination even while a peer also claims it."""
        endpoint = _endpoint(endpoint)
        enabled = frozenset(n for n in mixes if type(n) is int and 1 <= n <= MAX_MIX)
        sorting = bool(sorting)
        if self._closed or (endpoint, enabled, sorting) == (self._endpoint, self._mixes, self._sorting):
            return
        if self._endpoint and self._endpoint != endpoint:
            self._announce(self._endpoint, (), False)
        self._endpoint, self._mixes, self._sorting = endpoint, enabled, sorting
        self._heartbeat()

    def conflicts(self, endpoint, mix):
        """Whether another live instance claims this controller's Mix."""
        endpoint = _endpoint(endpoint)
        now = self._clock()
        return any(peer.endpoint == endpoint and now < peer.expires and mix in peer.mixes
                   for peer in self._peers.values())

    def remote_sorting(self, endpoint):
        endpoint = _endpoint(endpoint)
        now = self._clock()
        return any(peer.endpoint == endpoint and now < peer.expires and peer.sorting
                   for peer in self._peers.values())

    def close(self):
        if self._closed:
            return
        self._closed = True
        self._timer.stop()
        if self._endpoint and self._socket.state() == QAbstractSocket.SocketState.BoundState:
            self._announce(self._endpoint, (), False)
        self._socket.close()
        self._peers.clear()
        self.available = False
        self._publish()

    def _heartbeat(self):
        if self._closed:
            return
        now = self._clock()
        self._peers = {nonce: peer for nonce, peer in self._peers.items() if now < peer.expires}
        self.available = bool(self._endpoint and self._announce(self._endpoint, self._mixes, self._sorting))
        self._publish()

    def _announce(self, endpoint, mixes, sorting):
        if self._socket.state() != QAbstractSocket.SocketState.BoundState:
            mode = QAbstractSocket.BindFlag.ShareAddress | QAbstractSocket.BindFlag.ReuseAddressHint
            if not self._socket.bind(QHostAddress.SpecialAddress.AnyIPv4, self._port, mode):
                return False
            self._port = self._socket.localPort()
        self._sequence += 1
        packet = json.dumps({'popMixPeers': 1, 'instance': self._nonce, 'sequence': self._sequence,
                             'endpoint': endpoint, 'mixes': sorted(mixes), 'sorting': sorting},
                            separators=(',', ':')).encode('ascii')
        if len(packet) > MAX_DATAGRAM:
            return False
        loopback = IPv4Address(endpoint[0]).is_loopback
        sent = False
        for target in _destinations(endpoint):
            success = self._socket.writeDatagram(packet, QHostAddress(target), self._port) == len(packet)
            if loopback or not IPv4Address(target).is_loopback:
                sent |= success
        return sent

    def _read(self):
        while self._socket.hasPendingDatagrams():
            message = self._socket.receiveDatagram(MAX_DATAGRAM)
            self._receive(bytes(message.data()), message.senderAddress().toString())

    def _receive(self, payload, source):
        if self._closed or not 0 < len(payload) <= MAX_DATAGRAM:
            return
        try:
            sender = IPv4Address(source)
            data = json.loads(payload)
        except (ValueError, UnicodeError, RecursionError):
            return
        if not (sender.is_loopback or is_lan_address(sender)) or not isinstance(data, dict):
            return
        if type(data.get('popMixPeers')) is not int or data['popMixPeers'] != 1:
            return
        nonce, seq = data.get('instance'), data.get('sequence')
        if (not isinstance(nonce, str) or not re.fullmatch('[0-9a-f]{32}', nonce) or nonce == self._nonce
                or type(seq) is not int or not 1 <= seq <= 2**63 - 1):
            return
        endpoint, mixes, sorting = _endpoint(data.get('endpoint')), data.get('mixes'), data.get('sorting')
        if (not endpoint or (IPv4Address(endpoint[0]).is_loopback and not sender.is_loopback)
                or type(sorting) is not bool or not isinstance(mixes, list)
                or any(type(n) is not int or not 1 <= n <= MAX_MIX for n in mixes)):
            return
        previous = self._peers.get(nonce)
        if previous and seq <= previous.sequence:
            return
        if not previous and len(self._peers) >= MAX_PEERS:
            return
        self._peers[nonce] = _Advertisement(seq, endpoint, frozenset(mixes), sorting, self._clock() + LEASE_SECONDS)
        # Respond once to a new workstation so it can see our claims before the next heartbeat.
        if previous is None and self._endpoint == endpoint:
            self._announce(self._endpoint, self._mixes, self._sorting)
        self._publish()

    def _publish(self):
        now = self._clock()
        visible = [p for p in self._peers.values() if p.endpoint == self._endpoint and now < p.expires]
        state = (frozenset().union(*(p.mixes for p in visible)), any(p.sorting for p in visible), self.available)
        if self._visible != state:
            self._visible = state
            self.changed.emit()
