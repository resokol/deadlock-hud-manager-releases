"""Mount a manager-owned Panorama pack for one game process."""

from hashlib import sha256
import json
import logging
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

from .native_hud_config import normalize_native_hud_options, rewrite_native_hud_pack
from .panorama_outline import OUTLINE_RESOURCE, recolor_spectator_outlines


NUMBER_MODES = ('overlay', 'replace', 'local')


def _cached_packs():
    directory = Path(os.environ['LOCALAPPDATA']) / 'DeadlockHUDManager' / 'Panorama'
    return directory / 'normal.vpk', directory / 'minimap.vpk'


def _release_directory():
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).parent / 'Panorama'
    return None


def packs():
    root = _release_directory()
    if root is not None:
        from ._release_keys import RELEASE

        directory = root / RELEASE['version']
        normal = directory / 'normal.vpk'
        if normal.is_file():
            return normal, directory / 'minimap.vpk'
    portable = Path(__file__).resolve().parent.parent / 'Resources' / 'Panorama'
    if (portable / 'normal.vpk').is_file():
        return portable / 'normal.vpk', portable / 'minimap.vpk'
    return _cached_packs()


def _digest(path):
    return sha256(path.read_bytes()).digest()


def _replace(installed, source):
    with tempfile.NamedTemporaryFile(dir=installed.parent, suffix='.tmp', delete=False) as stream:
        temp = Path(stream.name)
        with source.open('rb') as payload:
            shutil.copyfileobj(payload, stream)
    try:
        os.replace(temp, installed)
    finally:
        temp.unlink(missing_ok=True)


def _seed(installed, source):
    installed.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=installed.parent, delete=False) as stream:
        temp = Path(stream.name)
    try:
        shutil.copyfile(source, temp)
        # Both operations fail if another add-on has already claimed the path.
        if sys.platform == 'win32':
            temp.rename(installed)
        else:
            os.link(temp, installed)
    except FileExistsError:
        pass
    finally:
        temp.unlink(missing_ok=True)


def _numbered_pack(path, numbers):
    return path if numbers == 'off' else path.with_stem(f'{path.stem}-{numbers}')


def _logo_pack(minimap):
    return minimap.with_stem(f'{minimap.stem}-logo')


def _fast_pack(path):
    return path.with_stem(f'{path.stem}-fast')


def _pause_pack(fast):
    return fast.with_stem(f'{fast.stem}-pause')


def _rift_pack(path):
    return path.with_stem(f'{path.stem}-rift')


def _mid_boss_pack(rift):
    return rift.with_stem(f'{rift.stem}-midboss')


def fast_normal_available():
    normal, _ = packs()
    fast = _fast_pack(normal)
    rift = _rift_pack(fast)
    return _mid_boss_pack(rift).is_file() or rift.is_file() or fast.is_file()


def _variants(normal, minimap):
    logo = _logo_pack(minimap)
    normal_fast, logo_fast = _fast_pack(normal), _fast_pack(logo)
    pause = _pause_pack(logo_fast)
    rifts = _rift_pack(normal_fast), _rift_pack(pause)
    bases = (normal, minimap, logo, normal_fast, logo_fast, pause,
             *rifts, *(_mid_boss_pack(rift) for rift in rifts))
    return [*bases[1:], *(_numbered_pack(path, mode) for path in bases for mode in NUMBER_MODES)]


def _known_packs(current):
    sources = [current, _cached_packs()]
    previous = current[0].parent / 'previous' / 'normal.vpk'
    if previous.is_file():
        sources.append((previous, previous.with_name('minimap.vpk')))
    root = _release_directory()
    if root is not None and root.is_dir():
        sources.extend((directory / 'normal.vpk', directory / 'minimap.vpk')
                       for directory in root.iterdir() if directory.is_dir())
    # A game launched with an older installation can leave its own pack mounted.
    return [path for normal, minimap in dict.fromkeys(sources)
            for path in (normal, *_variants(normal, minimap))] + list(_configured_directory().glob('*/*.vpk'))


def _configured_directory():
    return _cached_packs()[0].parent / 'configured'


def _configure_pack(selected, options, stock_index):
    if options is None:
        return selected
    outline = None
    colors = options.get('minimapTeamColors')
    if colors:
        from .build_panorama_health import read_vpk

        try:
            resource = read_vpk(stock_index, {OUTLINE_RESOURCE})[OUTLINE_RESOURCE]
            outline = recolor_spectator_outlines(resource, colors)
        except (IndexError, OSError, ValueError) as exc:
            logging.getLogger(__name__).warning('Could not apply Deadlock observer outline colors: %s', exc)
    config = _digest(selected) + json.dumps(options, sort_keys=True).encode('ascii')
    fingerprint = sha256(config + (outline or b'')).hexdigest()
    target = _configured_directory() / fingerprint / selected.name
    return rewrite_native_hud_pack(selected, target, options, outline=outline)


def restore(installed, mounted=None):
    normal, minimap = packs()
    if not installed.is_file() or not normal.is_file():
        return
    installed_digest = _digest(installed)
    if installed_digest == _digest(normal):
        return
    if any((mounted is None or path.name == mounted) and path.is_file() and _digest(path) == installed_digest
           for path in _known_packs((normal, minimap))):
        _replace(installed, normal)


def prepare_normal(citadel):
    """Seed the startup sampler for a subsequent Steam launch; never replace an existing add-on."""
    installed = citadel / 'addons' / 'pak88_dir.vpk'
    if installed.exists():
        return
    from .steam import is_deadlock_running
    try:
        if is_deadlock_running():
            return
    except (OSError, subprocess.SubprocessError):
        return
    normal, _ = packs()
    if normal.is_file():
        _seed(installed, normal)


def mount(citadel, *, minimap_only=True, numbers='off', native_hud=None):
    normal, minimap = packs()
    if numbers not in ('off', *NUMBER_MODES):
        raise RuntimeError('Неизвестный режим номеров на миникарте.')
    base = _logo_pack(minimap) if minimap_only else normal
    fast = _fast_pack(base)
    preferred = _pause_pack(fast) if minimap_only else fast
    fallbacks = (fast, base, minimap) if minimap_only else (base,)
    rift = _rift_pack(preferred)
    variants = (_mid_boss_pack(rift), rift, preferred, *fallbacks)
    paths = [_numbered_pack(path, numbers) for path in variants]
    selected = next((path for path in paths if path.is_file()), paths[-1])
    if numbers != 'off' and not selected.is_file():
        raise RuntimeError('Пакет Panorama для выбранного режима номеров не установлен.')
    installed = citadel / 'addons' / 'pak88_dir.vpk'
    if not all(path.is_file() for path in (normal, selected)):
        raise RuntimeError('Установите базовый и выбранный пакеты Panorama.')
    try:
        selected = _configure_pack(selected, normalize_native_hud_options(native_hud), citadel / 'pak01_dir.vpk')
    except ValueError as exc:
        raise RuntimeError(str(exc)) from exc
    if not installed.exists():
        _seed(installed, normal)
    installed_digest = _digest(installed)
    if not any(path.is_file() and _digest(path) == installed_digest
               for path in _known_packs((normal, minimap))):
        raise RuntimeError('Пакет Panorama в папке игры изменён. Новый режим не применён.')
    _replace(installed, selected)
    argv = [sys.executable]
    if getattr(sys, 'frozen', False):
        argv.append('--restore-panorama-pack')
    else:
        argv.extend(['-m', 'observer_assist.panorama_mount'])
    try:
        subprocess.Popen([*argv, str(installed), selected.name], creationflags=subprocess.DETACHED_PROCESS,
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        restore(installed)
        raise
    return installed


def watch(installed, mounted=None):
    from .steam import is_deadlock_running

    deadline = time.monotonic() + 90
    seen = False
    absent = 0
    while True:
        try:
            running = is_deadlock_running()
        except (OSError, subprocess.SubprocessError):
            time.sleep(2)
            continue
        if running:
            seen, absent = True, 0
        else:
            absent += 1
            if (seen and absent >= 2) or time.monotonic() >= deadline:
                break
        time.sleep(2)
    for _ in range(5):
        try:
            restore(installed, mounted)
            return
        except OSError:
            time.sleep(1)


if __name__ == '__main__':
    watch(Path(sys.argv[1]), *sys.argv[2:])
