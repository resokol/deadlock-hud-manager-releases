"""Publish one selection of guest URLs and labels to existing vMix browser inputs."""

from collections import Counter, deque
from dataclasses import dataclass, field
from hashlib import sha256
from ipaddress import IPv4Address
from types import MappingProxyType
from urllib.parse import urlencode
from xml.etree import ElementTree

from PySide6.QtCore import QObject, QTimer, QUrl, Signal
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkProxy, QNetworkReply, QNetworkRequest

from .camera_preparation import camera_identity, camera_page
from .camera_vmix import _read_state, browser_source
from .match_stats import is_lan_address
from .vmix_control import REQUEST_TIMEOUT_MS, _guid


@dataclass(frozen=True)
class AppliedInput:
    number: int
    guid: str
    label: str
    empty: bool


@dataclass(frozen=True)
class AppliedBatch:
    endpoint: tuple
    preset: str
    rows: tuple
    browser_inputs: object = field(default_factory=dict, repr=False, compare=False)


@dataclass
class _Row:
    page: str
    label: str
    number: int
    guid: str = ''
    done: bool = False
    started: bool = False

    @property
    def clear(self):
        return self.page == '' and self.label == '-'


@dataclass
class _Batch:
    address: tuple
    url: QUrl
    rows: list
    validate: object
    authorize: object
    queue: deque = field(default_factory=deque)
    counts: Counter = field(default_factory=Counter)
    preset: str = ''
    cancelling: bool = False
    browser_inputs: dict = field(default_factory=dict)
    inspected: bool = False
    inspection_message: str = ''
    seen_catalog: bool = False
    initial_bank: dict | None = None


class VmixRequest(QObject):
    """One finite vMix Web API request, cancelled without delivering stale callbacks."""

    def __init__(self, parent):
        super().__init__(parent)
        self._network = QNetworkAccessManager(self)
        self._network.setProxy(QNetworkProxy(QNetworkProxy.ProxyType.NoProxy))
        self._reply = None
        self._deadline = QTimer(self, singleShot=True)
        self._deadline.timeout.connect(self._timeout)

    def cancel(self):
        self._deadline.stop()
        reply, self._reply = self._reply, None
        if reply is not None:
            reply.abort()

    def send(self, address, command, callback):
        url = QUrl(address)
        if command:
            url.setQuery(urlencode(command))
        request = QNetworkRequest(url)
        request.setTransferTimeout(REQUEST_TIMEOUT_MS)
        request.setAttribute(QNetworkRequest.Attribute.RedirectPolicyAttribute,
                             QNetworkRequest.RedirectPolicy.ManualRedirectPolicy)
        reply = self._network.get(request)
        self._reply = reply

        def finished():
            # Release the Python callback while the request and its network manager
            # are still alive, including when a panel cancels an outstanding read.
            QObject.disconnect(connection)
            reply.deleteLater()
            if self._reply is not reply:
                return
            self._reply = None
            self._deadline.stop()
            code = reply.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute)
            ok = code == 200 and reply.error() == QNetworkReply.NetworkError.NoError
            error = '' if ok else (f'HTTP {code}' if code else 'нет ответа от Web Controller')
            payload = bytes(reply.readAll()) if ok else b''
            if command and ok:
                response = payload[:8192].lower()
                if any(word in response for word in (b'failed', b'error', b'not supported', b'not found', b'denied')):
                    error = 'Web Controller отклонил функцию'
            callback(error, payload if not command else b'')

        connection = reply.finished.connect(finished)
        self._deadline.start(REQUEST_TIMEOUT_MS)

    def _timeout(self):
        if self._reply is not None:
            self._reply.abort()


class VdoVmixPublisher(QObject):
    """Finite batches. The private first argument of result identifies the panel row."""

    result = Signal(str, str)
    position_result = Signal(int, str)
    batch_completed = Signal(int, int, int)
    finished = Signal(str)

    def __init__(self, parent=None, *, settings=None):
        super().__init__(parent)
        self._settings = settings
        self._recheck = {}
        self._http = VmixRequest(self)
        self._batch = None
        self.last_receipt = None
        self._pages = {}  # (endpoint, GUID) -> digest of acknowledged navigation
        self._presets = {}

    @property
    def busy(self):
        return self._batch is not None

    @property
    def active_endpoint(self):
        return self._batch.address if self._batch is not None else None

    @staticmethod
    def _page_group(endpoint):
        digest = sha256(f'{endpoint[0]}:{endpoint[1]}'.encode()).hexdigest()
        return f'nativePageAckV1/{digest}'

    def _select_preset(self, endpoint, preset):
        if self._presets.get(endpoint) == preset:
            return
        first = endpoint not in self._presets
        self._presets[endpoint] = preset
        self._pages = {key: value for key, value in self._pages.items() if key[0] != endpoint}
        self._recheck.pop(endpoint, None)
        if self._settings is None:
            return
        group = self._page_group(endpoint)
        token = sha256(preset.encode()).hexdigest()
        if first and preset and self._settings.value(f'{group}/preset', '', type=str) == token:
            self._settings.beginGroup(group)
            try:
                for guid in self._settings.childKeys():
                    if _guid(guid) != guid:
                        continue
                    raw = self._settings.value(guid, '', type=str)
                    if len(raw) != 64:
                        continue
                    try:
                        self._pages[endpoint, guid] = bytes.fromhex(raw)
                    except ValueError:
                        continue
                    self._recheck.setdefault(endpoint, set()).add(guid)
            finally:
                self._settings.endGroup()
        else:
            self._settings.remove(group)
            if preset:
                self._settings.setValue(f'{group}/preset', token)

    def needs_page_check(self, endpoint, preset):
        self._select_preset(endpoint, preset)
        return bool(self._recheck.get(endpoint))

    def observe_pages(self, endpoint, state, xml):
        """Discard stale ACKs before trusting them across a process restart.

        Public vMix XML does not promise a CEF URL. Where provided, compare the
        actual input's URL privately; a missing field leaves the last ACK in force.
        """
        self._select_preset(endpoint, state.preset)
        for cache_endpoint, guid in list(self._pages):
            if cache_endpoint == endpoint and guid not in state.browsers:
                self.invalidate_page(endpoint, guid)
        recovered = self._recheck.pop(endpoint, set())
        if not recovered:
            return
        for entry in ElementTree.fromstring(xml).findall('./inputs/input'):
            guid = _guid(entry.get('key'))
            if guid not in recovered:
                continue
            # An initial URL or input title need not follow CEF navigation.
            current = entry.get('currentUrl') or entry.get('browserCurrentUrl')
            if current and current.startswith(('https://', 'http://', 'about:')):
                if self._pages.get((endpoint, guid)) != sha256(current.encode()).digest():
                    self.invalidate_page(endpoint, guid)

    def page_acknowledged(self, endpoint, preset, guid, rendered):
        self._select_preset(endpoint, preset)
        return self._pages.get((endpoint, guid)) == sha256(rendered.encode()).digest()

    def invalidate_page(self, endpoint, guid):
        self._pages.pop((endpoint, guid), None)
        self._recheck.get(endpoint, set()).discard(guid)
        if self._settings is not None and _guid(guid) == guid:
            key = f'{self._page_group(endpoint)}/{guid}'
            if self._settings.contains(key):
                self._settings.remove(key)
                # A lost response or process exit can follow the navigation.
                self._settings.sync()

    def record_page(self, endpoint, preset, guid, rendered):
        self._select_preset(endpoint, preset)
        digest = sha256(rendered.encode()).digest()
        self._pages[endpoint, guid] = digest
        if self._settings is not None and preset and _guid(guid) == guid:
            self._settings.setValue(f'{self._page_group(endpoint)}/{guid}', digest.hex())

    def forget_pages(self, endpoint, guids):
        """Operator-requested reload or endpoint ownership handover."""
        for guid in guids:
            if key := _guid(guid):
                self.invalidate_page(endpoint, key)

    def forget(self, guids, endpoint=None):
        """Invalidate URL acknowledgements when another controller edited these inputs."""
        selected = {_guid(guid) for guid in guids} - {None}
        receipt = self.last_receipt
        if (receipt and (endpoint is None or endpoint == receipt.endpoint)
                and any(row.guid in selected for row in receipt.rows)):
            self.last_receipt = None
        if endpoint is not None:
            self.forget_pages(endpoint, selected)
            return
        for address in tuple(self._presets):
            self.forget_pages(address, selected)
        if self._settings is not None:
            self._settings.beginGroup('nativePageAckV1')
            try:
                for group in self._settings.childGroups():
                    for guid in selected:
                        self._settings.remove(f'{group}/{guid}')
            finally:
                self._settings.endGroup()

    def _address(self, host, port):
        try:
            ip = IPv4Address(host)
            port = int(port)
            if (is_lan_address(ip) or ip.is_loopback) and 1 <= port <= 65535:
                return str(ip), port
        except (TypeError, ValueError):
            pass
        self.finished.emit('Проверьте локальный IP-адрес и порт vMix.')
        return None

    @staticmethod
    def _rows(rows):
        try:
            targets = [_Row(page, label, number) for page, label, number in rows]
            if not 1 <= len(targets) <= 12 or any(
                type(row.number) is not int or row.number < 1 or not isinstance(row.label, str)
                or not isinstance(row.page, str) for row in targets
            ):
                raise ValueError
        except (TypeError, ValueError):
            raise ValueError('Выберите от 1 до 12 гостей и укажите их номера входов vMix.') from None
        numbers = {row.number for row in targets}
        cameras = [row for row in targets if not row.clear]
        try:
            guests = {camera_identity(row.page) for row in cameras}
        except ValueError:
            raise ValueError('Проверьте адреса страниц камер.') from None
        labels = [row.label.strip().casefold() for row in cameras if row.label.strip()]
        if len(numbers) != len(targets) or len(guests) != len(cameras) or len(set(labels)) != len(labels):
            raise ValueError('Повторяются гости, Label или номера входов. Проверьте назначения.')
        return targets

    def inspect_inputs(self, host, port, *, validate=None):
        """Read the Browser GUID catalog without navigating or renaming any input."""
        return self.start_preparation(host, port, resolve=lambda *_: [] if validate is None or validate() else None)

    def start_preparation(self, host, port, *, resolve, validate=None, authorize=None):
        """Resolve saved original GUIDs to their *current* numbers before planning writes."""
        if self.busy:
            return False
        self.last_receipt = None
        address = self._address(host, port)
        if not address:
            return False
        batch = _Batch(address, QUrl(f'http://{address[0]}:{address[1]}/api/'), [], validate, authorize)
        self._batch = batch

        def catalog(current, state):
            try:
                resolved = resolve(state.preset, MappingProxyType(current.browser_inputs))
            except Exception:
                resolved = None
            if self._batch is not current:
                return
            if resolved is None:
                self.cancel()
                return
            if not resolved:
                current.inspected = True
                current.inspection_message = 'GUID оригиналов прочитаны из vMix.'
                self._finish(current)
                return
            try:
                current.rows = self._rows(resolved)
            except ValueError as exc:
                self._end_remaining(current, 'error', str(exc))
                return
            current.initial_bank = {n: key for n, key in current.browser_inputs.items() if 1 <= n <= 12}
            if any(row.number not in current.initial_bank for row in current.rows):
                self._end_remaining(current, 'skip', 'Назначьте оригинальные Web Browser в диапазоне 1–12.')
                return
            self._plan(current, state)
        self._catalog(batch, catalog)
        return True

    def start(self, host, port, rows, *, validate=None, authorize=None):
        """An explicit ('', '-', number) clears that browser. validate guards each write."""
        if self.busy:
            return False
        self.last_receipt = None
        address = self._address(host, port)
        if not address:
            return False
        try:
            targets = self._rows(rows)
        except ValueError as exc:
            self.finished.emit(str(exc))
            return False
        url = QUrl(f'http://{address[0]}:{address[1]}/api/')
        batch = _Batch(address, url, targets, validate, authorize)
        self._batch = batch
        self._catalog(batch, self._plan)
        return True

    def cancel(self):
        batch = self._batch
        if batch is None or batch.cancelling:
            return
        batch.cancelling = True
        self._http.cancel()
        if not batch.rows:
            batch.counts['skip'] += 1
        for row in batch.rows:
            if not row.done:
                message = 'Дальнейшая отправка отменена. Проверьте вход в vMix.' if row.started else 'Отменено.'
                self._report(batch, row, 'skip', message)
        self._finish(batch)

    def _finish(self, batch):
        if self._batch is batch:
            self._batch = None
            counts = batch.counts
            if not batch.cancelling and (batch.inspected or (batch.rows and counts['ok'] == len(batch.rows))):
                self.last_receipt = AppliedBatch(batch.address, batch.preset, tuple(
                    AppliedInput(row.number, row.guid, row.label, row.clear) for row in batch.rows),
                    MappingProxyType(batch.browser_inputs))
            self.batch_completed.emit(counts['ok'], counts['skip'], counts['error'])
            prefix = 'Отправка отменена. ' if batch.cancelling else ''
            if batch.inspection_message:
                prefix += batch.inspection_message + ' '
            self.finished.emit(f'{prefix}Готово: {counts["ok"]}. Пропущено: {counts["skip"]}. Ошибок: {counts["error"]}.')

    def _report(self, batch, row, category, message):
        row.done = True
        batch.counts[category] += 1
        text = f'Вход {row.number}: {message}'
        self.result.emit(row.page, text)
        if self._batch is batch:
            self.position_result.emit(row.number, text)

    def _end_remaining(self, batch, category, message):
        if not batch.rows:
            batch.counts[category] += 1
            batch.inspection_message = message
        for row in batch.rows:
            if self._batch is not batch:
                return
            if not row.done:
                self._report(batch, row, category, message)
        self._finish(batch)

    def _request(self, batch, command, callback):
        self._http.send(batch.url, command, callback)

    def _catalog(self, batch, callback):
        def receive(error, payload):
            if error:
                self._end_remaining(batch, 'error', f'Не удалось прочитать входы vMix ({error}).')
                return
            try:
                state = _read_state(payload)
            except (ElementTree.ParseError, ValueError):
                self._end_remaining(batch, 'error', 'Web Controller вернул некорректный список входов.')
                return
            self.observe_pages(batch.address, state, payload)
            if batch.seen_catalog and batch.preset != state.preset:
                self._end_remaining(batch, 'skip', 'Пресет изменился. Проверьте номера входов.')
                return
            batch.preset = state.preset
            batch.seen_catalog = True
            batch.browser_inputs = {state.inputs[guid]['number']: guid for guid in state.browsers}
            if (batch.initial_bank is not None
                    and {n: key for n, key in batch.browser_inputs.items() if 1 <= n <= 12} != batch.initial_bank):
                self._end_remaining(batch, 'skip', 'Номера оригинальных камер изменились. Повторите применение.')
                return
            callback(batch, state)

        self._request(batch, None, receive)

    def _current(self, batch, row):
        try:
            valid = batch.validate is None or batch.validate(row.page, row.label, row.number)
        except Exception:
            valid = False
        if self._batch is not batch:
            return False
        if not valid:
            self._report(batch, row, 'skip', 'Гость или выбранный вход изменился.')
            return False
        return True

    def _plan(self, batch, state):
        numbers = {info['number']: guid for guid, info in state.inputs.items()}
        for row in batch.rows:
            if self._batch is not batch:
                return
            row.guid = numbers.get(row.number, '')
            url = QUrl(row.page, QUrl.ParsingMode.StrictMode)
            if not row.label.strip() or len(row.label) > 256 or not row.label.isprintable() or '://' in row.label:
                self._report(batch, row, 'skip', 'Нужен корректный Label гостя.')
            elif not row.clear and (not url.isValid() or url.scheme() not in ('http', 'https') or not url.host()):
                self._report(batch, row, 'skip', 'Некорректная ссылка гостя.')
            elif not row.guid:
                self._report(batch, row, 'skip', 'Вход отсутствует в пресете.')
            elif not browser_source(state.inputs[row.guid]):
                self._report(batch, row, 'skip', 'Нужен оригинальный вход Web Browser.')
            elif self._current(batch, row):
                batch.queue.append(row)
        if self._batch is not batch:
            return
        if batch.queue and batch.authorize is not None:
            try:
                approved = batch.authorize({row.guid for row in batch.queue})
            except Exception:
                approved = False
            if self._batch is not batch:
                return
            if not approved:
                self.cancel()
                return
        self._next(batch)

    def _next(self, batch):
        if self._batch is not batch:
            return
        if not batch.queue:
            self._finish(batch)
            return
        # Re-read after operator confirmation and between rows. Input numbers may move.
        self._catalog(batch, self._apply)

    def _apply(self, batch, state, *, navigated=False):
        row = batch.queue[0]
        info = state.inputs.get(row.guid, {})
        if info.get('number') != row.number or not browser_source(info):
            self._report(batch, row, 'skip', 'Вход изменился после проверки пресета.')
        elif self._current(batch, row):
            rendered = camera_page(row.page)
            applied = 'Прозрачный источник с названием «-».' if row.clear else 'Страница и Label применены.'
            if not self.page_acknowledged(batch.address, batch.preset, row.guid, rendered):
                if navigated:
                    self._complete_row(batch, row, 'skip', 'Источник изменился. Повторите проверку входа.')
                    return
                self.invalidate_page(batch.address, row.guid)
                row.started = True
                command = dict(Function='BrowserNavigate', Input=row.guid, Value=rendered)

                def after_navigation(error, _):
                    if error:
                        self._complete_row(batch, row, 'error', f'Не удалось открыть страницу ({error}).')
                    else:
                        self.record_page(batch.address, batch.preset, row.guid, rendered)
                        # Navigation can also change the current title. Check again before renaming.
                        self._catalog(batch, lambda current, catalog: self._apply(current, catalog, navigated=True))
                self._request(batch, command, after_navigation)
                return
            if info['title'] != row.label:
                row.started = True
                command = dict(Function='SetInputName', Input=row.guid, Value=row.label)

                def renamed(error, _):
                    if error:
                        self._complete_row(batch, row, 'error', f'Страница открыта, ошибка переименования ({error}).')
                    else:
                        self._complete_row(batch, row, 'ok', applied)
                self._request(batch, command, renamed)
                return
            self._report(batch, row, 'ok', applied)
        if self._batch is batch:
            batch.queue.popleft()
            self._next(batch)

    def _complete_row(self, batch, row, category, message):
        batch.queue.popleft()
        self._report(batch, row, category, message)
        self._next(batch)


def publish_room_cameras(parent, panel, room, publisher, cameras, legacy_panel, host, port, rows, *,
                         on_auto_conflict=None):
    from PySide6.QtWidgets import QMessageBox

    generation = room.generation

    def current(page, label, number):
        return (room.generation == generation and room.fresh
                and panel.is_current_vmix_row(page, label, number))

    def authorize(guids):
        endpoint = host, port
        roles = cameras.conflicting_modules(endpoint, guids)
        legacy = (not legacy_panel.suspended and legacy_panel.endpoint == endpoint
                  and (legacy_panel.rename or legacy_panel.player_pages) and
                  any(number in legacy_panel.inputs + legacy_panel.virtual_inputs for _, _, number in rows))
        if roles or legacy:
            names = ', '.join([r.title() for r in roles] + (['POV vMix'] if legacy else []))
            if on_auto_conflict:
                on_auto_conflict(f'Входы заняты: {names}. Для передачи управления примените назначения вручную.')
                return False
            choice = QMessageBox.question(parent, 'Передать входы в VDO Ninja',
                f'Этими входами управляет {names}. Остановить это управление и записать камеры из комнаты? '
                'Текущий выбор Program сохранится, изображение изменённых входов обновится.',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
            if choice != QMessageBox.StandardButton.Yes or not all(current(*row) for row in rows):
                return False
            if legacy:
                cameras.managed = True
                cameras.activated.emit()
                cameras.save()
            publisher.forget(guids, endpoint=endpoint)
        cameras.release_inputs(endpoint, guids, roles)
        return True

    if not room.fresh:
        panel.vmix_finished('Дождитесь свежего списка камер из комнаты.')
        return
    if getattr(panel, 'submitted_mode', '') == 'preparation' and getattr(panel, 'native_preparation', False):
        def resolve(preset, browsers):
            nonlocal rows
            if room.generation != generation or not room.fresh:
                return None
            rows = panel.preparation_from_catalog(preset, browsers)
            if (room.generation != generation or not room.fresh
                    or (rows is not None and not rows and not panel.preparation_read_only)):
                return None
            return rows
        publisher.start_preparation(host, port, resolve=resolve, validate=current, authorize=authorize)
    else:
        publisher.start(host, port, rows, validate=current, authorize=authorize)
