"""Read-only match data shared by the observer HUD and the camera director."""

from dataclasses import dataclass
from unicodedata import category

from .broadcast_tables import observed_hud_slot, players_by_portrait


POV_MATCH_ROUTE = '/api/v1/pov/match'


@dataclass(frozen=True)
class RemoteMatch:
    match_id: str
    names: tuple[str, ...]
    observed: int | None
    roster: dict | None

    @property
    def source(self):
        identity = f'матч {self.match_id}' if self.match_id else 'ожидаем Match ID'
        return f'Panorama по сети · 12 портретов слева направо · {identity}'


def _number(value, maximum_digits):
    if type(value) not in (int, str):
        return None
    text = str(value)
    if text.isascii() and text.isdecimal() and len(text) <= maximum_digits and int(text) > 0:
        return str(int(text))
    return None


def _ordered_names(slots, *, by_position=False):
    if not isinstance(slots, dict) or len(slots) != 12:
        return ()
    values = [slots.get(str(i)) for i in range(1, 13)]
    if not all(isinstance(name, str) and name.strip() and len(name) <= 256 for name in values):
        return ()
    if by_position:
        # Slot numbers disambiguate identical Steam names. Permit Unicode spaces and joiners.
        if any(any(not c.isprintable() and category(c) not in ('Cf', 'Zs') for c in n) for n in values):
            return ()
        return tuple(name.strip() for name in values)
    if not all(name.isprintable() for name in values):
        return ()
    names = tuple(name.strip() for name in values)
    return names if len({name.casefold() for name in names}) == 12 else ()


def _roster(match, teams, names, account_field):
    """Join only complete, unique account identities for exactly these 12 nicknames."""
    if not isinstance(teams, list) or len(teams) != 2:
        return None
    found = {}
    accounts = set()
    sides = set()
    for team in teams:
        if not isinstance(team, dict) or type(team.get('side')) is not int:
            return None
        side, players = team['side'], team.get('players')
        if side not in (2, 3) or side in sides or not isinstance(players, list) or len(players) != 6:
            return None
        sides.add(side)
        for player in players:
            if not isinstance(player, dict) or not isinstance(player.get('name'), str):
                return None
            name = player['name'].strip().casefold()
            account = _number(player.get(account_field), 10)
            if not account or int(account) > 0xffffffff or account in accounts or name in found:
                return None
            accounts.add(account)
            item = {'accountId': account}
            if isinstance(player.get('hero'), str) and len(player['hero']) <= 96:
                item['hero'] = player['hero']
            if type(player.get('heroId')) is int and player['heroId'] > 0:
                item['heroId'] = player['heroId']
            found[name] = side, item
    if found.keys() != {name.casefold() for name in names}:
        return None
    groups = {2: [], 3: []}
    for name in names:
        side, row = found[name.casefold()]
        groups[side].append({**row, 'name': name})
    return {'matchId': match, 'teams': [{'side': side, 'players': rows} for side, rows in groups.items()]}


def make_pov_snapshot(telemetry, match_id, source_roster):
    match = _number(match_id, 20)
    waiting = {'version': 1, 'status': 'waiting', 'panorama_match_id': match}
    if not telemetry:
        return {**waiting, 'reason': 'no_recent_sample'}
    teams = telemetry.get('teams') or []
    if (not isinstance(teams, list) or len(teams) != 2
            or not all(isinstance(t, dict) and type(t.get('side')) is int and isinstance(t.get('players'), list)
                       and all(isinstance(p, dict) and isinstance(p.get('name'), str) for p in t['players'])
                       for t in teams) or {t['side'] for t in teams} != {2, 3}):
        return {**waiting, 'reason': 'teams'}
    slots = players_by_portrait(teams)
    names = _ordered_names(slots, by_position=True)
    if not names:
        count = sum(len(t['players']) for t in teams)
        return {**waiting, 'reason': 'portraits', 'players': count}
    roster = _roster(match, teams, names, '_accountId') if match else None
    if match and not roster and source_roster and _number(source_roster.get('matchId'), 20) == match:
        roster = _roster(match, source_roster.get('teams'), names, 'accountId')
    return {'version': 1, 'status': 'live', 'panorama_match_id': match, 'panorama_slots': slots,
            'panorama_observed_slot': observed_hud_slot(slots, telemetry.get('selected')),
            'panorama_roster': roster}


def read_pov_snapshot(data, *, legacy=False, by_position=False):
    if (not isinstance(data, dict) or type(data.get('version')) is not int or data['version'] != 1):
        return None
    match = _number(data.get('panorama_match_id'), 20)
    if data.get('status') == 'waiting' and by_position and not legacy and match:
        return RemoteMatch(match, (), None, None)
    if data.get('status') != 'live':
        return None
    names = _ordered_names(data.get('panorama_slots'), by_position=by_position)
    pending_id = by_position and not legacy and 'panorama_match_id' in data and data['panorama_match_id'] is None
    if not names or not (match or pending_id) or (legacy and data.get('matchId') and _number(data['matchId'], 20) != match):
        return None
    observed = data.get('panorama_observed_slot')
    if observed is not None and (type(observed) is not int or not 1 <= observed <= 12):
        return None
    roster = None
    if not legacy and data.get('panorama_roster') is not None:
        supplied = data['panorama_roster']
        if not isinstance(supplied, dict) or _number(supplied.get('matchId'), 20) != match:
            return None
        roster = _roster(match, supplied.get('teams'), names, 'accountId')
        if not roster:
            return None
    return RemoteMatch(match or '', names, observed, roster)
