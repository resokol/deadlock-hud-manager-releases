"""Map top-bar positions to vMix inputs and route them to the selected Mix outputs."""

import json
import re
from ipaddress import ip_address

from PySide6.QtCore import Qt, QTimer, QUrl, Signal
from PySide6.QtWidgets import (
    QCheckBox, QFormLayout, QGridLayout, QGroupBox, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QPushButton, QSpinBox, QTableWidget, QTableWidgetItem, QVBoxLayout,
)

from .hud_nicknames import normalize_name
from .vmix_control import VmixInputNames, VmixProgram


def mix_numbers(text):
    if not text:
        return ()
    if not re.fullmatch(r'[1-9][0-9]*(?:[\s,;]+[1-9][0-9]*)*', text, re.ASCII):
        raise ValueError('Укажите номера Mix через запятую, например 2, 3.')
    return tuple(dict.fromkeys(map(int, re.findall(r'[0-9]+', text))))


class VmixPovPanel(QGroupBox):
    mappings_changed = Signal()

    def __init__(self, settings, *, suspended=False):
        super().__init__('Камеры по позициям 1–12')
        self.settings = settings
        self.input_names = VmixInputNames(self)
        self.program = VmixProgram(self)
        self.observer_program = VmixProgram(self)
        self.follow_update = QTimer(self, singleShot=True, interval=0)
        self.follow_update.timeout.connect(self._follow_observed)
        self.slots = {}
        self.inputs = tuple(range(1, 13))
        self.virtual_inputs = (0,) * 12
        self.original_mixes = self.copy_mixes = ()
        self.observed = None
        self.last_follow = None
        self.manual_slot = None
        self.player_pages = {}
        self.auto = self.rename = False
        self.endpoint = ('', 8088)
        try:
            config = json.loads(settings.value('povVmix', '{}', type=str))
        except ValueError:
            config = {}
        if not isinstance(config, dict):
            config = {}

        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.address = QLineEdit(str(config.get('address', '')))
        self.port = QSpinBox()
        self.port.setRange(1, 65535)
        self.port.setValue(config['port'] if type(config.get('port')) is int else 8088)
        self.mixes = QLineEdit(str(config.get('mixes', '')))
        self.mixes.setPlaceholderText('Например, 2, 3. Mix 1 — основной Program.')
        form.addRow('IP компьютера с vMix', self.address)
        form.addRow('Порт Web Controller', self.port)
        self.virtual_mixes = QLineEdit(str(config.get('virtualMixes', '')))
        self.virtual_mixes.setPlaceholderText('Например, 2')
        form.addRow('Mix обсервера · оригиналы', self.mixes)
        form.addRow('Mix Stream Deck · виртуальные копии', self.virtual_mixes)
        layout.addLayout(form)
        self.rename_inputs = QCheckBox('Переименовывать входы по никам игроков')
        self.rename_inputs.setChecked(config.get('renameInputs') is True)
        layout.addWidget(self.rename_inputs)
        self.follow = QCheckBox('Автоматически выводить игрока под наблюдением в выбранные Mix')
        self.follow.setChecked(config.get('followProgram') is True)
        layout.addWidget(self.follow)
        grid = QGridLayout()
        self.slot_inputs, self.copy_inputs, self.buttons = [], [], []
        for column, label in enumerate(('Позиция', 'Оригинал', 'Виртуальная копия', 'Stream Deck')):
            grid.addWidget(QLabel(label), 0, column)
        for index in range(12):
            slot = index + 1
            row = slot
            grid.addWidget(QLabel(str(slot)), row, 0)
            for col, fields, key, default in ((1, self.slot_inputs, 'slotInputs', slot),
                                              (2, self.copy_inputs, 'virtualInputs', 0)):
                field = QSpinBox()
                field.setRange(0, 9999)
                field.setSpecialValueText('Выкл.')
                saved = config.get(key)
                value = saved[index] if isinstance(saved, list) and len(saved) == 12 else default
                field.setValue(value if type(value) is int else default)
                fields.append(field)
                grid.addWidget(field, row, col)
            button = QPushButton('—')
            button.setEnabled(False)
            button.clicked.connect(lambda _, n=slot: self.take(n))
            self.buttons.append(button)
            grid.addWidget(button, row, 3)
        layout.addLayout(grid)
        layout.addWidget(QLabel('URL браузерных POV по никам игроков'))
        self.pages_table = QTableWidget(0, 2)
        self.pages_table.setHorizontalHeaderLabels(['Ник в Deadlock', 'URL Web Browser / WebRTC'])
        self.pages_table.horizontalHeader().setStretchLastSection(True)
        self.pages_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Interactive)
        self.pages_table.setMinimumHeight(150)
        layout.addWidget(self.pages_table)
        saved_pages = config.get('playerPages', {})
        if isinstance(saved_pages, dict):
            for nick, page in saved_pages.items():
                if isinstance(page, str):
                    self._add_page(nick, page)
        page_actions = QHBoxLayout()
        add = QPushButton('Добавить игрока')
        add.clicked.connect(lambda: self._add_page())
        remove = QPushButton('Удалить выбранную строку')
        remove.clicked.connect(lambda: self.pages_table.removeRow(self.pages_table.currentRow()))
        page_actions.addWidget(add)
        page_actions.addWidget(remove)
        page_actions.addStretch()
        layout.addLayout(page_actions)
        self.pages_status = QLabel()
        self.pages_status.setTextFormat(Qt.TextFormat.PlainText)
        self.pages_status.setWordWrap(True)
        layout.addWidget(self.pages_status)
        apply = QPushButton('Применить настройки POV')
        apply.clicked.connect(lambda: self._apply(save=True))
        layout.addWidget(apply, alignment=Qt.AlignmentFlag.AlignLeft)
        self.status, self.names_status = QLabel(), QLabel()
        for label in (self.status, self.names_status):
            label.setWordWrap(True)
            label.setTextFormat(Qt.TextFormat.PlainText)
            layout.addWidget(label)
        self.program.status.connect(self.status.setText)
        self.observer_status = QLabel()
        self.observer_status.setTextFormat(Qt.TextFormat.PlainText)
        self.observer_status.setWordWrap(True)
        layout.addWidget(self.observer_status)
        self.observer_program.status.connect(self.observer_status.setText)
        self.input_names.ready_changed.connect(self._show_routes)
        self.input_names.status.connect(self.names_status.setText)
        self.suspended = suspended
        if suspended:
            self.suspend()
        else:
            self._apply(save=False)

    def _add_page(self, nick='', page=''):
        row = self.pages_table.rowCount()
        self.pages_table.insertRow(row)
        for col, value in enumerate((nick, page)):
            self.pages_table.setItem(row, col, QTableWidgetItem(value))

    def _read_pages(self):
        saved, seen = {}, set()
        for row in range(self.pages_table.rowCount()):
            nick, page = (self.pages_table.item(row, col).text().strip() for col in (0, 1))
            if not page:
                continue
            key = normalize_name(nick)
            if not key or key in seen:
                raise ValueError(f'Проверьте ник в строке URL {row + 1}: нужен уникальный ник.')
            url = QUrl(page, QUrl.ParsingMode.StrictMode)
            if not url.isValid() or url.scheme() not in ('http', 'https') or not url.host():
                raise ValueError(f'Для игрока {nick} укажите полный HTTP(S) URL.')
            seen.add(key)
            saved[nick] = page
        return saved

    def _apply(self, *, save):
        address = self.address.text().strip()
        mixes_text = self.mixes.text().strip()
        copies_text = self.virtual_mixes.text().strip()
        auto, rename = self.follow.isChecked(), self.rename_inputs.isChecked()
        inputs = tuple(f.value() for f in self.slot_inputs)
        copies = tuple(f.value() for f in self.copy_inputs)
        try:
            pages = self._read_pages()
            mixes, copy_mixes = mix_numbers(mixes_text), mix_numbers(copies_text)
            if address:
                address = str(ip_address(address))
            if (auto or rename or mixes or copy_mixes or pages) and not address:
                raise ValueError('Укажите IP компьютера с vMix.')
            numbers = [n for n in (*inputs, *copies) if n]
            if len(numbers) != len(set(numbers)):
                raise ValueError('Укажите разные номера для оригиналов и копий. Ноль отключает вход.')
            if set(mixes).intersection(copy_mixes):
                raise ValueError('Один Mix не может получать одновременно оригинал и копию.')
            if auto and not mixes:
                raise ValueError('Укажите Mix для автоматического переключения.')
        except ValueError as exc:
            self.status.setText(str(exc))
            return
        self.endpoint = address, self.port.value()
        self.inputs, self.auto, self.rename = inputs, auto, rename
        self.virtual_inputs = copies
        self.original_mixes, self.copy_mixes = mixes, copy_mixes
        self.player_pages = {normalize_name(nick): page for nick, page in pages.items()}
        self.last_follow = None
        self.program.configure(*self.endpoint)
        self.observer_program.configure(*self.endpoint)
        if save:
            self.settings.setValue('povVmix', json.dumps(dict(address=address, port=self.port.value(),
                                   mixes=mixes_text, virtualMixes=copies_text, virtualInputs=copies, playerPages=pages,
                                   followProgram=auto, renameInputs=rename, slotInputs=inputs)))
        self.status.setText('Настройки POV применены.' if save else '')
        self._refresh()

    def suspend(self):
        self.suspended = True
        self.shutdown()
        self.auto = False
        self.setEnabled(False)
        self.status.setText('Управление передано в Live и Replay.')

    def resume(self):
        self.suspended = False
        self.setEnabled(True)
        self._apply(save=False)

    def set_hud_slots(self, slots):
        if self.suspended:
            return
        if slots != self.slots:
            self.program.cancel()
            self.observer_program.cancel()
            self.last_follow = None
            self.slots = slots
            known = {normalize_name(self.pages_table.item(i, 0).text()) for i in range(self.pages_table.rowCount())}
            for nick in slots.values():
                if normalize_name(nick) not in known:
                    self._add_page(nick)
                    known.add(normalize_name(nick))
            self._refresh()

    def targets(self, slot, *, automatic=False):
        name = self.slots.get(str(slot))
        if not name:
            return []
        original = self.inputs[slot - 1]
        if self.player_pages and not self.input_names.ready(original, self.player_pages.get(normalize_name(name))):
            return []
        number = original if automatic else self.virtual_inputs[slot - 1]
        mixes = self.original_mixes if automatic else self.copy_mixes
        return [(mix, number) for mix in mixes if number]

    def _expected_source(self, slot):
        if self.player_pages and slot:
            number = self.inputs[slot - 1]
            applied = self.input_names.applied.get(number)
            if applied:
                return number, applied[0]
        return None

    def _show_routes(self):
        if self.manual_slot and not self.targets(self.manual_slot):
            self.program.cancel()
            self.manual_slot = None
        for slot, button in enumerate(self.buttons, 1):
            name = self.slots.get(str(slot))
            button.setText(name or '—')
            button.setEnabled(bool(self.targets(slot)))
        self.mappings_changed.emit()
        self.follow_update.start()

    def _refresh(self):
        names, pages, missing = {}, {}, []
        for slot, number in enumerate(self.inputs, 1):
            name = self.slots.get(str(slot))
            if not name:
                continue
            if self.player_pages:
                page = self.player_pages.get(normalize_name(name))
                if number and page:
                    pages[number] = page
                elif self.virtual_inputs[slot - 1] or number:
                    missing.append(name)
            if self.rename:
                if number:
                    names[number] = name
                copy = self.virtual_inputs[slot - 1]
                if copy:
                    names[copy] = f'{name} (Virtual)'
        self.input_names.configure(*self.endpoint, names, pages)
        self.pages_status.setText('Проверьте URL и оригинальный вход: ' + ', '.join(missing) if missing else '')
        if not names and not pages:
            self.names_status.clear()
        self._show_routes()

    def set_observed(self, slot):
        if self.suspended:
            return
        self.observed = slot
        self._follow_observed()

    def _follow_observed(self):
        targets = self.targets(self.observed, automatic=True) if self.auto and self.observed else []
        expected = self._expected_source(self.observed)
        selection = (self.observed, tuple(targets), expected) if targets else None
        if selection != self.last_follow:
            self.last_follow = selection
            self.observer_program.select(targets, expected_source=expected)

    def take(self, slot):
        if type(slot) is int and 1 <= slot <= 12:
            self.manual_slot = slot
            self.program.select(self.targets(slot), expected_source=self._expected_source(slot))

    def shutdown(self):
        self.follow_update.stop()
        self.program.cancel()
        self.observer_program.cancel()
        self.input_names.close()
