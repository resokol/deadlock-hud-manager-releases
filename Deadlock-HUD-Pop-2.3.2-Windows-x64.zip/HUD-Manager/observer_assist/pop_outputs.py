"""Independently configured POV destinations, keyed by the physical vMix Mix number."""
import json

from PySide6.QtCore import QSignalBlocker, Signal
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QGridLayout, QHBoxLayout, QLabel, QPushButton, QSizePolicy, QSpinBox,
    QVBoxLayout, QWidget,
)


OUTPUTS_KEY = 'popOutputMixes'
ATTACHED_OUTPUTS_KEY = 'popAttachedOutputMixes'
MAX_MIX = 2147483647  # QSpinBox capacity; actual availability comes from the vMix catalog.
MEDIA = {'live': 'Есть видео', 'absent': 'Нет видео', 'unknown': 'Нет данных'}


def load_outputs(settings, key=OUTPUTS_KEY):
    if settings.contains(key):
        try:
            saved = json.loads(settings.value(key, '[]', type=str))
        except ValueError:
            saved = []
        rows, used = [], set()
        for row in saved if isinstance(saved, list) else ():
            if not isinstance(row, dict):
                continue
            mix = row.get('mix')
            if (type(mix) is int and 1 <= mix <= MAX_MIX and mix not in used
                    and row.get('bank') in ('live', 'replay')):
                rows.append(dict(mix=mix, bank=row['bank'], enabled=row.get('enabled') is True,
                                 follow=row.get('follow') is True))
                used.add(mix)
        return rows
    if key == ATTACHED_OUTPUTS_KEY:
        return []
    live = max(1, min(MAX_MIX, settings.value('popLiveMix', 1, type=int)))
    replay = max(2, min(MAX_MIX, settings.value('povVirtualReplayMix', 2, type=int)))
    conflict = live == replay
    if conflict:
        replay = 2 if live != 2 else 3
    return [
        dict(mix=live, bank='live', enabled=not conflict and settings.value('popLiveEnabled', False, type=bool),
             follow=settings.value('popLiveFollow', False, type=bool)),
        dict(mix=replay, bank='replay', enabled=not conflict and settings.value('popReplayEnabled', False, type=bool),
             follow=False),
    ]


class OutputRow(QWidget):
    changed = Signal()
    remove_requested = Signal()
    take_requested = Signal(int)

    def __init__(self, config):
        super().__init__()
        self.revision = 0
        self.number = config['mix']
        self.mix = QSpinBox()
        self.mix.setAccessibleName('Номер Mix')
        self.mix.setRange(1, MAX_MIX)
        self.mix.setPrefix('Mix ')
        self.mix.setKeyboardTracking(False)
        self.mix.setValue(self.number)
        self.bank = QComboBox()
        self.bank.setAccessibleName('Входы для Mix')
        self.bank.addItem('Live · оригиналы 1–12', 'live')
        self.bank.addItem('Replay · полный кадр 13–24', 'replay')
        self.bank.setCurrentIndex(self.bank.findData(config['bank']))
        self.enabled = QCheckBox('Управлять')
        self.enabled.setChecked(config['enabled'])
        self.follow = QCheckBox('Следовать за обсервером')
        self.follow.setChecked(config['follow'])
        remove = QPushButton('Удалить')
        remove.clicked.connect(self.remove_requested)
        layout = QVBoxLayout(self)
        controls = QHBoxLayout()
        for widget in (self.mix, self.bank, self.enabled):
            controls.addWidget(widget)
        controls.addStretch()
        controls.addWidget(remove)
        layout.addLayout(controls)
        line = QHBoxLayout()
        self.status = QLabel()
        self.status.setWordWrap(True)
        line.addWidget(self.status, 1)
        line.addWidget(self.follow)
        layout.addLayout(line)
        grid = QGridLayout()
        self.buttons = []
        for i in range(12):
            button = QPushButton()
            button.setMinimumHeight(48)
            button.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
            button.setEnabled(False)
            button.clicked.connect(lambda checked=False, slot=i + 1: self.take_requested.emit(slot))
            grid.addWidget(button, i // 4, i % 4)
            self.buttons.append(button)
        layout.addLayout(grid)
        self.enabled.toggled.connect(self.changed)
        self.bank.currentIndexChanged.connect(self.changed)
        self.follow.toggled.connect(self.changed)
        self.mix.valueChanged.connect(self.changed)

    def config(self):
        return dict(mix=self.number, bank=self.bank.currentData(), enabled=self.enabled.isChecked(),
                    follow=self.follow.isChecked())

    def render(self, routes, names, media, program, program_number, available, conflict):
        live = self.bank.currentData() == 'live'
        if conflict:
            status = conflict if isinstance(conflict, str) else 'Этим Mix управляет другой модуль'
        elif not available:
            status = 'Ожидаем Mix в проверенном пресете vMix'
        else:
            status = f'Program · вход {program_number or "—"}'
        self.status.setText(status)
        for i, button in enumerate(self.buttons):
            route = routes[i]
            physical = route['original_number' if live else 'virtual_number'] if route else i + (1 if live else 13)
            guid = route['original_guid' if live else 'virtual_guid'] if route else ''
            active = bool(program and program == guid)
            text = f'№ {physical} · {names[i] or "—"}\n{MEDIA[media[i]]}'
            if active:
                text += ' · Program'
            if text != button.text():
                button.setText(text)
                button.setToolTip(text)
            if button.property('onProgram') != active:
                button.setProperty('onProgram', active)
                button.style().unpolish(button)
                button.style().polish(button)
            button.setEnabled(bool(route and available and not conflict and self.enabled.isChecked()))


class OutputMixPanel(QWidget):
    changed = Signal()
    take_requested = Signal(object, int)
    companion_requested = Signal()

    def __init__(self, settings, *, attached=False):
        super().__init__()
        self.settings = settings
        self.rows = []
        self.catalog = {}
        layout = QVBoxLayout(self)
        controls = QHBoxLayout()
        self.add = QPushButton('Добавить Mix')
        self.add.clicked.connect(self.add_mix)
        controls.addWidget(self.add)
        controls.addStretch()
        companion = QPushButton('Companion…')
        companion.clicked.connect(self.companion_requested)
        controls.addWidget(companion)
        layout.addLayout(controls)
        self.external = QLabel()
        self.external.setWordWrap(True)
        layout.addWidget(self.external)
        self.hint = QLabel()
        self.hint.setWordWrap(True)
        layout.addWidget(self.hint)
        self.destinations = QVBoxLayout()
        layout.addLayout(self.destinations)
        layout.addStretch()
        self.set_profile(attached)

    def set_profile(self, attached):
        self.key = ATTACHED_OUTPUTS_KEY if attached else OUTPUTS_KEY
        self.hint.clear()
        self.catalog = {}
        for row in self.rows:
            self.destinations.removeWidget(row)
            row.hide()
            row.deleteLater()
        self.rows.clear()
        for config in load_outputs(self.settings, self.key):
            self._append(config)
        self._save()

    def _append(self, config):
        row = OutputRow(config)
        self.rows.append(row)
        self.destinations.addWidget(row)
        row.changed.connect(lambda: self._edited(row))
        row.remove_requested.connect(lambda: self._remove(row))
        row.take_requested.connect(lambda slot: self.take_requested.emit(row, slot))
        return row

    def add_mix(self):
        used = {r.number for r in self.rows}
        if self.catalog:
            choices = sorted(self.catalog.keys() - used)
            if not choices:
                self.hint.setText('Все доступные Mix уже добавлены.')
                return
            number = choices[0]
        else:
            number = next(n for n in range(1, len(used) + 2) if n not in used)
        self._append(dict(mix=number, bank='live', enabled=False, follow=False))
        self.hint.clear()
        self._save()

    def _edited(self, row):
        number = row.mix.value()
        if number != row.number and any(other.number == number for other in self.rows):
            with QSignalBlocker(row.mix):
                row.mix.setValue(row.number)
            self.hint.setText(f'Mix {number} уже добавлен.')
            return
        self.hint.clear()
        row.number = number
        row.revision += 1
        self._save()

    def _remove(self, row):
        self.rows.remove(row)
        self.destinations.removeWidget(row)
        row.hide()
        row.deleteLater()
        self._save()

    def _save(self):
        self.settings.setValue(self.key, json.dumps([row.config() for row in self.rows]))
        if not self.rows and self.key == ATTACHED_OUTPUTS_KEY:
            self.hint.setText('Добавьте свой Mix, выберите Live или Replay и включите «Управлять».')
        self.changed.emit()
