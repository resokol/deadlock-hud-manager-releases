"""Resolve fixed vMix camera banks by native lineage, saved GUIDs or preset position."""

from xml.etree.ElementTree import ParseError

from PySide6.QtCore import Qt, QUrl, Signal
from PySide6.QtWidgets import QLabel, QVBoxLayout, QWidget

from .camera_native_setup import NativePoolSetup, fixed_bank, pair_signature, pool_key
from .camera_native_sync import NativePair, read_native_catalog
from .camera_vdo_publish import VmixRequest


class NativePairBindings(QWidget):
    changed = Signal()
    pool_ready = Signal()

    def __init__(self, settings, parent=None, *, endpoint=None, can_setup=None):
        super().__init__(parent)
        self.settings = settings
        self.endpoint = endpoint
        self.can_setup = can_setup
        self.setup = NativePoolSetup(settings, self)
        self.setup.finished.connect(self._pool_finished)
        self.http = VmixRequest(self)
        self.receipt = None
        self.inputs = {}
        self._mapping = {}
        self.confirmed = False
        self.pool_status = QLabel()
        self.pool_status.setTextFormat(Qt.TextFormat.PlainText)
        self.pool_status.setWordWrap(True)
        QVBoxLayout(self).addWidget(self.pool_status)

    def mapping(self):
        return dict(self._mapping)

    def inspect(self, endpoint, state, parents):
        self.inputs = {g: info for g, info in state.inputs.items() if info['number'] <= 24}
        if self.settings.contains(pool_key(endpoint, state.preset, 'pendingCreation')):
            return None
        order, mapping = fixed_bank(self.settings, endpoint, state, parents)
        if len(mapping) != 12 or [mapping[g] for g in order[:12]] != order[12:24]:
            return None
        return mapping

    def bind(self, receipt, mapping):
        if not receipt or {r.guid for r in receipt.rows} != mapping.keys():
            raise ValueError('Банк 1–12 должен содержать 12 оригинальных браузеров.')
        self.receipt = receipt
        for source, copy in mapping.items():
            self.settings.setValue(pool_key(receipt.endpoint, receipt.preset, source), copy)
        self.settings.setValue(pool_key(receipt.endpoint, receipt.preset, 'approvedPairs'), pair_signature(mapping))
        self._mapping = dict(mapping)
        self.confirmed = True
        self.pool_status.setText('Оригиналы 1–12 и виртуальные копии 13–24 готовы.')
        self.changed.emit()

    def clear_binding(self):
        changed = self.confirmed or self.receipt is not None
        self.receipt = None
        self._mapping.clear()
        self.confirmed = False
        if changed:
            self.changed.emit()

    def set_receipt(self, receipt):
        """Re-read the catalog when restoring an already locked match layout."""
        self.http.cancel()
        self.clear_binding()
        if not receipt or len(receipt.rows) != 12:
            return
        self.receipt = receipt
        host, port = receipt.endpoint

        def receive(error, xml):
            if self.receipt is not receipt:
                return
            try:
                if error:
                    raise ValueError('Нет ответа vMix.')
                state, parents = read_native_catalog(xml)
                if state.preset != receipt.preset:
                    raise ValueError('Пресет vMix изменился.')
                mapping = self.inspect(receipt.endpoint, state, parents)
                if not mapping:
                    raise ValueError('Порядок оригиналов и копий в vMix изменился.')
                self.bind(receipt, mapping)
            except (ValueError, ParseError) as exc:
                self.pool_status.setText(str(exc))
                self.changed.emit()

        self.http.send(QUrl(f'http://{host}:{port}/api/'), None, receive)

    def prepare(self, endpoint, preset, validate):
        def current():
            return (validate() and (not self.endpoint or endpoint == self.endpoint())
                    and (not self.can_setup or self.can_setup()))

        if not current():
            raise ValueError('Входами камер управляет другой модуль vMix.')
        self.pool_status.setText('Проверяем и подготавливаем виртуальные копии vMix…')
        self.setup.start(endpoint, preset=preset, validate=current)

    def _pool_finished(self, ok, message):
        self.pool_status.setText(message)
        if ok:
            self.pool_ready.emit()

    def cancel(self):
        self.http.cancel()
        self.setup.cancel()

    def pairs(self, originals):
        if not self.confirmed or len(originals) != 12 or {r.guid for r in originals} != self._mapping.keys():
            return ()
        return tuple(NativePair(r.guid, self._mapping[r.guid], r.name, operator_verified=True) for r in originals)
