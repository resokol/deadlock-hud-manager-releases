"""Windows Steam launch integration for Deadlock."""

import os
from pathlib import Path
import re
import subprocess
import sys


def find_steam():
    import winreg

    locations = (
        (winreg.HKEY_CURRENT_USER, 'SteamExe', 0),
        (winreg.HKEY_LOCAL_MACHINE, 'InstallPath', winreg.KEY_WOW64_32KEY),
    )
    for hive, name, view in locations:
        try:
            with winreg.OpenKey(hive, r'Software\Valve\Steam', 0, winreg.KEY_READ | view) as key:
                value, _ = winreg.QueryValueEx(key, name)
        except OSError:
            continue
        if not value or not isinstance(value, str):
            continue
        path = Path(os.path.expandvars(value))
        executable = path / 'steam.exe' if name == 'InstallPath' else path
        if executable.is_file():
            return executable
    raise RuntimeError('Steam не найден. Установите или откройте Steam и повторите запуск.')


def is_deadlock_running():
    system_root = Path(os.environ['SystemRoot'])
    result = subprocess.run(
        [str(system_root / 'System32' / 'tasklist.exe'), '/FI', 'IMAGENAME eq deadlock.exe',
         '/FO', 'CSV', '/NH'],
        capture_output=True, check=True, creationflags=subprocess.CREATE_NO_WINDOW, timeout=4,
    )
    return any(line.lower().startswith(b'"deadlock.exe",') for line in result.stdout.splitlines())


def find_deadlock_citadel():
    root = find_steam().parent
    libraries = [root]
    try:
        listing = (root / 'steamapps' / 'libraryfolders.vdf').read_text(encoding='utf-8')
    except (OSError, UnicodeError):
        pass
    else:
        libraries.extend(Path(path.replace('\\\\', '\\')) for path in re.findall(r'^\s*"path"\s+"([^"]+)"', listing, re.MULTILINE))
    for library in libraries:
        candidate = library / 'steamapps' / 'common' / 'Deadlock' / 'game' / 'citadel'
        if (candidate / 'pak01_dir.vpk').is_file():
            return candidate
    raise RuntimeError('Установка Deadlock не найдена в библиотеках Steam.')


def launch_deadlock(selective_hud, panorama_health=False, minimap_numbers='off', native_hud=None, dev=False):
    if sys.platform != 'win32':
        raise RuntimeError('Запуск Deadlock через менеджер доступен в Windows.')
    try:
        running = is_deadlock_running()
    except (OSError, subprocess.SubprocessError) as exc:
        raise RuntimeError('Не удалось проверить, запущен ли Deadlock.') from exc
    if running:
        raise RuntimeError('Deadlock уже запущен. Закройте игру перед новым запуском.')

    executable = find_steam()
    args = [str(executable), '-applaunch', '1422450']
    if dev:
        args.append('-dev')
    from . import panorama_mount

    panorama_installed = os.environ.get('LOCALAPPDATA') and panorama_mount.packs()[0].is_file()
    if panorama_health or selective_hud or minimap_numbers != 'off' or panorama_installed or native_hud:
        args.append('-condebug')
    installed = None
    if native_hud:
        installed = panorama_mount.mount(find_deadlock_citadel(), minimap_only=selective_hud,
                                        numbers=minimap_numbers, native_hud=native_hud)
    elif minimap_numbers != 'off':
        installed = panorama_mount.mount(find_deadlock_citadel(), minimap_only=selective_hud, numbers=minimap_numbers)
    elif selective_hud:
        installed = panorama_mount.mount(find_deadlock_citadel())
    elif panorama_health and (dev or panorama_installed and panorama_mount.fast_normal_available()):
        installed = panorama_mount.mount(find_deadlock_citadel(), minimap_only=False)
    elif panorama_installed:
        try:
            citadel = find_deadlock_citadel()
        except RuntimeError:
            pass
        else:
            panorama_mount.restore(citadel / 'addons' / 'pak88_dir.vpk')
    try:
        subprocess.Popen(args, cwd=executable.parent)
    except OSError:
        if installed is not None:
            panorama_mount.restore(installed)
        raise
