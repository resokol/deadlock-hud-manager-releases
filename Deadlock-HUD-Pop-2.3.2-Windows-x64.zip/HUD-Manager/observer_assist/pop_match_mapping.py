"""An operator can bind a game identity to a room camera without matching approximate names."""
from dataclasses import replace
from hashlib import sha256
import json

from PySide6.QtWidgets import (QComboBox, QDialog, QDialogButtonBox, QFormLayout, QLabel, QVBoxLayout)


def camera_matches(names, accounts, prepared, suggestions, overrides):
    """Resolve all twelve together. A unique original is mandatory for each position."""
    if len(names) != 12 or len(prepared) != 12:
        return ()
    rows = {row.guid: row for row in prepared}
    if len(rows) != 12:
        return ()
    exact = {row.name.strip().casefold(): row.guid for row in prepared if row.name.strip()}
    keys = player_keys(names, accounts)
    chosen = {i: overrides[key] for i, key in enumerate(keys) if key in overrides}
    if len(set(chosen.values())) != len(chosen) or any(g not in rows for g in chosen.values()):
        return ()
    used = set(chosen.values())
    natural = {row.name.strip().casefold(): row.guid for row in suggestions}
    for i, name in enumerate(names):
        if i in chosen:
            continue
        folded = name.strip().casefold()
        guid = exact.get(folded) or natural.get(folded)
        if exact.get(folded) in used:
            return ()
        if guid and guid not in used:
            chosen[i] = guid
            used.add(guid)
    free = {row.guid: row for row in prepared if row.guid not in used}
    for i in range(12):
        if i not in chosen:
            # Keep a replacement in its current physical seat when ownership permits.
            seat = min(free.values(), key=lambda row: (bool(row.name), row.number != i+1, row.number))
            chosen[i] = seat.guid
            del free[seat.guid]
    return tuple(replace(rows[chosen[i]], name=name, slot=i+1) for i, name in enumerate(names))


def player_keys(names, accounts):
    return tuple('id.' + str(accounts[i]) if accounts.get(i) else 'nick.' + name.strip().casefold()
                 for i, name in enumerate(names, 1))


class MatchCameraBindings:
    def __init__(self, settings):
        self.settings = settings
        self.scope, self.values, self.known = '', {}, {}

    def select(self, room_key, receipt):
        if not room_key or not receipt:
            self.scope, self.values, self.known = '', {}, {}
            return
        key = 'popMatchCamera/' + sha256(repr((room_key, receipt.endpoint, receipt.preset)).encode()).hexdigest()
        if self.scope != key:
            self.scope = key
            try:
                data = json.loads(self.settings.value(key, '{}', type=str))
            except ValueError:
                data = {}
            self.values = data if isinstance(data, dict) else {}
            try:
                known = json.loads(self.settings.value(key+'/accounts', '{}', type=str))
            except ValueError:
                known = {}
            self.known = known if isinstance(known, dict) else {}

    def for_prepared(self, rows):
        owners = {r.guid: r.name.strip().casefold() for r in rows}
        remembered = {key: pair[0] for key,pair in self.known.items()
                      if isinstance(pair, list) and len(pair) == 2 and isinstance(pair[0], str)
                      and owners.get(pair[0]) == pair[1]}
        return {**remembered, **self.values}

    def confirm(self, accounts, pairs, aliases):
        if self.scope:
            for account, pair in zip(accounts, pairs):
                owner = aliases.get(pair.original_guid, '').strip().casefold()
                if account and owner:
                    self.known['id.'+str(account)] = [pair.original_guid, owner]
            self.settings.setValue(self.scope+'/accounts', json.dumps(self.known, ensure_ascii=False))

    def save(self, changes):
        if self.scope:
            self.values.update(changes)
            self.values = {key: guid for key, guid in self.values.items() if guid}
            self.settings.setValue(self.scope, json.dumps(self.values, ensure_ascii=False))

    def edit(self, names, accounts, prepared, parent, *, current):
        if len(names) != 12 or len(prepared) != 12:
            return False
        dialog = QDialog(parent)
        dialog.setWindowTitle('Сопоставление игроков и камер')
        layout = QVBoxLayout(dialog)
        help_text = QLabel('Выберите камеру для несовпадающих ников. Пустой выбор возвращает автоматическое сопоставление.')
        help_text.setWordWrap(True)
        layout.addWidget(help_text)
        form = QFormLayout()
        layout.addLayout(form)
        choices = {}
        for i, (name, key) in enumerate(zip(names, player_keys(names, accounts)), 1):
            choice = QComboBox()
            choice.addItem('По нику игрока', '')
            for row in prepared:
                if row.name:
                    choice.addItem(row.name, row.guid)
            choice.setCurrentIndex(max(0, choice.findData(self.values.get(key, ''))))
            choices[key] = choice
            form.addRow(f'{i} · {name}' + (f'  (ID {accounts[i]})' if accounts.get(i) else ''), choice)
        errors = QLabel()
        layout.addWidget(errors)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        def accept():
            if not current():
                errors.setText('Состав или комната изменились. Закройте окно и откройте актуальный состав.')
                return
            selected = [c.currentData() for c in choices.values() if c.currentData()]
            if len(selected) != len(set(selected)):
                errors.setText('Двум игрокам назначен один оригинал.')
                return
            dialog.accept()
        buttons.accepted.connect(accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.save({key: c.currentData() for key, c in choices.items()})
            return True
        return False
