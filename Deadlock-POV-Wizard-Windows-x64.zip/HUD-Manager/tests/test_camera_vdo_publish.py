from threading import Event
from urllib.parse import parse_qsl, urlsplit
from xml.etree import ElementTree as ET

import pytest

from observer_assist.camera_preparation import camera_page
from observer_assist.camera_vdo_publish import VdoVmixPublisher
from test_vmix_control import app, fake_api, process_events, wait_for


def guid(number):
    return f'961935d1-a250-4a9b-8397-{number:012d}'


def row(i, number=None, label=None):
    return ('https://vdo.ninja/?view=guest' + str(i) + '&room=private-room#password=private-secret%2B',
            label if label is not None else f'Игрок {i}', number if number is not None else i)


class Preset:
    def __init__(self):
        self.name = 'Показ 1'
        self.inputs = {}
        self.writes = []
        self.fail = {}

    def add(self, number, kind='Browser', **attrs):
        self.inputs[guid(number)] = dict(key=guid(number), number=str(number), type=kind, title='Original', **attrs)

    def answer(self, path):
        if path == '/api/':
            root = ET.Element('vmix')
            ET.SubElement(root, 'preset').text = self.name
            inputs = ET.SubElement(root, 'inputs')
            for entry in self.inputs.values():
                ET.SubElement(inputs, 'input', entry)
            return 200, {}, ET.tostring(root, encoding='utf-8')
        q = dict(parse_qsl(urlsplit(path).query))
        self.writes.append((q['Function'], q['Input'], q['Value']))
        code = self.fail.get((q['Function'], q['Input']), 200)
        if q['Function'] == 'SetInputName' and code == 200:
            self.inputs[q['Input']]['title'] = q['Value']
        return code, {}, b''


@pytest.fixture
def publisher(app, fake_api):
    api = Preset()
    fake_api.answer = api.answer
    service = VdoVmixPublisher()
    results, summaries = [], []
    service.result.connect(lambda page, msg: results.append((page, msg)))
    service.finished.connect(summaries.append)

    def start(rows, **options):
        return service.start('127.0.0.1', fake_api.server_port, rows, **options)

    yield service, start, api, results, summaries
    service.cancel()


def test_twelve_distinct_browser_inputs_apply_once_and_forget_individually(publisher, fake_api):
    service, start, api, results, summaries = publisher
    rows = [row(i, number=40 + i) for i in range(1, 13)]
    rows[0] = row(1, 41, 'A B')
    rows[1] = row(2, 42, 'A  B')
    rows[2] = row(3, 43, '<player-name>')
    for _, _, number in rows:
        api.add(number, virtual='False')
    authorized = []
    assert start(rows, authorize=lambda guids: authorized.append(guids) or True)
    assert service.busy and not start(rows)
    endpoint = ('127.0.0.1', fake_api.server_port)
    assert service.active_endpoint == endpoint
    wait_for(lambda: not service.busy)
    assert authorized == [{guid(number) for _, _, number in rows}]
    assert service.active_endpoint is None
    assert api.writes == [operation for page, label, number in rows for operation in [
        ('BrowserNavigate', guid(number), camera_page(page)), ('SetInputName', guid(number), label)]]
    assert [key for key, _ in results] == [r[0] for r in rows]
    assert 'Готово: 12' in summaries[-1]
    assert all('private-' not in msg and '<player' not in msg for msg in summaries + [s for _, s in results])
    api.writes.clear()
    service.forget({guid(41)}, ('127.0.0.2', fake_api.server_port))
    assert start(rows)
    wait_for(lambda: not service.busy)
    assert not api.writes
    service.forget({'{' + guid(41).upper() + '}'}, endpoint)
    assert start(rows[:2])
    wait_for(lambda: not service.busy)
    assert api.writes == [('BrowserNavigate', guid(41), camera_page(rows[0][0]))]
    api.name = 'Показ 2'
    api.writes.clear()
    assert start(rows[:2])
    wait_for(lambda: not service.busy)
    assert [key for _, key, _ in api.writes] == [guid(41), guid(42)]


def test_bad_input_isolated_and_partial_retry_preserves_acknowledged_pages(publisher):
    service, start, api, results, summaries = publisher
    for number in [1, 2, 6, 7]:
        api.add(number)
    api.add(3, 'Capture')
    api.add(4, virtual='True')
    targets = [row(i, label='' if i == 6 else None) for i in range(1, 8)]
    api.fail = {('SetInputName', guid(2)): 500, ('BrowserNavigate', guid(7)): 503}
    assert start(targets)
    wait_for(lambda: not service.busy)
    assert len(results) == 7
    assert set(key for _, key, _ in api.writes) == {guid(1), guid(2), guid(7)}
    assert 'Готово: 1' in summaries[-1] and 'Пропущено: 4' in summaries[-1] and 'Ошибок: 2' in summaries[-1]
    assert '500' in dict(results)[row(2)[0]] and '503' in dict(results)[row(7)[0]]
    api.writes.clear()
    api.fail.clear()
    assert start(targets)
    wait_for(lambda: not service.busy)
    assert api.writes == [('SetInputName', guid(2), row(2)[1]),
                          ('BrowserNavigate', guid(7), camera_page(row(7)[0])),
                          ('SetInputName', guid(7), row(7)[1])]


@pytest.mark.parametrize('rows', [
    [], [row(i) for i in range(1, 14)], [row(1), row(2, number=1)],
    [row(1), (row(1)[0] + '&appearance=other', 'Другой', 2)], [row(1), row(2, label=' ИГРОК 1 ')],
])
def test_ambiguous_batch_never_contacts_vmix(publisher, fake_api, rows):
    service, start, _, _, summaries = publisher
    assert not start(rows)
    assert summaries and not service.busy and not fake_api.requests


def test_number_replaced_during_authorization_and_validate_before_rename(publisher, fake_api):
    service, start, api, results, summaries = publisher
    api.add(1)
    api.add(2)
    valid = {row(1)[0], row(2)[0]}
    def authorize(keys):
        assert keys == {guid(1), guid(2)}
        api.inputs[guid(1)]['number'] = '12'
        api.add(9)
        api.inputs[guid(9)]['number'] = '1'
        return True

    def answer(path):
        reply = api.answer(path)
        if 'Function=BrowserNavigate' in path:
            valid.discard(row(2)[0])
        return reply
    fake_api.answer = answer
    assert start([row(1), row(2)], validate=lambda page, label, number: page in valid, authorize=authorize)
    wait_for(lambda: not service.busy)
    assert len(results) == 2 and 'Пропущено: 2' in summaries[-1]
    assert api.writes == [('BrowserNavigate', guid(2), camera_page(row(2)[0]))]


def test_denied_or_reentrant_authorization_does_not_write_old_selection(publisher):
    service, start, api, _, summaries = publisher
    api.add(1)
    api.add(2)
    assert start([row(1)], authorize=lambda keys: False)
    wait_for(lambda: not service.busy)
    assert not api.writes and 'отменена' in summaries[-1]
    def replace(keys):
        service.cancel()
        assert start([row(2)])
        return True
    assert start([row(1)], authorize=replace)
    wait_for(lambda: not service.busy)
    assert [key for _, key, _ in api.writes] == [guid(2)] * 2


def test_cancel_during_navigation_prevents_followup_writes(publisher, fake_api):
    service, start, api, _, summaries = publisher
    api.add(1)
    api.add(2)
    entered, release = Event(), Event()
    def answer(path):
        reply = api.answer(path)
        if 'Function=BrowserNavigate' in path:
            entered.set()
            release.wait(2)
        return reply
    fake_api.answer = answer
    try:
        assert start([row(1), row(2)])
        wait_for(entered.is_set)
        service.cancel()
        assert not service.busy and 'отменена' in summaries[-1]
    finally:
        release.set()
    process_events(35)
    assert api.writes == [('BrowserNavigate', guid(1), camera_page(row(1)[0]))]


def test_position_rows_clear_unmatched_guests_and_swap_by_guid(publisher):
    service, start, api, _, summaries = publisher
    outcomes = []
    service.position_result.connect(lambda number, msg: outcomes.append((number, msg)))
    for i in range(1, 13):
        api.add(i)
    alpha = row(1, label='Alpha')
    bravo = row(2, label='Bravo')
    empties = [('', '-', i) for i in range(3, 13)]
    authorized = []
    targets = [alpha, bravo, *empties]
    assert start(targets, authorize=lambda guids: authorized.append(guids) or True)
    wait_for(lambda: not service.busy)
    assert authorized == [{guid(i) for i in range(1, 13)}]
    assert [n for n, _ in outcomes] == list(range(1, 13))
    assert all('Прозрачный' in msg for _, msg in outcomes[2:])
    assert all(('BrowserNavigate', guid(i), 'about:blank') in api.writes and
               ('SetInputName', guid(i), '-') in api.writes for i in range(3, 13))
    assert 'Готово: 12' in summaries[-1]
    api.writes.clear()
    assert start(targets)
    wait_for(lambda: not service.busy)
    assert not api.writes
    swapped = [(*bravo[:2], 1), (*alpha[:2], 2), *empties]
    assert start(swapped)
    wait_for(lambda: not service.busy)
    assert api.writes == [('BrowserNavigate', guid(1), camera_page(bravo[0])), ('SetInputName', guid(1), 'Bravo'),
                          ('BrowserNavigate', guid(2), camera_page(alpha[0])), ('SetInputName', guid(2), 'Alpha')]
    api.writes.clear()
    moved = [('', '-', 1), (*alpha[:2], 2), (*bravo[:2], 3), *empties[1:]]
    assert start(moved)
    wait_for(lambda: not service.busy)
    assert api.writes == [('BrowserNavigate', guid(1), 'about:blank'), ('SetInputName', guid(1), '-'),
                          ('BrowserNavigate', guid(3), camera_page(bravo[0])), ('SetInputName', guid(3), 'Bravo')]


def test_empty_rows_check_freshness_and_retry_only_unacknowledged_operation(publisher):
    service, start, api, _, summaries = publisher
    outcomes = []
    service.position_result.connect(lambda number, msg: outcomes.append((number, msg)))
    for i in (1, 2, 3):
        api.add(i)
    rows = [('', '-', n) for n in (1, 2, 3)]
    api.fail = {('SetInputName', guid(1)): 500, ('BrowserNavigate', guid(2)): 503}
    allowed = set(rows)
    def approve(_):
        allowed.discard(rows[2])  # Room snapshot changed while the operator confirmed.
        return True

    assert start(rows, validate=lambda *r: r in allowed, authorize=approve)
    wait_for(lambda: not service.busy)
    assert api.writes == [('BrowserNavigate', guid(1), 'about:blank'), ('SetInputName', guid(1), '-'),
                          ('BrowserNavigate', guid(2), 'about:blank')]
    assert '500' in dict(outcomes)[1] and '503' in dict(outcomes)[2] and 'изменился' in dict(outcomes)[3]
    assert 'Пропущено: 1' in summaries[-1] and 'Ошибок: 2' in summaries[-1]
    api.writes.clear()
    api.fail.clear()
    assert start(rows, validate=lambda *r: r in allowed)
    wait_for(lambda: not service.busy)
    assert api.writes == [('SetInputName', guid(1), '-'), ('BrowserNavigate', guid(2), 'about:blank'),
                          ('SetInputName', guid(2), '-')]


def test_non_sentinel_blank_is_never_allowed_to_clear_a_camera(publisher, fake_api):
    service, start, api, results, summaries = publisher
    for i in (1, 2):
        api.add(i)
    assert not start([('', '-', 1), ('', '-', 1)])
    assert not fake_api.requests
    assert start([('', 'Player', 1), ('', '-', 2)])
    wait_for(lambda: not service.busy)
    assert api.writes == [('BrowserNavigate', guid(2), 'about:blank'), ('SetInputName', guid(2), '-')]
    assert 'Вход 1' in results[0][1] and 'Пропущено: 1' in summaries[-1]


def test_counts_and_guid_receipt_available_before_finished(publisher, fake_api):
    service, start, api, _, _ = publisher
    events = []
    service.batch_completed.connect(lambda *counts: events.append((counts, service.last_receipt)))
    service.finished.connect(lambda _: events.append('finished'))
    api.add(7)
    api.add(8)
    assert start([('', '-', 8), row(1, number=7)])
    wait_for(lambda: not service.busy)
    (counts, receipt), finish = events
    assert counts == (2, 0, 0) and finish == 'finished'
    assert receipt.endpoint == ('127.0.0.1', fake_api.server_port) and receipt.preset == api.name
    assert [(r.number, r.guid, r.label, r.empty) for r in receipt.rows] == [
        (8, guid(8), '-', True), (7, guid(7), 'Игрок 1', False)]
    assert 'private-' not in repr(receipt)
    events.clear()
    assert start([row(1, number=9)])
    assert service.last_receipt is None
    wait_for(lambda: not service.busy)
    assert events == [((0, 1, 0), None), 'finished']
