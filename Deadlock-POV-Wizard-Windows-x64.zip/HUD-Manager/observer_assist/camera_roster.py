"""Account-based camera assignments for the current match's spectator hotkeys."""

from collections import Counter
import json

from PySide6.QtCore import Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QAbstractItemView, QApplication, QBoxLayout, QDialog, QDialogButtonBox, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QPushButton, QSizePolicy, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from .broadcast_tables import TEAM_NAMES, players_by_match_position
from .camera_mapping import OperatorCamera
from .game_icons import icon_root
from .hud_nicknames import normalize_name


KEYS = tuple('1234567890-=')


def _account(value):
    if type(value) not in (str, int):
        return None
    value = str(value)
    if value.isascii() and value.isdecimal() and len(value) <= 10 and 0 < int(value) <= 0xffffffff:
        return str(int(value))
    return None


def _page_valid(value):
    if not isinstance(value, str):
        return False
    url = QUrl(value, QUrl.ParsingMode.StrictMode)
    return url.isValid() and url.scheme() in ('https', 'http') and bool(url.host())


def _read_map(settings, key):
    try:
        result = json.loads(settings.value(key, '{}', type=str))
    except (ValueError, TypeError):
        return {}
    return result if isinstance(result, dict) else {}


def _hero_names():
    try:
        names = json.loads((icon_root() / 'catalog.json').read_text(encoding='utf-8'))['heroNames']
    except (OSError, KeyError, TypeError, ValueError):
        return {}
    labels = {}
    if isinstance(names, dict):
        for name, hero_id in names.items():
            if not isinstance(name, str) or not name or '_' in name:
                continue
            key = str(hero_id)
            if key not in labels or any('а' <= letter <= 'я' for letter in name.casefold()):
                labels[key] = name.title()
    return labels


def _ordered_accounts(names, identities):
    result = [identities.get(normalize_name(names.get(str(pos)))) for pos in range(1, 13)]
    return result if all(result) and len(set(result)) == 12 else []


class CameraRoster(QWidget):
    changed = Signal()

    def __init__(self, settings, *, right_to_left=False):
        super().__init__()
        self.settings = settings
        self.right_to_left = right_to_left
        self.pages = {key: page for key, page in _read_map(settings, 'cameraAccountPages').items()
                      if _account(key) == key and _page_valid(page)}
        self._orders = _read_map(settings, 'cameraManualOrders')
        self._last_confirmed = _read_map(settings, 'cameraConfirmedOrders')
        self._hero_labels = _hero_names()
        self.match_id = None
        self.players = {}
        self.slots = {}
        self.observed = None
        self._unidentified = []
        self._api = []
        self._raw = []
        self._draft = None
        self._display = []
        self._view = None
        self._camera_mapping = lambda: {}
        self._mapping_timer = QTimer(self, interval=1000)
        self._mapping_timer.timeout.connect(self._render)
        self._complete = False
        self._has_portraits = False

        self.setObjectName('cameraRoster')
        self.setStyleSheet("""
            QLabel#rosterTitle { font-size: 14pt; font-weight: 600; color: #edf3f4; }
            QLabel#rosterCount, QLabel#rosterStatus { color: #b8c6cb; }
            QLabel#rosterFocus { color: #91dcce; }
            QTableWidget#rosterTable { background: #141a21; alternate-background-color: #1d252e;
                color: #e0e9eb; border: 1px solid #394651; selection-background-color: #355b59;
                selection-color: #ffffff; }
            QTableWidget#rosterTable QHeaderView::section { background: #26313a; color: #c2cdd2;
                border: 0; padding: 5px 6px; }
            QTableWidget#rosterTable::item { padding: 2px 6px; }
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        heading = QHBoxLayout()
        title = QLabel('Игроки и камеры')
        title.setObjectName('rosterTitle')
        heading.addWidget(title)
        heading.addStretch()
        self.count = QLabel()
        self.count.setObjectName('rosterCount')
        heading.addWidget(self.count)
        layout.addLayout(heading)
        self.status = QLabel()
        self.status.setObjectName('rosterStatus')
        self.status.setWordWrap(True)
        self.status.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.status)
        self.focus_player = QLabel()
        self.focus_player.setObjectName('rosterFocus')
        self.focus_player.setWordWrap(True)
        self.focus_player.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.focus_player)

        self.table = QTableWidget(12, 14)
        self.table.setObjectName('rosterTable')
        self.table.setAccessibleName('Позиции игроков, камеры и назначения vMix')
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.setHorizontalHeaderLabels(
            ['Клавиша', 'Игрок', 'Герой', 'Команда', 'Account ID', 'SourceTV', 'Panorama', 'URL камеры',
             'Позиция', 'Stream ID', 'Пара', 'GUID оригинала', 'GUID копии', 'Состояние камеры'])
        self.table.verticalHeader().hide()
        self.table.verticalHeader().setDefaultSectionSize(max(30, self.table.fontMetrics().height() + 12))
        self.table.setMinimumHeight(12 * self.table.verticalHeader().defaultSectionSize()
                                    + self.table.horizontalHeader().sizeHint().height() + 22)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        header = self.table.horizontalHeader()
        header.setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setMaximumSectionSize(260)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Interactive)
        self.table.setColumnWidth(1, 160)
        # Left-to-right operator workflow, with the source ordering evidence at the end.
        for visual, logical in enumerate((8, 0, 1, 2, 3, 4, 13, 9, 7, 10, 11, 12, 5, 6)):
            header.moveSection(header.visualIndex(logical), visual)
        for col in (9, 11, 12, 13):
            header.setSectionResizeMode(col, QHeaderView.ResizeMode.Interactive)
            self.table.setColumnWidth(col, 210 if col == 13 else 140)
        self.table.horizontalHeaderItem(13).setToolTip(
            'Готовность Live и Replay показывает доступность маршрута vMix. Видео проверьте на выходе.')
        self.table.horizontalHeaderItem(5).setToolTip('Позиция по команде и линии из SourceTV')
        direction = 'справа налево' if right_to_left else 'слева направо'
        self.table.horizontalHeaderItem(6).setToolTip(f'Позиция портрета {direction} в текущем матче')
        self.table.currentCellChanged.connect(self._buttons)
        self.table.cellClicked.connect(lambda row, col: self._edit_page() if col == 7 else None)
        layout.addWidget(self.table)

        self.up, self.down = QPushButton('Выше'), QPushButton('Ниже')
        self.up.clicked.connect(lambda: self._move(-1))
        self.down.clicked.connect(lambda: self._move(1))
        self.apply = QPushButton('Подтвердить порядок вручную')
        self.apply.clicked.connect(self._apply_order)
        self.reset = QPushButton('Вернуть порядок Panorama')
        self.reset.clicked.connect(self._reset_order)
        self.edit = QPushButton('Изменить URL игрока')
        self.edit.clicked.connect(self._edit_page)
        self.copy_page = QPushButton('Копировать URL камеры')
        self.copy_page.clicked.connect(self._copy_page)
        self.actions = QWidget()
        self.actions.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.toolbar = QBoxLayout(QBoxLayout.Direction.TopToBottom, self.actions)
        self.toolbar.setContentsMargins(0, 0, 0, 0)
        self.edit_actions = QBoxLayout(QBoxLayout.Direction.LeftToRight)
        self.save_actions = QBoxLayout(QBoxLayout.Direction.LeftToRight)
        for group, buttons in ((self.edit_actions, (self.edit, self.copy_page, self.up, self.down)),
                               (self.save_actions, (self.apply, self.reset))):
            for button in buttons:
                group.addWidget(button)
            group.addStretch()
            self.toolbar.addLayout(group)
        layout.addWidget(self.actions)
        self._render()

    def bind_camera_mapping(self, read):
        self._camera_mapping = read
        self._render()

    def showEvent(self, event):
        super().showEvent(event)
        self._render()
        self._mapping_timer.start()

    def hideEvent(self, event):
        self._mapping_timer.stop()
        super().hideEvent(event)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._size_actions(event.size().width())

    def _size_actions(self, width):
        edit_width = sum(b.sizeHint().width() for b in (self.edit, self.copy_page, self.up, self.down)) + 24
        save_width = self.apply.sizeHint().width() + self.reset.sizeHint().width() + 16
        row, column = QBoxLayout.Direction.LeftToRight, QBoxLayout.Direction.TopToBottom
        self.toolbar.setDirection(row if width >= edit_width + save_width + 20 else column)
        self.edit_actions.setDirection(row if width >= edit_width else column)
        self.save_actions.setDirection(row if width >= save_width else column)

    def update_match(self, roster, slots, observed, confirmed: bool, heroes=None):
        """Only same-match portrait coordinates or an explicit match override enable keys."""
        match = (roster or {}).get('matchId')
        match = str(match) if match else None
        rows = []
        for team in (roster or {}).get('teams', []):
            for player in team.get('players', []):
                name = player.get('name') or ''
                hero_id = player.get('heroId')
                hero = player.get('hero') or (heroes or {}).get(name) or self._hero_labels.get(str(hero_id))
                rows.append(dict(name=name, accountId=_account(player.get('accountId')), side=team['side'],
                                 heroId=hero_id, hero=hero))
        accounts = Counter(p['accountId'] for p in rows)
        names = Counter(normalize_name(p['name']) for p in rows)
        players = {p['accountId']: p for p in rows if p['accountId'] and accounts[p['accountId']] == 1}
        unknown = [p for p in rows if p['accountId'] not in players]
        identities = {normalize_name(p['name']): account for account, p in players.items()
                      if p['name'].strip() and names[normalize_name(p['name'])] == 1}
        complete = len(players) == len(rows) == 12 and Counter(p['side'] for p in rows) == {2: 6, 3: 6}
        api = _ordered_accounts(players_by_match_position(roster), identities) if complete else []
        raw = _ordered_accounts(slots, identities) if match and confirmed and complete else []
        observed_name = slots.get(str(observed)) if match and confirmed and type(observed) is int else None
        observing = identities.get(normalize_name(observed_name))
        previous = self.match_id, self.players, self.slots, self.observed
        if match != self.match_id or self.players.keys() != players.keys():
            self._draft = None
        self.match_id, self.players, self.observed = match, players, observing
        self._unidentified, self._complete = unknown, complete
        self._api = self._orient(api)
        self._raw = self._orient(raw)
        self._has_portraits = bool(confirmed and slots)
        if raw and self._last_confirmed.get(match) != raw:
            self._last_confirmed[match] = raw
            self._save_map('cameraConfirmedOrders', self._last_confirmed)
        self._refresh_order()
        if previous != (self.match_id, self.players, self.slots, self.observed):
            self.changed.emit()

    def _save_map(self, key, value):
        self.settings.setValue(key, json.dumps(value, ensure_ascii=False))

    def manual_names(self):
        return tuple(self.players[key]['name'] for key in self._saved_order(self._orders))

    def _orient(self, order):
        """Convert between stored HUD order (left to right) and this panel’s position order."""
        return order[::-1] if self.right_to_left else order.copy()

    def _saved_order(self, orders):
        saved = orders.get(self.match_id)
        if (self._complete and self.match_id and isinstance(saved, list) and len(saved) == 12
                and all(isinstance(key, str) for key in saved) and set(saved) == self.players.keys()):
            return self._orient(saved)
        return []

    def _refresh_order(self):
        manual = self._saved_order(self._orders)
        self.slots = dict(enumerate(manual or self._raw, 1))
        previous_order = self._display
        previously_selected = self.table.currentRow()
        self._display = list(self._draft or manual or self._raw or self._saved_order(self._last_confirmed)
                             or self._api or self._orient(list(self.players)))
        self._render()
        if previous_order != self._display and 0 <= previously_selected < len(previous_order):
            selected = previous_order[previously_selected]
            if selected in self._display:
                self.table.selectRow(self._display.index(selected))
            else:
                self.table.setCurrentCell(-1, -1)
                self.table.clearSelection()

    def _render(self):
        manual = self._saved_order(self._orders)
        rows = [self.players[account] for account in self._display] + self._unidentified
        self.table.setVisible(bool(rows))
        self.actions.setVisible(bool(rows))
        self.count.setVisible(bool(rows))
        self.count.setText(f'Account ID · {len(self.players)} / 12')
        focused = self.players.get(self.observed)
        self.focus_player.setVisible(bool(focused))
        self.focus_player.setText('Под наблюдением · ' + focused['name'] if focused else '')
        if not self.match_id:
            status = 'Введите ID матча и нажмите «Подключить», чтобы загрузить состав SourceTV.'
        elif not rows:
            status = 'Ожидание состава из SourceTV.'
        elif not self._complete:
            status = 'Для назначения клавиш нужны 12 уникальных Account ID, по 6 на команду.'
        elif self._draft is not None:
            status = 'Порядок изменён. Нажмите «Подтвердить порядок вручную», чтобы назначить клавиши.'
        elif manual:
            status = 'Клавиши назначены вручную для этого матча.'
        elif self._raw:
            status = 'Клавиши подтверждены портретами Panorama.'
        elif self._has_portraits:
            status = 'Не удалось однозначно сопоставить ники Panorama с Account ID. Доступна ручная расстановка.'
        else:
            status = 'Ожидание портретов Panorama этого матча. Доступна ручная расстановка.'
        if self._api and self._raw and self._api != self._raw:
            status += ' Порядок SourceTV отличается от Panorama.'
        if self.match_id:
            status = f'Матч {self.match_id} · {status}'
        if status != self.status.text():
            self.status.setText(status)
        if not rows:
            self._view = None
            self._buttons()
            return
        mappings = self._camera_mapping()
        values = []
        for i, key in enumerate(reversed(KEYS) if self.right_to_left else KEYS):
            p = rows[i] if i < len(rows) else {}
            account = self._display[i] if i < len(self._display) else None
            hero_id = p.get('heroId')
            values.append((key, p.get('name') or '—', p.get('hero') or (f'ID {hero_id}' if hero_id else '—'),
                           TEAM_NAMES.get(p.get('side'), '—'), account or '—',
                           str(self._api.index(account) + 1) if account in self._api else '—',
                           str(self._raw.index(account) + 1) if account in self._raw else '—',
                           'Задан' if account in self.pages else 'Добавить' if account else '—',
                           str(i + 1), *(s or '—' for s in mappings.get(account, OperatorCamera()))))
        if values != self._view:
            self._view = values
            for row, cells in enumerate(values):
                for col, value in enumerate(cells):
                    item = QTableWidgetItem(value)
                    if col in (0, 5, 6):
                        item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                    if col in (0, 1):
                        font = item.font()
                        font.setBold(True)
                        item.setFont(font)
                    if col == 3 and value in TEAM_NAMES.values():
                        item.setForeground(QColor('#e6be83' if value == TEAM_NAMES[2] else '#a6c9f2'))
                    if col == 7 and value != '—':
                        item.setForeground(QColor('#91dcce' if value == 'Задан' else '#b8c6cb'))
                        item.setToolTip('Открыть ссылку VDO.Ninja для редактирования')
                    elif value != '—':
                        item.setToolTip(value)
                    self.table.setItem(row, col, item)
        self._buttons()

    def _buttons(self, *_):
        row = self.table.currentRow()
        editable = bool(self.match_id and self._complete)
        self.up.setEnabled(editable and 0 < row < 12)
        self.down.setEnabled(editable and 0 <= row < 11)
        self.apply.setEnabled(editable)
        self.reset.setEnabled(self._draft is not None or bool(self._saved_order(self._orders)))
        self.edit.setEnabled(0 <= row < len(self._display))
        self.copy_page.setEnabled(0 <= row < len(self._display) and bool(self.pages.get(self._display[row])))

    def _copy_page(self):
        row = self.table.currentRow()
        if 0 <= row < len(self._display):
            page = self.pages.get(self._display[row])
            if page:
                QApplication.clipboard().setText(page)

    def _move(self, delta):
        row = self.table.currentRow()
        target = row + delta
        if not self.match_id or not self._complete or not 0 <= row < 12 or not 0 <= target < 12:
            return
        self._draft = self._display.copy()
        self._draft[row], self._draft[target] = self._draft[target], self._draft[row]
        self._refresh_order()
        self.table.selectRow(target)

    def _apply_order(self):
        if self._complete and self.match_id:
            self._orders[self.match_id] = self._orient(self._display)
            self._save_map('cameraManualOrders', self._orders)
            self._draft = None
            self._refresh_order()
            self.changed.emit()

    def _reset_order(self):
        self._orders.pop(self.match_id, None)
        self._save_map('cameraManualOrders', self._orders)
        self._draft = None
        self._refresh_order()
        self.changed.emit()

    def _edit_page(self):
        row = self.table.currentRow()
        if not 0 <= row < len(self._display):
            return
        key = self._display[row]
        name = self.players[key]['name']
        dialog = QDialog(self)
        dialog.setWindowTitle('Камера VDO.Ninja')
        layout = QVBoxLayout(dialog)
        identity = QLabel(f'{name} · Account ID {key}')
        identity.setTextFormat(Qt.TextFormat.PlainText)
        identity.setWordWrap(True)
        layout.addWidget(identity)
        field = QLineEdit(self.pages.get(key, ''))
        field.setClearButtonEnabled(True)
        field.setEchoMode(QLineEdit.EchoMode.Password)
        label = QLabel('Приватный URL просмотра VDO.Ninja')
        label.setBuddy(field)
        layout.addWidget(label)
        layout.addWidget(field)
        note = QLabel('Когда vMix применит новый URL, браузерный вход переподключится. '
                      'Если камера в эфире, изображение может прерваться.')
        note.setWordWrap(True)
        layout.addWidget(note)
        error = QLabel()
        error.setWordWrap(True)
        error.hide()
        layout.addWidget(error)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Save).setText('Сохранить URL')
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText('Отмена')
        buttons.rejected.connect(dialog.reject)

        def accept():
            if key not in self.players:
                error.setText('Игрок покинул состав. Закройте окно и проверьте текущий матч.')
            elif self.set_page(key, field.text().strip()):
                dialog.accept()
                return
            else:
                error.setText('Укажите полный HTTP(S) URL камеры или очистите поле.')
                field.setFocus()
            error.show()

        buttons.accepted.connect(accept)
        layout.addWidget(buttons)
        dialog.resize(400, dialog.sizeHint().height())
        field.setFocus()
        dialog.exec()
        dialog.deleteLater()

    def set_page(self, account, page):
        if account not in self.players:
            return False
        if page and not _page_valid(page):
            self.status.setText('Введите полный HTTP(S) URL камеры.')
            return False
        self.update_pages({account: page})
        return True

    def update_pages(self, updates):
        pages = dict(self.pages)
        for account, page in updates.items():
            if _account(account) != account or (page and not _page_valid(page)):
                raise ValueError('Проверьте Account ID и URL камеры.')
            if page:
                pages[account] = page
            else:
                pages.pop(account, None)
        if pages != self.pages:
            self.pages = pages
            self._save_map('cameraAccountPages', pages)
            self._render()
            self.changed.emit()
