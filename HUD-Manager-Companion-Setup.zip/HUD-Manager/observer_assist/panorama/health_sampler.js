const nativeHudOptions = null;
(function () {
    const root = $.GetContextPanel();
    let previousPlayer = '';
    let selectedPlayer = '';
    let selectedDetails = {};
    let selection = 0;
    $.Msg('[DOA-PANORAMA] sampler loaded');
    const wantsMinimapOnly = false;
    const hidden = new Map();
    let appliedMap = null;
    let appliedPause = null;
    let nextHudRefresh = 0;
    let lastRoster = 0;
    let bossCountdown = null;
    let lastFrame = 0;
    let lastFrameKey = '';
    let sequence = 0;
    const session = Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
    let rift = null;
    let riftMap = null;
    let riftSequence = 0;
    let riftWatching = false;
    let riftWarningDeadline = null;
    let nextRiftCheck = 0;
    let lastRiftPacket = 0;
    let midBoss = null;
    let dataFeed = null;
    let bossSequence = 0;
    let claimSequence = 0;
    let nextBossCheck = 0;
    let lastBossPacket = 0;
    let bossFeedEntries = new Map();
    let nativeFeed = null;
    let nativeFeedRows = new Map();
    let nativeFeedSequence = 0;
    let nativeFeedEvents = [];
    let urnCarry = null;
    let nextFeedCheck = 0;
    let lastFeedPacket = 0;
    const spentRejuvenators = {2: new Map(), 3: new Map()};
    const spentBadgeLifetime = 8000;
    let reportedError = false;
    let reportedRestoreError = false;
    const sampleInterval = 0.025;

    function restorePanelOpacity(panel, opacity) {
        try {
            if (!panel.IsValid()) return;
            if (!opacity && typeof panel.ClearPropertyFromCode === 'function') {
                panel.ClearPropertyFromCode('opacity');
            } else {
                panel.style.opacity = opacity || '1.0';
            }
        } catch (error) {
            if (!reportedRestoreError) {
                reportedRestoreError = true;
                $.Msg('[DOA-PANORAMA] opacity restore diagnostic: ' + String(error));
            }
        }
    }

    function restoreHud() {
        const wasHidden = hidden.size > 0;
        for (const [panel, opacity] of hidden) {
            restorePanelOpacity(panel, opacity);
        }
        hidden.clear();
        appliedMap = null;
        appliedPause = null;
        if (wasHidden) $.Msg('[DOA-PANORAMA] HUD restored');
    }

    function updateHud(minimap, observing, now) {
        if (!observing || (!wantsMinimapOnly && !nativeHudOptions) || !minimap) {
            if (appliedMap || hidden.size) restoreHud();
            return;
        }
        // PregameCountdown has another PausedGameContainer before the actual match pause.
        const pause = appliedPause?.IsValid() ? appliedPause :
            root.FindChildTraverse('PausedInfo')?.FindChildTraverse('PausedGameContainer') ?? null;
        const samePanels = appliedMap === minimap && appliedPause === pause;
        if (samePanels && (!nativeHudOptions || now < nextHudRefresh)) return;
        nextHudRefresh = now + 200;
        const hud = root.id === 'Hud' ? root : (root.FindChildTraverse('Hud') || root);
        const {show, hide} = nativeHudOptions ? doaNativeHudPanels(hud, minimap, nativeHudOptions) : {show: [], hide: []};
        const desired = new Set(hide);
        const keep = new Set();
        const parents = new Set();
        for (const target of wantsMinimapOnly ? [minimap, pause, ...show] : []) {
            if (!target) continue;
            const path = [];
            let node = target;
            for (let i = 0; node && node !== hud && i < 32; i += 1) {
                path.push(node);
                node = node.GetParent();
            }
            if (node !== hud) {
                if (target === minimap) {
                    restoreHud();
                    return;
                }
                continue;
            }
            for (const child of path) {
                keep.add(child);
                parents.add(child.GetParent());
            }
        }
        for (const parent of parents) {
            if (parent === minimap || parent === pause || show.includes(parent)) continue;
            for (let index = 0; index < parent.GetChildCount(); index += 1) {
                const panel = parent.GetChild(index);
                if (!panel || !panel.IsValid() || keep.has(panel)) continue;
                desired.add(panel);
            }
        }
        for (const [panel, opacity] of hidden) {
            if (!desired.has(panel) || !panel.IsValid()) {
                hidden.delete(panel);
                restorePanelOpacity(panel, opacity);
            }
        }
        for (const panel of desired) {
            if (!panel.IsValid() || hidden.has(panel)) continue;
            hidden.set(panel, panel.style.opacity || '');
            panel.style.opacity = '0.0';
        }
        appliedMap = minimap;
        appliedPause = pause;
        if (!samePanels && wantsMinimapOnly) {
            $.Msg('[DOA-PANORAMA] minimap-only applied; hidden=' + hidden.size + '; pause=' + keep.has(pause));
        }
    }

    function firstLabel(parent, className) {
        if (!parent || !parent.IsValid()) return null;
        const labels = parent.FindChildrenWithClassTraverse(className);
        return labels.length === 1 ? labels[0] : null;
    }

    function labelText(label) {
        if (!label || typeof label.text !== 'string') return null;
        const text = label.text.trim();
        return text && !/^\{[^}]+\}$/.test(text) ? text.slice(0, 160) : null;
    }

    function readNumber(label) {
        const text = (labelText(label) || '').replace(/[\s\u00a0\u202f]/g, '');
        if (!/^\/?\d{1,7}$/.test(text)) return null;
        return Number(text.replace('/', ''));
    }

    function encode(value) {
        return JSON.stringify(value)
            .replace(/[^\x20-\x7e]/g, character => '\\u' + character.charCodeAt(0).toString(16).padStart(4, '0'));
    }

    function logJson(marker, value) {
        $.Msg(marker + encode(value));
    }

    function isSpectating(minimap) {
        for (let panel = minimap; panel; panel = panel.GetParent()) {
            if (panel.BHasClass('TeamSpectator')) return true;
        }
        return false;
    }

    const minimapStyles = new Map();
    let nextMinimapUpdate = 0;
    let hiddenMinimapFrame = null;
    let originalMinimapFrameOpacity = '';
    let terrainBackdrop = null;
    let hiddenMinimapLocation = null;
    let originalMinimapLocationOpacity = '';

    function updateMinimapBackdrop(frame, terrain) {
        if (hiddenMinimapFrame !== frame) {
            if (hiddenMinimapFrame) restorePanelOpacity(hiddenMinimapFrame, originalMinimapFrameOpacity);
            hiddenMinimapFrame = frame;
            if (frame) {
                originalMinimapFrameOpacity = frame.style.opacity || '';
                frame.style.opacity = '0.0';
            }
        }
        if (terrainBackdrop?.IsValid() && terrainBackdrop.GetParent() !== terrain) {
            terrainBackdrop.DeleteAsync(0);
            terrainBackdrop = null;
        }
        if (terrain && !terrainBackdrop?.IsValid()) {
            terrainBackdrop = $.CreatePanel('Image', terrain, 'DhmMinimapBackdrop');
            terrainBackdrop.AddClass('can_zoom');
            terrainBackdrop.hittest = false;
            terrainBackdrop.hittestchildren = false;
            Object.assign(terrainBackdrop.style, {
                width: '100%', height: '100%', zIndex: '-4', opacity: '0.86',
            });
            // Native terrain layers change floors, but player markers still cover the full map.
            terrainBackdrop.SetImage('s2r://panorama/images/doa/minimap_surface.vsvg');
            $.Msg('[DOA-MINIMAP] terrain backdrop applied');
        }
    }

    function updateSpectatorMinimap(minimap, now) {
        if (now < nextMinimapUpdate) return;
        nextMinimapUpdate = now + 200;
        const colors = nativeHudOptions?.minimapTeamColors;
        const container = minimap?.FindChildTraverse?.('minimap_container');
        const location = minimap?.FindChildTraverse?.('minimap_location');
        const spectating = (colors || container || location) && minimap?.IsValid() && isSpectating(minimap);
        // The transparent-background option already hides the frame with the other HUD panels.
        const backdropEnabled = spectating && nativeHudOptions?.minimapBackground !== false;
        const frame = backdropEnabled ? container?.FindChildTraverse('minimap_frame') : null;
        const terrain = backdropEnabled ? container?.FindChildTraverse('MinimapBackgroundTest') : null;
        updateMinimapBackdrop(frame?.IsValid() ? frame : null, terrain?.IsValid() ? terrain : null);
        const visibleLocation = spectating && location?.IsValid() ? location : null;
        if (visibleLocation !== hiddenMinimapLocation) {
            if (hiddenMinimapLocation) restorePanelOpacity(hiddenMinimapLocation, originalMinimapLocationOpacity);
            hiddenMinimapLocation = visibleLocation;
            if (visibleLocation) {
                originalMinimapLocationOpacity = visibleLocation.style.opacity || '';
                visibleLocation.style.opacity = '0.0';
                $.Msg('[DOA-MINIMAP] street label hidden');
            }
        }
        if (!colors) return;
        const active = new Set();
        const hadMarkers = minimapStyles.size > 0;
        if (spectating) {
            for (const marker of minimap.FindChildrenWithClassTraverse('map_button')) {
                if (!marker.IsValid() || !marker.BHasClass('player')) continue;
                const color = marker.BHasClass('team1') ? colors.left :
                    marker.BHasClass('team2') ? colors.right : null;
                const background = color && marker.FindChildTraverse('BackgroundImage');
                if (!background?.IsValid()) continue;
                if (!minimapStyles.has(background)) minimapStyles.set(background, background.style.backgroundColor || '');
                active.add(background);
                if (background.style.backgroundColor !== color) background.style.backgroundColor = color;
            }
        }
        for (const [background, original] of minimapStyles) {
            if (active.has(background)) continue;
            if (background.IsValid()) background.style.backgroundColor = original;
            minimapStyles.delete(background);
        }
        if (!hadMarkers && active.size) $.Msg('[DOA-MINIMAP] team colors applied: ' + active.size);
    }

    function riftPhase(minimap) {
        if (!isSpectating(minimap)) return null;
        let active = 0;
        let warning = 0;
        for (const point of minimap.FindChildrenWithClassTraverse('capture_point')) {
            if (!point.IsValid() || point.visible === false || !point.BHasClass('map_button')) continue;
            if (point.BHasClass('koth_warning')) warning += 1;
            else if (point.BHasClass('active')) active += 1;
        }
        if (active === 1) return 'spawned';
        return !active && warning === 1 ? 'warning' : null;
    }

    function feedActor(row, top) {
        const actor = row.FindChildTraverse('KillerContainer');
        if (!actor) return null;
        const name = labelText(firstLabel(actor, 'killerInfo'));
        const amber = actor.BHasClass('team_1');
        const sapphire = actor.BHasClass('team_2');
        const sideFromClass = amber !== sapphire ? (amber ? 2 : 3) : null;
        const matches = [];
        if (name) {
            for (const [side, relation] of [[2, 'Friendly'], [3, 'Enemy']]) {
                const cards = doaSpectatorCards(top.FindChildTraverse('Team' + relation));
                for (const card of cards) {
                    if (labelText(firstLabel(card, 'PlayerName')) === name) matches.push(side);
                }
            }
        }
        const exact = matches.length === 1 ? matches[0] : null;
        if (exact && sideFromClass && exact !== sideFromClass) return null;
        const side = sideFromClass ?? exact;
        return side ? { side, name, uniqueOnSide: matches.filter(match => match === side).length === 1 } : null;
    }

    function newMidBoss() {
        return { id: session + ':boss:' + ++bossSequence, killedBy: null, killedAt: null, claimedBy: null, claimedAt: null };
    }

    function publishMidBoss(now) {
        logJson('[DOA-TELEMETRY] ', { version: 1, kind: 'midboss', stream: session, midBoss });
        lastBossPacket = now;
    }

    function updateMidBoss(minimap, top, now) {
        if (now < nextBossCheck) return;
        nextBossCheck = now + 100;
        const feed = top && minimap?.IsValid() && isSpectating(minimap) ? root.FindChildTraverse('DataFeed') : null;
        const sameFeed = !!feed && feed === dataFeed;
        let changed = !sameFeed && !!midBoss;
        if (!sameFeed) {
            dataFeed = feed;
            midBoss = null;
            bossFeedEntries.clear();
            for (const spent of Object.values(spentRejuvenators)) spent.clear();
        }
        if (feed?.IsValid()) {
            const currentEntries = new Map();
            for (const [className, event] of [['midBoss', 'killed'], ['isRejuvenatorPickup', 'claimed'], ['isRejuvenatorUsed', 'spent']]) {
                const fresh = [];
                for (const row of feed.FindChildrenWithClassTraverse(className)) {
                    if (!row.IsValid() || !['CitadelHudInfoFeed', 'CitadelHudBossKilled'].includes(row.paneltype)) continue;
                    if (event === 'killed' && !row.BHasClass('bossDied')) continue;
                    const actor = feedActor(row, top);
                    if (!actor) continue;
                    const signature = JSON.stringify([event, actor.side, actor.name]);
                    currentEntries.set(row, signature);
                    if (bossFeedEntries.get(row) !== signature) fresh.push(actor);
                }
                if (event === 'spent') {
                    for (const actor of fresh) {
                        if (actor.uniqueOnSide) spentRejuvenators[actor.side].set(actor.name, now);
                    }
                } else if (event === 'killed' && fresh.length === 1) {
                    midBoss = newMidBoss();
                    midBoss.killedBy = fresh[0].side;
                    midBoss.killedAt = sameFeed ? now : null;
                    changed = true;
                } else if (event === 'claimed' && (sameFeed || fresh.length === 1)) {
                    for (const {side} of fresh) {
                        midBoss ??= newMidBoss();
                        midBoss.claimedBy = side;
                        midBoss.claimedAt = sameFeed ? now : null;
                        midBoss.claimId = session + ':claim:' + ++claimSequence;
                        spentRejuvenators[side].clear();
                        publishMidBoss(now);
                        changed = false;
                    }
                }
            }
            bossFeedEntries = currentEntries;
        }
        if (changed || midBoss && now - lastBossPacket >= 500) publishMidBoss(now);
    }

    function updateRift(minimap, top, now) {
        if (now < nextRiftCheck) return;
        nextRiftCheck = now + 100;
        const watching = !!top && minimap?.IsValid() && isSpectating(minimap);
        const phase = watching ? riftPhase(minimap) : null;
        const sameMap = minimap === riftMap;
        const wasWatching = riftWatching;
        riftWatching = watching;
        riftMap = minimap;
        if (!rift && !phase) return;
        const changed = !sameMap || rift?.phase !== phase;
        if (changed) {
            const witnessed = sameMap && rift?.phase === 'warning' && phase === 'spawned';
            const gameClock = labelText(top?.FindChildTraverse('GameTime'));
            const seconds = clockSeconds(gameClock);
            // The stock warning lasts 20 game seconds. A warning already in progress has no known start.
            riftWarningDeadline = sameMap && wasWatching && phase === 'warning' && seconds !== null ? seconds + 20 : null;
            rift = phase ? {
                id: witnessed ? rift.id : session + ':' + ++riftSequence,
                phase,
                spawnedAt: witnessed ? now : null,
                gameClock,
            } : null;
        }
        if (rift?.phase === 'warning' && riftWarningDeadline !== null) {
            const seconds = clockSeconds(labelText(top?.FindChildTraverse('GameTime')));
            if (seconds !== null) {
                rift.secondsUntil = Math.min(20, Math.max(0, riftWarningDeadline - seconds));
                rift.estimated = true;
            }
        }
        if (changed || now - lastRiftPacket >= 500) {
            logJson('[DOA-TELEMETRY] ', { version: 1, kind: 'rift', stream: session, rift });
            lastRiftPacket = now;
        }
    }

    function logTelemetry(value) {
        const payload = encode(value);
        const length = 650;
        const total = Math.ceil(payload.length / length);
        if (total > 36) return;
        sequence += 1;
        for (let index = 0; index < total; index += 1) {
            logJson('[DOA-TELEMETRY-PART] ', {
                session, sequence, index, total, part: payload.slice(index * length, (index + 1) * length),
            });
        }
    }

    function updateNativeFeed(minimap, top, now) {
        if (typeof doaReadNativeObjectiveRow !== 'function' || now < nextFeedCheck) return;
        nextFeedCheck = now + 100;
        const feed = top && minimap?.IsValid() && isSpectating(minimap)
            ? root.FindChildTraverse('DataFeed')?.FindChildTraverse('EventFeed') : null;
        const sameFeed = !!feed && feed === nativeFeed;
        let changed = !sameFeed && nativeFeedEvents.length > 0;
        if (!sameFeed) {
            nativeFeed = feed;
            nativeFeedRows.clear();
            nativeFeedEvents = [];
            urnCarry = null;
        }
        if (feed?.IsValid()) {
            const currentRows = new Map();
            const gameClock = labelText(top.FindChildTraverse('GameTime'));
            const seconds = clockSeconds(gameClock);
            for (let index = 0; index < feed.GetChildCount(); index += 1) {
                const row = feed.GetChild(index);
                const entry = doaReadNativeObjectiveRow(row);
                if (!entry) continue;
                const key = JSON.stringify(entry);
                currentRows.set(row, key);
                if (key === nativeFeedRows.get(row)) continue;
                const event = {...entry, id: session + ':feed:' + ++nativeFeedSequence, at: now, gameClock};
                if (entry.kind === 'urnPickup') {
                    urnCarry = sameFeed && entry.actor && entry.actorSide && seconds !== null
                        ? {name: entry.actor, side: entry.actorSide, seconds} : null;
                } else if (entry.kind === 'urnDelivery') {
                    if (urnCarry && seconds !== null && seconds >= urnCarry.seconds &&
                            urnCarry.name === entry.actor && urnCarry.side === entry.actorSide) {
                        event.durationSeconds = seconds - urnCarry.seconds;
                    }
                    urnCarry = null;
                }
                nativeFeedEvents.push(event);
                changed = true;
            }
            nativeFeedRows = currentRows;
        }
        if (changed || nativeFeedEvents.length && now - lastFeedPacket >= 1500) {
            nativeFeedEvents = nativeFeedEvents.slice(-12);
            logTelemetry({version: 1, kind: 'world-feed', stream: session, events: nativeFeedEvents});
            lastFeedPacket = now;
        }
    }

    function rosterHealth(row, spectating) {
        const bar = row.FindChildTraverse('HealthBar');
        if (!bar?.IsValid()) return undefined;
        if (row.BHasClass('Dead')) return 0;
        const shown = row.BHasClass('HealthVisible');
        if (!spectating && !shown) return undefined;
        const contents = bar.FindChildTraverse('HealthBar_Contents');
        const fill = contents?.FindChildTraverse('HealthBar_Fill');
        if (!fill?.IsValid() || fill.visible === false) return undefined;
        const clip = /^rect\(\s*([\d.]+)%\s*,\s*[\d.]+%\s*,\s*([\d.]+)%\s*,\s*[\d.]+%\s*\)$/.exec(fill.style?.clip?.trim());
        if (clip) {
            const visible = Number(clip[2]) - Number(clip[1]);
            if (visible >= 0 && visible <= 100 && (shown || visible !== 100)) return Math.round(visible);
        }
        const percentage = /^(\d{1,3}(?:\.\d+)?)%$/.exec(fill.style?.height?.trim());
        if (percentage) {
            const value = Number(percentage[1]);
            if (value <= 100 && (shown || value !== 100)) return Math.round(value);
        }
        const height = contents.actuallayoutheight;
        const filled = fill.actuallayoutheight;
        if (Number.isFinite(height) && Number.isFinite(filled) && height > 0 &&
                (filled > 0 || filled === 0 && shown) && (filled < height || shown && filled === height)) {
            return Math.round(100 * filled / height);
        }
    }

    function playerRows(team, side, now, spectating) {
        const result = [];
        for (const row of doaSpectatorCards(team)) {
            const name = labelText(firstLabel(row, 'PlayerName'));
            if (!name) continue;
            const ready = row.BHasClass?.('HasRejuvenator') || row.BHasClass?.('HasRebirthAndRejuv');
            const spentAt = spentRejuvenators[side].get(name);
            const rejuvenator = spentAt === undefined ? (ready ? 'ready' : null) :
                (now - spentAt < spentBadgeLifetime ? 'spent' : null);
            const hpPercent = rosterHealth(row, spectating);
            const unlocked = !!row.BHasClass?.('UltimateUnlocked');
            const ultimate = row.FindChildTraverse('UltimateStatus')?.IsValid()
                ? {unlocked, ready: unlocked && !!row.BHasClass?.('UltimateCooldownReady')} : undefined;
            result.push({
                name,
                hero: labelText(firstLabel(row, 'HeroName')),
                souls: labelText(row.FindChildTraverse('SoulsValue')),
                level: readNumber(firstLabel(row, 'HeroLevelLabel')),
                kills: readNumber(firstLabel(row, 'kills')),
                deaths: readNumber(firstLabel(row, 'deaths')),
                assists: readNumber(firstLabel(row, 'assists')),
                respawn: labelText(firstLabel(row, 'RespawnTimer')),
                hpPercent,
                ultimate,
                ...(rejuvenator ? {rejuvenator} : {}),
            });
        }
        return result;
    }

    function visibleLabels(panel, count) {
        const result = [];
        if (!panel) return result;
        const pending = [panel];
        for (let seen = 0; pending.length && seen < 150 && result.length < count; seen += 1) {
            const child = pending.pop();
            if (!child || !child.IsValid() || child.visible === false) continue;
            if (child.paneltype === 'Label') {
                const text = labelText(child);
                if (text) result.push({ id: child.id || null, text });
                continue;
            }
            for (let i = child.GetChildCount() - 1; i >= 0; i -= 1) pending.push(child.GetChild(i));
        }
        return result;
    }

    function upgradeLevel(slot) {
        const tiers = [0, 1, 2, 3].filter(level => slot.BHasClass?.('Tier' + level));
        if (tiers.length === 1) return tiers[0];
        if (tiers.length) return undefined;
        const holder = slot.FindChildTraverse('ReadOnlyPipsContainer');
        const pips = holder?.FindChildrenWithClassTraverse('readOnlyPip')?.filter(pip => pip.IsValid());
        return pips?.length === 3 ? pips.filter(pip => pip.BHasClass('upgraded')).length : undefined;
    }

    function abilitySlots(panel, limit, signature = false) {
        if (!panel) return [];
        const result = [];
        const slots = panel.FindChildrenWithClassTraverse('ability_container');
        for (const slot of slots) {
            if (result.length >= limit) break;
            if (!slot.IsValid() || slot.visible === false || slot.BHasClass?.('NoAbility')) continue;
            const name = labelText(firstLabel(slot, 'ability_name'));
            const keyboard = labelText(slot.FindChildTraverse('KeyboardLetter'));
            // Panorama keeps the last timer text when the native CSS hides it.
            const showingCooldown = slot.BHasClass?.('cooling_down') &&
                !['active', 'toggled_on', 'channeling'].some(state => slot.BHasClass(state));
            const text = showingCooldown ? labelText(firstLabel(slot, 'cooldown_timer')) : null;
            const seconds = text && /^\d{1,3}(?:[.,]\d{1,2})?$/.test(text) ? Number(text.replace(',', '.')) : null;
            let image = null;
            const artwork = slot.FindChildTraverse('ability_image');
            if (artwork) {
                try {
                    const source = typeof artwork.GetImage === 'function' ? artwork.GetImage() : artwork.src;
                    if (typeof source === 'string' && source.length < 240) image = source;
                } catch (_) {}
            }
            if (name || keyboard || image || seconds > 0) {
                const level = signature ? upgradeLevel(slot) : undefined;
                const bonus = signature && slot.BHasClass('hasBonusCounter')
                    ? labelText(firstLabel(slot, 'bonusCounter')) : null;
                const stackCount = bonus && /^(?:[x×+]\s*)?(\d{1,6})$/i.exec(bonus);
                const stacks = stackCount ? Number(stackCount[1]) : undefined;
                const charges = signature && slot.BHasClass('uses_charges')
                    ? readNumber(slot.FindChildTraverse('charges')) ?? undefined : undefined;
                result.push({ name, key: keyboard, cooldown: seconds, image, level, stacks, charges });
            }
        }
        return result;
    }

    function hasAncestorClass(panel, name) {
        for (let node = panel; node; node = node.GetParent?.()) {
            if (node.BHasClass?.(name)) return true;
        }
        return false;
    }

    function visibleResource(parent, name) {
        const panels = parent.FindChildrenWithClassTraverse(name)
            .filter(panel => panel.IsValid() && panel.visible !== false);
        return panels.length === 1 ? panels[0] : undefined;
    }

    function staminaFromReticle(pips) {
        // The native dash reticle starts at 135 degrees and divides 93 degrees
        // into equal slots, leaving a three-degree gap after each charge.
        const pitch = 93 / pips.length;
        const full = pitch - 3;
        const tolerance = .03;
        const sectors = [];
        for (const pip of pips) {
            const clip = pip.FindChildTraverse('progress')?.style?.clip;
            const angles = /^radial\([^,]+,\s*(-?[\d.]+)deg,\s*(-?[\d.]+)deg\s*\)$/.exec(clip?.trim());
            if (!angles) return undefined;
            const start = Number(angles[1]);
            const sweep = Math.abs(Number(angles[2]));
            if (!Number.isFinite(start) || !Number.isFinite(sweep) || sweep > full + tolerance) return undefined;
            sectors.push({start, sweep, pip});
        }
        sectors.sort((left, right) => left.start - right.start);
        if (sectors.some(({start}, index) => Math.abs(start - (135 + index * pitch)) > tolerance)) return undefined;
        return sectors.filter(({sweep, pip}) => sweep >= full - tolerance &&
            !['charging', 'draining', 'disabled'].some(name => pip.BHasClass(name))).length;
    }

    function selectedResources(minimap) {
        if (!minimap?.IsValid() || !isSpectating(minimap)) return {};
        const result = {};
        const gold = root.FindChildTraverse('gold_and_ap_container');
        const insecureSouls = readNumber(gold?.FindChildTraverse('hudDeathGoldLabel'));
        if (insecureSouls !== null) result.insecureSouls = insecureSouls;
        const crosshair = root.FindChildTraverse('crosshair');
        if (!crosshair?.IsValid() || !hasAncestorClass(crosshair, 'view_is_in_eye')) return result;

        const gun = visibleResource(crosshair, 'ability_element_gun');
        const magazine = gun?.FindChildTraverse('ammo_panel');
        if (magazine?.IsValid() && magazine.visible !== false) {
            if (hasAncestorClass(magazine, 'infinite_ammo')) {
                result.ammoInfinite = true;
            } else {
                const ammo = readNumber(firstLabel(magazine, 'weapon_ammo'));
                const maxAmmo = readNumber(firstLabel(magazine, 'weapon_ammo_max'));
                if (ammo !== null && maxAmmo > 0) Object.assign(result, {ammo, maxAmmo});
            }
        }

        const dash = visibleResource(crosshair, 'ability_element_charges');
        const charges = dash?.BHasClass('active') ? dash.FindChildTraverse('charges_container') : null;
        const pips = charges?.FindChildrenWithClassTraverse('charge')
            .filter(pip => pip.IsValid() && pip.visible !== false && pip.BHasClass('has_charge')) ?? [];
        if (pips.length && pips.length <= 16) {
            result.maxStamina = pips.length;
            const stamina = staminaFromReticle(pips);
            if (stamina !== undefined) result.stamina = stamina;
        }

        const invisibility = root.FindChildTraverse('gameplay_hud_alive')?.FindChildTraverse('invisibility');
        if (invisibility?.IsValid()) {
            result.invisible = invisibility.BHasClass('is_invisible');
            const modes = ['spotted', 'hidden', 'fully'].filter(state => invisibility.BHasClass('invis_' + state));
            result.invisibility = result.invisible ? (modes.length === 1 ? modes[0] : 'invisible') : 'visible';
        }
        return result;
    }

    function clockSeconds(text) {
        const clock = /^(\d{1,4}):([0-5]\d)$/.exec(text || '');
        return clock ? Number(clock[1]) * 60 + Number(clock[2]) : null;
    }

    function midBossCountdown(top, minimap, gameClock) {
        const clock = clockSeconds(gameClock);
        if (clock === null || !isSpectating(minimap)) {
            bossCountdown = null;
            return null;
        }
        const topTimer = top.FindChildTraverse('RejuvenatorTimer');
        const marker = minimap.FindChildrenWithClassTraverse('mid_boss')
            .find(panel => panel.IsValid() && panel.BHasClass('map_button'));
        if (topTimer?.BHasClass('midboss_available') || marker?.BHasClass('midboss_spawned')) {
            bossCountdown = null;
            return null;
        }
        if (bossCountdown?.map !== minimap || clock < bossCountdown.clock || clock - bossCountdown.clock > 10) {
            bossCountdown = {map: minimap, clock, deadline: null, topSeconds: null, mapSeconds: null};
        }
        const state = bossCountdown;
        const topSeconds = topTimer?.BHasClass('midboss_cooldown') && !topTimer.BHasClass('has_rejuv')
            ? clockSeconds(labelText(topTimer.FindChildTraverse('MidbossTimerLabel'))) : null;
        const mapSeconds = clockSeconds(labelText(firstLabel(marker, 'midboss_timer'))?.replace(/<[^>]+>/g, ''));
        if (topSeconds !== null && topSeconds !== state.topSeconds) {
            state.deadline = clock + topSeconds;
            state.topSeconds = topSeconds;
        } else if (topSeconds === null && mapSeconds !== null && state.mapSeconds !== null) {
            const decrease = state.mapSeconds - mapSeconds;
            if (decrease > 0 && decrease <= clock - state.clock + 1) state.deadline = clock + mapSeconds;
        }
        // Rejuvenator charges hide the top-bar label without clearing its text.
        // The match clock continues to advance and stops for game pauses.
        state.clock = clock;
        state.mapSeconds = mapSeconds;
        const remaining = state.deadline === null ? 0 : state.deadline - clock;
        return remaining > 0 ? Math.floor(remaining / 60) + ':' + String(remaining % 60).padStart(2, '0') : null;
    }

    function publishRoster(top, minimap) {
        const gameClock = labelText(top.FindChildTraverse('GameTime'));
        const now = Date.now();
        const spectating = !!minimap?.IsValid() && isSpectating(minimap);
        const teams = [[2, 'Friendly'], [3, 'Enemy']].map(([side, relation]) => {
            const team = top.FindChildTraverse('Team' + relation);
            const score = top.FindChildTraverse('TeamScore' + relation);
            const netWorth = labelText(firstLabel(score, 'ScoreLabel'));
            const charges = top.FindChildTraverse('Rejuvenator' + relation);
            const rejuv = [1, 2, 3, 4].filter(value => charges?.BHasClass?.('RejuvCount_' + value));
            return {
                side,
                netWorth: netWorth ? netWorth.replace(/<[^>]+>/g, '').trim() : null,
                kills: readNumber(firstLabel(top, relation + 'Kills')),
                rejuvenatorCharges: rejuv.length === 1 ? rejuv[0] : undefined,
                players: playerRows(team, side, now, spectating),
            };
        });
        logTelemetry({
            version: 1,
            kind: 'roster',
            stream: session,
            gameClock,
            midBossTimer: midBossCountdown(top, minimap, gameClock),
            teams,
        });
    }

    function publishFrame(top, selected, now, switching = false) {
        const gameClock = labelText(top?.FindChildTraverse('GameTime'));
        const frameKey = JSON.stringify([gameClock, selected, switching]);
        if (frameKey === lastFrameKey && now - lastFrame < 250) return;
        logTelemetry({ version: 1, kind: 'frame', stream: session, selection,
                       sampledAt: now, gameClock, selected, ...(switching ? {switching} : {}) });
        lastFrameKey = frameKey;
        lastFrame = now;
    }

    function sample() {
        if (!root.IsValid()) return;
        try {
            const target = root.FindChildTraverse('spectate_target');
            const playerLabel = firstLabel(target, 'playerName');
            const player = labelText(playerLabel) || '';
            const minimap = root.FindChildTraverse('minimap_persp');
            const health = root.FindChildTraverse('health_and_abilities_container');
            const hp = readNumber(firstLabel(health, 'currentHealthLabel'));
            const maxHp = readNumber(firstLabel(health, 'totalHealthLabel'));
            const top = root.FindChildTraverse('TopBar');
            const now = Date.now();
            updateSpectatorMinimap(minimap, now);
            updateRift(minimap, top, now);
            updateMidBoss(minimap, top, now);
            updateNativeFeed(minimap, top, now);
            if (player !== previousPlayer && (selectedPlayer || !player)) {
                // The spectator name can change before the health and loadout panels settle.
                selectedPlayer = '';
                publishFrame(top, null, now, !!player);
                if (!player) lastRoster = 0;
            }
            if (top && player && player === previousPlayer && hp !== null && maxHp > 0) {
                const switched = player !== selectedPlayer;
                const refreshRoster = !lastRoster || now - lastRoster >= 750;
                if (switched) {
                    selectedPlayer = player;
                    selection += 1;
                }
                const abilities = root.FindChildTraverse('hud_signature');
                const items = root.FindChildTraverse('ActiveAbilitiesMenu');
                if (switched || refreshRoster) {
                    selectedDetails = {
                        abilities: visibleLabels(abilities, 16),
                        items: visibleLabels(items, 16),
                    };
                }
                const selected = {
                    player, hp, maxHp,
                    regen: labelText(firstLabel(health, 'healthRegenLabel')),
                    bulletShield: visibleLabels(health.FindChildTraverse('BulletShieldNumbers'), 2),
                    techShield: visibleLabels(health.FindChildTraverse('TechShieldNumbers'), 2),
                    abilitySlots: abilitySlots(abilities, 8, true),
                    itemSlots: abilitySlots(items, 8),
                    ...selectedResources(minimap),
                    ...selectedDetails,
                };
                if (!lastRoster) {
                    publishRoster(top, minimap);
                    lastRoster = now;
                }
                publishFrame(top, selected, now);
                if (refreshRoster && lastRoster !== now) {
                    publishRoster(top, minimap);
                    lastRoster = now;
                }
            } else if (top && !player && minimap?.IsValid() && isSpectating(minimap) && (!lastRoster || now - lastRoster >= 750)) {
                publishRoster(top, minimap);
                lastRoster = now;
            }
            previousPlayer = player;
            updateHud(minimap, !!player || nativeHudOptions && minimap?.IsValid() && isSpectating(minimap), now);
        } catch (error) {
            previousPlayer = '';
            if (!reportedError) {
                reportedError = true;
                $.Msg('[DOA-PANORAMA] sampler diagnostic: ' + String(error));
            }
            if (appliedMap || hidden.size) restoreHud();
        } finally {
            $.Schedule(sampleInterval, sample);
        }
    }

    $.Schedule(sampleInterval, sample);
})();
