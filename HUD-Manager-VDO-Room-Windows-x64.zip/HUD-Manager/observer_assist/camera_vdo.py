"""Deliver room snapshots from the loopback bridge to camera routing on the Qt thread."""
from time import monotonic

from PySide6.QtCore import QObject, QTimer, QUrl, Signal
from PySide6.QtGui import QDesktopServices

from .camera_vdo_bridge import VdoRoomBridge
from .camera_vdo_room import parse_director


class VdoImport(QObject):
    received = Signal(int, object)

    def __init__(self, panel, cameras, parent=None, *, bridge_factory=VdoRoomBridge, open_url=QDesktopServices.openUrl):
        super().__init__(parent)
        self.panel, self.cameras = panel, cameras
        self.bridge_factory, self.open_url = bridge_factory, open_url
        self.bridge = self.room = None
        self.generation = 0
        self.last_response = 0
        self.known = {}
        self.missing_since = {}
        self.seen_nonempty = False
        self.timer = QTimer(self, interval=3000)
        self.timer.timeout.connect(self._check_connection)
        self.received.connect(self._accept)
        panel.start_requested.connect(self.start)
        panel.reopen_requested.connect(self.reopen)
        panel.stop_requested.connect(self.stop)

    def start(self, raw):
        self.stop(reset_panel=False)
        try:
            self.room = parse_director(raw)
        except ValueError as exc:
            self.panel.start_failed(str(exc))
            return
        generation = self.generation
        try:
            as_director = self.panel.director_mode.isChecked() or self.room.codirector
            self.bridge = self.bridge_factory(raw, lambda guests: self.received.emit(generation, guests),
                                              scene=not as_director)
            if not self.open_url(QUrl(self.bridge.url)):
                raise OSError
        except (OSError, ValueError):
            self.stop(reset_panel=False)
            self.panel.start_failed('Не удалось открыть локальную вкладку. Проверьте браузер по умолчанию.')
            return
        self.last_response = monotonic()
        self.panel.started()
        self.timer.start()

    def reopen(self):
        if self.bridge:
            self.open_url(QUrl(self.bridge.url))

    def _accept(self, generation, guests):
        if not self.bridge or generation != self.generation:
            return
        now = monotonic()
        self.last_response = now
        live = {g['streamID']: g for g in guests}
        if len(live) != len(guests):
            self.panel.show_result(len(guests), 'В списке повторяется Stream ID. Назначения камер сохранены.')
            return
        if live:
            self.seen_nonempty = True
        if not self.seen_nonempty:
            # The Director DOM can return {} even before room authorization is complete.
            self.panel.set_guests([])
            self.panel.show_result(0, 'Ожидание гостей. Проверьте вход в комнату во вкладке браузера.')
            return
        for sid in self.known.keys() - live.keys():
            since = self.missing_since.setdefault(sid, now)
            if now - since >= 6:
                del self.known[sid]
                self.missing_since.pop(sid, None)
        for sid, guest in live.items():
            self.known[sid] = dict(streamID=sid, label=guest['label'], page=self.room.viewer(sid))
            self.missing_since.pop(sid, None)
        summary = self.cameras.import_vdo_guests(self.room.key, list(self.known.values()))
        rows = [dict(label=self.known[sid]['label'], page=self.known[sid]['page'],
                     bank=self.cameras.vdo_guest_bank(self.room.key, sid)) for sid in live]
        self.panel.set_guests(sorted(rows, key=lambda row: (row['bank'] or 13, row['label'].casefold())))
        self.panel.show_result(len(live), summary)

    def _check_connection(self):
        if self.bridge and monotonic() - self.last_response > 20:
            self.panel.show_stale()
            self.missing_since.clear()

    def stop(self, *, reset_panel=True):
        self.timer.stop()
        self.generation += 1
        bridge, self.bridge = self.bridge, None
        if bridge:
            bridge.close()
        self.room = None
        self.known.clear()
        self.missing_since.clear()
        self.seen_nonempty = False
        if reset_panel:
            self.panel.stop()
