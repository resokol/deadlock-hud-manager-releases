"""Operator controls for an independent LiveCamera or Replay vMix destination."""

from ipaddress import IPv4Address
from uuid import UUID

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QFormLayout, QFrame, QGridLayout, QGroupBox, QHBoxLayout,
    QLabel, QLineEdit, QMenu, QPushButton, QSizePolicy, QSpinBox, QTabBar, QToolButton,
    QVBoxLayout, QWidget,
)

from .match_stats import is_lan_address


class _InputPicker(QWidget):
    """Keep the operator's GUID draft independent of the polled input catalog."""

    def __init__(self, label, inputs):
        super().__init__()
        self.inputs = inputs
        self.edit = QLineEdit(placeholderText='GUID входа')
        self.edit.setAccessibleName(label)
        self.button = QToolButton()
        self.button.setArrowType(Qt.ArrowType.DownArrow)
        self.button.setToolTip(f'Выбрать вход vMix · {label}')
        self.button.setAccessibleName(self.button.toolTip())
        self.menu = QMenu(self.button)
        self.menu.aboutToShow.connect(self._populate)
        self.menu.triggered.connect(lambda action: self.edit.setText(action.data()))
        self.button.setMenu(self.menu)
        self.button.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)
        layout.addWidget(self.edit, 1)
        layout.addWidget(self.button)

    def _populate(self):
        self.menu.clear()
        for guid, info in self.inputs().items():
            title = str(info.get('title') or 'Без названия').replace('&', '&&')
            kind = info.get('type') or '—'
            action = self.menu.addAction(f"{info.get('number', '—')} · {title} · {kind}")
            action.setData(guid)
            action.setToolTip(guid)
        if self.menu.isEmpty():
            self.menu.addAction('Сначала получите список входов vMix').setEnabled(False)

    def value(self):
        text = self.edit.text().strip()
        if not text:
            return ''
        try:
            return str(UUID(text))
        except ValueError:
            self.edit.setFocus()
            self.edit.selectAll()
            raise ValueError(f'{self.edit.accessibleName()} · введите GUID или выберите вход из списка.') from None


def _feedback():
    label = QLabel()
    label.setWordWrap(True)
    label.setTextFormat(Qt.TextFormat.PlainText)
    return label


CAMERA_STYLE = """
QFrame#cameraSummary { background: #1d252e; border: 1px solid #35434f; border-left: 4px solid #91dcce; border-radius: 6px; }
QFrame#cameraSummary QLabel { background: transparent; }
QLabel#cameraCaption, QLabel#cameraMessage { color: #bac8d0; }
QLabel#cameraActive { color: #ebf2f5; font-size: 21pt; font-weight: 600; }
QLabel#cameraConnection { font-weight: 600; color: #c3d0d5; }
QLabel#cameraConnection[online="true"] { color: #91dcce; }
QLabel#cameraGroup { font-size: 13pt; font-weight: 600; }
QTabBar#cameraTabs::tab { background: #141a21; color: #bac8d0; border-bottom: 2px solid #41505e; padding: 8px 16px; }
QTabBar#cameraTabs::tab:selected { color: #ebf2f5; border-bottom-color: #91dcce; background: #263039; }
QTabBar#cameraTabs::tab:hover { background: #263039; }
QPushButton#cameraTile { padding: 0; border: 1px solid #465762; border-radius: 6px; background: #25313a; }
QPushButton#cameraTile:hover { background: #31424b; border-color: #91dcce; }
QPushButton#cameraTile[onAir="true"] { background: #264540; border: 2px solid #91dcce; }
QPushButton#cameraTile:pressed { background: #354d50; }
QPushButton#cameraTile:focus { border: 2px solid #91dcce; }
QPushButton#cameraTile:disabled { background: #1d252e; border-color: #37434e; }
QPushButton#cameraTile QLabel { background: transparent; }
QLabel#slotKey { color: #c9eee6; background: #253b3b; border: 1px solid #526d6c; border-radius: 4px; font-weight: 600; }
QLabel#slotKey:disabled { color: #b5c2c9; background: #29333d; border-color: #475561; }
QLabel#slotPosition { color: #aabac4; font-size: 9pt; }
QLabel#slotName { color: #ebf2f5; font-weight: 600; }
QLabel#slotName:disabled { color: #afbdc7; }
"""


class _CameraTile(QPushButton):
    def __init__(self, slot):
        super().__init__()
        self.setObjectName('cameraTile')
        self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.setMinimumHeight(74)
        self._player = ''
        self.slot = slot
        self.key = '1234567890-='[slot - 1]
        self.keycap = QLabel(self.key)
        self.keycap.setObjectName('slotKey')
        self.keycap.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.keycap.setFixedSize(26, 22)
        position = QLabel(f'Поз. {slot}')
        position.setObjectName('slotPosition')
        self.position = position
        self.name = QLabel()
        self.name.setObjectName('slotName')
        self.name.setTextFormat(Qt.TextFormat.PlainText)
        self.name.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        for label in (self.keycap, position, self.name):
            label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        top = QHBoxLayout()
        top.addWidget(self.keycap)
        top.addStretch()
        top.addWidget(position)
        contents = QVBoxLayout(self)
        contents.setContentsMargins(10, 8, 10, 8)
        contents.setSpacing(5)
        contents.addLayout(top)
        contents.addWidget(self.name)

    def set_player(self, player):
        if self._player != player:
            self._player = player
            self.setAccessibleName(f'{self.slot} · {player}')
            self.setToolTip(f'Позиция {self.slot} · клавиша {self.key} · {player}')
            self._fit_name()

    def _fit_name(self):
        self.name.setText(self.name.fontMetrics().elidedText(
            self._player, Qt.TextElideMode.ElideRight, max(1, self.width() - 24)))

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._fit_name()


class CameraPanel(QWidget):
    apply_requested = Signal(dict)
    take_requested = Signal(int)
    discover_requested = Signal(str, int)
    companion_requested = Signal()
    repair_requested = Signal()

    def __init__(self, role, parent=None):
        super().__init__(parent)
        if role not in ('live', 'replay'):
            raise ValueError('Unknown camera role')
        self.role = role
        self._inputs = {}
        live = role == 'live'
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        layout.setSpacing(12)
        self.setStyleSheet(CAMERA_STYLE)
        summary = QFrame()
        summary.setObjectName('cameraSummary')
        summary_layout = QVBoxLayout(summary)
        summary_layout.setContentsMargins(18, 13, 18, 13)
        summary_layout.setSpacing(3)
        caption = QLabel('Активная камера')
        caption.setObjectName('cameraCaption')
        self.active = _feedback()
        self.active.setObjectName('cameraActive')
        self.active.setAccessibleName('Активная камера')
        self.status = _feedback()
        self.status.setObjectName('cameraConnection')
        self.message = _feedback()
        self.message.setObjectName('cameraMessage')
        for label in (caption, self.active, self.status, self.message):
            summary_layout.addWidget(label)
        layout.addWidget(summary)

        self.tabs = QTabBar()
        self.tabs.setObjectName('cameraTabs')
        self.tabs.setAccessibleName('Режим работы с камерами')
        self.tabs.setExpanding(False)
        self.tabs.setDrawBase(False)
        self.tabs.addTab('Камеры')
        self.tabs.addTab('Настройки vMix')
        layout.addWidget(self.tabs, alignment=Qt.AlignmentFlag.AlignLeft)

        self.operation = QWidget()
        controls = QVBoxLayout(self.operation)
        controls.setContentsMargins(0, 0, 0, 0)
        controls.setSpacing(9)
        title = QLabel('Оригинальные камеры' if live else 'Виртуальные копии')
        title.setObjectName('cameraGroup')
        controls.addWidget(title)
        self.buttons = []
        self.grid = QGridLayout()
        self.grid.setSpacing(8)
        self._columns = 0
        for slot in range(1, 13):
            button = _CameraTile(slot)
            button.clicked.connect(lambda _=False, n=slot: self.take_requested.emit(n))
            self.buttons.append(button)
        self._arrange_tiles()
        controls.addLayout(self.grid)
        if not live:
            companion = QPushButton('Настроить кнопки Companion')
            companion.clicked.connect(self.companion_requested.emit)
            controls.addWidget(companion, alignment=Qt.AlignmentFlag.AlignLeft)
        layout.addWidget(self.operation)

        self.settings_page = QWidget()
        settings_layout = QVBoxLayout(self.settings_page)
        settings_layout.setContentsMargins(0, 0, 0, 0)
        connection = QGroupBox('Подключение и выход')
        form = QFormLayout(connection)
        form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.enabled = QCheckBox('Включить управление vMix')
        form.addRow(self.enabled)
        self.host = QLineEdit()
        self.port = QSpinBox()
        self.port.setRange(1, 65535)
        form.addRow('IPv4 компьютера с vMix', self.host)
        form.addRow('Порт Web Controller', self.port)
        self.discover = QPushButton('Получить список входов')
        self.discover.clicked.connect(self._discover)
        form.addRow(self.discover)
        self.repair = QPushButton('Восстановить URL камер')
        self.repair.setToolTip('Повторно открыть адреса камер на этом vMix. Потоки VDO.Ninja могут переподключиться.')
        self.repair.clicked.connect(self.repair_requested.emit)
        form.addRow(self.repair)
        self.discovery_error = _feedback()
        form.addRow(self.discovery_error)
        self.discovery_error.hide()
        self.mix = QSpinBox()
        self.mix.setRange(1, 2_147_483_647)
        form.addRow('Номер Mix', self.mix)
        if live:
            self.follow = QCheckBox('Следовать за игроком под наблюдением')
            form.addRow(self.follow)
            self.mode = QComboBox()
            self.mode.addItem('Program выбранного Mix', 'program')
            self.mode.addItem('Слой составного входа', 'layer')
            form.addRow('Назначение камеры', self.mode)
            self.target = _InputPicker('Составной вход', lambda: self._inputs)
            self.layer = QSpinBox()
            self.layer.setRange(1, 10)
            form.addRow('Составной вход', self.target)
            form.addRow('Номер слоя', self.layer)

            def show_destination():
                layer = self.mode.currentData() == 'layer'
                form.setRowVisible(self.target, layer)
                form.setRowVisible(self.layer, layer)
                form.setRowVisible(self.mix, not layer)

            self.mode.currentIndexChanged.connect(show_destination)
            show_destination()
        settings_layout.addWidget(connection)

        bank = QGroupBox('Входы камер')
        routes = QGridLayout(bank)
        routes.addWidget(QLabel('Пара'), 0, 0)
        routes.addWidget(QLabel('Оригинал' if live else 'Виртуальная копия'), 0, 1)
        routes.setColumnStretch(1, 1)
        if not live:
            routes.addWidget(QLabel('Оригинал на этом vMix'), 0, 2)
            routes.setColumnStretch(2, 1)
        self.guids, self.sources = [], []
        for slot in range(1, 13):
            routes.addWidget(QLabel(str(slot)), slot, 0)
            picker = _InputPicker(f'Вход камеры {slot}', lambda: self._inputs)
            routes.addWidget(picker, slot, 1)
            self.guids.append(picker)
            if not live:
                source = _InputPicker(f'Оригинал камеры {slot}', lambda: self._inputs)
                routes.addWidget(source, slot, 2)
                self.sources.append(source)
        settings_layout.addWidget(bank)
        self.validation = _feedback()
        settings_layout.addWidget(self.validation)
        self.validation.hide()
        self.apply = QPushButton('Применить настройки')
        self.apply.setObjectName('primary')
        self.apply.clicked.connect(self._apply)
        apply_note = QLabel('При включении менеджер откроет сохранённые URL в назначенных браузерах. Первичную настройку выполните вне эфира.')
        apply_note.setWordWrap(True)
        apply_note.setObjectName('cameraCaption')
        settings_layout.addWidget(apply_note)
        settings_layout.addWidget(self.apply, alignment=Qt.AlignmentFlag.AlignLeft)
        layout.addWidget(self.settings_page)
        self.tabs.currentChanged.connect(self._show_page)
        self._show_page(0)
        self.set_config({})
        self.render({}, {}, set(), '', 'Управление выключено.')

    def _show_page(self, index):
        self.operation.setVisible(index == 0)
        self.settings_page.setVisible(index == 1)

    def _arrange_tiles(self):
        width = self.width()
        columns = 6 if width >= 940 else 4 if width >= 620 else 3 if width >= 420 else 2
        if columns == self._columns:
            return
        self._columns = columns
        for i, button in enumerate(self.buttons):
            self.grid.addWidget(button, i // columns, i % columns)
        for column in range(6):
            self.grid.setColumnStretch(column, int(column < columns))

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._arrange_tiles()

    def set_config(self, config):
        """Load the saved settings when opening the panel or resetting a draft."""
        self.enabled.setChecked(config.get('enabled') is True)
        self.host.setText(config.get('host', '127.0.0.1'))
        self.port.setValue(config.get('port', 8088))
        self.mix.setValue(config.get('mix', 1 if self.role == 'live' else 2))
        if self.role == 'live':
            self.mode.setCurrentIndex(1 if config.get('mode') == 'layer' else 0)
            self.layer.setValue(config.get('layer', 1))
            self.target.edit.setText(config.get('target', ''))
            self.follow.setChecked(config.get('follow') is True)
        for fields, key in ((self.guids, 'guids'), (self.sources, 'sources')):
            values = config.get(key, [])
            for i, field in enumerate(fields):
                field.edit.setText(values[i] if i < len(values) else '')
        self.validation.hide()
        self.discovery_error.hide()

    def _endpoint(self):
        try:
            host = IPv4Address(self.host.text().strip())
        except ValueError:
            host = None
        if host is None or not (host.is_loopback or is_lan_address(host)):
            self.host.setFocus()
            self.host.selectAll()
            raise ValueError('Укажите локальный IPv4-адрес компьютера с vMix, например 192.168.1.10 или 127.0.0.1.')
        return str(host), self.port.value()

    def _discover(self):
        try:
            host, port = self._endpoint()
        except ValueError as exc:
            self.discovery_error.setText(str(exc))
            self.discovery_error.show()
            return
        self.discovery_error.hide()
        self.discover_requested.emit(host, port)

    def _apply(self):
        try:
            host, port = self._endpoint()
            config = dict(enabled=self.enabled.isChecked(), host=host, port=port, mix=self.mix.value(),
                          guids=[picker.value() for picker in self.guids])
            if self.role == 'live':
                mode = self.mode.currentData()
                target = self.target.value()
                if config['enabled'] and mode == 'layer' and not target:
                    self.target.edit.setFocus()
                    raise ValueError('Выберите составной вход для вывода камеры на слой.')
                config.update(mode=mode, target=target, layer=self.layer.value(), follow=self.follow.isChecked())
            else:
                config['sources'] = [picker.value() for picker in self.sources]
        except ValueError as exc:
            self.validation.setText(str(exc))
            self.validation.show()
            return
        self.validation.hide()
        self.discovery_error.hide()
        self.apply_requested.emit(config)

    def mark_active(self, slot):
        for button in self.buttons:
            selected = slot == button.slot
            if bool(button.property('onAir')) != selected:
                button.setProperty('onAir', selected)
                button.position.setText('В эфире' if selected else f'Поз. {button.slot}')
                button.style().unpolish(button)
                button.style().polish(button)
                button.update()

    def render(self, inputs, slots, available, active, status):
        """Update polled operator feedback. Inputs are keyed by vMix GUID."""
        self._inputs = inputs
        state, _, detail = status.partition(' · ')
        connected = state == 'Подключено'
        if self.status.property('online') != connected:
            self.status.setProperty('online', connected)
            self.status.style().unpolish(self.status)
            self.status.style().polish(self.status)
        if state in ('Выкл.', 'Управление выключено.'):
            state = 'Управление выключено'
            detail = detail or 'В «Настройках vMix» выберите входы и включите управление.'
        elif state == 'Ожидание vMix' and not detail:
            detail = 'Проверьте адрес и порт Web Controller в настройках.'
        self.active.setText(active or 'Нет данных о камере')
        self.status.setText(f'vMix · {state}')
        self.message.setText(detail)
        self.message.setVisible(bool(detail))
        for slot, button in enumerate(self.buttons, start=1):
            button.set_player(slots.get(slot) or '—')
            button.setEnabled(slot in available)
