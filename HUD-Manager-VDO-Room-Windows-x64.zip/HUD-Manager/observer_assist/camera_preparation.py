"""Prepare the twelve existing browser inputs before a match is available."""
from urllib.parse import unquote_plus, urlsplit

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog, QDialogButtonBox, QHeaderView, QLabel, QLineEdit, QTableWidget,
    QTableWidgetItem, QVBoxLayout,
)

# An empty CEF document has no body background. vMix composites its alpha.
TRANSPARENT_PAGE = 'about:blank'


def camera_page(raw):
    if not raw:
        return TRANSPARENT_PAGE
    parts = urlsplit(raw)
    if parts.hostname not in ('vdo.ninja', 'www.vdo.ninja'):
        return raw
    fields = [(unquote_plus(field.partition('=')[0]).lower(), field) for field in parts.query.split('&')]
    if not any(k in ('view', 'v', 'scene') for k, _ in fields):
        return raw
    # Preserve the encoding/order of stream IDs, room credentials and other viewer options.
    appearance = {'transparent', 'transparency', 'clean', 'cleanoutput', 'style', 'st', 'chroma', 'bgimage'}
    query = '&'.join([field for k, field in fields if k not in appearance] +
                     ['transparent', 'cleanoutput', 'style=1'])
    return parts._replace(query=query).geturl()


class CameraPreparation(QDialog):
    def __init__(self, rows, commit, parent):
        super().__init__(parent)
        self.setWindowTitle('Камеры до матча')
        layout = QVBoxLayout(self)
        hint = QLabel('Для каждой пары vMix укажите ссылку просмотра и Account ID игрока. '
                      'Если ID пока неизвестен, введите игровой ник. Пустая ссылка оставляет вход прозрачным.')
        hint.setWordWrap(True)
        layout.addWidget(hint)
        self.table = QTableWidget(12, 3)
        self.table.setHorizontalHeaderLabels(['Account ID', 'Игровой ник', 'URL просмотра VDO.Ninja'])
        self.table.setVerticalHeaderLabels([f'Пара {i}' for i in range(1, 13)])
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.setColumnWidth(0, 118)
        self.table.setColumnWidth(1, 150)
        self.fields = []
        for row, (account, nick, page) in enumerate(rows):
            self.table.setItem(row, 0, QTableWidgetItem(account))
            self.table.setItem(row, 1, QTableWidgetItem(nick))
            private = QLineEdit(page)
            private.setAccessibleName(f'URL камеры, пара {row + 1}')
            private.setEchoMode(QLineEdit.EchoMode.PasswordEchoOnEdit)
            self.table.setCellWidget(row, 2, private)
            self.fields.append(private)
        layout.addWidget(self.table)
        self.message = QLabel('При сохранении включённые модули обновят браузеры изменённых пар.')
        self.message.setWordWrap(True)
        self.message.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.message)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Save).setText('Сохранить камеры')
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText('Отмена')
        buttons.rejected.connect(self.reject)

        def save():
            values = [(self.table.item(i, 0).text().strip(), self.table.item(i, 1).text().strip(), field.text().strip())
                      for i, field in enumerate(self.fields)]
            try:
                commit(rows, values)
            except ValueError as exc:
                self.message.setText(str(exc))
                return
            self.accept()

        buttons.accepted.connect(save)
        layout.addWidget(buttons)
        self.resize(820, 550)
