"""Match accounts own camera pairs. HUD positions only select accounts."""
import json
from collections import Counter
from hashlib import sha256
from datetime import datetime
from ipaddress import IPv4Address
from uuid import UUID

from PySide6.QtCore import QObject, QTimer, Signal
from PySide6.QtWidgets import (
    QComboBox, QFormLayout, QGroupBox, QLabel, QMessageBox, QPlainTextEdit, QPushButton,
)

from .camera_vmix import CameraEndpoint
from .camera_preparation import CameraPreparation, camera_page
from .camera_roster import _account, _page_valid
from .hud_nicknames import normalize_name
from .match_stats import is_lan_address

ROLES = ('live', 'replay')


def _digest(text):
    return sha256(text.encode('utf-8')).hexdigest()


def _guest_marker(value):
    if isinstance(value, dict) and all(isinstance(value.get(k), str) for k in ('room', 'stream', 'owner', 'page')):
        return {**{k: value[k] for k in ('room', 'stream', 'owner', 'page')},
                'allocated': value.get('allocated') is True}
    return None


def _guest_identity(label, players, rows):
    """A numeric label may be either an account or a nickname. All evidence must agree."""
    name = normalize_name(label)
    accounts = {account for account, player in players.items() if normalize_name(player['name']) == name or account == label}
    banks = [i for i, (account, nick, _) in enumerate(rows)
             if (account and (account in accounts or account == label)) or normalize_name(nick) == name]
    accounts.update(rows[i][0] for i in banks if rows[i][0])
    if len(accounts) > 1 or len(banks) > 1:
        return None
    return next(iter(accounts), ''), next(iter(banks), None)


def defaults(role):
    return dict(enabled=False, host='127.0.0.1', port=8088, mix=1 if role == 'live' else 2,
                mode='program', target='', layer=1, follow=False, guids=[''] * 12, sources=[''] * 12)


def endpoint_key(config):
    return config['host'], config['port']


def destination(config):
    if config['mode'] == 'layer':
        return 'layer', config['target'], config['layer']
    return 'mix', config['mix']


def validate_config(role, draft, other):
    config = defaults(role)
    config.update({k: v for k, v in draft.items() if k in config})
    address = IPv4Address(config['host'])
    if not (is_lan_address(address) or address.is_loopback):
        raise ValueError('Укажите локальный адрес vMix.')
    config['host'] = str(address)
    if not 1 <= config['port'] <= 65535 or not 1 <= config['mix'] or not 1 <= config['layer'] <= 10:
        raise ValueError('Проверьте порт, Mix и номер слоя.')
    if config['mode'] not in ('program', 'layer') or role == 'replay' and config['mode'] != 'program':
        raise ValueError('Проверьте способ вывода камеры.')
    def guid(value):
        return str(UUID(value.strip())) if value else ''
    try:
        for key in ('guids', 'sources'):
            if len(config[key]) != 12:
                raise ValueError
            config[key] = [guid(ref) for ref in config[key]]
        config['target'] = guid(config['target'])
    except (TypeError, ValueError, AttributeError):
        raise ValueError('Выберите существующие входы по GUID.') from None
    if config['enabled'] and config['mode'] == 'layer' and not config['target']:
        raise ValueError('Выберите целевой вход для слоя.')
    if role == 'live':
        config['sources'] = [''] * 12
    live, replay = (config, other) if role == 'live' else (other, config)
    shared = endpoint_key(live) == endpoint_key(replay)
    if shared and live['enabled'] and replay['enabled'] and destination(live) == destination(replay):
        raise ValueError('Этот выход уже закреплён за другим модулем.')
    originals = list(replay['sources'])
    if shared:
        for idx, ref in enumerate(live['guids']):
            if originals[idx] and ref and originals[idx] != ref:
                raise ValueError(f'У пары {idx + 1} заданы два разных оригинала на одном vMix.')
            originals[idx] = originals[idx] or ref
    for refs in (live['guids'], originals + replay['guids']):
        assigned = [ref for ref in refs if ref]
        if len(assigned) != len(set(assigned)):
            raise ValueError('Каждому входу нужна своя пара. Проверьте повторяющиеся GUID.')
    if live['mode'] == 'layer' and live['target'] and live['target'] in (
            live['guids'] + (originals + replay['guids'] if shared else [])):
        raise ValueError('Целевой вход слоя должен отличаться от источников камер.')
    return config


class CameraRouting(QObject):
    changed = Signal()
    activated = Signal()

    def __init__(self, settings, roster, panels, parent=None, factory=CameraEndpoint):
        super().__init__(parent)
        self.settings, self.roster, self.panels = settings, roster, panels
        self.factory = factory
        self.endpoints, self.discovery = {}, {}
        self.config = {r: defaults(r) for r in ROLES}
        self.owners = [''] * 12
        self.labels = {}
        self.pending_pages = {}
        self.guest_banks = [None] * 12
        self.managed = False
        self.closed = False
        self.armed_observer = None
        self.last_observer = None
        self.observer_match = None
        self.pending_choices = {}
        self.queued_observer = None
        self.status = dict.fromkeys(ROLES, '')
        self.available = {r: set() for r in ROLES}
        self._export = None
        self.last_tally = {}
        self.last_assignment_view = None
        self._render_timer = QTimer(self, singleShot=True, interval=0)
        self._render_timer.timeout.connect(self.refresh)
        self.bank_widget = QGroupBox('Пары камер и журнал')
        layout = QFormLayout(self.bank_widget)
        self.owner_box = QComboBox()
        self.bank_box = QComboBox()
        self.assign = QPushButton('Назначить игроку пару')
        self.assign.clicked.connect(self._assign)
        layout.addRow('Игрок', self.owner_box)
        layout.addRow('Пара входов', self.bank_box)
        layout.addRow(self.assign)
        self.note = QLabel()
        self.note.setWordWrap(True)
        layout.addRow(self.note)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumBlockCount(250)
        self.log.setMaximumHeight(140)
        layout.addRow('Журнал', self.log)
        try:
            saved = json.loads(settings.value('cameraRoutingV1', '{}', type=str))
            if saved:
                for role in ROLES:
                    self.config[role] = validate_config(role, saved[role], self.config[self._other(role)])
                owners = saved['owners']
                if len(owners) != 12 or len(set(filter(None, owners))) != sum(bool(v) for v in owners):
                    raise ValueError
                self.labels = {k: v for k, v in saved.get('labels', {}).items() if isinstance(v, str)}
                self.pending_pages = {k: v for k, v in saved.get('pendingPages', {}).items()
                                      if k.startswith('nick:') and _page_valid(v)}
                markers = saved.get('vdoBanks')
                if isinstance(markers, list) and len(markers) == 12:
                    self.guest_banks = [_guest_marker(marker) for marker in markers]
                self.owners = list(owners)
                self.managed = True
        except (ValueError, KeyError, TypeError):
            self.managed = settings.contains('cameraRoutingV1')
            self.config = {r: defaults(r) for r in ROLES}
            self.record('Сохранённые настройки камер требуют проверки.')
        for role, panel in panels.items():
            panel.set_config(self.config[role])
            panel.apply_requested.connect(lambda draft, r=role: self.apply(r, draft))
            panel.take_requested.connect(lambda slot, r=role: self.take(r, slot))
            panel.repair_requested.connect(lambda r=role: self.restore_pages(r))
            panel.discover_requested.connect(lambda host, port, r=role: self.discover(r, host, port))
        roster.changed.connect(self.schedule)
        self.schedule()

    @staticmethod
    def _other(role):
        return 'live' if role == 'replay' else 'replay'

    def record(self, text):
        self.log.appendPlainText(f'{datetime.now():%H:%M:%S}  {text}')

    def save(self):
        self.settings.setValue('cameraRoutingV1', json.dumps(dict(self.config, owners=self.owners, labels=self.labels, pendingPages=self.pending_pages, vdoBanks=self.guest_banks)))
        self.settings.sync()

    def schedule(self):
        if not self.closed:
            self._render_timer.start()

    def _endpoint(self, key):
        ep = self.endpoints.get(key)
        if ep is None:
            ep = self.factory(self)
            self.endpoints[key] = ep
            ep.changed.connect(self.schedule)
            ep.event.connect(lambda message: self._message(key, message))
        return ep

    def _message(self, key, message):
        self.record(f'{key[0]}:{key[1]} · {message}')
        for role, cfg in self.config.items():
            if endpoint_key(cfg) == key:
                self.status[role] = message
        self.schedule()

    def restore_pages(self, role):
        cfg = self.config[role]
        ep = self.endpoints.get(endpoint_key(cfg))
        if not cfg['enabled'] or not ep or not ep.online:
            self.status[role] = 'Для восстановления нужна связь с включённым vMix.'
            self.schedule()
            return
        if QMessageBox.question(self.panels[role], 'Восстановление URL',
                'Повторно открыть страницы настроенных камер в этом vMix? '
                'Картинка может пропасть на время подключения VDO.Ninja, в том числе на общем выходе.'
                ) == QMessageBox.StandardButton.Yes:
            ep.forget_pages(set(filter(None, self._originals(role))))
            self.record(f'{role}: оператор запросил повторное подключение браузеров.')
            self.schedule()

    def discover(self, role, host, port):
        try:
            key = (str(IPv4Address(host)), port)
            validate_config(role, dict(defaults(role), host=key[0], port=port), defaults(self._other(role)))
        except (ValueError, TypeError):
            self.status[role] = 'Для поиска укажите локальный IPv4 и порт.'
        else:
            self.discovery[role] = key
            self._endpoint(key)
        self.schedule()

    def apply(self, role, draft):
        try:
            cfg = validate_config(role, draft, self.config[self._other(role)])
        except (ValueError, TypeError) as exc:
            self.status[role] = str(exc)
            self.record(f'{role}: {exc}')
            self.schedule()
            return False
        old = self.config[role]
        ep = self.endpoints.get(endpoint_key(old))
        if ep and old['enabled']:
            ep.cancel_take(old['mix'], old['target'] if old['mode'] == 'layer' else '', old['layer'])
        self.pending_choices.pop(role, None)
        if role == 'live':
            self.queued_observer = None
        if endpoint_key(old) != endpoint_key(cfg) or destination(old) != destination(cfg):
            self.last_tally.pop(role, None)
        self.discovery.pop(role, None)
        self.config[role] = cfg
        if role == 'live':
            self.armed_observer = self.roster.observed if cfg['enabled'] and cfg['follow'] else None
            self.last_observer = self.roster.observed
        if not self.managed:
            self.managed = True
            self.activated.emit()
        self.save()
        self.record(f'{role}: настройки сохранены, модуль ' + ('включён' if cfg['enabled'] else 'выключен'))
        self.status[role] = ''
        self.refresh()
        return True

    def _originals(self, role):
        live, replay = self.config['live'], self.config['replay']
        if role == 'live':
            return live['guids']
        if endpoint_key(live) == endpoint_key(replay):
            return [a or b for a, b in zip(replay['sources'], live['guids'])]
        return replay['sources']

    def _replaceable(self, bank):
        # Check both configured destinations, including a disabled module holding its last output.
        checked = False
        for role, cfg in self.config.items():
            refs = {self._originals(role)[bank], cfg['guids'][bank]} - {''}
            if not refs:
                continue
            checked = True
            ep = self.endpoints.get(endpoint_key(cfg))
            requested = {v[1] for v in self.pending_choices.values() if v[0] == endpoint_key(cfg)}
            if (not ep or not ep.online or not ep.protection_known or refs & (ep.protected | requested)
                    or not refs <= ep.inputs.keys()):
                return False
        return checked

    def _source(self, owner):
        if owner.startswith('nick:'):
            return self.pending_pages.get(owner, '')
        return self.roster.pages.get(owner, '')

    def preparation_rows(self):
        rows = []
        for owner in self.owners:
            account = '' if owner.startswith('nick:') else owner
            name = self.roster.players.get(owner, {}).get('name') or self.labels.get(owner, '')
            rows.append((account, name, self._source(owner)))
        return rows

    def edit_preparation(self, parent):
        releasing = {}

        def save(original, edited):
            confirmed = {i for i, expected in releasing.items() if edited[i] == expected}
            self.save_preparation(original, edited, release_vdo=confirmed)

        dialog = CameraPreparation(self.preparation_rows(), save, parent)
        release = QPushButton('Освободить пары VDO.Ninja')
        release.setEnabled(any(self._owns_guest(i) for i in range(12)))

        def edit_imported():
            draft = [(dialog.table.item(i, 0).text().strip(), dialog.table.item(i, 1).text().strip(),
                      field.text().strip()) for i, field in enumerate(dialog.fields)]
            cleared = self.released_vdo_rows(draft)
            current = self.preparation_rows()
            for bank, (before, after) in enumerate(zip(draft, cleared)):
                if before == current[bank] and self._owns_guest(bank):
                    releasing[bank] = after
                if before != after:
                    dialog.table.item(bank, 0).setText(after[0])
                    dialog.table.item(bank, 1).setText(after[1])
                    dialog.fields[bank].setText(after[2])
            dialog.message.setText('Проверьте изменённые пары и нажмите «Сохранить камеры». '
                                   'Для смены состава остановите импорт из прежней комнаты.')

        release.clicked.connect(edit_imported)
        dialog.layout().insertWidget(dialog.layout().count() - 1, release)
        dialog.exec()
        dialog.deleteLater()

    def released_vdo_rows(self, draft):
        current = self.preparation_rows()
        rows = list(draft)
        for i, marker in enumerate(self.guest_banks):
            account, nick, page = current[i]
            if self._owns_guest(i) and current[i] == rows[i]:
                rows[i] = ('', '', '') if marker['allocated'] else (account, nick, '')
        return rows

    def save_preparation(self, original, edited, *, from_vdo=False, release_vdo=()):
        if len(original) != 12 or len(edited) != 12:
            raise ValueError('Для настройки нужны 12 пар.')
        current = self.preparation_rows()
        owners, labels, pending, updates = [], self.labels.copy(), {}, {}
        for bank, (before, draft, now) in enumerate(zip(original, edited, current), 1):
            if before != draft and before != now and draft != now:
                raise ValueError(f'Пара {bank} изменилась в матче. Откройте таблицу заново.')
            account, nick, page = now if before == draft else draft
            owner = _account(account) if account else ('nick:' + normalize_name(nick) if nick.strip() else '')
            if account and not owner or page and (not owner or not _page_valid(page)):
                raise ValueError(f'Пара {bank}: проверьте Account ID или ник и полный URL просмотра.')
            if owner and owner in owners:
                raise ValueError(f'Пара {bank}: этот игрок уже назначен другой паре.')
            owners.append(owner)
            if owner:
                labels[owner] = nick
                if owner.startswith('nick:'):
                    if page:
                        pending[owner] = page
                else:
                    updates[owner] = page
        if not from_vdo:
            for bank, (before, after, now) in enumerate(zip(original, edited, current)):
                if before != after and now != after and self.guest_banks[bank]:
                    # Clearing an automatically provisioned account also releases its imported URL.
                    marker = self.guest_banks[bank]
                    account, _, page = now
                    if (not any(after) and account and account not in owners and marker['owner'] == account
                            and marker['page'] == _digest(page)):
                        updates[account] = ''
                    marker['owner'] = ''
                if bank in release_vdo and before == now:
                    self.guest_banks[bank] = None
        self.owners, self.labels, self.pending_pages = owners, labels, pending
        self.roster.update_pages(updates)
        if not self.managed:
            self.managed = True
            self.activated.emit()
        self.save()
        self.record('Состав камер обновлён по списку гостей VDO.Ninja.' if from_vdo else
                    'Предматчевые назначения камер сохранены.')
        self.refresh()

    def _owns_guest(self, bank):
        marker = self.guest_banks[bank]
        owner = self.owners[bank]
        return bool(marker and owner and marker['owner'] == owner and marker['page'] == _digest(self._source(owner)))

    def vdo_guest_bank(self, room_key, stream_id):
        if not isinstance(room_key, str) or not room_key or not isinstance(stream_id, str) or not stream_id:
            return None
        room, stream = _digest(room_key), _digest(stream_id)
        return next((i + 1 for i, m in enumerate(self.guest_banks)
                     if m and m['room'] == room and m['stream'] == stream and self._owns_guest(i)), None)

    def import_vdo_guests(self, room_key, guests):
        """Apply a complete director snapshot. An unavailable director must not call this with []."""
        if not isinstance(room_key, str) or not room_key or not isinstance(guests, list):
            return 'Список гостей недоступен. Назначения сохранены.'
        room = _digest(room_key)
        entries = {}
        labels = Counter()
        duplicates = set()
        incomplete = False
        issues = 0
        for guest in guests:
            stream_id = guest.get('streamID') if isinstance(guest, dict) else None
            if not isinstance(stream_id, str) or not stream_id.strip():
                incomplete = True
                issues += 1
                continue
            stream = _digest(stream_id)
            if stream in entries:
                duplicates.add(stream)
            raw = guest.get('label')
            label = raw.strip() if isinstance(raw, str) else ''
            if len(label) > 256 or '://' in label or any(not ch.isprintable() for ch in label):
                label = ''
            entries[stream] = label, guest.get('page')
            labels[normalize_name(label)] += 1

        previous = self.preparation_rows()
        rows = list(previous)
        markers = [m.copy() if m else None for m in self.guest_banks]
        linked = {m['stream']: bank for bank, m in enumerate(markers) if m and m['room'] == room}

        # Only the room that issued this snapshot can signal a departure. Verify ownership
        # and the last auto-applied URL before making a source transparent.
        cleared_banks = []
        for stream, bank in linked.items():
            m = markers[bank]
            if stream in entries or incomplete or not m['owner']:
                continue
            account, nick, page = rows[bank]
            if self.owners[bank] != m['owner'] or _digest(page) != m['page']:
                m['owner'] = ''
                continue
            if page:
                rows[bank] = account, nick, ''
                m['page'] = _digest('')
                cleared_banks.append(bank)

        identities = {stream: _guest_identity(label, self.roster.players, rows)
                      for stream, (label, _) in entries.items() if label}
        claims = Counter(identity for identity in identities.values() if identity and identity != ('', None))
        full = connected = 0
        # Existing streams always keep first claim on their banks, regardless of director order.
        for stream in sorted(entries, key=lambda k: (k not in linked, normalize_name(entries[k][0]), k)):
            label, page = entries[stream]
            nick_key = normalize_name(label)
            if stream in duplicates or not _page_valid(page):
                issues += 1
                continue
            identified = bool(nick_key and labels[nick_key] == 1)
            if stream in linked:
                bank = linked[stream]
                m = markers[bank]
                if not m['owner'] or self.owners[bank] != m['owner'] or _digest(rows[bank][2]) != m['page']:
                    m['owner'] = ''
                    issues += 1
                    continue
                account, nick, _ = rows[bank]
                if not identified:
                    issues += 1
                elif not account and label != nick:
                    if any(nick_key == normalize_name(row[1]) for i, row in enumerate(rows) if i != bank):
                        issues += 1
                    else:
                        nick = label
            else:
                if not identified:
                    issues += 1
                    continue
                identity = identities.get(stream)
                if identity is None or claims[identity] > 1:
                    issues += 1
                    continue
                account, bank = identity
                if bank is not None:
                    marker = markers[bank]
                    if marker:
                        # A room switch or a reconnect may provide a new stream ID. A single
                        # exact identity can reclaim its own unchanged camera only.
                        can_replace = (marker['owner'] and marker['owner'] == self.owners[bank]
                                       and _digest(rows[bank][2]) == marker['page']
                                       and (marker['room'] != room or not incomplete and marker['stream'] not in entries))
                        if not can_replace:
                            issues += 1
                            continue
                    elif rows[bank][2] or account and self.roster.pages.get(account):
                        issues += 1
                        continue
                    allocated = marker['allocated'] if marker else False
                    account, nick, _ = rows[bank]
                else:
                    if account and self.roster.pages.get(account):
                        issues += 1
                        continue
                    bank = next((i for i, (a, n, _) in enumerate(rows) if not a and not n), None)
                    if bank is None:
                        full += 1
                        continue
                    allocated = True
                    nick = self.roster.players.get(account, {}).get('name') or label
                markers[bank] = dict(room=room, stream=stream, owner='', page='', allocated=allocated)

            rows[bank] = (account, nick, page)
            markers[bank]['owner'] = account or ('nick:' + normalize_name(nick))
            markers[bank]['page'] = _digest(page)
            connected += 1

        if markers != self.guest_banks or rows != previous:
            former = self.guest_banks
            self.guest_banks = markers
            if rows != previous:
                try:
                    self.save_preparation(previous, rows, from_vdo=True)
                except ValueError:
                    self.guest_banks = former
                    return 'Назначения изменились. Проверьте пары камер и повторите импорт.'
            else:
                self.save()
        result = f'Камеры гостей · {connected} из {len(guests)}.'
        departed = sum(not rows[i][2] for i in cleared_banks)
        if departed:
            result += f' Переведено в прозрачный режим · {departed}.'
        if full:
            result += f' Все 12 пар заняты, ожидают · {full}. Освободите пары в «Камеры до матча».'
        if issues:
            result += f' Требуют проверки · {issues}. Проверьте подписи и ручные назначения.'
        return result

    def _allocate(self):
        slots = self.roster.slots
        if not self.managed or len(slots) != 12 or len(set(slots.values())) != 12:
            return
        current = set(slots.values())
        updated = False
        matches = {}
        for account in current:
            matches.setdefault('nick:' + normalize_name(self.roster.players[account]['name']), []).append(account)
        for bank, pending in enumerate(self.owners):
            candidates = matches.get(pending, [])
            if len(candidates) == 1 and candidates[0] not in self.owners:
                account = candidates[0]
                self.owners[bank] = account
                self.labels.pop(pending, None)
                page = self.pending_pages.pop(pending, '')
                marker = self.guest_banks[bank]
                saved_page = self.roster.pages.get(account, '')
                if marker and marker['owner'] == pending:
                    marker['owner'] = account
                    if saved_page:
                        # A previously configured account URL wins over the provisional director link.
                        marker['owner'] = ''
                        page = saved_page
                self.roster.update_pages({account: page})
                self.record(f'Пара {bank + 1}: подтверждён Account ID {account}.')
                updated = True
        for pos, account in sorted(slots.items()):
            if account in self.owners:
                continue
            bank = pos - 1
            if self.owners[bank]:
                bank = next((i for i, owner in enumerate(self.owners) if not owner), None)
            if bank is None:
                bank = next((i for i, owner in enumerate(self.owners)
                             if not owner.startswith('nick:') and owner not in current
                             and not (self.guest_banks[i] and self.guest_banks[i]['owner'] == owner)
                             and self._replaceable(i)), None)
            if bank is not None:
                self.owners[bank] = account
                self.record(f'Пара {bank + 1} закреплена за Account ID {account}.')
                updated = True
        for account in current.intersection(self.owners):
            nick = self.roster.players[account]['name']
            if self.labels.get(account) != nick:
                self.labels[account] = nick
                updated = True
        if updated:
            self.save()

    def _assign(self):
        account = self.owner_box.currentData()
        bank = self.bank_box.currentIndex()
        if not account or bank < 0 or self.owners[bank] == account:
            return
        if QMessageBox.question(self.bank_widget, 'Назначение камеры',
                f'Закрепить пару {bank + 1} за {self.roster.players[account]["name"]}? '
                'Изменение браузерного источника может сразу появиться в эфире.') != QMessageBox.StandardButton.Yes:
            return
        if account in self.owners:
            old = self.owners.index(account)
            self.owners[old] = self.owners[bank]
            if self.guest_banks[old]:
                self.guest_banks[old]['owner'] = ''
        self.owners[bank] = account
        if self.guest_banks[bank]:
            self.guest_banks[bank]['owner'] = ''
        if not self.managed:
            self.managed = True
            self.activated.emit()
        self.save()
        self.record(f'Оператор назначил пару {bank + 1} аккаунту {account}.')
        self.refresh()

    def _view_banks(self):
        players = self.roster.players
        state = tuple((acc, p['name']) for acc, p in players.items()), tuple(self.owners)
        if state != self.last_assignment_view:
            self.last_assignment_view = state
            selected, bank = self.owner_box.currentData(), self.bank_box.currentIndex()
            self.owner_box.clear()
            for account, p in players.items():
                self.owner_box.addItem(f"{p['name']} · {account}", account)
            self.owner_box.setCurrentIndex(max(0, self.owner_box.findData(selected)))
            self.bank_box.clear()
            for i, account in enumerate(self.owners, 1):
                name = players.get(account, {}).get('name') or self.labels.get(account) or account
                self.bank_box.addItem(f'{i} · {name or "свободна"}')
            self.bank_box.setCurrentIndex(max(0, bank))
            missing = [p['name'] for a,p in players.items() if a not in self.owners]
            self.note.setText('Ожидают назначения: ' + ', '.join(missing) if missing else '')
        self.assign.setEnabled(bool(players))

    def _sync(self):
        desired = {}
        for role, cfg in self.config.items():
            if not cfg['enabled']:
                continue
            key = endpoint_key(cfg)
            self._endpoint(key)
            names, pages = desired.setdefault(key, ({}, {}))
            for bank, original in enumerate(self._originals(role)):
                account = self.owners[bank]
                nick = self.roster.players.get(account, {}).get('name') or self.labels.get(account) or account
                page = self._source(account)
                if original:
                    names[original] = nick if page else '-'
                    pages[original] = camera_page(page)
                copy = cfg['guids'][bank]
                if role == 'replay' and copy:
                    names[copy] = nick + ' (Virtual)' if page else '-'
        for key, ep in self.endpoints.items():
            enabled = key in desired or key in self.discovery.values()
            ep.configure(*key, enabled)
            if enabled:
                ep.sync(*desired.get(key, ({}, {})))

    def routable(self, role, account):
        cfg = self.config[role]
        ep = self.endpoints.get(endpoint_key(cfg))
        if not cfg['enabled'] or not ep or not ep.online or account not in self.owners:
            return False
        bank = self.owners.index(account)
        original = self._originals(role)[bank]
        guid = cfg['guids'][bank]
        page = camera_page(self._source(account))
        if not ep.ready(original, page) or guid not in ep.inputs:
            return False
        return cfg['target'] in ep.inputs if cfg['mode'] == 'layer' else cfg['mix'] in ep.mixes

    def take(self, role, slot, *, automatic=False):
        account = self.roster.slots.get(slot)
        if not account or not self.routable(role, account):
            return False
        cfg = self.config[role]
        guid = cfg['guids'][self.owners.index(account)]
        if role == 'live':
            self.armed_observer = None
            self.last_observer = self.roster.observed
            self.queued_observer = account if automatic else None
        key = endpoint_key(cfg)
        accepted = self.endpoints[key].take(
            guid, cfg['mix'], cfg['target'] if cfg['mode'] == 'layer' else '', cfg['layer'],
            original=self._originals(role)[self.owners.index(account)], page=camera_page(self._source(account)))
        if accepted:
            self.pending_choices[role] = (key, guid, account)
            self.record(f"{role}: клавиша {slot}, {self.roster.players[account]['name']}, пара {self.owners.index(account) + 1}.")
        return accepted

    def refresh(self):
        if self.closed:
            return
        for role, (key, guid, account) in list(self.pending_choices.items()):
            ep, cfg = self.endpoints[key], self.config[role]
            lost_observer = role == 'live' and self.queued_observer and self.queued_observer != self.roster.observed
            if not ep.online or lost_observer or account not in self.roster.slots.values() or not self.routable(role, account):
                ep.cancel_take(cfg['mix'], cfg['target'] if cfg['mode'] == 'layer' else '', cfg['layer'])
                self.pending_choices.pop(role, None)
            elif (ep.layers.get((cfg['target'], cfg['layer'])) if cfg['mode'] == 'layer' else ep.mixes.get(cfg['mix'])) == guid:
                self.pending_choices.pop(role, None)
        self._allocate()
        self._view_banks()
        self._sync()
        names = {pos: self.roster.players[a]['name'] for pos, a in self.roster.slots.items()}
        for role, cfg in self.config.items():
            ep = self.endpoints.get(endpoint_key(cfg))
            discovered = self.endpoints.get(self.discovery.get(role)) or ep
            self.available[role] = {s for s, a in self.roster.slots.items() if self.routable(role, a)}
            actual = None
            if ep and ep.online:
                actual = (ep.layers.get((cfg['target'], cfg['layer'])) if cfg['mode'] == 'layer'
                          else ep.mixes.get(cfg['mix']))
            active = ep.inputs.get(actual, {}).get('title', '') if actual and ep else ''
            if ep and ep.online:
                self.last_tally[role] = active
            elif self.last_tally.get(role):
                active = self.last_tally[role] + ' (последнее подтверждение)'
            state = 'Выкл.' if not cfg['enabled'] else ('Подключено' if ep and ep.online else 'Ожидание vMix')
            ready = self.available[role]
            guidance = ''
            if cfg['enabled'] and ep and ep.online:
                if cfg['mode'] == 'program' and cfg['mix'] not in ep.mixes:
                    guidance = f"В пресете отсутствует Mix {cfg['mix']}."
                elif cfg['mode'] == 'layer' and cfg['target'] not in ep.inputs:
                    guidance = 'Целевой вход слоя отсутствует в пресете.'
                elif not names:
                    guidance = 'Ожидание подтверждённого порядка Match & Players.'
                elif len(ready) < len(names):
                    guidance = f'Готовы {len(ready)} из {len(names)}. Проверьте назначение пар, GUID и URL игроков.'
            self.panels[role].render(discovered.inputs if discovered else {}, names, ready, active,
                                     ' · '.join(filter(None, (state, self.status[role], guidance))))
            active_slot = None
            if actual and actual in cfg['guids']:
                owner = self.owners[cfg['guids'].index(actual)]
                active_slot = next((s for s, a in self.roster.slots.items() if a == owner), None)
            self.panels[role].mark_active(active_slot)
        cfg = self.config['live']
        if self.roster.match_id and self.observer_match != self.roster.match_id:
            self.observer_match = self.roster.match_id
            self.last_observer = None
        if not self.roster.observed:
            self.armed_observer = None
        elif self.last_observer != self.roster.observed:
            self.last_observer = self.roster.observed
            self.armed_observer = self.roster.observed if cfg['enabled'] and cfg['follow'] else None
        if self.armed_observer:
            slot = next((pos for pos, a in self.roster.slots.items() if a == self.armed_observer), None)
            if slot in self.available['live']:
                self.take('live', slot, automatic=True)
        state = (names, frozenset(self.available['replay']), self.roster.observed, self.input_numbers(),
                 self.roster.players.copy(), tuple(self.owners),
                 tuple(tuple(self.config[r]['guids']) for r in ROLES))
        if state != self._export:
            self._export = state
            self.changed.emit()

    def input_numbers(self):
        cfg = self.config['live']
        ep = self.endpoints.get(endpoint_key(cfg))
        refs = {owner: cfg['guids'][i] for i, owner in enumerate(self.owners) if owner}
        return tuple(ep.inputs.get(refs.get(self.roster.slots.get(i)), {}).get('number', 0) if ep else 0
                     for i in range(1, 13))

    def close(self):
        self.closed = True
        self._render_timer.stop()
        for ep in self.endpoints.values():
            ep.close()
