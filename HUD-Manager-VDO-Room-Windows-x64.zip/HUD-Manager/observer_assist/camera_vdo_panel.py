"""Room director link and discovery status for the camera operator."""

import re

from PySide6.QtCore import QSignalBlocker, Qt, Signal
from PySide6.QtWidgets import (
    QAbstractItemView, QApplication, QCheckBox, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)


SETTINGS_KEY = 'cameraVdoDirectorUrl'
DIRECTOR_MODE_KEY = 'cameraVdoDirectorMode'
_PRIVATE_LINK = re.compile(r'://|vdo\.ninja[/#?]|[?&](?:director|room|view|password|token)=', re.I)


def _label(text, name=None):
    label = QLabel(text)
    label.setTextFormat(Qt.TextFormat.PlainText)
    label.setWordWrap(True)
    if name:
        label.setObjectName(name)
    return label


class VdoRoomPanel(QWidget):
    start_requested = Signal(str)
    stop_requested = Signal()
    reopen_requested = Signal()

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.settings = settings
        self._phase = 'idle'
        self._pending_url = ''
        self.setStyleSheet("""
            QLabel#roomTitle { font-size: 14pt; font-weight: 600; color: #ebf2f5; }
            QLabel#roomHelp { color: #b8c6cb; }
            QLabel#roomStatus { font-weight: 600; }
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        layout.addWidget(_label('Гости комнаты VDO.Ninja', 'roomTitle'))
        layout.addWidget(_label('Укажите игровой ник в имени гостя или в параметре &label= его ссылки. '
                                'Для импорта нужны разные ники.', 'roomHelp'))

        caption = _label('Приватная ссылка директора')
        self.url = QLineEdit(settings.value(SETTINGS_KEY, '', type=str))
        self.url.setEchoMode(QLineEdit.EchoMode.Password)
        self.url.setPlaceholderText('Вставьте ссылку директора комнаты')
        self.url.setAccessibleName(caption.text())
        caption.setBuddy(self.url)
        self.url.returnPressed.connect(self._request_start)
        layout.addWidget(caption)
        layout.addWidget(self.url)
        self.url.setToolTip('После успешного запуска ссылка сохраняется в настройках на этом ПК.')
        self.director_mode = QCheckBox('Открыть как режиссёр (включая гостей вне сцены)')
        self.director_mode.setChecked(settings.value(DIRECTOR_MODE_KEY, False, type=bool))
        layout.addWidget(self.director_mode)
        self.mode_hint = _label('', 'roomHelp')
        layout.addWidget(self.mode_hint)
        self.director_mode.toggled.connect(self._show_mode_hint)
        self._show_mode_hint(self.director_mode.isChecked())

        controls = QHBoxLayout()
        self.connect_button = QPushButton('Подключиться к комнате')
        self.connect_button.setObjectName('primary')
        self.connect_button.clicked.connect(self._request_start)
        self.reopen_button = QPushButton('Открыть вкладку')
        self.reopen_button.setToolTip('Если вкладка закрылась, откройте её снова и оставьте открытой для импорта.')
        self.reopen_button.clicked.connect(self.reopen_requested.emit)
        self.stop_button = QPushButton('Отключить')
        self.stop_button.clicked.connect(self.stop_requested.emit)
        for button in (self.connect_button, self.reopen_button, self.stop_button):
            controls.addWidget(button)
        controls.addStretch()
        layout.addLayout(controls)

        self.status = _label('', 'roomStatus')
        self.summary = _label('')
        layout.addWidget(self.status)
        layout.addWidget(self.summary)
        self._guests = ()
        self.table = QTableWidget(0, 2)
        self.table.setAccessibleName('Гости комнаты и пары камер')
        self.table.setHorizontalHeaderLabels(['Имя гостя', 'Пара камер'])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.table.verticalHeader().hide()
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setAlternatingRowColors(True)
        self.table.setMinimumHeight(125)
        self.table.setMaximumHeight(250)
        self.table.hide()
        layout.addWidget(self.table)
        self.copy_button = QPushButton('Копировать ссылку камеры')
        self.copy_button.clicked.connect(self._copy_camera)
        self.copy_button.setEnabled(False)
        self.copy_button.hide()
        layout.addWidget(self.copy_button, alignment=Qt.AlignmentFlag.AlignLeft)
        self.table.itemSelectionChanged.connect(self._update_copy)
        self.url.textChanged.connect(self._update_controls)
        self.stop()

    def _show_mode_hint(self, director):
        if director:
            self.mode_hint.setText('Если главный Director уже открыт, разрешите Co-Director в Room Settings '
                                   'и используйте приглашение второго режиссёра.')
        else:
            self.mode_hint.setText('Обычная ссылка директора открывает гостевую сцену. Главный Director может '
                                   'оставаться открытым. Приглашение Co-Director включает режим режиссёра автоматически.')

    def _update_controls(self):
        idle = self._phase == 'idle'
        self.url.setReadOnly(not idle)
        self.director_mode.setEnabled(idle)
        self.connect_button.setVisible(idle)
        self.connect_button.setEnabled(idle and bool(self.url.text().strip()))
        self.reopen_button.setVisible(self._phase == 'running')
        self.stop_button.setVisible(not idle)

    def _request_start(self):
        if self._phase != 'idle':
            return
        link = self.url.text().strip()
        if not link:
            return
        self._phase = 'starting'
        self._pending_url = link
        self.status.setText('Открываем комнату в браузере…')
        self.summary.hide()
        self._update_controls()
        self.start_requested.emit(link)

    def started(self):
        if self._phase != 'starting':
            return
        self.settings.setValue(SETTINGS_KEY, self._pending_url)
        self.settings.setValue(DIRECTOR_MODE_KEY, self.director_mode.isChecked())
        self._pending_url = ''
        self._phase = 'running'
        self.status.setText('Ожидаем список гостей. Оставьте вкладку браузера открытой.')
        self._update_controls()

    def start_failed(self, reason):
        self.stop()
        message = reason.strip()
        self.status.setText(message if message and not _PRIVATE_LINK.search(message)
                            else 'Не удалось подключиться. Проверьте ссылку директора и повторите попытку.')

    def show_result(self, guests_count, summary):
        if self._phase != 'running':
            return
        self.status.setText(f'Видимых гостей · {guests_count}')
        message = summary.strip()
        if _PRIVATE_LINK.search(message):
            message = 'Список гостей обновлён.'
        self.summary.setText(message)
        self.summary.setVisible(bool(message))

    def show_stale(self):
        if self._phase == 'running':
            self.status.setText('Список гостей не обновляется. Нажмите «Открыть вкладку» и проверьте комнату в браузере.')
            self.summary.clear()
            self.summary.hide()
            self.set_guests([])

    def _selected_page(self):
        selected = self.table.selectionModel().selectedRows()
        return self._guests[selected[0].row()][2] if selected else ''

    def _update_copy(self):
        self.copy_button.setEnabled(bool(self._selected_page()))

    def _copy_camera(self):
        page = self._selected_page()
        if page:
            QApplication.clipboard().setText(page)

    def set_guests(self, rows):
        """Show a room snapshot in the controller's order; pages are private viewer URLs."""
        guests = tuple((g['label'], g['bank'], g['page']) for g in rows) if self._phase == 'running' else ()
        if guests == self._guests:
            return
        selected = self._selected_page()
        with QSignalBlocker(self.table):
            self._guests = guests
            self.table.setRowCount(len(guests))
            self.table.setCurrentCell(-1, -1)
            self.table.clearSelection()
            for i, (label, bank, page) in enumerate(guests):
                name = label if label and not _PRIVATE_LINK.search(label) else 'Без имени'
                self.table.setItem(i, 0, QTableWidgetItem(name))
                self.table.setItem(i, 1, QTableWidgetItem(str(bank) if bank is not None else 'Не назначена'))
                if selected and page == selected:
                    self.table.selectRow(i)
        self._update_copy()
        self.table.setVisible(bool(guests))
        self.copy_button.setVisible(bool(guests))

    def stop(self):
        self._phase = 'idle'
        self._pending_url = ''
        self.status.setText('Комната отключена.')
        self.summary.clear()
        self.summary.hide()
        self.set_guests([])
        self._update_controls()
