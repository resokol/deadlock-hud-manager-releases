"""Collect VDO.Ninja room snapshots through a private loopback browser page."""

import html
import json
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit


# The direct iframe commands in VDO.Ninja main.js return the objects built by
# getGuestList and getDetailedState in lib.js, keyed by slot and stream ID respectively.
_SCRIPT = """
const frame = document.querySelector('#director');
const status = document.querySelector('#status');
const target = new URL(frame.src).origin;
const scene = frame.dataset.mode === 'scene';
const tabHeader = {'X-Room-Tab': frame.dataset.tab};
let serial = 0;
let pending = '';
let unanswered = 0;
let posting = false;
let stopped = false;
let checking = false;
let missedChecks = 0;
let slots;
let excluded;

function stop(message) {
    stopped = true;
    pending = '';
    clearInterval(timer);
    frame.remove();
    status.textContent = message;
}

async function checkSession() {
    if (checking || stopped) return;
    checking = true;
    try {
        const result = await fetch('active', {headers: tabHeader, credentials:'omit',
                                             signal:AbortSignal.timeout(4500)});
        if (result.status === 410) stop('Подключение продолжено в другой вкладке.');
        else if (!result.ok) throw new Error();
        missedChecks = 0;
    } catch {
        if (++missedChecks >= 3) stop('Подключение остановлено. Откройте комнату из HUD Manager.');
    } finally {
        checking = false;
    }
}

function poll() {
    if (stopped) return;
    if (unanswered >= 20) {
        unanswered = 0;
        pending = '';
        status.textContent = 'Переподключение к VDO.Ninja…';
        frame.src = frame.src;
        return;
    }
    if (unanswered >= 2) status.textContent = 'Ожидание ответа VDO.Ninja…';
    unanswered++;
    pending = 'guests-' + (++serial);
    slots = undefined;
    excluded = undefined;
    const request = {getDetailedState: true};
    if (!scene) request.getGuestList = true;
    frame.contentWindow.postMessage({...request, cib: pending}, target);
}

function object(value) {
    return Object.prototype.toString.call(value) === '[object Object]';
}

function directorGuests(slots, excluded) {
    if (!object(slots)) return;
    const rows = [];
    for (const [slot, guest] of Object.entries(slots)) {
        if (!/^[1-9][0-9]*$/.test(slot) || !object(guest)) return;
        if (excluded.has(String(guest.streamID))) continue;
        if (typeof guest.streamID !== 'string' || !guest.streamID.trim() || typeof guest.label !== 'string') return;
        if (!guest.streamID.endsWith(':s')) rows.push({streamID: guest.streamID, label: guest.label});
    }
    return rows;
}

function peers(state) {
    if (!object(state)) return;
    const rows = [];
    const excluded = new Set();
    let includesSelf = false;
    for (const [key, peer] of Object.entries(state)) {
        if (!object(peer)) return;
        if (peer.localStream === true) {
            includesSelf = true;
            excluded.add(key);
            continue;
        }
        if (peer.localStream !== false || typeof peer.director !== 'boolean'
            || typeof peer.UUID !== 'string' || !peer.UUID || !key.trim() || peer.streamID !== key) return;
        if (peer.director || peer.iframeSrc || key.endsWith(':s')) {
            excluded.add(key);
            continue;
        }
        if (peer.label != null && peer.label !== false && typeof peer.label !== 'string') return;
        rows.push({streamID: key, label: peer.label || ''});
    }
    if (includesSelf) return {rows, excluded};
}

window.addEventListener('message', async event => {
    if (event.source !== frame.contentWindow || event.origin !== target) return;
    const data = event.data;
    if (!pending || !data || data.cib !== pending) return;
    const snapshot = peers(data.detailedState);
    let rows;
    if (scene) {
        rows = snapshot?.rows;
    } else {
        if (snapshot) excluded = snapshot.excluded;
        if (object(data.guestList)) slots = data.guestList;
        if (excluded && slots) rows = directorGuests(slots, excluded);
    }
    if (!rows) return;
    pending = '';
    unanswered = 0;
    if (posting) return;
    posting = true;
    try {
        const response = await fetch('guests', {
            method: 'POST', credentials: 'omit', headers: {...tabHeader, 'Content-Type': 'application/json'},
            body: JSON.stringify(rows), signal: AbortSignal.timeout(4500)
        });
        if (response.status === 410) return stop('Подключение продолжено в другой вкладке.');
        if (!response.ok) throw new Error();
        status.textContent = 'Связь с HUD Manager установлена. Гостей: ' + rows.length + '.';
    } catch {
        status.textContent = 'Нет связи с HUD Manager. Проверьте подключение комнаты в приложении.';
    } finally {
        posting = false;
    }
});

frame.addEventListener('load', poll);
const timer = setInterval(() => {checkSession(); poll();}, 3000);
poll();
"""

_PAGE = """<!doctype html><html lang="ru"><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>VDO.Ninja · HUD Manager</title>
<style nonce="{nonce}">
html, body {{ margin:0; height:100%; }} body {{ display:flex; flex-direction:column;
font:16px system-ui,sans-serif; color:#eef1f3; background:#192127; }}
header {{ padding:.75rem 1rem; }} p {{ margin:.25rem 0; }} iframe {{ flex:1; border:0; width:100%; }}
</style>
<header><p><strong>VDO.Ninja · HUD Manager</strong></p>
<p>Оставьте эту вкладку открытой. Если VDO.Ninja запросит вход, завершите его ниже.</p>
<p id="status" role="status">Подключение к комнате…</p></header>
<iframe id="director" data-mode="{mode}" data-tab="{tab}" title="Комната VDO.Ninja" referrerpolicy="no-referrer"
allow="autoplay" src="{director}"></iframe>
<script nonce="{nonce}">{script}</script></html>"""


def _guests(body):
    values = json.loads(body.decode('utf-8'))
    if not isinstance(values, list) or len(values) > 512:
        raise ValueError
    result = []
    for guest in values:
        if not isinstance(guest, dict):
            raise ValueError
        stream_id, label = guest.get('streamID'), guest.get('label')
        if (not isinstance(stream_id, str) or not stream_id.strip() or len(stream_id) > 256
                or not isinstance(label, str) or len(label) > 512):
            raise ValueError
        result.append(dict(streamID=stream_id, label=label))
    return result


class _Handler(BaseHTTPRequestHandler):
    def setup(self):
        super().setup()
        self.connection.settimeout(5)

    def log_message(self, *args):
        pass  # The local capability path and private room link are never logged.

    def _reply(self, code, body=b'', content_type='text/plain; charset=utf-8'):
        self.send_response(code)
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Content-Security-Policy', self.server.csp)
        self.end_headers()
        if body:
            try:
                self.wfile.write(body)
            except (ConnectionError, TimeoutError):
                pass

    def do_GET(self):
        server = self.server
        if self.headers.get_all('Host') != [server.authority]:
            self._reply(404)
            return
        if self.path == server.path + 'active':
            self._reply(204 if self._current() else 410)
        elif self.path == server.path:
            with server.delivery_lock:
                server.tab = secrets.token_urlsafe(24)
                page = _PAGE.format(tab=server.tab, **server.page_options).encode()
            self._reply(200, page, 'text/html; charset=utf-8')
        else:
            self._reply(404)

    def _current(self):
        return (not self.server.closed and self.server.tab and
                self.headers.get_all('X-Room-Tab') == [self.server.tab])

    def do_POST(self):
        server = self.server
        if self.headers.get_all('Host') != [server.authority] or self.path != server.path + 'guests':
            self._reply(404)
            return
        if self.headers.get_all('Origin') != [server.origin]:
            self._reply(403)
            return
        if self.headers.get_all('Content-Type') != ['application/json']:
            self._reply(415)
            return
        lengths = self.headers.get_all('Content-Length') or []
        if len(lengths) != 1 or not lengths[0].isascii() or not lengths[0].isdecimal() or self.headers.get('Transfer-Encoding'):
            self._reply(400)
            return
        if len(lengths[0]) > 6 or int(lengths[0]) > 65536:
            self._reply(413)
            return
        try:
            length = int(lengths[0])
            body = self.rfile.read(length)
            if len(body) != length:
                raise ValueError
            guests = _guests(body)
        except (ValueError, UnicodeError, RecursionError, TimeoutError):
            self._reply(400)
            return
        # close() waits for a callback already in progress and excludes later ones.
        with server.delivery_lock:
            if not self._current():
                self._reply(410)
                return
            try:
                server.on_guests(guests)
            except Exception:
                self._reply(500)
                return
        self._reply(204)


class VdoRoomBridge:
    """Serve an operator-only room tab. on_guests is called on a server thread."""

    def __init__(self, room_url, on_guests, *, scene=False):
        if scene:
            from .camera_vdo_room import scene_url as frame_url
        else:
            from .camera_vdo_room import director_url as frame_url

        parts = urlsplit(frame_url(room_url))
        if parts.scheme != 'https' or not parts.hostname or parts.username or parts.password:
            raise ValueError('Нужна HTTPS-ссылка директора VDO.Ninja.')
        server = ThreadingHTTPServer(('127.0.0.1', 0), _Handler)
        self._server = server
        server.authority = f'127.0.0.1:{server.server_port}'
        server.origin = 'http://' + server.authority
        server.path = '/' + secrets.token_urlsafe(32) + '/'
        self.url = server.origin + server.path
        query = [(k, v) for k, v in parse_qsl(parts.query, keep_blank_values=True)
                 if k.casefold() != 'iframetarget']
        query.append(('iframetarget', server.origin))
        source = urlunsplit(parts._replace(query=urlencode(query)))
        nonce = secrets.token_urlsafe(24)
        server.csp = (f"default-src 'none'; frame-src https://{parts.netloc}; "
                      f"script-src 'nonce-{nonce}'; style-src 'nonce-{nonce}'; connect-src 'self'; "
                      "base-uri 'none'; frame-ancestors 'none'; form-action 'none'")
        server.page_options = dict(nonce=nonce, mode='scene' if scene else 'director',
                                   director=html.escape(source, quote=True), script=_SCRIPT)
        server.tab = ''
        server.delivery_lock = threading.Lock()
        server.closed = False
        server.on_guests = on_guests
        self._thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': 0.05}, daemon=True)
        self._thread.start()

    def close(self):
        with self._server.delivery_lock:
            if self._server.closed:
                return
            self._server.closed = True
        self._server.shutdown()
        self._server.server_close()
        self._thread.join()
