from urllib.parse import parse_qs, urlsplit
from unittest.mock import Mock

import pytest
from PySide6.QtCore import QSettings

from observer_assist.camera_vdo import VdoImport
from observer_assist.camera_vdo_panel import SETTINGS_KEY, VdoRoomPanel
from observer_assist.camera_vdo_room import parse_director, scene_url
from observer_assist.hud_manager import HudManager
from test_vmix_control import app


def test_solo_and_discovery_keep_only_viewer_access_options():
    link = ('https://vdo.ninja/?director=Final&push=PRODUCER&api=CONTROL&codirector=CO'
            '&maindirectorpassword=MASTER#pw=A%2BB%26C')
    room = parse_director(link)
    assert room.codirector
    assert 'PRODUCER' not in room.director and 'CONTROL' not in room.director
    assert 'CO' in room.director and 'MASTER' in room.director
    for url in [room.viewer('S+&1'), scene_url(link)]:
        address = urlsplit(url)
        values = parse_qs(address.query)
        assert values['room'] == ['Final']
        assert parse_qs(address.fragment) == {'password': ['A+B&C']}
        assert not {'director', 'codirector', 'push', 'api', 'maindirectorpassword'}.intersection(values)
    assert parse_qs(urlsplit(room.viewer('S+&1')).query)['view'] == ['S+&1']
    assert parse_qs(urlsplit(scene_url(link)).query)['scene'] == ['0']
    room2 = parse_director('https://vdo.ninja/?dir&room=Final&p0')
    assert room.key == room2.key
    assert parse_qs(urlsplit(room2.viewer('x')).query)['password'] == ['false']


@pytest.mark.parametrize('link', ['https://vdo.ninja/?room=x', 'http://vdo.ninja/?director=x',
    'https://example.com/?director=x', 'https://vdo.ninja/?director=x&password', 'https://vdo.ninja/?director'])
def test_bad_director_links(link):
    with pytest.raises(ValueError):
        parse_director(link)


def test_operator_import_without_match_and_transient_disconnect(app, tmp_path, monkeypatch):
    manager = HudManager(QSettings(str(tmp_path / 'settings.ini'), QSettings.IniFormat), tmp_path / 'hud')
    controller, panel, cameras = manager.vdo_import, manager.vdo_panel, manager.cameras
    bridges = []
    class Bridge:
        def __init__(self, raw, callback, *, scene, interval):
            self.callback = callback
            self.scene = scene
            self.interval = interval
            self.url = 'http://127.0.0.1:54321/private/'
            self.closed = False
            bridges.append(self)
        def close(self):
            self.closed = True

    controller.bridge_factory = Bridge
    controller.open_url = lambda url: True
    clock = [100.0]
    monkeypatch.setattr('observer_assist.camera_vdo.monotonic', lambda: clock[0])
    try:
        panel.url.setText('https://vdo.ninja/?director=Final&password=private&api=control')
        panel.forward_to_modules.setChecked(True)
        panel.connect_button.click()
        assert len(bridges) == 1 and not bridges[0].scene and bridges[0].interval == 3
        guests = [dict(streamID='abc', label='ghoul'), dict(streamID='def', label='Snaps')]
        bridges[0].callback(guests)
        rows = cameras.preparation_rows()
        ghoul = next(i for i,p in enumerate(rows) if p[1] == 'ghoul')
        assert parse_qs(urlsplit(rows[ghoul][2]).query) == {
            'room': ['Final'], 'view': ['abc'], 'solo':['1'], 'password':['private']}
        bridges[0].callback(list(reversed(guests)))
        assert cameras.preparation_rows() == rows
        bridges[0].callback(guests[1:])
        clock[0] += 24
        controller._check_connection()
        assert cameras.preparation_rows() == rows
        bridges[0].callback(guests)
        bridges[0].callback(guests[1:])
        clock[0] += 7
        bridges[0].callback(guests[1:])
        assert cameras.preparation_rows()[ghoul][2] == ''
        bridges[0].callback(guests)
        assert cameras.preparation_rows() == rows
        assert not cameras.roster.match_id and not cameras.roster.slots
        assert 'private' not in cameras.log.toPlainText()
        panel.stop_button.click()
        assert bridges[0].closed
        bridges[0].callback([])
        assert cameras.preparation_rows() == rows
    finally:
        manager.close()


def test_configured_interval_12_guests_reconnect_and_opt_out(app, tmp_path, monkeypatch):
    setting = QSettings(str(tmp_path / 'room.ini'), QSettings.IniFormat)
    setting.setValue(SETTINGS_KEY, 'https://vdo.ninja/?director=Final')
    opener, factory, cameras = Mock(return_value=True), Mock(), Mock()
    cameras.vdo_guest_bank.return_value = None
    cameras.import_vdo_guests.return_value = 'Список обновлён.'
    clock = [100.0]
    monkeypatch.setattr('observer_assist.camera_vdo.monotonic', lambda: clock[0])
    panel = VdoRoomPanel(setting)
    panel.forward_to_modules.setChecked(True)
    ctl = VdoImport(panel, cameras, bridge_factory=factory, open_url=opener)
    factory.return_value.url = 'http://127.0.0.1:18283/local-test/'
    transitions = []
    ctl.freshness_changed.connect(transitions.append)
    guests = [dict(streamID=f'camera{i}', label=f'Player{i}') for i in range(12)]
    try:
        panel.poll_interval.setValue(4)
        factory.assert_not_called()
        opener.assert_not_called()
        panel.connect_button.click()
        assert factory.call_args.kwargs == dict(scene=False, interval=4)
        accept = factory.call_args.args[1]
        accept(guests)
        assert ctl.fresh and panel.table.rowCount() == 12
        panel.poll_interval.setValue(15)
        factory.return_value.set_interval.assert_called_once_with(15)
        assert ctl.stale_after == 47
        accept(guests[:-1])
        clock[0] += 15
        accept(guests[:-1])
        assert len(cameras.import_vdo_guests.call_args.args[1]) == 12
        assert cameras.import_vdo_guests.call_args.kwargs['observed_streams'] == {
            guest['streamID'] for guest in guests[:-1]}
        clock[0] += 15
        accept(guests[:-1])
        assert len(cameras.import_vdo_guests.call_args.args[1]) == 11
        accept(list(reversed(guests)))
        assert len(cameras.import_vdo_guests.call_args.args[1]) == 12
        accept(guests[:-1])
        clock[0] += 48
        ctl._check_connection()
        ctl._check_connection()
        cameras.end_vdo_session.assert_called_once_with()
        assert not ctl.fresh and not panel.table.rowCount()
        accept(guests[:-1])
        assert ctl.fresh and len(cameras.import_vdo_guests.call_args.args[1]) == 12
        cameras.end_vdo_session.assert_called_once_with()
        # A suspended GUI can receive a new snapshot before the expired Qt timer runs.
        clock[0] += ctl.stale_after
        cameras.reset_mock()
        accept(guests)
        assert [call[0] for call in cameras.method_calls[:2]] == ['end_vdo_session', 'import_vdo_guests']
        panel.stop_button.click()
        assert not ctl.fresh and not ctl.timer.isActive()
        assert cameras.end_vdo_session.call_count == 2
        ctl.stop()
        assert cameras.end_vdo_session.call_count == 2
        panel.poll_interval.setValue(8)
        accept([])
        assert len(cameras.import_vdo_guests.call_args.args[1]) == 12
        assert transitions == [True, False, True, False]
        assert opener.call_count == factory.call_count == 1
    finally:
        ctl.stop()
        panel.close()
