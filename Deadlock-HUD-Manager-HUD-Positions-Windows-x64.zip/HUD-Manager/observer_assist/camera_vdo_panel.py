"""Room director link and discovery status for the camera operator."""

from collections import Counter
from hashlib import sha256
from ipaddress import IPv4Address
import json
import re
from typing import NamedTuple
from urllib.parse import parse_qs, urlsplit

from PySide6.QtCore import QSignalBlocker, Qt, Signal
from PySide6.QtWidgets import (
    QAbstractItemView, QApplication, QCheckBox, QFormLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QPushButton, QSpinBox, QTabBar, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from .camera_vdo_bridge import DEFAULT_POLL_SECONDS, MAX_POLL_SECONDS, poll_seconds
from .camera_vdo_room import parse_director
from .match_stats import is_lan_address


SETTINGS_KEY = 'cameraVdoDirectorUrl'
DIRECTOR_MODE_KEY = 'cameraVdoDirectorMode'
POLL_INTERVAL_KEY = 'cameraVdoPollSeconds'
FORWARD_KEY = 'cameraVdoForwardModules'
HOST_KEY = 'cameraVdoVmixHost'
PORT_KEY = 'cameraVdoVmixPort'
_PRIVATE_LINK = re.compile(r'://|vdo\.ninja[/#?]|[?&](?:director|room|view|password|token)=', re.I)


def _label(text, name=None):
    label = QLabel(text)
    label.setTextFormat(Qt.TextFormat.PlainText)
    label.setWordWrap(True)
    if name:
        label.setObjectName(name)
    return label


class _Guest(NamedTuple):
    label: str
    bank: int | None
    page: str
    identity: str
    issue: str


def _settings_map(settings, key):
    try:
        value = json.loads(settings.value(key, '{}', type=str))
    except (TypeError, ValueError):
        return {}
    return value if isinstance(value, dict) else {}


def _guest(row):
    label = str(row.get('label') or '').strip()
    if not label.isprintable() or _PRIVATE_LINK.search(label):
        label = ''
    page = str(row.get('page') or '').strip()
    try:
        url = urlsplit(page)
        query = parse_qs(url.query, keep_blank_values=True)
        options = set(query) | parse_qs(url.fragment.lstrip('?&'), keep_blank_values=True).keys()
        view = query.get('view') or query.get('v') or []
        valid = (url.scheme == 'https' and url.hostname in ('vdo.ninja', 'www.vdo.ninja')
                 and not url.username and not url.password and url.port in (443, None)
                 and len(view) == 1 and view[0] and not options.intersection({'director', 'dir', 'codirector'}))
    except ValueError:
        valid = False
    stream = row.get('streamID') or (view[0] if valid else '')
    if not valid or view[0] != stream:
        return _Guest(label, row.get('bank'), '', '', 'Нет ссылки просмотра')
    key = sha256(stream.encode()).hexdigest()
    if not label:
        return _Guest('', row.get('bank'), page, key, 'Нужен игровой ник')
    return _Guest(label, row.get('bank'), page, key, '')


class _HudRow(NamedTuple):
    name: str
    number: int
    page: str
    title: str
    problem: str


class _PositionAssignments(QWidget):
    edited = Signal()
    SETTINGS_KEY = 'cameraVdoPositionInputs'

    def __init__(self, settings):
        super().__init__()
        self.settings = settings
        self.names = ()
        self.source = ''
        self.rows = ()
        self.revision = 0
        self.results = {}
        self.ready = False
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.hint = _label('', 'roomHelp')
        layout.addWidget(self.hint)
        self.table = QTableWidget(12, 5)
        self.table.setAccessibleName('Камеры в порядке верхней полосы HUD')
        self.table.setHorizontalHeaderLabels(['Поз. / клавиша', 'Игрок в HUD', 'Вход vMix', 'Название в vMix', 'Состояние'])
        self.table.verticalHeader().hide()
        self.table.verticalHeader().setDefaultSectionSize(36)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.setMinimumHeight(170)
        self.table.setMaximumHeight(300)
        layout.addWidget(self.table)
        saved = _settings_map(settings, self.SETTINGS_KEY)
        self.inputs = []
        for i, key in enumerate('1234567890-='):
            self.table.setItem(i, 0, QTableWidgetItem(f'{i + 1} / {key}'))
            for col in (1, 3, 4):
                self.table.setItem(i, col, QTableWidgetItem())
            field = QSpinBox(self.table)
            field.setRange(1, 9999)
            field.setAccessibleName(f'Вход vMix для позиции {i + 1}')
            field.setKeyboardTracking(False)
            n = saved.get(str(i + 1))
            field.setValue(n if type(n) is int and 1 <= n <= 9999 else i + 1)
            self.table.setCellWidget(i, 2, field)
            self.inputs.append(field)
            field.valueChanged.connect(self._save_inputs)

    def _save_inputs(self):
        self.settings.setValue(self.SETTINGS_KEY, json.dumps({i: f.value() for i, f in enumerate(self.inputs, 1)}))
        self.edited.emit()

    def set_order(self, names, source):
        values = ()
        if (isinstance(names, (list, tuple)) and len(names) == 12
                and all(isinstance(s, str) and s.strip() for s in names)):
            candidates = tuple(s.strip() for s in names)
            if len({s.casefold() for s in candidates}) == 12:
                values = candidates
        source = source if source and not _PRIVATE_LINK.search(source) else ''
        changed = (values, source) != (self.names, self.source)
        if changed:
            self.names, self.source = values, source
            self.revision += 1
            self.results.clear()
        return changed

    def refresh(self, guests, issues, fresh, busy):
        by_name = {}
        for g in guests:
            if g.label:
                by_name.setdefault(g.label.casefold(), []).append(g)
        numbers = Counter(field.value() for field in self.inputs)
        rows = []
        for i, field in enumerate(self.inputs):
            field.setEnabled(not busy)
            number = field.value()
            name = self.names[i] if self.names else ''
            matched = by_name.get(name.casefold(), [])
            page = title = problem = ''
            if not name:
                problem = 'Ожидание порядка'
            elif not fresh:
                problem = 'Ожидание комнаты'
            elif len(matched) > 1:
                problem = 'Повторяется ник'
            elif matched:
                guest = matched[0]
                problem = issues.get(guest.page, '')
                if not problem:
                    page, title = guest.page, name
            else:
                title = '-'
            if numbers[number] > 1:
                problem = 'Номер входа занят дважды'
            rows.append(_HudRow(name, number, page, title, problem))
        rows = tuple(rows)
        if rows != self.rows:
            self.revision += 1
            self.results.clear()
            self.rows = rows
        matched = sum(bool(row.page) for row in rows)
        clears = sum(row.title == '-' and not row.problem for row in rows)
        self.ready = bool(matched) and fresh and all(not row.problem for row in rows)
        if not self.names:
            hint = 'Нужен полный порядок 12 разных игроков. Проверьте данные матча и верхней полосы HUD.'
        elif not fresh:
            hint = 'Дождитесь свежего списка гостей VDO.Ninja.'
        elif not matched:
            hint = 'Нет совпадений. Сверьте Label гостей с никами игроков. Отправка заблокирована.'
        elif any(row.problem for row in rows):
            hint = 'Проверьте строки с ошибками. Для отправки нужны однозначные назначения всех 12 входов.'
        else:
            hint = (f'Камер · {matched}  |  Прозрачных входов · {clears}. '
                    'Для позиций без камеры название входа станет «-».')
        self.hint.setText(f'{self.source} · {hint}' if self.source else hint)
        for i, row in enumerate(rows):
            status = row.problem or self.results.get(row.number) or ('Камера' if row.page else 'Нет камеры · прозрачно')
            for col, value in ((1, row.name or '—'), (3, row.title or '—'), (4, status)):
                item = self.table.item(i, col)
                if item.text() != value:
                    item.setText(value)
                    item.setToolTip(value)

    def commands(self):
        return [(r.page, r.title, r.number) for r in self.rows] if self.ready else []


class VdoRoomPanel(QWidget):
    start_requested = Signal(str)
    stop_requested = Signal()
    reopen_requested = Signal()
    apply_vmix_requested = Signal(str, int, object)

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.settings = settings
        self._phase = 'idle'
        self._pending_url = ''
        self._room_inputs_key = ''
        self._numbers = {}
        self._results = {}
        self._issues = {}
        self._busy = False
        self._room_fresh = False
        self._submitted_revision = None
        self._submitted = {}
        self._guests = ()
        previous = _settings_map(settings, 'cameraRoutingV1')
        live = previous.get('live') if isinstance(previous.get('live'), dict) else {}
        replay = previous.get('replay') if isinstance(previous.get('replay'), dict) else {}
        self.setStyleSheet("""
            QLabel#roomTitle { font-size: 14pt; font-weight: 600; color: #ebf2f5; }
            QLabel#roomHelp { color: #b8c6cb; }
            QLabel#roomStatus { font-weight: 600; }
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        layout.addWidget(_label('Гости комнаты VDO.Ninja', 'roomTitle'))
        layout.addWidget(_label('Укажите игровой ник в имени гостя или в параметре &label= его ссылки. '
                                'Для импорта нужны разные ники.', 'roomHelp'))

        caption = _label('Приватная ссылка директора')
        self.url = QLineEdit(settings.value(SETTINGS_KEY, '', type=str))
        self.url.setEchoMode(QLineEdit.EchoMode.Password)
        self.url.setPlaceholderText('Вставьте ссылку директора комнаты')
        self.url.setAccessibleName(caption.text())
        caption.setBuddy(self.url)
        self.url.returnPressed.connect(self._request_start)
        layout.addWidget(caption)
        layout.addWidget(self.url)
        self.url.setToolTip('После успешного запуска ссылка сохраняется в настройках на этом ПК.')
        self.director_mode = QCheckBox('Открыть как режиссёр (включая гостей вне сцены)')
        self.director_mode.setChecked(settings.value(DIRECTOR_MODE_KEY, True, type=bool))
        self.advanced = QPushButton('Дополнительные настройки')
        self.advanced.setCheckable(True)
        layout.addWidget(self.advanced, alignment=Qt.AlignmentFlag.AlignLeft)
        advanced_page = QWidget()
        advanced_layout = QVBoxLayout(advanced_page)
        advanced_layout.setContentsMargins(0, 0, 0, 0)
        advanced_layout.addWidget(self.director_mode)
        self.mode_hint = _label('', 'roomHelp')
        advanced_layout.addWidget(self.mode_hint)
        self.director_mode.toggled.connect(self._show_mode_hint)
        self._show_mode_hint(self.director_mode.isChecked())

        cadence = QHBoxLayout()
        caption = _label('Интервал обновления списка гостей')
        self.poll_interval = QSpinBox()
        self.poll_interval.setRange(1, MAX_POLL_SECONDS)
        self.poll_interval.setSuffix(' с')
        self.poll_interval.setAccessibleName(caption.text())
        self.poll_interval.setToolTip('Изменение применяется к открытой вкладке комнаты.')
        self.poll_interval.setValue(poll_seconds(settings.value(POLL_INTERVAL_KEY, DEFAULT_POLL_SECONDS)))
        self.poll_interval.valueChanged.connect(lambda value: settings.setValue(POLL_INTERVAL_KEY, value))
        caption.setBuddy(self.poll_interval)
        cadence.addWidget(caption)
        cadence.addWidget(self.poll_interval)
        cadence.addStretch()
        advanced_layout.addLayout(cadence)
        self.forward_to_modules = QCheckBox('Передавать гостей в Live и Replay')
        upgrading = bool(self.url.text() and (live.get('enabled') is True or replay.get('enabled') is True))
        self.forward_to_modules.setChecked(settings.value(FORWARD_KEY, upgrading, type=bool))
        # Freeze the migration decision before this new panel first saves a director URL.
        if not settings.contains(FORWARD_KEY):
            settings.setValue(FORWARD_KEY, self.forward_to_modules.isChecked())
        self.forward_to_modules.toggled.connect(self._set_forwarding)
        advanced_layout.addWidget(self.forward_to_modules)
        advanced_page.hide()
        self.advanced.toggled.connect(advanced_page.setVisible)
        layout.addWidget(advanced_page)

        controls = QHBoxLayout()
        self.connect_button = QPushButton('Подключиться к комнате')
        self.connect_button.setObjectName('primary')
        self.connect_button.clicked.connect(self._request_start)
        self.reopen_button = QPushButton('Открыть вкладку')
        self.reopen_button.setToolTip('Если вкладка закрылась, откройте её снова и оставьте открытой для импорта.')
        self.reopen_button.clicked.connect(self.reopen_requested.emit)
        self.stop_button = QPushButton('Отключить')
        self.stop_button.clicked.connect(self.stop_requested.emit)
        for button in (self.connect_button, self.reopen_button, self.stop_button):
            controls.addWidget(button)
        controls.addStretch()
        layout.addLayout(controls)

        self.status = _label('', 'roomStatus')
        self.summary = _label('')
        layout.addWidget(self.status)
        layout.addWidget(self.summary)
        self.assignment_tabs = QTabBar()
        self.assignment_tabs.setAccessibleName('Способ назначения входов vMix')
        self.assignment_tabs.setExpanding(False)
        self.assignment_tabs.addTab('Вручную по гостям')
        self.assignment_tabs.addTab('По позициям HUD')
        layout.addWidget(self.assignment_tabs, alignment=Qt.AlignmentFlag.AlignLeft)
        self.table = QTableWidget(0, 4)
        self.table.setAccessibleName('Гости комнаты и входы vMix')
        self.table.setHorizontalHeaderLabels(['Имя гостя', 'Вход vMix', 'Состояние', 'Пара камер'])
        self.table.setColumnHidden(3, not self.forward_to_modules.isChecked())
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.table.verticalHeader().hide()
        self.table.verticalHeader().setDefaultSectionSize(36)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setAlternatingRowColors(True)
        self.table.setMinimumHeight(125)
        self.table.setMaximumHeight(250)
        self.table.hide()
        layout.addWidget(self.table)
        self.copy_button = QPushButton('Копировать ссылку камеры')
        self.copy_button.clicked.connect(self._copy_camera)
        self.copy_button.setEnabled(False)
        self.copy_button.hide()
        layout.addWidget(self.copy_button, alignment=Qt.AlignmentFlag.AlignLeft)
        self.table.itemSelectionChanged.connect(self._update_copy)
        self.positions = _PositionAssignments(settings)
        self.positions.edited.connect(self._refresh_vmix)
        layout.addWidget(self.positions)
        target = QFormLayout()
        target.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        self.vmix_host = QLineEdit(settings.value(HOST_KEY, live.get('host') or '127.0.0.1', type=str))
        self.vmix_port = QSpinBox()
        self.vmix_host.setAccessibleName('IPv4 компьютера с vMix')
        self.vmix_port.setAccessibleName('Порт Web Controller')
        self.vmix_port.setRange(1, 65535)
        saved_port = settings.value(PORT_KEY, live.get('port', 8088))
        try:
            port = int(saved_port)
        except (TypeError, ValueError):
            port = 8088
        self.vmix_port.setValue(port if 1 <= port <= 65535 else 8088)
        target.addRow('IPv4 компьютера с vMix', self.vmix_host)
        target.addRow('Порт Web Controller', self.vmix_port)
        layout.addLayout(target)
        layout.addWidget(_label('Выберите номера существующих входов Web Browser. '
                                'За один раз можно применить до 12 камер.', 'roomHelp'))
        self.apply_vmix = QPushButton('Применить в vMix')
        self.apply_vmix.setObjectName('primary')
        self.apply_vmix.clicked.connect(self._apply_vmix)
        layout.addWidget(self.apply_vmix, alignment=Qt.AlignmentFlag.AlignLeft)
        self.apply_positions = QPushButton('Применить по позициям HUD в vMix')
        self.apply_positions.setObjectName('primary')
        self.apply_positions.clicked.connect(self._apply_vmix)
        layout.addWidget(self.apply_positions, alignment=Qt.AlignmentFlag.AlignLeft)
        self.assignment_tabs.currentChanged.connect(self._switch_view)
        self.vmix_message = _label('')
        layout.addWidget(self.vmix_message)
        self.vmix_host.textChanged.connect(self._destination_changed)
        self.vmix_port.valueChanged.connect(self._destination_changed)
        self.url.textChanged.connect(self._update_controls)
        self._switch_view()
        self.stop()

    def _show_mode_hint(self, director):
        if director:
            self.mode_hint.setText('Если главный Director уже открыт, разрешите Co-Director в Room Settings '
                                   'и используйте приглашение второго режиссёра.')
        else:
            self.mode_hint.setText('Режим сцены показывает подключённых к ней гостей. Главный Director может '
                                   'оставаться открытым. Приглашение Co-Director включает режим режиссёра автоматически.')

    def _update_controls(self):
        idle = self._phase == 'idle'
        self.url.setReadOnly(not idle)
        self.director_mode.setEnabled(idle)
        self.connect_button.setVisible(idle)
        self.connect_button.setEnabled(idle and bool(self.url.text().strip()))
        self.reopen_button.setVisible(self._phase == 'running')
        self.stop_button.setVisible(not idle)

    def _request_start(self):
        if self._phase != 'idle':
            return
        link = self.url.text().strip()
        if not link:
            return
        self._phase = 'starting'
        self._pending_url = link
        self.status.setText('Открываем комнату в браузере…')
        self.summary.hide()
        self._update_controls()
        self.start_requested.emit(link)

    def started(self):
        if self._phase != 'starting':
            return
        try:
            room = parse_director(self._pending_url)
        except ValueError as exc:
            self.start_failed(str(exc))
            return
        self._room_inputs_key = f'cameraVdoInputNumbers/{room.key}'
        self._numbers = {key: n for key, n in _settings_map(self.settings, self._room_inputs_key).items()
                         if type(n) is int and 0 <= n <= 9999}
        self.settings.setValue(SETTINGS_KEY, self._pending_url)
        self.settings.setValue(DIRECTOR_MODE_KEY, self.director_mode.isChecked())
        self._pending_url = ''
        self._phase = 'running'
        self.status.setText('Ожидаем список гостей. Оставьте вкладку браузера открытой.')
        self._update_controls()

    def start_failed(self, reason):
        self.stop()
        message = reason.strip()
        self.status.setText(message if message and not _PRIVATE_LINK.search(message)
                            else 'Не удалось подключиться. Проверьте ссылку директора и повторите попытку.')

    def show_result(self, guests_count, summary):
        if self._phase != 'running':
            return
        self.status.setText(f'Видимых гостей · {guests_count}')
        message = summary.strip()
        if _PRIVATE_LINK.search(message):
            message = 'Список гостей обновлён.'
        self.summary.setText(message)
        self.summary.setVisible(bool(message) and (self.forward_to_modules.isChecked() or not self._guests))

    def show_stale(self):
        if self._phase == 'running':
            self.set_room_fresh(False)
            self.status.setText('Список гостей не обновляется. Нажмите «Открыть вкладку» и проверьте комнату в браузере.')
            self.summary.clear()
            self.summary.hide()
            self.set_guests([])

    def _selected_page(self):
        selected = self.table.selectionModel().selectedRows()
        return self._guests[selected[0].row()].page if selected else ''

    def _update_copy(self):
        self.copy_button.setEnabled(bool(self._selected_page()))

    def _copy_camera(self):
        page = self._selected_page()
        if page:
            QApplication.clipboard().setText(page)

    def _set_forwarding(self, enabled):
        self.settings.setValue(FORWARD_KEY, enabled)
        self.table.setColumnHidden(3, not enabled)
        self.summary.setVisible(enabled and bool(self.summary.text()))

    def set_guests(self, rows):
        """Update current guests; never reuse a stream's assignment in another room."""
        guests = tuple(_guest(row) for row in rows) if self._phase == 'running' else ()
        if guests == self._guests:
            return
        selected = self._selected_page()
        old_labels = {g.page: g.label for g in self._guests}
        self._guests = guests
        names = Counter(g.label.casefold() for g in guests)
        identities = Counter(g.identity for g in guests)
        self._issues = {}
        before = dict(self._numbers)
        for g in guests:
            issue = g.issue
            if not issue and identities[g.identity] > 1:
                issue = 'Повторяется Stream ID'
            if not issue and names[g.label.casefold()] > 1:
                issue = 'Повторяется ник'
            if issue:
                self._issues[g.page] = issue
        present = set(identities)
        valid = [g for g in guests if g.page not in self._issues]
        assigned = sum(bool(self._numbers.get(g.identity)) for g in valid)
        for g in valid:
            if g.identity in self._numbers or assigned >= 12:
                continue
            current = {self._numbers.get(key) for key in present}
            free = [n for n in range(1, 13) if n not in current]
            if not free:
                break
            # Leave absent guests' assignments intact until all unused physical inputs are taken.
            number = next((n for n in free if n not in self._numbers.values()), free[0])
            self._claim_number(g.identity, number, present)
            assigned += 1
        if self._numbers != before:
            self._save_numbers()
        self._results = {g.page: self._results[g.page] for g in guests
                         if g.page in self._results and old_labels.get(g.page) == g.label}
        with QSignalBlocker(self.table):
            self.table.setRowCount(len(guests))
            self.table.setCurrentCell(-1, -1)
            self.table.clearSelection()
            for i, g in enumerate(guests):
                self.table.setItem(i, 0, QTableWidgetItem(g.label or 'Без имени'))
                field = self.table.cellWidget(i, 1)
                if field is None:
                    field = QSpinBox(self.table)
                    field.setRange(0, 9999)
                    field.setSpecialValueText('Пропустить')
                    field.setKeyboardTracking(False)
                    field.valueChanged.connect(self._number_edited)
                    self.table.setCellWidget(i, 1, field)
                field.setProperty('guestRow', i)
                field.setAccessibleName(f'Вход vMix для гостя {g.label or i + 1}')
                with QSignalBlocker(field):
                    field.setValue(self._numbers.get(g.identity, 0) if g.page not in self._issues else 0)
                self.table.setItem(i, 2, QTableWidgetItem())
                self.table.setItem(i, 3, QTableWidgetItem(str(g.bank) if g.bank is not None else 'Не назначена'))
                if selected and g.page == selected:
                    self.table.selectRow(i)
        self._update_copy()
        manual = self.assignment_tabs.currentIndex() == 0
        self.table.setVisible(manual and bool(guests))
        self.copy_button.setVisible(manual and bool(guests))
        self._refresh_vmix()

    def _switch_view(self):
        positions = self.assignment_tabs.currentIndex() == 1
        self.positions.setVisible(positions)
        self.table.setVisible(not positions and bool(self._guests))
        self.copy_button.setVisible(not positions and bool(self._guests))
        self.apply_vmix.setVisible(not positions)
        self.apply_positions.setVisible(positions)
        self._refresh_vmix()

    def set_hud_order(self, names, source=''):
        if self.positions.set_order(names, source):
            self._refresh_vmix()

    def set_room_fresh(self, fresh):
        self._room_fresh = bool(fresh) and self._phase == 'running'
        self._refresh_vmix()

    def _save_numbers(self):
        if self._room_inputs_key:
            self.settings.setValue(self._room_inputs_key, json.dumps(self._numbers))

    def _claim_number(self, identity, number, present):
        if number:
            for key in list(self._numbers):
                if key not in present and self._numbers[key] == number:
                    del self._numbers[key]
        self._numbers[identity] = number

    def _number_edited(self, number):
        field = self.sender()
        row = field.property('guestRow')
        if not 0 <= row < len(self._guests) or self.table.cellWidget(row, 1) is not field:
            return
        guest = self._guests[row]
        self._claim_number(guest.identity, number, {g.identity for g in self._guests})
        self._save_numbers()
        self._results.pop(guest.page, None)
        self.vmix_message.clear()
        self._refresh_vmix()

    def _destination_changed(self):
        self._results.clear()
        self.positions.results.clear()
        self.vmix_message.clear()
        self._refresh_vmix()

    def _selected_inputs(self):
        return [(g.page, g.label, self._numbers[g.identity]) for g in self._guests
                if g.page not in self._issues and self._numbers.get(g.identity)]

    def _refresh_vmix(self):
        self.positions.refresh(self._guests, self._issues, self._room_fresh, self._busy)
        self.apply_positions.setEnabled(self.positions.ready and not self._busy)
        self.assignment_tabs.setEnabled(not self._busy)
        chosen = self._selected_inputs()
        counts = Counter(row[2] for row in chosen)
        valid = bool(chosen) and len(chosen) <= 12 and max(counts.values(), default=0) <= 1
        self.apply_vmix.setEnabled(self._phase == 'running' and valid and not self._busy)
        self.vmix_host.setEnabled(not self._busy)
        self.vmix_port.setEnabled(not self._busy)
        for i, g in enumerate(self._guests):
            number = self._numbers.get(g.identity, 0)
            issue = self._issues.get(g.page)
            self.table.cellWidget(i, 1).setEnabled(not issue and not self._busy)
            if not issue and number and counts[number] > 1:
                issue = 'Номер занят дважды'
            if not issue and number and len(chosen) > 12:
                issue = 'Лимит 12 камер'
            state = 'К применению' if number else 'Пропущен'
            self.table.item(i, 2).setText(issue or self._results.get(g.page) or state)

    def _apply_vmix(self):
        by_position = self.sender() is self.apply_positions
        button = self.apply_positions if by_position else self.apply_vmix
        if not button.isEnabled():
            return
        try:
            host = IPv4Address(self.vmix_host.text().strip())
            if not host.is_loopback and not is_lan_address(host):
                raise ValueError
        except ValueError:
            self.vmix_message.setText('Укажите локальный IPv4 компьютера с vMix или 127.0.0.1.')
            self.vmix_host.setFocus()
            return
        rows = self.positions.commands() if by_position else self._selected_inputs()
        self.settings.setValue(HOST_KEY, str(host))
        self.settings.setValue(PORT_KEY, self.vmix_port.value())
        self._submitted_revision = self.positions.revision if by_position else None
        if by_position:
            self._results.clear()
            self.positions.results = {row.number: 'В очереди' for row in self.positions.rows}
        else:
            self.positions.results.clear()
            self._submitted = {page: (label, number) for page, label, number in rows}
            self._results = dict.fromkeys(self._submitted, 'В очереди')
        self._busy = True
        self.vmix_message.setText('Применяем назначения в vMix…')
        self._refresh_vmix()
        self.apply_vmix_requested.emit(str(host), self.vmix_port.value(), rows)

    def is_current_vmix_row(self, page, label, number):
        if self._submitted_revision is not None:
            return (self.positions.revision == self._submitted_revision
                    and (page, label, number) in self.positions.commands())
        rows = self._selected_inputs()
        return (self._phase == 'running' and len(rows) <= 12 and (page, label, number) in rows
                and sum(row[2] == number for row in rows) == 1)

    def vmix_result(self, page, message):
        if self._busy and page in self._submitted and self.is_current_vmix_row(page, *self._submitted[page]):
            self._results[page] = 'Получен ответ vMix' if _PRIVATE_LINK.search(message) else message
            self._refresh_vmix()

    def vmix_position_result(self, number, message):
        if self._busy and self.positions.revision == self._submitted_revision:
            self.positions.results[number] = 'Получен ответ vMix' if _PRIVATE_LINK.search(message) else message
            self._refresh_vmix()

    def vmix_finished(self, message):
        if self._busy:
            self._busy = False
            self._submitted.clear()
            self._submitted_revision = None
            self.positions.results = {k: v for k, v in self.positions.results.items() if v != 'В очереди'}
            self._results = {k: v for k, v in self._results.items() if v != 'В очереди'}
            self.vmix_message.setText('Ответ vMix получен.' if _PRIVATE_LINK.search(message) else message)
            self._refresh_vmix()

    def stop(self):
        self._phase = 'idle'
        self._pending_url = ''
        self.status.setText('Комната отключена.')
        self._results.clear()
        self._room_fresh = False
        self._submitted_revision = None
        self.positions.results.clear()
        self.vmix_message.clear()
        self.summary.clear()
        self.summary.hide()
        self.set_guests([])
        self._busy = False
        self._submitted.clear()
        self._refresh_vmix()
        self._update_controls()
