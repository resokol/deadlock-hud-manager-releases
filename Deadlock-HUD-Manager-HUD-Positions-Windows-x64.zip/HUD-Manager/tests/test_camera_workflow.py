"""Exercise the two camera modules through HudManager, Web Controller and Companion."""
import json
from functools import partial
from urllib.error import HTTPError
from urllib.parse import parse_qsl, urlsplit
from urllib.request import Request, urlopen
from uuid import UUID
from xml.etree import ElementTree as ET

import pytest

from test_vmix_control import app, fake_api, process_events, wait_for
from test_vmix_control import fake_api as second_api
from observer_assist import camera_vmix, live_stats_panel, source_tv_panel
from observer_assist.hud_manager import HudManager
from observer_assist.camera_preparation import camera_page, TRANSPARENT_PAGE
from observer_assist.match_stats import StatsLanServer
from observer_assist.panorama_health import PanoramaHealthLog
from PySide6.QtCore import QSettings


MATCH = '12345678'
PAGES = ('https://vdo.ninja/?view=private-first&codec=h264',
         'https://vdo.ninja/?view=private-second')


class Mixer:
    """A local vMix stand-in with XML state that reflects accepted commands."""

    def __init__(self, server, offset, pairs=2):
        self.pairs = pairs
        spare = 2 * pairs + 1
        self.port = server.server_port
        self.keys = {i: str(UUID(int=offset + i)) for i in range(1, spare + 1)}
        self.active = {1: spare, 2: spare}
        self.names = {i: f'Input {i}' for i in self.keys}
        self.commands = []
        self.connected = True
        server.answer = self.answer

    def answer(self, path):
        if not self.connected:
            return 503, {}, b''
        command = dict(parse_qsl(urlsplit(path).query))
        if command:
            number = next(i for i, key in self.keys.items() if key == command['Input'])
            function = command['Function']
            if function == 'SetInputName':
                self.names[number] = command['Value']
            elif function == 'ActiveInput':
                self.active[int(command['Mix']) + 1] = number
            self.commands.append(command)
            return 200, {}, b''
        root = ET.Element('vmix')
        ET.SubElement(root, 'preset').text = 'Show'
        inputs = ET.SubElement(root, 'inputs')
        for i, guid in self.keys.items():
            kind = 'Browser' if i <= self.pairs else 'Virtual' if i <= 2 * self.pairs else 'Colour'
            ET.SubElement(inputs, 'input', number=str(i), key=guid, title=self.names[i], type=kind)
        ET.SubElement(root, 'active').text = str(self.active[1])
        ET.SubElement(ET.SubElement(root, 'mix', number='2'), 'active').text = str(self.active[2])
        ET.SubElement(ET.SubElement(root, 'outputs'), 'output', number='1', source='Output')
        return 200, {}, ET.tostring(root)

    def writes(self, function):
        return [c for c in self.commands if c['Function'] == function]


def snapshot(window, names):
    rows = [dict(team=2 + i // 6, accountId=501 + i, heroId=1 + i, name=name,
                 assignedLane=(1, 4, 6)[(i % 6) // 2]) for i, name in enumerate(names)]
    window.source_tv.consume(dict(type='snapshot', matchId=MATCH, players=rows))


def portraits(window, names, selected=None, match_id=MATCH):
    teams = [dict(side=2 + begin // 6,
                  players=[dict(name=names[i], portraitX=30 * i, hero=f'Hero {i + 1}')
                           for i in range(begin, begin + 6)]) for begin in (0, 6)]
    packet = dict(version=1, teams=teams, selected={'player': selected} if selected else {})
    with window._health_log.path.open('a') as log:
        log.write(f'[DOA-MATCH-ID] {match_id}\n[DOA-TELEMETRY] {json.dumps(packet)}\n')
    window._poll_panorama_health()


def configure(window, role, mixer):
    panel = window.camera_panels[role]
    panel.enabled.setChecked(True)
    panel.port.setValue(mixer.port)
    if role == 'live':
        panel.follow.setChecked(True)
    for bank in range(2):
        source = mixer.keys[bank + 1]
        if role == 'replay':
            panel.sources[bank].edit.setText(source)
        panel.guids[bank].edit.setText(source if role == 'live' else mixer.keys[bank + 3])
    panel.apply.click()


@pytest.fixture
def window(app, monkeypatch, tmp_path):
    monkeypatch.setattr(camera_vmix, 'POLL_MS', 80)
    monkeypatch.setattr(live_stats_panel, 'StatsLanServer', partial(StatsLanServer, port=0))
    settings = QSettings(str(tmp_path / 'camera.ini'), QSettings.Format.IniFormat)
    manager = HudManager(settings, hud_directory=tmp_path / 'huds')
    log = tmp_path / 'console.log'
    log.touch()
    manager._health_log = PanoramaHealthLog(log)
    manager.panorama_enabled.setChecked(True)
    manager._health_timer.stop()
    manager.live_stats.network.addItem('Loopback', '127.0.0.1/8')
    manager.live_stats.network.setCurrentIndex(manager.live_stats.network.count() - 1)
    manager.live_stats.share.setChecked(True)
    try:
        yield manager
    finally:
        manager.close()


def post(lan, slot):
    with urlopen(Request(lan.program_url(slot), method='POST'), timeout=2) as reply:
        return reply.status


def companion(lan):
    with urlopen(lan.url, timeout=2) as reply:
        return json.load(reply)


@pytest.mark.parametrize('separate', (False, True), ids=('one-vmix', 'two-vmix'))
def test_account_cameras_follow_observer_and_companion_independently(window, fake_api, second_api, separate, monkeypatch):
    live = Mixer(fake_api, 100)
    replay = Mixer(second_api, 200) if separate else live
    lan = window.live_stats._export
    names = [f'Player {i}' for i in range(1, 13)]
    before = window.cameras.preparation_rows()
    draft = list(before)
    draft[0] = ('501', names[0], PAGES[0])
    draft[1] = ('', names[1], PAGES[1])
    window.cameras.save_preparation(before, draft)
    configure(window, 'live', live)
    configure(window, 'replay', replay)
    assert window.pov.suspended and not window.pov.isEnabled()
    wait_for(lambda: live.names[1] == names[0] and replay.names[4] == names[1] + ' (Virtual)')
    assert not window.camera_roster.slots and not live.writes('ActiveInput') and not replay.writes('ActiveInput')
    assert any(c['Value'] == camera_page(PAGES[1]) for c in live.writes('BrowserNavigate'))
    snapshot(window, names)

    portraits(window, names, names[1], match_id='22345678')
    assert not window.camera_roster.slots
    with pytest.raises(HTTPError) as wrong_match:
        post(lan, 2)
    assert wrong_match.value.code == 409

    portraits(window, names, names[1])
    wait_for(lambda: live.active[1] == 2 and window.camera_panels['replay'].buttons[0].isEnabled())
    assert post(lan, 1) == 202
    wait_for(lambda: replay.active[2] == 3)
    assert live.active[1] == 2
    data = companion(lan)
    assert data['hud_slots'] == {str(i): name for i, name in enumerate(names, 1)}
    assert data['hud_observed_slot'] == 2
    for i, key in enumerate('1234567890-=', 1):
        slot = data['camera_slots'][str(i)]
        assert (slot['key'], slot['name'], slot['account_id']) == (key, names[i - 1], str(500 + i))
    assert data['replay_button_labels']['1'] == names[0]
    assert data['replay_button_labels']['12'] == names[11] + '\nНет камеры'
    assert data['camera_slots']['1']['has_camera']
    assert data['camera_slots']['1']['live_guid'] == live.keys[1]
    assert data['camera_slots']['1']['replay_guid'] == replay.keys[3]

    pools = [live, replay] if separate else [live]
    navigation = [(m.keys[i], camera_page(page)) for m in pools for i, page in enumerate(PAGES, 1)]
    def destinations():
        return [(c['Input'], c['Value']) for m in pools for c in m.writes('BrowserNavigate')]
    assert sorted(destinations()) == sorted(navigation)
    previous_takes = replay.writes('ActiveInput')
    # The POST is accepted on the HTTP thread. Reorder before Qt delivers its queued signal.
    assert post(lan, 1) == 202
    names[0] = 'Renamed & One'
    snapshot(window, names)
    swapped = [names[1], names[0], *names[2:]]
    portraits(window, swapped, names[1])
    wait_for(lambda: replay.names[3] == 'Renamed & One (Virtual)' and live.names[1] == names[0])
    assert window.camera_roster.slots[2] == '501'
    assert companion(lan)['hud_slots']['1'] == names[1]
    assert companion(lan)['hud_observed_slot'] == 1
    assert replay.writes('ActiveInput') == previous_takes
    assert post(lan, 1) == 202
    wait_for(lambda: replay.active[2] == 4)
    assert live.active[1] == 2
    assert sorted(destinations()) == sorted(navigation)
    exported = json.dumps(companion(lan))
    assert all(word not in exported for word in ('private-first', 'private-second', 'vdo.ninja'))
    assert 'private-first' not in window.cameras.log.toPlainText()
    window.camera_panels['live'].buttons[1].click()
    wait_for(lambda: live.active[1] == 1)
    portraits(window, swapped, names[1])
    process_events(160)
    assert live.active[1] == 1 and replay.active[2] == 4

    replay.connected = False
    wait_for(lambda: not window.camera_panels['replay'].buttons[0].isEnabled())
    with pytest.raises(HTTPError) as disconnected:
        post(lan, 1)
    assert disconnected.value.code == 409
    if separate:
        assert window.camera_panels['live'].buttons[0].isEnabled()
    writes_before_reconnect = replay.writes('ActiveInput')
    replay.connected = True
    wait_for(lambda: window.camera_panels['replay'].buttons[0].isEnabled())
    process_events(160)
    assert replay.writes('ActiveInput') == writes_before_reconnect
    assert sorted(destinations()) == sorted(navigation)

    window._health_log._telemetry_time -= 5
    window._poll_panorama_health()
    wait_for(lambda: not window.camera_roster.slots and not companion(lan)['hud_slots'])
    portraits(window, swapped)
    wait_for(lambda: window.camera_panels['replay'].buttons[0].isEnabled())
    received = window.source_tv._last_snapshot
    with monkeypatch.context() as clock:
        clock.setattr(source_tv_panel, 'monotonic', lambda: received + 20)
        window.source_tv._update_age()
    wait_for(lambda: not window.camera_roster.players and not companion(lan)['hud_slots'])
    with pytest.raises(HTTPError) as stale:
        post(lan, 1)
    assert stale.value.code == 409
    snapshot(window, names)
    portraits(window, swapped)
    wait_for(lambda: window.camera_panels['replay'].buttons[0].isEnabled())
    assert sorted(destinations()) == sorted(navigation)

    assert window.camera_roster.set_page('502', '')
    wait_for(lambda: live.names[2] == '-' and replay.names[4] == '-' and replay.names[2] == '-')
    assert companion(lan)['hud_slots']['1'] == names[1]
    assert companion(lan)['replay_button_labels']['1'] == names[1] + '\nНет камеры'
    before = replay.writes('ActiveInput')
    with pytest.raises(HTTPError) as missing:
        post(lan, 1)
    assert missing.value.code == 409
    process_events(100)
    assert replay.writes('ActiveInput') == before
    assert sorted(destinations()) == sorted(navigation + [(m.keys[2], TRANSPARENT_PAGE) for m in pools])


def test_twelve_cameras_in_companion_order_after_side_swap(window, fake_api):
    from test_camera_vdo_bridge import DirectorFrame, request

    mixer = Mixer(fake_api, 700, pairs=12)
    names = [f'Player {i:02}' for i in range(12)]
    guests = [dict(streamID=f'cam-{i}', label=name.upper()) for i, name in enumerate(names)]
    window.vdo_import.open_url = lambda _: True
    window.vdo_panel.url.setText('https://vdo.ninja/?director=studio-fixture')
    window.vdo_panel.forward_to_modules.setChecked(True)
    window.vdo_panel.connect_button.click()
    bridge = window.vdo_import.bridge
    frame = DirectorFrame()
    frame.feed(request(bridge)[2].decode())
    headers = {'Content-Type': 'application/json', 'Origin': 'http://' + urlsplit(bridge.url).netloc,
               'X-Room-Tab': frame.attrs['data-tab']}
    assert request(bridge, 'POST', 'guests', headers, json.dumps(guests))[0] == 204
    wait_for(lambda: all(row[2] for row in window.cameras.preparation_rows()))
    for role in ('live', 'replay'):
        panel = window.camera_panels[role]
        panel.port.setValue(mixer.port)
        panel.discover.click()
        wait_for(lambda: len(panel._inputs) == 25)
        panel.fill_pairs.click()
        panel.enabled.setChecked(True)
        if role == 'live':
            panel.follow.setChecked(True)
        panel.apply.click()
    snapshot(window, names)
    screen_order = names[5::-1] + names[11:5:-1]
    portraits(window, screen_order, names[0])
    wait_for(lambda: len(window.cameras.available['replay']) == 12)
    wait_for(lambda: mixer.active[1] == 1 and mixer.names[24] == names[-1] + ' (Virtual)')
    lan = window.live_stats._export
    before = list(mixer.writes('BrowserNavigate'))
    assert len(before) == 12
    for pos, name in enumerate(screen_order, 1):
        data = companion(lan)
        assert data['replay_button_labels'][str(pos)] == name
        assert post(lan, pos) == 202
        wait_for(lambda: mixer.active[2] == 13 + names.index(name))
        assert mixer.active[1] == 1
    previous_takes = list(mixer.writes('ActiveInput'))
    # Same 12 identities exchange sides. SourceTV also changes the team membership.
    sides = [dict(side=side, players=players) for side, players in (
        (2, window.source_tv.roster['teams'][1]['players']), (3, window.source_tv.roster['teams'][0]['players']))]
    window.source_tv.consume(dict(type='snapshot', matchId=MATCH,
        players=[dict(player, team=team['side']) for team in sides for player in team['players']]))
    screen_order = screen_order[6:] + screen_order[:6]
    portraits(window, screen_order, names[0])
    wait_for(lambda: companion(lan)['replay_button_labels']['1'] == screen_order[0])
    assert request(bridge, 'POST', 'guests', headers, json.dumps(guests[::-1]))[0] == 204
    process_events(150)
    assert mixer.writes('ActiveInput') == previous_takes
    assert mixer.writes('BrowserNavigate') == before
    assert set(command['Function'] for command in mixer.commands) <= {'BrowserNavigate', 'SetInputName', 'ActiveInput'}
    assert 'studio-fixture' not in json.dumps(companion(lan))
    # The lineup plays the next match in the same positions before Qt receives the press.
    assert post(lan, 1) == 202
    window.source_tv.consume(dict(type='snapshot', matchId='12345679',
        players=[dict(player, team=team['side']) for team in sides for player in team['players']]))
    portraits(window, screen_order, names[0], match_id='12345679')
    wait_for(lambda: companion(lan)['camera_slots']['1']['match_id'] == '12345679')
    process_events(150)
    assert [c for c in mixer.writes('ActiveInput') if c['Mix'] == '1'] == [
        c for c in previous_takes if c['Mix'] == '1']


def test_replay_refuses_a_guid_pointing_to_program_colour_input(window, fake_api):
    mixer = Mixer(fake_api, 900)
    before = window.cameras.preparation_rows()
    draft = list(before)
    draft[0] = ('501', 'Player 0', PAGES[0])
    window.cameras.save_preparation(before, draft)
    replay = window.camera_panels['replay']
    replay.enabled.setChecked(True)
    replay.port.setValue(mixer.port)
    replay.sources[0].edit.setText(mixer.keys[1])
    replay.guids[0].edit.setText(mixer.keys[5])
    replay.apply.click()
    names = [f'Player {i}' for i in range(12)]
    snapshot(window, names)
    portraits(window, names)
    wait_for(lambda: mixer.names[1] == 'Player 0' and window.camera_roster.slots)
    assert not companion(window.live_stats._export)['camera_slots']['1']['replay_ready']
    with pytest.raises(HTTPError) as invalid:
        post(window.live_stats._export, 1)
    assert invalid.value.code == 409
    assert mixer.names[5] == 'Input 5'
    assert not mixer.writes('ActiveInput')


def test_direct_room_apply_uses_guest_input_numbers_before_match(window, fake_api):
    from test_camera_vdo_bridge import DirectorFrame, request

    mixer = Mixer(fake_api, 400, pairs=18)
    panel = window.vdo_panel
    window.vdo_import.open_url = lambda _: True
    panel.vmix_host.setText('127.0.0.1')
    panel.vmix_port.setValue(mixer.port)
    panel.url.setText('https://vdo.ninja/?director=room&codirector=secret')
    panel.connect_button.click()
    bridge = window.vdo_import.bridge
    frame = DirectorFrame()
    frame.feed(request(bridge)[2].decode())
    headers = {'Content-Type': 'application/json', 'Origin': 'http://' + urlsplit(bridge.url).netloc,
               'X-Room-Tab': frame.attrs['data-tab']}
    guests = [dict(streamID=f'first-{i}', label=f'Guest {i}') for i in range(1, 13)]
    assert request(bridge, 'POST', 'guests', headers, json.dumps(guests))[0] == 204
    wait_for(lambda: panel.table.rowCount() == 12 and panel.apply_vmix.isEnabled())
    assert not window.camera_roster.match_id and not window.cameras.managed
    assert not panel.forward_to_modules.isChecked() and not mixer.commands
    assert [panel.table.cellWidget(i, 1).value() for i in range(12)] == list(range(1, 13))
    panel.table.cellWidget(0, 1).setValue(17)
    panel.table.cellWidget(11, 1).setValue(0)
    panel.apply_vmix.click()
    wait_for(lambda: not window.vdo_publisher.busy and panel.apply_vmix.isEnabled())
    assert set(mixer.names[i] for i in (17, *range(2, 12))) == {g['label'] for g in guests[:11]}
    assert mixer.names[1] == 'Input 1' and mixer.names[12] == 'Input 12'
    pages = {c['Input']: dict(parse_qsl(urlsplit(c['Value']).query))['view']
             for c in mixer.writes('BrowserNavigate')}
    assert pages == {mixer.keys[17 if i == 1 else i]: f'first-{i}' for i in range(1, 12)}
    assert all(c['Function'] in ('BrowserNavigate', 'SetInputName') for c in mixer.commands)
    before = list(mixer.commands)
    panel.apply_vmix.click()
    wait_for(lambda: panel.apply_vmix.isEnabled())
    assert mixer.commands == before
    assert not window.cameras.managed and not window.camera_roster.match_id


def test_direct_takeover_only_pauses_overlapping_modules(window, fake_api, second_api, monkeypatch):
    from PySide6.QtWidgets import QMessageBox
    live, replay = Mixer(fake_api, 800), Mixer(second_api, 1000)
    configure(window, 'live', live)
    configure(window, 'replay', replay)
    wait_for(lambda: live.names[1] == '-' and replay.names[1] == '-')
    panel = window.vdo_panel
    window.vdo_import.open_url = lambda _: True
    panel.url.setText('https://vdo.ninja/?director=room')
    panel.connect_button.click()
    window.vdo_import._accept(window.vdo_import.generation, [dict(label='Guest', streamID='stream')])
    panel.vmix_port.setValue(live.port)
    monkeypatch.setattr(QMessageBox, 'question', lambda *args: QMessageBox.StandardButton.No)
    panel.apply_vmix.click()
    wait_for(lambda: panel.apply_vmix.isEnabled())
    assert window.cameras.config['live']['enabled'] and live.names[1] == '-'
    monkeypatch.setattr(QMessageBox, 'question', lambda *args: QMessageBox.StandardButton.Yes)
    panel.apply_vmix.click()
    wait_for(lambda: panel.apply_vmix.isEnabled() and live.names[1] == 'Guest')
    assert not window.cameras.config['live']['enabled']
    assert window.cameras.config['replay']['enabled']
    assert not live.writes('ActiveInput') and not replay.writes('ActiveInput')


def test_room_cameras_use_hud_targets_when_player_moves(window, fake_api):
    mixer = Mixer(fake_api, 1100, pairs=16)
    panel = window.vdo_panel
    window.vdo_import.open_url = lambda _: True
    panel.url.setText('https://vdo.ninja/?director=event&codirector=test')
    panel.connect_button.click()
    names = ['SURGERY', 'freemok', 'ghoul', 'Dorian', 'SunnyDrive', 'apacycle',
             'Werkom', 'B3AN', 'Jakey', 'mana', 'Jaw.', 'Snaps']
    guests = [dict(streamID=f'cam-{i}', label=name.lower())
              for i, name in enumerate(names) if name != 'Dorian']
    window.vdo_import._accept(window.vdo_import.generation, guests[::-1])
    panel.vmix_host.setText('127.0.0.1')
    panel.vmix_port.setValue(mixer.port)
    panel.assignment_tabs.setCurrentIndex(1)
    assert not panel.apply_positions.isEnabled()
    snapshot(window, names)
    assert 'SourceTV' in panel.positions.hint.text()
    panel.positions.inputs[11].setValue(15)
    panel.apply_positions.click()
    wait_for(lambda: not window.vdo_publisher.busy and mixer.names[3] == 'ghoul')
    before = list(mixer.commands)
    names[2], names[6] = names[6], names[2]
    portraits(window, names)
    assert 'Panorama' in panel.positions.hint.text()
    assert panel.positions.table.item(6, 1).text() == 'ghoul'
    assert mixer.commands == before
    panel.apply_positions.click()
    wait_for(lambda: not window.vdo_publisher.busy and mixer.names[7] == 'ghoul')
    assert mixer.names[3] == 'Werkom' and mixer.names[15] == 'Snaps'
    assert mixer.names[4] == '-' and mixer.names[12] == 'Input 12'
    after = mixer.commands[len(before):]
    assert {c['Input'] for c in after} == {mixer.keys[3], mixer.keys[7]}
    assert {c['Function'] for c in after} == {'BrowserNavigate', 'SetInputName'}
    assert any(c['Input'] == mixer.keys[7] and 'view=cam-2' in c.get('Value', '') for c in after)


def test_room_order_accepts_standalone_panorama_and_expires(window, fake_api):
    positions = window.positions
    names = [f'Player {i}' for i in range(12)]
    positions.source.setCurrentIndex(positions.source.findData('local'))
    positions.connect_source()
    portraits(window, names)
    assert positions.room_camera_order()[0] == tuple(names)
    assert not positions.room_camera_order('another match')[0]
    positions.observe(None)
    assert not positions.room_camera_order()[0]
    positions.source.setCurrentIndex(positions.source.findData('remote'))
    positions.url.setText(f'http://127.0.0.1:{fake_api.server_port}/match')
    slots = {str(i): name for i, name in enumerate(names, 1)}
    remote = dict(hud_slots=slots, matchId=MATCH, panorama_match_id=MATCH)
    fake_api.answer = lambda _: (200, {}, json.dumps(remote).encode())
    positions.connect_source()
    wait_for(lambda: positions.reply is None)
    assert not positions.room_camera_order()[0]  # hud_slots can be an estimate.
    remote['panorama_slots'] = slots.copy()
    positions._poll()
    wait_for(lambda: positions.reply is None)
    assert positions.room_camera_order()[0] == tuple(names)
    remote['panorama_slots']['12'] = names[0]
    positions._poll()
    wait_for(lambda: positions.reply is None)
    assert not positions.room_camera_order()[0]
