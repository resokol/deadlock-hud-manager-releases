from xml.etree import ElementTree as ET

import pytest
from PySide6.QtCore import QCoreApplication, QEvent

from observer_assist.camera_native_monitor import NativeCameraMonitor
from observer_assist.camera_native_sync import NativePair
from observer_assist.camera_preparation import TRANSPARENT_PAGE, camera_page
from observer_assist.camera_vdo_publish import VdoVmixPublisher
from test_camera_vdo_publish import guid, row
from test_vmix_control import app


class Transport:
    def __init__(self):
        self.calls = []
        self.callback = None

    def send(self, url, command, callback):
        assert self.callback is None
        self.calls.append(command)
        self.callback = callback

    def answer(self, data=b'', error=''):
        cb, self.callback = self.callback, None
        cb(error, data)

    def cancel(self):
        self.callback = None


@pytest.fixture
def rig(app):
    publisher = VdoVmixPublisher()
    monitor = NativeCameraMonitor(publisher, publisher)
    transport = Transport()
    monitor._http = transport
    root = ET.fromstring('<vmix><preset>A</preset><inputs /></vmix>')
    pairs, evidence = [], {}
    endpoint = ('127.0.0.1', 8088)
    valid = [True]
    for pos in range(1, 13):
        original, virtual = guid(pos), guid(pos + 12)
        nick = f'Guest {pos}'
        pair = NativePair(original, virtual, nick, False, True)
        pairs.append(pair)
        ET.SubElement(root.find('inputs'), 'input', key=original, number=str(pos), type='Browser', title=nick,
                      virtual='False')
        ET.SubElement(root.find('inputs'), 'input', key=virtual, number=str(pos + 12), type='Browser',
                      title=nick + ' - Virtual', virtual='True')
        page = row(pos)[0]
        evidence[original] = ('live', page) if pos % 2 else ('absent', '')
        publisher.record_page(endpoint, 'A', original, camera_page(page if pos % 2 else ''))

    def start():
        assert monitor.start(endpoint, 'A', pairs, media=lambda: evidence, validate=lambda: valid[0])

    start()
    yield monitor, transport, root, evidence, valid, start
    monitor.stop()
    publisher.deleteLater()
    QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)


def tick(monitor):
    monitor._timer.stop()
    monitor._tick()


def test_live_outage_late_join_and_restart_do_not_reopen_existing_views(rig):
    monitor, http, root, evidence, _, restart = rig
    statuses = []
    monitor.status.connect(statuses.append)
    tick(monitor)
    assert http.calls == []
    evidence[guid(1)] = ('unknown', '')
    tick(monitor)
    assert http.calls == []
    evidence[guid(1)] = ('absent', '')
    evidence[guid(2)] = ('live', row(2)[0])
    for pos, expected in [(1, TRANSPARENT_PAGE), (2, camera_page(row(2)[0]))]:
        tick(monitor)
        assert http.calls[-1] is None
        http.answer(ET.tostring(root))
        assert http.calls[-1] == dict(Function='BrowserNavigate', Input=guid(pos), Value=expected)
        http.answer()
    restart()
    tick(monitor)
    assert len(http.calls) == 4
    evidence[guid(1)] = ('live', row(1)[0])
    tick(monitor)
    http.answer(ET.tostring(root))
    assert http.calls[-1] == dict(Function='BrowserNavigate', Input=guid(1), Value=camera_page(row(1)[0]))
    http.answer()
    assert all('private-' not in s and 'https' not in s for s in statuses)


@pytest.mark.parametrize('change', ['preset', 'title', 'slot', 'type', 'deleted'])
def test_catalog_drift_stops_mutation_and_retries(rig, change, monkeypatch):
    monitor, http, root, evidence, _, _ = rig
    clock = [12.]
    monkeypatch.setattr('observer_assist.camera_native_monitor.monotonic', lambda: clock[0])
    evidence[guid(1)] = ('absent', '')
    tick(monitor)
    valid = ET.tostring(root)
    virtual = root.find(f'.//input[@key="{guid(13)}"]')
    if change == 'preset':
        root.find('preset').text = 'B'
    elif change == 'deleted':
        root.find('inputs').remove(virtual)
    elif change == 'type':
        root.find(f'.//input[@key="{guid(1)}"]').set('type', 'Video')
    else:
        virtual.set('title' if change == 'title' else 'number', '47')
    http.answer(ET.tostring(root))
    tick(monitor)
    assert http.calls == [None]
    clock[0] += 3
    tick(monitor)
    http.answer(valid)
    assert http.calls[-1] == dict(Function='BrowserNavigate', Input=guid(1), Value=TRANSPARENT_PAGE)


def test_old_match_or_lost_ownership_stops_inflight_request(rig):
    monitor, http, root, evidence, valid, restart = rig
    evidence[guid(1)] = ('absent', '')
    tick(monitor)
    valid[0] = False
    http.answer(ET.tostring(root))
    tick(monitor)
    assert http.calls == [None]
    valid[0] = True
    tick(monitor)
    late_callback = http.callback
    monitor.stop()
    restart()
    late_callback('', ET.tostring(root))
    assert http.calls == [None, None]


def test_failed_navigation_does_not_block_other_cameras_or_expose_viewer(rig, monkeypatch):
    monitor, http, root, evidence, _, _ = rig
    clock = [1.]
    monkeypatch.setattr('observer_assist.camera_native_monitor.monotonic', lambda: clock[0])
    evidence[guid(1)] = ('absent', '')
    evidence[guid(2)] = ('live', row(2)[0])
    tick(monitor)
    http.answer(error='request with private URL')
    tick(monitor)
    assert http.calls == [None]
    clock[0] += 1
    tick(monitor)
    http.answer(ET.tostring(root))
    http.answer(error='timeout')
    tick(monitor)
    http.answer(ET.tostring(root))
    assert http.calls[-1]['Input'] == guid(2)
    http.answer()
    assert _serve(monitor, http, root) is None  # Fresh title read after guest 2 navigated.
    assert len(http.calls) == 6
    clock[0] += 1
    tick(monitor)
    http.answer(ET.tostring(root))
    assert http.calls[-1]['Input'] == guid(1)
    http.answer()
    assert _serve(monitor, http, root) is None
    assert len(http.calls) == 9


def test_room_evidence_changes_between_catalog_and_send(rig):
    monitor, http, root, evidence, _, _ = rig
    evidence[guid(1)] = ('absent', '')
    tick(monitor)
    evidence[guid(1)] = ('unknown', '')
    evidence[guid(2)] = ('live', 'https://vdo.ninja/?view=v&director=private')
    http.answer(ET.tostring(root))
    assert http.calls == [None]


def test_ack_after_takeover_does_not_overwrite_new_owner(rig):
    monitor, http, root, evidence, valid, _ = rig
    evidence[guid(1)] = ('absent', '')
    tick(monitor)
    http.answer(ET.tostring(root))
    valid[0] = False
    endpoint = ('127.0.0.1', 8088)
    monitor.publisher.record_page(endpoint, 'A', guid(1), 'new owner page')
    http.answer()
    assert monitor.publisher.page_acknowledged(endpoint, 'A', guid(1), 'new owner page')


def _alpha(root, number, byte):
    entry = root.find(f'.//input[@key="{guid(number)}"]')
    if byte is None:
        entry.attrib.pop('alpha', None)
    else:
        entry.set('alpha', str(byte))


def _serve(monitor, http, root):
    tick(monitor)
    assert http.calls[-1] is None and http.callback
    http.answer(ET.tostring(root))
    if http.callback:
        command = http.calls[-1]
        if command['Function'] == 'SetAlpha':
            root.find(f'.//input[@key="{command["Input"]}"]').set('alpha', command['Value'])
        http.answer()
        return command


def test_native_opacity_preserves_connections_restores_each_guid_and_stays_idle(rig):
    monitor, http, root, evidence, _, restart = rig
    original, virtual = guid(1), guid(13)
    _alpha(root, 1, 183)
    _alpha(root, 13, 122)
    evidence[original] = ('absent', '')
    for target in (original, virtual):
        assert _serve(monitor, http, root) == dict(Function='SetAlpha', Input=target, Value='0')
    before = list(http.calls)
    for _ in range(30):
        tick(monitor)
    assert http.calls == before
    restart()  # Revalidate masks after a handover; input GUIDs and matched viewer are unchanged.
    assert _serve(monitor, http, root) is None
    evidence[original] = ('live', row(1)[0])
    for target, value in [(original, 183), (virtual, 122)]:
        assert _serve(monitor, http, root) == dict(Function='SetAlpha', Input=target, Value=str(value))
    assert all(call is None or call['Function'] == 'SetAlpha' for call in http.calls)
    before = list(http.calls)
    tick(monitor)
    assert http.calls == before


def test_one_missing_or_ambiguous_alpha_uses_shared_page_without_touching_other_input(rig):
    monitor, http, root, evidence, _, _ = rig
    _alpha(root, 1, 182)
    _alpha(root, 13, '1')
    evidence[guid(1)] = ('absent', '')
    assert _serve(monitor, http, root) == dict(Function='BrowserNavigate', Input=guid(1), Value=TRANSPARENT_PAGE)
    evidence[guid(1)] = ('live', row(1)[0])
    assert _serve(monitor, http, root)['Function'] == 'BrowserNavigate'
    assert root.find(f'.//input[@key="{guid(1)}"]').get('alpha') == '182'


def test_short_drop_only_restores_input_already_masked_and_new_url_first(rig):
    monitor, http, root, evidence, _, _ = rig
    _alpha(root, 1, 200)
    _alpha(root, 13, 235)
    evidence[guid(1)] = ('absent', '')
    assert _serve(monitor, http, root) == dict(Function='SetAlpha', Input=guid(1), Value='0')
    evidence[guid(1)] = ('live', row(2)[0])
    assert _serve(monitor, http, root) == dict(Function='BrowserNavigate', Input=guid(1), Value=camera_page(row(2)[0]))
    assert _serve(monitor, http, root) == dict(Function='SetAlpha', Input=guid(1), Value='200')
    assert all(call is None or call['Input'] != guid(13) for call in http.calls)


def test_no_commands_with_unknown_room_or_monitor_off_and_alpha_journal_restarts(rig, tmp_path):
    from PySide6.QtCore import QSettings
    monitor, http, root, evidence, valid, _ = rig
    settings = QSettings(str(tmp_path / 'ops.ini'), QSettings.IniFormat)
    monitor._settings = settings
    _alpha(root, 1, 178)
    _alpha(root, 13, 207)
    originals, pairs, endpoint = monitor.publisher, monitor._pairs, monitor._endpoint
    evidence[guid(1)] = ('absent', '')
    for _ in range(2):
        _serve(monitor, http, root)
    monitor.set_enabled(False)
    before = list(http.calls)
    evidence[guid(1)] = ('live', row(1)[0])
    tick(monitor)
    assert http.calls == before
    monitor.stop()
    replacement = NativeCameraMonitor(originals, settings=settings)
    replacement._http = http
    try:
        valid[0] = False
        assert replacement.start(endpoint, 'A', pairs, media=lambda: evidence, validate=lambda: valid[0])
        tick(replacement)
        assert http.calls == before
        valid[0] = True
        for target, value in [(guid(1), 178), (guid(13), 207)]:
            assert _serve(replacement, http, root) == dict(Function='SetAlpha', Input=target, Value=str(value))
        assert not settings.allKeys()
    finally:
        replacement.stop()


def test_mask_sparse_after_setalpha_or_interrupted_http_still_returns_prior_value(rig):
    monitor, http, root, evidence, _, _ = rig
    _alpha(root, 1, 216)
    _alpha(root, 13, 192)
    evidence[guid(1)] = ('absent', '')
    assert _serve(monitor, http, root)['Input'] == guid(1)
    _alpha(root, 1, None)
    assert _serve(monitor, http, root)['Input'] == guid(13)
    _alpha(root, 13, None)
    evidence[guid(1)] = ('unknown', '')
    before = list(http.calls)
    tick(monitor)
    assert http.calls == before
    evidence[guid(1)] = ('live', row(1)[0])
    for target, value in [(guid(1), 216), (guid(13), 192)]:
        assert _serve(monitor, http, root) == dict(Function='SetAlpha', Input=target, Value=str(value))


def test_prematch_camera_receives_page_on_assigned_pair_before_all_names_known(rig):
    monitor, http, root, evidence, valid, _ = rig
    pairs = [NativePair(p.original_guid, p.virtual_guid, '', True, True) for p in monitor._pairs]
    assert monitor.start(monitor._endpoint, 'A', pairs, media=lambda: evidence, validate=lambda: valid[0],
                         prematch=True)
    evidence[guid(2)] = ('live', row(2)[0])
    assert _serve(monitor, http, root) == dict(Function='BrowserNavigate', Input=guid(2), Value=camera_page(row(2)[0]))


def test_mask_never_reveals_intentionally_zero_opacity_or_private_metadata(rig):
    monitor, http, root, evidence, _, _ = rig
    _alpha(root, 1, 0)
    _alpha(root, 13, 211)
    evidence[guid(1)] = ('absent', '')
    assert _serve(monitor, http, root) == dict(Function='SetAlpha', Input=guid(13), Value='0')
    evidence[guid(1)] = ('live', row(1)[0])
    assert _serve(monitor, http, root) == dict(Function='SetAlpha', Input=guid(13), Value='211')
    assert root.find(f'.//input[@key="{guid(1)}"]').get('alpha') == '0'


def test_failed_mask_may_have_reached_vmix_and_recovery_preempts_old_retry(rig):
    monitor, http, root, evidence, _, _ = rig
    _alpha(root, 1, 147)
    _alpha(root, 13, 243)
    evidence[guid(1)] = ('absent', '')
    tick(monitor)
    http.answer(ET.tostring(root))
    assert http.calls[-1] == dict(Function='SetAlpha', Input=guid(1), Value='0')
    _alpha(root, 1, 0)
    http.answer(error='timeout')
    evidence[guid(1)] = ('live', row(1)[0])
    assert _serve(monitor, http, root) == dict(Function='SetAlpha', Input=guid(1), Value='147')
    assert all(call is None or call['Input'] != guid(13) for call in http.calls)


def test_restart_uses_only_digests_and_detects_changed_page_or_explicit_reload(rig, tmp_path):
    from PySide6.QtCore import QSettings
    monitor, http, root, evidence, valid, _ = rig
    settings = QSettings(str(tmp_path / 'pages.ini'), QSettings.IniFormat)
    publisher = VdoVmixPublisher(settings=settings)
    endpoint, pairs = monitor._endpoint, monitor._pairs
    for n in range(1, 13):
        page = row(n)[0] if n % 2 else ''
        publisher.record_page(endpoint, 'A', guid(n), camera_page(page))
    settings.sync()
    contents = (tmp_path / 'pages.ini').read_text()
    assert 'https:' not in contents and 'private' not in contents
    root.find(f'.//input[@key="{guid(5)}"]').set('currentUrl', 'about:blank')
    restored = VdoVmixPublisher(settings=settings)
    monitor.publisher = restored
    assert monitor.start(endpoint, 'A', pairs, media=lambda: evidence, validate=lambda: valid[0])
    assert _serve(monitor, http, root) == dict(Function='BrowserNavigate', Input=guid(5), Value=camera_page(row(5)[0]))
    assert _serve(monitor, http, root) is None
    count = len(http.calls)
    tick(monitor)
    assert len(http.calls) == count  # XML omits URL for the other eleven; remembered pages stay connected.
    restored.forget_pages(endpoint, {guid(3)})
    assert _serve(monitor, http, root) == dict(Function='BrowserNavigate', Input=guid(3), Value=camera_page(row(3)[0]))
    restored.forget({guid(9)})  # Ownership handed to a second controller before the next launch.
    settings.sync()
    again = VdoVmixPublisher(settings=settings)
    assert not again.page_acknowledged(endpoint, 'A', guid(9), camera_page(row(9)[0]))
    assert again.page_acknowledged(endpoint, 'A', guid(3), camera_page(row(3)[0]))
    assert not again.page_acknowledged(endpoint, 'new preset', guid(3), camera_page(row(3)[0]))


def test_unsaved_preset_does_not_persist_page_acks(rig, tmp_path):
    from PySide6.QtCore import QSettings
    monitor, *_ = rig
    settings = QSettings(str(tmp_path / 'pages.ini'), QSettings.IniFormat)
    publisher = VdoVmixPublisher(settings=settings)
    page = camera_page(row(1)[0])
    publisher.record_page(monitor._endpoint, '', guid(1), page)
    assert publisher.page_acknowledged(monitor._endpoint, '', guid(1), page)
    assert not VdoVmixPublisher(settings=settings).page_acknowledged(monitor._endpoint, '', guid(1), page)


@pytest.mark.parametrize('title_prefix', ['', 'Browser '])
def test_own_page_navigation_repairs_only_its_generated_title_once(rig, title_prefix):
    monitor, http, root, evidence, _, _ = rig
    guid_2 = guid(2)
    viewer = camera_page(row(2)[0])
    evidence[guid_2] = ('live', row(2)[0])
    nick = 'Guest 2'
    assert _serve(monitor, http, root)['Function'] == 'BrowserNavigate'
    entry = root.find(f'.//input[@key="{guid_2}"]')
    entry.set('currentUrl', viewer)
    entry.set('title', title_prefix + viewer)
    assert monitor.allows_pending_title(monitor._endpoint, 'A', guid_2, entry.get('title'))
    assert not monitor.allows_pending_title(monitor._endpoint, 'A', guid(1), entry.get('title'))
    tick(monitor)
    http.answer(ET.tostring(root))
    assert http.calls[-1] == dict(Function='SetInputName', Input=guid_2, Value=nick)
    entry.set('title', nick)
    http.answer()
    assert _serve(monitor, http, root) is None
    assert not monitor.allows_pending_title(monitor._endpoint, 'A', guid_2, viewer)
    assert [cmd['Function'] for cmd in http.calls if cmd] == ['BrowserNavigate', 'SetInputName']


@pytest.mark.parametrize('changed', ['manual', 'other_title', 'copy', 'parent', 'url', 'expired', 'owner', 'preset'])
def test_navigation_repair_rejects_ambiguous_or_stale_ownership(rig, monkeypatch, changed):
    monitor, http, root, evidence, valid, _ = rig
    clock = [4.]
    monkeypatch.setattr('observer_assist.camera_native_monitor.monotonic', lambda: clock[0])
    messages = []
    monitor.status.connect(messages.append)
    viewer = camera_page(row(2)[0])
    evidence[guid(2)] = ('live', row(2)[0])
    assert _serve(monitor, http, root)['Function'] == 'BrowserNavigate'
    entry = root.find(f'.//input[@key="{guid(2)}"]')
    entry.set('title', viewer)
    if changed == 'manual':
        entry.set('title', 'Manual title')
    elif changed in ('other_title', 'copy'):
        target = guid(3) if changed == 'other_title' else guid(14)
        root.find(f'.//input[@key="{target}"]').set('title', 'Manual title')
    elif changed == 'parent':
        root.find(f'.//input[@key="{guid(14)}"]').set('originalKey', guid(1))
    elif changed == 'url':
        entry.set('currentUrl', 'about:blank')
    elif changed == 'expired':
        clock[0] += 7
    elif changed == 'owner':
        valid[0] = False
    elif changed == 'preset':
        root.find('preset').text = 'Other'
    tick(monitor)
    if http.callback:
        http.answer(ET.tostring(root))
    assert [cmd['Function'] for cmd in http.calls if cmd] == ['BrowserNavigate']
    assert all('private' not in msg and 'https:' not in msg for msg in messages)
