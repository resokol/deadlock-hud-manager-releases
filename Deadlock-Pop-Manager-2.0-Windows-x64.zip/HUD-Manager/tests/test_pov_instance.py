from PySide6.QtCore import QSettings

from observer_assist import hud_manager
from observer_assist.pov_instance import PovInstance
from test_vmix_control import app, wait_for


def test_hud_button_launches_camera_workspace(app, tmp_path, monkeypatch):
    launches = []
    monkeypatch.setattr(hud_manager, 'start_pov_manager', lambda: launches.append(True) or True)
    settings = QSettings(str(tmp_path/'hud.ini'), QSettings.Format.IniFormat)
    window = hud_manager.HudManager(settings, hud_directory=tmp_path/'huds')
    try:
        window.open_cameras.click()
        assert launches == [True]
        assert not hasattr(window, 'vdo_publisher')
    finally:
        window.close()


def test_second_pov_launch_activates_first_instance_and_lock_releases(app, tmp_path):
    first = PovInstance(tmp_path)
    second = PovInstance(tmp_path)
    calls = []
    first.activate.connect(lambda: calls.append(True))
    try:
        assert first.acquire()
        assert not second.acquire()
        wait_for(lambda: calls == [True])
    finally:
        first.close()
    assert second.acquire()
    second.close()
