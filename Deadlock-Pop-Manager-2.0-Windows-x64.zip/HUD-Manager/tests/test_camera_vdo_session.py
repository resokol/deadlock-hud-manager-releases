import json
import subprocess
from unittest.mock import Mock
from urllib.parse import parse_qs, urlsplit

from PySide6.QtCore import QSettings

from observer_assist.camera_vdo import VdoImport
from observer_assist.camera_vdo_bridge import VdoRoomBridge, _SCRIPT
from observer_assist.camera_vdo_panel import VdoRoomPanel
from test_camera_vdo_bridge import DirectorFrame, request
from test_vmix_control import app


def test_managed_import_keeps_single_room_during_login_and_cleans_up(app, tmp_path):
    panel = VdoRoomPanel(QSettings(str(tmp_path / 'managed.ini'), QSettings.Format.IniFormat))
    cameras, bridge, session = Mock(), Mock(), Mock()
    bridge.return_value.url = 'http://127.0.0.1:9999/room/'
    controller = VdoImport(panel, cameras, managed=True, bridge_factory=bridge, session_factory=session)
    try:
        assert panel.poll_interval.minimum() == 1 and panel.poll_interval.maximum() == 2
        assert controller.session is None
        panel.url.setText('https://vdo.ninja/?director=Match&codirector=login')
        panel.connect_button.click()
        assert controller.session is session.return_value
        session.assert_called_once()
        assert bridge.call_args.kwargs == dict(scene=False, interval=1)
        assert 'login' not in panel.status.text()
        controller.reopen()
        session.return_value.reveal.assert_called_once()
        accepted = bridge.call_args.args[1]
        accepted([dict(streamID='A', label='Player', video='live')])
        assert controller.fresh
        session.return_value.confirmed.assert_called_once()
        controller.reopen()
        assert controller.fresh and session.call_count == bridge.call_count == 1
        panel.poll_interval.setValue(2)
        bridge.return_value.set_interval.assert_called_once_with(2)
        panel.stop_button.click()
        assert not controller.fresh and controller.session is None
        session.return_value.close.assert_called_once()
        bridge.return_value.close.assert_called_once()
        accepted([dict(streamID='A', label='Late', video='live')])
        assert not controller.known
    finally:
        controller.stop()
        panel.close()


def test_managed_director_params_do_not_leak_into_viewer():
    bridge = VdoRoomBridge('https://vdo.ninja/?director=T&codirector=P', lambda _: None, managed=True, interval=2)
    try:
        _, _, html = request(bridge)
        frame = DirectorFrame()
        frame.feed(html.decode())
        assert frame.attrs['data-managed'] == '1'
        params = parse_qs(urlsplit(frame.attrs['src']).query, keep_blank_values=True)
        assert params['pausepreview'] == [''] and params['noaudio'] == [''] and params['codirector'] == ['P']
        assert 'Оставьте эту вкладку' not in html.decode()
    finally:
        bridge.close()


def test_managed_signaling_loss_holds_last_source_and_requests_only_missing_metadata():
    fixture = r"""
const assert = require('node:assert/strict');
const vm = require('node:vm');
const calls = [], guests = [];
let listen, poll, now = 5000;
const frame = {dataset:{mode:'director', managed:'1', pollSeconds:'2'},src:'https://vdo.ninja/',
    contentWindow:{postMessage:m=>calls.push(m)},addEventListener:()=>{}};
vm.runInNewContext(SCRIPT,{document:{querySelector:q=>q === '#director'? frame : {}},
  window:{addEventListener:(e,f)=>listen=f},performance:{now:()=>now},URL,AbortSignal,
  setTimeout,clearTimeout,setInterval:f=>{poll=f},fetch:async(path,req)=>{
    if(path==='guests')guests.push(JSON.parse(req.body));return {ok:true};}});
const send = data => listen({data,source:frame.contentWindow,origin:'https://vdo.ninja'});
const peers = {self:{localStream:true}};
const slots = {};
for(const id of ['withMedia','unknown','noVideo']){
  peers[id]={UUID:'peer-'+id,localStream:false,director:false,streamID:id,label:id};
  slots[Object.keys(slots).length+1]={streamID:id,label:id};
}
peers.withMedia.videoMuted=false; peers.withMedia.miscellaneous={video_init_width:320,video_init_height:180};
peers.noVideo.videoMuted=true;
async function snapshot(detail=peers,guestList=slots){
  poll();
  const cib=calls.filter(x=>x.getGuestList).at(-1).cib;
  await send({cib,stats:{inbound:{}},guestList,detailedState:detail});
}
(async()=>{
  await snapshot();
  assert.equal(guests.length,0);
  const health = (frames, extra={}) => send({popMonitorSignaling:true,popMonitorMedia:{
    'peer-withMedia':{frames,connected:true,liveTrack:true, ...extra}}});
  await health(2); await snapshot();
  assert.deepEqual(guests[0].map(x=>x.video),['unknown','unknown','absent']);
  assert.deepEqual(calls.filter(x=>'bitrate' in x).map(x=>[x.UUID,x.bitrate]),
                   [['peer-withMedia',35],['peer-unknown',35]]);
  await health(3); await snapshot();
  assert.deepEqual(guests[1].map(x=>x.video),['live','unknown','absent']);
  peers.unknown.videoMuted=true;
  await snapshot();
  assert.deepEqual(calls.filter(x=>'bitrate' in x).map(x=>x.bitrate),[35,35,0,0]);
  now+=9000; await health(3); await snapshot();
  assert.equal(guests.at(-1)[0].video,'unknown'); // no automatic blackout on a still picture
  now+=1000; await health(3); await snapshot();
  now+=1000; await health(3,{liveTrack:false,endedTrack:true}); await snapshot();
  assert.equal(guests.at(-1)[0].video,'absent'); // active sample witnessed receiver track ending
  const beforeDrop=guests.length;
  await send({popMonitorSignaling:false});
  await snapshot({self:{localStream:true}},{});
  assert.equal(guests.length,beforeDrop);
  await send({popMonitorSignaling:true}); now+=8000;
  await snapshot({self:{localStream:true}},{});
  assert.equal(guests.length,beforeDrop);
  await send({popMonitorSignaling:true});
  await snapshot({self:{localStream:true}},{});
  assert.deepEqual(guests.at(-1),[]);
  const before=calls.length; frame.dataset.login='1'; poll(); assert.equal(calls.length,before);
})().catch(e=>{console.error(e);process.exitCode=1});
"""
    subprocess.run(['node', '-e', 'const SCRIPT=' + json.dumps(_SCRIPT) + ';\n' + fixture], check=True, timeout=10)


def test_inline_permission_only_for_current_room_on_explicit_operator_click(app):
    from PySide6.QtCore import QUrl
    from PySide6.QtWidgets import QWidget
    from observer_assist.camera_vdo_session import _PermissionBar

    parent = QWidget()
    bar = _PermissionBar(parent)
    decisions = []
    assert not bar.ask(QUrl('https://example.org'), 'ClipboardReadWrite', decisions.append)
    assert decisions == [False]
    assert bar.ask(QUrl('https://vdo.ninja'), 'ClipboardReadWrite', decisions.append)
    assert decisions == [False]
    bar.allow.click()
    assert bar.pending is None and decisions == [False, True]
    assert not bar.ask(QUrl('https://vdo.ninja'), 'DesktopVideoCapture', decisions.append)
    assert decisions == [False, True, False]
    parent.close()


def test_two_confirmations_for_departures_and_loss_truncates_evidence(app, tmp_path, monkeypatch):
    panel = VdoRoomPanel(QSettings(str(tmp_path / 'grace.ini'), QSettings.Format.IniFormat))
    factory, browser = Mock(), Mock()
    factory.return_value.url = 'http://127.0.0.1:9999/local/'
    browser.return_value.online = True
    now = [100.]
    monkeypatch.setattr('observer_assist.camera_vdo.monotonic', lambda: now[0])
    ctl = VdoImport(panel, Mock(), managed=True, bridge_factory=factory, session_factory=browser)
    try:
        panel.url.setText('https://vdo.ninja/?director=Room')
        panel.connect_button.click()
        accepted = factory.call_args.args[1]
        accepted([dict(streamID='A', label='Camera', video='live')])
        now[0] += 1
        accepted([])
        assert 'A' in ctl.known
        browser.return_value.online = False
        ctl._link_changed(ctl.generation, False)
        now[0] += 1
        accepted([])
        assert 'A' in ctl.known and not ctl.fresh
        browser.return_value.online = True
        accepted([])
        assert 'A' in ctl.known
        now[0] += 0.55
        accepted([])
        assert 'A' in ctl.known and not ctl.fresh  # empty directory while reconnecting is inconclusive
        accepted([dict(streamID='B', label='Other', video='live')])
        assert 'A' in ctl.known
        now[0] += 0.55
        accepted([dict(streamID='B', label='Other', video='live')])
        assert set(ctl.known) == {'B'}
    finally:
        ctl.stop()
        panel.close()
