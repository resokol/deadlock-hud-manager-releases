"""A restarted POV process must restore the GUID reservations before any source write."""

from urllib.parse import parse_qs, urlsplit
from unittest.mock import Mock

from PySide6.QtCore import QCoreApplication, QEvent, QSettings

from observer_assist.camera_preparation import TRANSPARENT_PAGE
from observer_assist.pov_manager import PovManager
from test_pov_manager import NativeMixer
from test_vmix_control import app, fake_api, process_events, wait_for


def test_restarted_operator_preparation_navigates_each_players_original_guid(app, fake_api, tmp_path):
    mixer = NativeMixer(fake_api, 7600)
    ini = str(tmp_path / 'originals.ini')

    def prepare(guests, expected_views):
        window = PovManager(QSettings(ini, QSettings.Format.IniFormat))
        try:
            panel = window.vdo_panel
            window.vdo_import.open_url = lambda _: True
            window.vdo_import.bridge_factory = Mock(return_value=Mock(url='http://127.0.0.1:1/local'))
            panel.url.setText('https://vdo.ninja/?director=testroom')
            panel.vmix_port.setValue(mixer.port)
            panel.connect_button.click()
            window.vdo_import._accept(window.vdo_import.generation, guests)
            wait_for(lambda: window.prematch.ready and all(
                any(c['Input'] == guid and parse_qs(urlsplit(c['Value']).query).get('view') == [view]
                    for c in mixer.writes('BrowserNavigate')) for guid, view in expected_views))
            wait_for(lambda: not window.monitor._busy)
            assert len(panel.prepared_originals) == 12
        finally:
            window.close()
            process_events(15)
            window.deleteLater()
            QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)

    def guest(name):
        return dict(label=name, streamID=f'camera-{name}', video='live')

    prepare([guest('Ada'), guest('Bob')], [(mixer.keys[1], 'camera-Ada'), (mixer.keys[2], 'camera-Bob')])
    # The same preset was physically sorted while the POV manager was closed.
    mixer.order[0], mixer.order[1] = mixer.order[1], mixer.order[0]
    mixer.commands.clear()
    prepare([guest('Aardvark'), guest('Bob')], [(mixer.keys[3], 'camera-Aardvark')])
    pages = {item['Input']: item['Value'] for item in mixer.writes('BrowserNavigate')}
    assert pages[mixer.keys[1]] == TRANSPARENT_PAGE
    assert mixer.keys[2] not in pages and mixer.titles[mixer.keys[2]] == 'Bob'
    assert parse_qs(urlsplit(pages[mixer.keys[3]]).query)['view'] == ['camera-Aardvark']
    assert not any('camera-Bob' in page for page in pages.values())
    assert not mixer.writes('MoveInput') and not mixer.writes('ActiveInput')
