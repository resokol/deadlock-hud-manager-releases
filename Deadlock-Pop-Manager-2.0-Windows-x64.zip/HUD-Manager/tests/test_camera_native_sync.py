from dataclasses import replace
from urllib.parse import parse_qsl, urlsplit
from xml.etree import ElementTree as ET

import pytest

from observer_assist.camera_native_sync import (
    NativePair, NativePairSync, check_native_layout, read_native_catalog,
)
from test_camera_vdo_publish import guid
from test_vmix_control import app, fake_api, wait_for


class NativePreset:
    def __init__(self):
        self.preset = 'Native match'
        self.order = [guid(i) for i in range(1, 26)]
        self.inputs = {}
        self.pos = {}
        self.active = {1: guid(5), 2: guid(13)}
        for i, key in enumerate(self.order, 1):
            attrs = dict(key=key, type='Browser' if i <= 24 else 'Colour', title=f'Input {i}')
            if 13 <= i <= 24:
                attrs.update(virtual='True', originalKey=guid(i-12))
            elif i <= 12:
                attrs['virtual'] = 'False'
            self.inputs[key] = attrs
            self.pos[key] = dict(panX='0', panY='0', zoomX='1', zoomY='1',
                                 cropX1='0', cropY1='0', cropX2='1', cropY2='1')
        self.pairs = tuple(NativePair(guid(i), guid(i+12), f'Игрок {i}', i % 2 == 0) for i in range(1, 13))
        self.writes = []
        self.exchange = False
        self.apply_command = True
        self.after = None
        self.reject = None

    def xml(self):
        root = ET.Element('vmix')
        ET.SubElement(root, 'preset').text = self.preset
        inputs = ET.SubElement(root, 'inputs')
        for i, key in enumerate(self.order, 1):
            entry = ET.SubElement(inputs, 'input', number=str(i), **self.inputs[key])
            ET.SubElement(entry, 'position', self.pos[key])
        ET.SubElement(root, 'active').text = str(self.order.index(self.active[1]) + 1)
        mix = ET.SubElement(root, 'mix', number='2')
        ET.SubElement(mix, 'active').text = str(self.order.index(self.active[2]) + 1)
        outputs = ET.SubElement(root, 'outputs')
        ET.SubElement(outputs, 'output', type='Output', number='2', source='Mix', mix='1')
        return ET.tostring(root, encoding='utf-8')

    def answer(self, path):
        if path == '/api/':
            return 200, {}, self.xml()
        q = dict(parse_qsl(urlsplit(path).query))
        self.writes.append(q)
        f, k, v = q['Function'], q['Input'], q.get('Value')
        if (f, k) == self.reject:
            return 503, {}, b''
        if self.apply_command:
            if f == 'MoveInput':
                a, b = self.order.index(k), int(v) - 1
                if self.exchange:
                    self.order[a], self.order[b] = self.order[b], self.order[a]
                else:
                    self.order.insert(b, self.order.pop(a))
            elif f == 'SetInputName':
                self.inputs[k]['title'] = v
            elif f == 'ActiveInput':
                self.active[int(q['Mix']) + 1] = k
            elif f == 'SetCrop':
                self.pos[k].update(dict(zip(('cropX1','cropY1','cropX2','cropY2'), v.split(','))))
            elif f == 'SetZoom':
                self.pos[k].update(zoomX=v, zoomY=v)
            elif f in ('SetPanX', 'SetPanY'):
                self.pos[k]['pan' + f[-1]] = v
            else:
                raise AssertionError(f)
        if self.after:
            self.after()
        return 200, {}, b''


@pytest.fixture
def native(app, fake_api):
    api = NativePreset()
    fake_api.answer = api.answer
    service = NativePairSync()
    address = ('127.0.0.1', fake_api.server_port)
    yield service, api, address
    service.cancel()


def finished(service):
    wait_for(lambda: not service.busy)


def test_minimal_native_moves_preserve_tally_and_original_transform(native):
    s, api, address = native
    original_active = api.active.copy()
    api.pos[guid(1)].update(panX='.75', zoomX='1.5')
    api.pos[guid(13)].update(panX='.5', cropX1='.1')
    ordered = api.pairs[1:] + api.pairs[:1]
    approved = []
    assert s.start(address, api.preset, ordered, authorize=lambda endpoint, keys: approved.append((endpoint,keys)) or True)
    finished(s)
    assert s.ready and s.receipt.endpoint == address
    assert approved == [(address, set(api.order[:24]))]
    moves = [q for q in api.writes if q['Function'] == 'MoveInput']
    assert moves == [dict(Function='MoveInput', Input=guid(1), Value='12'), dict(Function='MoveInput', Input=guid(13), Value='24')]
    expected = tuple(r.original_guid for r in ordered) + tuple(r.virtual_guid for r in ordered) + (guid(25),)
    assert tuple(api.order) == expected
    assert api.active == original_active and s.mixes == original_active and s.external2 == 'mix=1'
    assert [(q['Function'], q['Input']) for q in api.writes if q['Function'] not in ('MoveInput','SetInputName')] == [
        ('SetPanX', guid(13)), ('SetCrop', guid(13))]
    assert api.pos[guid(1)]['panX'] == '.75' and api.pos[guid(1)]['zoomX'] == '1.5'
    for slot, row in enumerate(ordered, 1):
        assert api.inputs[row.original_guid]['title'] == row.name
        assert api.inputs[row.virtual_guid]['title'] == row.name + ' - Virtual'
        assert s.route(slot) == dict(original_guid=row.original_guid, original_number=slot, virtual_guid=row.virtual_guid,
                                     virtual_number=slot+12, title=row.name, empty=row.empty)
        assert s.receipt.rows[slot-1].guid == row.original_guid and s.numbers[row.virtual_guid] == slot+12
    # Replay can deliberately display the transparent input; sync did not switch any Mix.
    assert ordered[0].empty and not s.take(1, 1)
    assert s.take(1, 2)
    wait_for(lambda: api.active[2] == guid(14))
    wait_for(lambda: s.mixes[2] == guid(14))
    assert api.active[1] == original_active[1]
    api.writes.clear()
    assert s.verify(address, api.preset, ordered)
    finished(s)
    assert s.ready and not api.writes
    assert s.start(address, api.preset, ordered)
    finished(s)
    assert s.ready and not api.writes


def test_no_tenure_by_name_and_no_orphan_ambiguity(native):
    s, api, address = native
    del api.inputs[guid(13)]['originalKey']
    state, parents = read_native_catalog(api.xml())
    with pytest.raises(ValueError, match='подтвердите'):
        check_native_layout(state, parents, api.pairs)
    confirmed = (replace(api.pairs[0], operator_verified=True), *api.pairs[1:])
    check_native_layout(state, parents, confirmed)
    api.inputs[guid(13)]['originalKey'] = guid(2)
    assert s.start(address, api.preset, confirmed)
    finished(s)
    assert not s.ready and not api.writes
    api.inputs[guid(13)]['originalKey'] = guid(1)
    api.inputs[guid(13)]['sourceKey'] = 'no-such-guid'
    assert s.start(address, api.preset, confirmed)
    finished(s)
    assert not s.ready and not api.writes
    del api.inputs[guid(13)]['sourceKey']
    # The presence of an explicitly assigned source on an original means it is not an original browser.
    api.inputs[guid(1)]['originalKey'] = guid(2)
    assert s.start(address, api.preset, confirmed)
    finished(s)
    assert not s.ready and not api.writes
    del api.inputs[guid(1)]['originalKey']
    api.order[23], api.order[24] = api.order[24], api.order[23]
    assert s.start(address, api.preset, confirmed)
    finished(s)
    assert not s.ready and not api.writes
    assert not s.start(address, api.preset, (api.pairs[0],)*12)


def test_partial_retry_validates_ack_and_unchanged_preset(native):
    s, api, address = native
    ordered = api.pairs[::-1]
    api.reject = ('SetInputName', ordered[0].virtual_guid)
    assert s.start(address, api.preset, ordered)
    finished(s)
    assert not s.ready and '503' in s.message and s.receipt is None
    moves = len([q for q in api.writes if q['Function'] == 'MoveInput'])
    assert moves == 44  # 22 forward moves and 22 verified moves back to the original order.
    assert api.order == [guid(i) for i in range(1, 26)]
    assert all(api.inputs[guid(i)]['title'] == f'Input {i}' for i in range(1, 25))
    assert not s.has_recovery(address, api.preset)
    api.writes.clear()
    api.reject = None
    assert s.start(address, api.preset, ordered)
    finished(s)
    assert s.ready and {q['Function'] for q in api.writes} == {'MoveInput', 'SetInputName'}
    api.writes.clear()
    api.preset = 'Replacement'
    assert s.take(2)
    finished(s)
    assert not api.writes and not s.ready and 'Пресет' in s.message


@pytest.mark.parametrize('change, msg', [('no-effect','XML'), ('mix','Mix'), ('geometry','геометрия'), ('preset','Пресет')])
def test_abort_if_controller_ack_is_incorrect_or_other_state_drifts(native, change, msg):
    s, api, address = native
    ordered = api.pairs[1:] + api.pairs[:1]
    if change == 'no-effect':
        api.apply_command = False
    elif change == 'mix':
        api.after = lambda: api.active.update({1: guid(2)})
    elif change == 'geometry':
        api.after = lambda: api.pos[guid(1)].update(panX='1')
    else:
        api.after = lambda: setattr(api, 'preset', 'other')
    assert s.start(address, api.preset, ordered)
    finished(s)
    assert not s.ready and msg in s.message and len(api.writes) == 1


def test_validate_cancels_commands_and_refused_take_never_replays(native):
    s, api, address = native
    current = [True]
    api.after = lambda: current.__setitem__(0, False)
    assert s.start(address, api.preset, api.pairs, validate=lambda: current[0])
    finished(s)
    assert not s.ready and len(api.writes) == 1
    api.after = None
    current[0] = True
    assert s.has_recovery(address, api.preset)
    assert s.recover(address, api.preset, validate=lambda: current[0])
    finished(s)
    assert not s.has_recovery(address, api.preset)
    assert s.start(address, api.preset, api.pairs, validate=lambda: current[0])
    finished(s)
    assert s.ready
    api.writes.clear()
    assert s.take(1, 2, validate=lambda: False)
    finished(s)
    assert not api.writes
    s._monitor()
    wait_for(lambda: s.ready)
    assert not api.writes


def test_swap_semantics_and_no_program_commands_during_sort(native):
    s, api, address = native
    api.exchange = True
    ordered = api.pairs[4:] + api.pairs[:4]
    assert s.start(address, api.preset, ordered)
    finished(s)
    assert s.ready
    assert api.order[:12] == [r.original_guid for r in ordered]
    assert api.order[12:24] == [r.virtual_guid for r in ordered]
    assert set(q['Function'] for q in api.writes) == {'MoveInput','SetInputName'}


def test_http_200_failure_text_and_delayed_readback_never_claim_success(native, fake_api):
    s, api, address = native
    def answer(path):
        if '?' in path:
            return 200, {}, b'Error: function failed; private URL redacted by caller'
        return api.answer(path)
    fake_api.answer = answer
    assert s.start(address, api.preset, api.pairs)
    finished(s)
    assert not s.ready and 'отклонил' in s.message and 'private' not in s.message and not api.writes


def test_restart_restores_only_confirmed_match_read_only_then_explicit_live_take(native, tmp_path):
    from PySide6.QtCore import QSettings
    _, api, address = native
    path = str(tmp_path / 'native.ini')
    service = NativePairSync(settings=QSettings(path, QSettings.Format.IniFormat))
    try:
        assert service.start(address, api.preset, api.pairs, match_id='match-1')
        finished(service)
        assert service.saved_layout(address, api.preset).pairs == api.pairs
        service.cancel()
        restored = NativePairSync(settings=QSettings(path, QSettings.Format.IniFormat))
        try:
            api.writes.clear()
            assert not restored.restore_confirmed(address, api.preset, 'match-2')
            assert not restored.ready and not api.writes
            assert restored.restore_confirmed(address, api.preset, 'match-1')
            finished(restored)
            assert restored.ready and not api.writes and restored.route(3)['original_guid'] == guid(3)
            assert restored.take_live(3, 1)
            wait_for(lambda: api.active[1] == guid(3))
            assert api.writes == [dict(Function='ActiveInput', Input=guid(3), Mix='0')]
            wait_for(lambda: not restored.busy)
            api.writes.clear()
            api.inputs[guid(1)]['title'] = 'Отредактировано в vMix'
            assert restored.restore_confirmed(address, api.preset, 'match-1')
            finished(restored)
            assert not restored.ready and not api.writes
        finally:
            restored.cancel()
    finally:
        service.cancel()


def test_crash_after_written_move_before_ack_recovers_from_write_ahead_record(native, tmp_path):
    from PySide6.QtCore import QSettings
    from threading import Event
    from test_vmix_control import process_events
    _, api, address = native
    path = str(tmp_path / 'recover.ini')
    service = NativePairSync(settings=QSettings(path, QSettings.Format.IniFormat))
    started, allow_response = Event(), Event()
    api.after = lambda: (started.set(), allow_response.wait(3))
    try:
        assert service.start(address, api.preset, api.pairs[1:] + api.pairs[:1], match_id='next-match')
        wait_for(started.is_set)
        service.cancel()
        assert service.has_recovery(address, api.preset)
        assert service.recovery_rows(address, api.preset)[0] == (1, guid(1), 'Input 1')
    finally:
        allow_response.set()
        api.after = None
    process_events(30)
    second = NativePairSync(settings=QSettings(path, QSettings.Format.IniFormat))
    try:
        assert second.has_recovery(address, api.preset) and not second.saved_layout(address, api.preset)
        assert second.recover(address, api.preset, authorize=lambda endpoint, keys: True)
        finished(second)
        assert not second.ready and not second.has_recovery(address, api.preset)
        assert api.order == [guid(i) for i in range(1, 26)]
        assert [c['Function'] for c in api.writes] == ['MoveInput','MoveInput']
    finally:
        second.cancel()


def test_recovery_never_overwrites_external_edits_or_changed_program(native):
    s, api, address = native
    ordered = api.pairs[1:] + api.pairs[:1]
    def outside_edit():
        api.inputs[guid(1)]['title'] = 'Имя оператора'
    api.after = outside_edit
    assert s.start(address, api.preset, ordered)
    finished(s)
    assert len(api.writes) == 1 and s.has_recovery(address, api.preset)
    assert not s.ready and api.inputs[guid(1)]['title'] == 'Имя оператора'
    api.after = None
    assert s.recover(address, api.preset)
    finished(s)
    assert len(api.writes) == 1 and s.has_recovery(address, api.preset)
    api.inputs[guid(1)]['title'] = 'Input 1'
    api.active[1] = guid(4)
    assert s.recover(address, api.preset)
    finished(s)
    assert len(api.writes) == 1 and s.has_recovery(address, api.preset)
    assert s.discard_recovery(address, api.preset) and not s.has_recovery(address, api.preset)


def test_recovery_restores_only_observed_virtual_geometry(native):
    s, api, address = native
    api.pos[guid(13)].update(panX='.35', panY='.25')
    api.reject = ('SetPanY', guid(13))
    baseline_active = dict(api.active)
    assert s.start(address, api.preset, api.pairs)
    finished(s)
    assert not s.ready and not s.has_recovery(address, api.preset)
    assert api.pos[guid(13)]['panX'] == '.35'
    assert api.pos[guid(13)]['panY'] == '.25' and api.active == baseline_active
    assert all(api.inputs[guid(i)]['title'] == f'Input {i}' for i in range(1, 25))


def test_private_titles_are_not_disclosed_in_persisted_recovery_or_recovery_rows(native, tmp_path):
    from PySide6.QtCore import QSettings
    _, api, address = native
    path = tmp_path / 'privacy.ini'
    s = NativePairSync(settings=QSettings(str(path), QSettings.Format.IniFormat))
    api.inputs[guid(1)]['title'] = 'https://room.invalid/?password=private-fixture'
    allowed = [True]
    api.after = lambda: allowed.__setitem__(0, False)
    assert s.start(address, api.preset, api.pairs, validate=lambda: allowed[0])
    finished(s)
    assert s.has_recovery(address, api.preset)
    assert 'private-fixture' not in str(s.recovery_rows(address, api.preset))
    assert b'private-fixture' not in path.read_bytes()
    api.after = None
    # The running process can restore the original title without saving its secret.
    assert s.recover(address, api.preset)
    finished(s)
    assert api.inputs[guid(1)]['title'].endswith('private-fixture') and not s.has_recovery(address, api.preset)
    s.cancel()


def test_repeat_unchanged_sync_does_not_repeat_hidden_geometry_setters(native):
    s, api, address = native
    api.pos[guid(13)].pop('cropX1')
    # This vMix dialect accepts the command, yet never publishes that field.
    api.after = lambda: api.pos[guid(13)].pop('cropX1', None)
    assert s.start(address, api.preset, api.pairs)
    finished(s)
    assert s.ready and any(q['Function'] == 'SetCrop' for q in api.writes)
    api.writes.clear()
    assert s.start(address, api.preset, api.pairs)
    finished(s)
    assert s.ready and api.writes == []


def test_later_failed_match_keeps_last_confirmed_layout_and_restores_it(native, tmp_path):
    from PySide6.QtCore import QSettings
    _, api, address = native
    s = NativePairSync(settings=QSettings(str(tmp_path/'match.ini'), QSettings.Format.IniFormat))
    try:
        assert s.start(address, api.preset, api.pairs, match_id='old')
        finished(s)
        new = tuple(replace(row, name='Новый ' + row.name) for row in api.pairs[::-1])
        api.reject = ('SetInputName', new[1].original_guid)
        assert s.start(address, api.preset, new, match_id='new')
        finished(s)
        saved = s.saved_layout(address, api.preset)
        assert saved.match_id == 'old' and saved.pairs == api.pairs and not s.ready
        assert not s.has_recovery(address, api.preset)
        api.writes.clear()
        assert s.restore_confirmed(address, api.preset, 'old')
        finished(s)
        assert s.ready and not api.writes
    finally:
        s.cancel()


def test_hidden_geometry_retains_manual_recovery_until_operator_ack(native):
    s, api, address = native
    api.pos[guid(13)].pop('cropX1')
    api.pos[guid(14)]['panY'] = '.12'
    api.reject = ('SetPanY', guid(14))
    assert s.start(address, api.preset, api.pairs)
    finished(s)
    assert not s.ready and s.has_recovery(address, api.preset) and 'скрытые' in s.message
    assert all(api.inputs[guid(i)]['title'] == f'Input {i}' for i in range(1, 25))
    assert not any(cmd['Function'] == 'ActiveInput' for cmd in api.writes)
    assert s.discard_recovery(address, api.preset)


def test_confirmed_restore_after_temporary_offline_is_read_only(native, fake_api):
    s, api, address = native
    assert s.start(address, api.preset, api.pairs, match_id='saved')
    finished(s)
    s.cancel()
    api.writes.clear()
    fake_api.answer = lambda _: (503,{},b'')
    assert s.restore_confirmed(address, api.preset, 'saved')
    finished(s)
    assert not s.ready
    fake_api.answer = api.answer
    s._monitor()
    wait_for(lambda: s.ready)
    assert api.writes == []


@pytest.mark.parametrize('conflict', ['other_original', 'copy', 'geometry', 'slot', 'expired', 'manual'])
def test_pending_navigation_title_never_hides_other_changes(native, conflict):
    s, api, endpoint = native
    assert s.start(endpoint, api.preset, api.pairs)
    finished(s)
    title = 'https://vdo.ninja/?view=stream-1&password=secret-fixture'
    s.pending_title = lambda address, preset, key, value: (
        (address, preset, key, value) == (endpoint, api.preset, guid(1), title) and conflict != 'expired')
    api.inputs[guid(1)]['title'] = title
    if conflict == 'other_original':
        api.inputs[guid(2)]['title'] = 'Edited'
    if conflict == 'copy':
        api.inputs[guid(13)]['title'] = 'Edited copy'
    if conflict == 'slot':
        api.order[21], api.order[22] = api.order[22], api.order[21]
    if conflict == 'geometry':
        api.pos[guid(15)]['panX'] = '.4'
    if conflict == 'manual':
        api.inputs[guid(1)]['title'] = 'Human operator'
    api.writes.clear()
    s._monitor()
    wait_for(lambda: not s.ready)
    assert s.route(1) is None and not api.writes and 'secret-fixture' not in s.message


def test_pending_navigation_suspends_routes_without_losing_repair_authority(native):
    s, api, endpoint = native
    assert s.start(endpoint, api.preset, api.pairs)
    finished(s)
    transient = 'https://vdo.ninja/?view=private-fixture'
    s.pending_title = lambda addr, preset, key, title: (addr, preset, key, title) == (endpoint, api.preset, guid(1), transient)
    api.inputs[guid(1)]['title'] = transient
    api.writes.clear()
    assert s.take(1)
    finished(s)
    assert s.ready and s.route(1) is None and not s.take(2) and not s.take_live(1)
    assert not api.writes and 'private-fixture' not in s.message
    api.inputs[guid(1)]['title'] = api.pairs[0].name
    s._monitor()
    wait_for(lambda: s.route(1) is not None)
    assert not api.writes
