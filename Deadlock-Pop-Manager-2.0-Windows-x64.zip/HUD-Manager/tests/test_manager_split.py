from PySide6.QtCore import QSettings

from observer_assist.hud_manager import HudManager
from observer_assist.manager_settings import pov_settings
from test_vmix_control import app, fake_api


def test_hud_launch_does_not_restore_camera_writers(app, tmp_path):
    settings = QSettings(str(tmp_path / 'hud.ini'), QSettings.Format.IniFormat)
    settings.setValue('cameraVdoDirectorUrl', 'https://vdo.ninja/?director=old')
    manager = HudManager(settings, hud_directory=tmp_path / 'huds')
    try:
        titles = [manager.compact_navigation.itemText(i) for i in range(manager.compact_navigation.count())]
        assert titles == ['Match', 'Позиции Panorama', 'Статистика', 'HUD', 'Модули']
        assert manager.live_stats.copy_program.isHidden()
        assert not any(hasattr(manager, key) for key in ('pov', 'cameras', 'vdo_import', 'vdo_publisher'))
    finally:
        manager.close()


def test_pov_imports_camera_settings_once_and_preserves_hud_configuration(tmp_path):
    hud = QSettings(str(tmp_path / 'hud.ini'), QSettings.Format.IniFormat)
    pov = QSettings(str(tmp_path / 'pov.ini'), QSettings.Format.IniFormat)
    hud.setValue('cameraVdoPositionInputs', '{"11":12}')
    hud.setValue('cameraVdoInputNumbers/room', '{"guest":9}')
    hud.setValue('positionsUrl', 'http://127.0.0.1:53558/api/v1/match')
    hud.setValue('statsExportToken', 'hud-test-key')
    hud.setValue('panoramaEnabled', True)
    pov_settings(hud, pov)
    assert pov.value('cameraVdoInputNumbers/room') == '{"guest":9}'
    assert pov.value('cameraVdoPositionInputs') == '{"11":12}'
    assert pov.value('positionsUrl') == hud.value('positionsUrl')
    assert not pov.contains('statsExportToken') and not pov.contains('panoramaEnabled')
    pov.setValue('cameraVdoPositionInputs', '{}')
    pov_settings(hud, pov)
    assert pov.value('cameraVdoPositionInputs') == '{}'
    assert hud.value('cameraVdoPositionInputs') == '{"11":12}'


def test_remote_hud_supplies_positions_and_named_audio_only_replay_is_selectable(app, tmp_path, monkeypatch, fake_api):
    from functools import partial

    from observer_assist import hud_manager, live_stats_panel
    from observer_assist.match_stats import StatsLanServer
    from observer_assist.panorama_hud_mode import PanoramaTelemetryServer
    from observer_assist.pov_manager import PovManager
    from test_camera_workflow import snapshot, MATCH
    from test_pov_manager import NativeMixer
    from test_vmix_control import wait_for

    monkeypatch.setattr(hud_manager, 'PanoramaTelemetryServer', partial(PanoramaTelemetryServer, port=0))
    monkeypatch.setattr(live_stats_panel, 'StatsLanServer', partial(StatsLanServer, port=0))
    manager = HudManager(QSettings(str(tmp_path / 'observer.ini'), QSettings.Format.IniFormat), tmp_path / 'huds')
    pov = PovManager(QSettings(str(tmp_path / 'pov.ini'), QSettings.Format.IniFormat))
    try:
        stats = manager.live_stats
        stats.network.addItem('Loopback', '127.0.0.1/8')
        stats.network.setCurrentIndex(stats.network.count()-1)
        stats.share.setChecked(True)
        names = [f'Guest{i}' for i in range(12)]
        names[10] = 'obikym'
        snapshot(manager, names)
        teams = [dict(side=side, players=[dict(name=names[i], portraitX=20*i)
                      for i in range(start, start+6)]) for side, start in ((2, 0), (3, 6))]
        manager._telemetry.publish(dict(teams=teams, selected={'player': 'obikym'}), match_id=MATCH)
        pov.mode.setCurrentIndex(pov.mode.findData('remote'))
        pov.remote_url.setText(stats._export.url)
        pov._connect_remote()
        wait_for(lambda: pov.names == tuple(names))
        assert pov.observed == 11
        pov.vdo_import.open_url = lambda _: True
        panel = pov.vdo_panel
        panel.url.setText('https://vdo.ninja/?director=fixture')
        panel.connect_button.click()
        guests = [dict(streamID=f'camera-{i}', label=name, video='absent' if i == 10 else 'live')
                  for i, name in enumerate(names)]
        pov.vdo_import._accept(pov.vdo_import.generation, guests)
        mixer = NativeMixer(fake_api, 4000, lineage=False)
        panel.vmix_host.setText('127.0.0.1')
        panel.vmix_port.setValue(mixer.port)
        wait_for(lambda: all(combo.count() >= 13 for combo in pov.bindings.choices))
        assert not pov.bindings.confirmed
        assert not pov.sync_button.isEnabled()
        for i, combo in enumerate(pov.bindings.choices):
            combo.setCurrentIndex(combo.findData(mixer.keys[i + 13]))
        pov.bindings.accept.click()
        wait_for(lambda: pov.prematch.ready and pov.sync_button.isEnabled())
        pov.sync_button.click()
        wait_for(lambda: pov.native.ready)
        route = pov.native.route(11)
        assert route['virtual_number'] == 23 and route['original_number'] == 11
        assert mixer.titles[route['original_guid']] == 'obikym'
        assert mixer.titles[route['virtual_guid']] == 'obikym - Virtual'
        assert pov.companion.payload['replay_button_labels']['11'] == 'obikym'
        assert pov.companion.payload['camera_slots']['11']['replay_ready']
        wait_for(lambda: any(c['Input'] == route['original_guid'] and c['Value'] == 'about:blank'
                   for c in mixer.writes('BrowserNavigate')))
        assert not mixer.writes('ActiveInput')
    finally:
        pov.close()
        manager.close()
