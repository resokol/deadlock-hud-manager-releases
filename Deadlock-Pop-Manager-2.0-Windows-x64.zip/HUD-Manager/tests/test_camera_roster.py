import json
import os

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

import pytest
from PySide6.QtCore import QSettings
from PySide6.QtNetwork import QNetworkReply, QNetworkRequest
from PySide6.QtWidgets import QApplication

from observer_assist.camera_roster import CameraRoster
from observer_assist.hud_positions import PanoramaPositions
from observer_assist.source_tv_panel import SourceTvPanel


@pytest.fixture
def app():
    return QApplication.instance() or QApplication([])


@pytest.fixture
def settings(tmp_path):
    return QSettings(str(tmp_path / 'roster.ini'), QSettings.Format.IniFormat)


def teams():
    return [dict(side=side, players=[
        dict(name=f'p{i}', accountId=i, heroId=i + 1, assignedLane=(1, 4, 6)[j // 2],
             portraitX=i * 30, hero=f'Hero {i}') for j, i in enumerate(range(start, start + 6))
    ]) for side, start in ((2, 1), (3, 7))]


def test_actual_portraits_applied_only_for_matching_match(app, settings):
    positions = PanoramaPositions(settings)
    roster = dict(matchId='100', teams=teams())
    positions.set_match(roster)
    sample = dict(teams=teams(), selected={'player': 'p12'})
    positions.observe(sample, '200')
    assert not positions.camera_confirmed
    positions.observe(sample, '100')
    assert positions.camera_slots['12'] == 'p12' and positions.camera_observed == 12
    assert positions.camera_heroes['p1'] == 'Hero 1'
    positions.set_match(dict(roster, matchId='200'))
    assert not positions.camera_slots and positions.camera_observed is None
    positions.close()


def test_lan_ignores_derived_slots_and_other_matches(app, settings):
    positions = PanoramaPositions(settings)
    positions.mode = 'remote'
    positions.set_match(dict(matchId='100', teams=teams()))
    slots = {str(i): f'p{i}' for i in range(1, 13)}
    class Reply:
        def __init__(self, fields):
            self.fields = fields
        def deleteLater(self):
            pass
        def attribute(self, key):
            assert key == QNetworkRequest.Attribute.HttpStatusCodeAttribute
            return 200
        def error(self):
            return QNetworkReply.NetworkError.NoError
        def readAll(self):
            return json.dumps(self.fields).encode()

    data = dict(hud_slots=slots, hud_observed_slot=4, matchId='100')
    for proof, expected in (({}, False), ({'panorama_match_id': '200', 'panorama_slots': slots}, False),
                             ({'panorama_match_id': '100', 'panorama_slots': slots, 'panorama_observed_slot': 2}, True),
                             ({}, False)):
        r = Reply(dict(data, **proof))
        positions.reply = r
        positions._received(r)
        assert positions.camera_confirmed == expected
        assert positions.camera_observed == (2 if expected else None)


def test_match_scoped_order_uses_raw_observer_and_stable_account_links(app, settings):
    widget = CameraRoster(settings)
    roster = dict(teams=teams(), matchId='100')
    slots = {str(i): f'p{i}' for i in range(1, 13)}
    slots['1'], slots['2'] = slots['2'], slots['1']
    widget.update_match(roster, slots, 2, False)
    assert not widget.slots and widget.observed is None
    widget.update_match(roster, slots, 2, True)
    assert widget.slots[1] == '2' and widget.observed == '1'
    assert 'отличается' in widget.status.text()
    assert widget.table.item(11, 0).text() == '='
    assert widget.set_page('2', 'https://vdo.ninja/?view=secret')
    assert not widget.set_page('2', 'file:///wrong')
    widget.table.selectRow(0)
    widget.down.click()
    widget.apply.click()
    assert widget.slots[1] == '1' and widget.observed == '1'
    widget.update_match(dict(roster, matchId='200'), {}, None, False)
    assert not widget.slots and widget.observed is None
    restored = CameraRoster(settings)
    restored.update_match(roster, {}, None, False)
    assert restored.slots[1] == '1' and restored.pages['2'].endswith('secret')
    restored.reset.click()
    assert not restored.slots
    assert restored.table.item(0, 1).text() == 'p2'
    restored.update_match(None, {}, None, False)
    assert not restored.slots and not restored.players


def test_duplicate_names_require_manual_identity_duplicate_accounts_disable_manual(app, settings):
    roster = dict(teams=teams(), matchId='100')
    roster['teams'][0]['players'][1]['name'] = 'P1'
    widget = CameraRoster(settings)
    slots = {str(i): p['name'] for i, p in enumerate(
        [p for team in roster['teams'] for p in team['players']], 1)}
    widget.update_match(roster, slots, 1, True)
    assert not widget.slots and widget.observed is None
    widget.apply.click()
    assert widget.slots[1] == '1' and widget.slots[2] == '2'
    roster['teams'][0]['players'][1]['accountId'] = 1
    widget.update_match(roster, slots, 1, True)
    assert not widget.slots and '1' not in widget.players and not widget.apply.isEnabled()


def test_source_reader_keeps_identity_private(app):
    panel = SourceTvPanel()
    panel.consume(dict(type='snapshot', matchId='100', players=[
        dict(name='p1', team=2, accountId=45, heroId=1)]))
    assert panel.roster['teams'][0]['players'][0]['accountId'] == 45
    assert panel.roster['teams'][0]['players'][0]['heroId'] == 1
    public = panel.public_roster['teams'][0]['players'][0]
    assert 'accountId' not in public and 'heroId' not in public
    panel.close()


def test_reconnect_backs_off_switch_cancels_and_stop_disarms(app, monkeypatch):
    from PySide6.QtCore import QProcess
    panel = SourceTvPanel()
    started = []
    monkeypatch.setattr(panel, '_start', started.append)
    panel.url.setText('111')
    panel.connect_button.click()
    for seconds in (2, 4, 8, 16, 32, 60, 60):
        panel.consume({'type': 'error', 'message': 'SourceTV: HTTP 405 (sync).'})
        panel._finished(1, QProcess.ExitStatus.NormalExit)
        assert panel.retry_timer.isActive() and panel.retry_timer.interval() == 1000 * seconds
        assert '405' in panel.status.text()
        panel.retry_timer.stop()
        panel._retry()
        assert started[-1] == '111'
    panel.url.setText('222')
    panel.connect_button.click()
    assert started[-1] == '222' and not panel.retry_timer.isActive()
    panel._finished(1, QProcess.ExitStatus.CrashExit)
    assert panel.retry_timer.interval() == 2000 and panel.stop_button.isEnabled()
    panel.stop_button.click()
    assert not panel.retry_timer.isActive() and not panel.stop_button.isEnabled()
    started.clear()
    panel._retry()
    assert not started


def test_completed_broadcast_stays_stopped_and_wrong_match_never_becomes_live(app, monkeypatch):
    from PySide6.QtCore import QProcess
    panel = SourceTvPanel()
    panel._requested_source = panel._match_id = '111'
    monkeypatch.setattr(panel.process, 'kill', lambda: None)
    panel.consume(dict(type='snapshot', matchId='222', players=[dict(name='x', team=2)]))
    assert panel.roster is None and 'отличается' in panel.status.text()
    panel._finished(1, QProcess.ExitStatus.CrashExit)
    assert panel.retry_timer.isActive()
    panel.retry_timer.stop()
    panel.consume({'type': 'end'})
    panel._finished(0, QProcess.ExitStatus.NormalExit)
    assert not panel.retry_timer.isActive()


def test_roster_empty_and_compact_layout(app, settings):
    widget = CameraRoster(settings)
    widget.show()
    app.processEvents()
    assert widget.table.isHidden() and widget.actions.isHidden()
    assert 'Подключить' in widget.status.text()
    widget.resize(960, 600)
    widget.update_match(dict(matchId='123', teams=teams()),
                        {str(i): f'p{i}' for i in range(1, 13)}, 12, True)
    widget.resize(350, 650)
    app.processEvents()
    assert widget.width() == 350
    assert widget.focus_player.text().endswith('p12')
    assert widget.table.horizontalScrollBar().maximum() > 0
    for button in (widget.up, widget.down, widget.apply, widget.reset, widget.edit):
        assert button.isVisible() and button.geometry().right() < widget.actions.width()
    widget.close()


def test_url_editor_validates_before_saving_and_explains_live_reconnect(app, settings):
    from PySide6.QtCore import QTimer
    from PySide6.QtWidgets import QDialogButtonBox, QLabel, QLineEdit
    widget = CameraRoster(settings)
    widget.update_match(dict(matchId='234', teams=teams()), {}, None, False)
    widget.table.selectRow(0)
    observed = []

    def edit():
        dialog = app.activeModalWidget()
        observed.extend(label.text() for label in dialog.findChildren(QLabel) if 'переподключится' in label.text())
        field = dialog.findChild(QLineEdit)
        save = dialog.findChild(QDialogButtonBox).button(QDialogButtonBox.StandardButton.Save)
        field.setText('invalid')
        save.click()
        observed.append(dialog.isVisible())
        field.setText('https://vdo.ninja/?view=private')
        save.click()

    QTimer.singleShot(0, edit)
    widget.edit.click()
    assert len(observed) == 2 and observed[1] is True
    assert widget.pages['1'] == 'https://vdo.ninja/?view=private'
    assert widget.table.item(0, 7).text() == 'Задан'


def test_right_to_left_pov_positions_keep_observer_identity_and_saved_orders(app, settings):
    roster = dict(teams=teams(), matchId='100')
    slots = {str(i): f'p{i}' for i in range(1, 13)}
    settings.setValue('cameraManualOrders', json.dumps({'100': [str(i) for i in range(1, 13)]}))
    panel = CameraRoster(settings, right_to_left=True)
    panel.update_match(roster, slots, 12, True)
    assert panel.slots[1] == '12' and panel.slots[12] == '1'
    assert panel.observed == '12' and panel.manual_names()[0] == 'p12'
    assert panel.table.item(0, 0).text() == '='
    panel.table.selectRow(0)
    panel.down.click()
    panel.apply.click()
    assert panel.slots[1] == '11' and panel.slots[2] == '12'
    assert panel.observed == '12'
    reopened = CameraRoster(settings)
    reopened.update_match(roster, {}, None, False)
    assert reopened.slots[12] == '11' and reopened.slots[11] == '12'
    assert json.loads(settings.value('cameraConfirmedOrders'))['100'][0] == '1'
