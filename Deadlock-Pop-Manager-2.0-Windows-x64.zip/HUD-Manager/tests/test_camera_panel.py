import os

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

import pytest
from PySide6.QtWidgets import QApplication, QPushButton

from observer_assist.camera_panel import CameraPanel


GUID = 'ce88e923-43b6-4740-ab47-e1a497e20c47'
COPY = '8ebd8031-4f13-48b2-b448-8080231b78c0'


@pytest.fixture(scope='module')
def app():
    return QApplication.instance() or QApplication([])


def test_discover_before_enable_and_choose_guid_despite_renumbering(app):
    panel = CameraPanel('replay')
    discoveries, saved = [], []
    panel.discover_requested.connect(lambda *args: discoveries.append(args))
    panel.apply_requested.connect(saved.append)
    panel.host.setText('192.168.1.5')
    panel.discover.click()
    assert discoveries == [('192.168.1.5', 8088)]
    assert not panel.enabled.isChecked()
    inputs = {COPY: {'number': '18', 'title': 'Alice', 'type': 'Virtual'},
              GUID: {'number': '7', 'title': 'Alice', 'type': 'Browser'}}
    panel.render(inputs, {7: 'Alice'}, set(), '', 'Подключено')
    for field, guid in [(panel.guids[6], COPY), (panel.sources[6], GUID)]:
        field.menu.aboutToShow.emit()
        next(action for action in field.menu.actions() if action.data() == guid).trigger()
        assert field.edit.text() == guid
    panel.sources[4].edit.setText('incomplete-draft')
    panel.render({COPY: dict(inputs[COPY], number='42')}, {}, set(), '', 'Отключено')
    assert panel.sources[4].edit.text() == 'incomplete-draft'
    panel.sources[4].edit.clear()
    panel.apply.click()
    assert saved[0]['guids'] == [''] * 6 + [COPY] + [''] * 5
    assert saved[0]['sources'] == [''] * 6 + [GUID] + [''] * 5
    assert saved[0]['host'] == '192.168.1.5'
    assert not saved[0]['enabled']


def test_live_settings_roundtrip_and_layer_target_required(app):
    panel = CameraPanel('live')
    saved = []
    panel.apply_requested.connect(saved.append)
    config = dict(enabled=True, host='127.0.0.1', port=1234, mix=3, mode='layer', layer=4, follow=True,
                  target=COPY, guids=[GUID] + [''] * 11)
    panel.set_config(config)
    panel.apply.click()
    assert saved == [config]
    panel.target.edit.clear()
    panel.apply.click()
    assert saved == [config]
    assert not panel.validation.isHidden()
    panel.mode.setCurrentIndex(0)
    panel.apply.click()
    assert saved[-1]['mode'] == 'program'


@pytest.mark.parametrize('host', ['8.8.8.8', '::1', 'example.com', '0.0.0.0', '224.0.0.1', ''])
def test_rejects_non_lan_ipv4_for_discovery_and_apply(app, host):
    panel = CameraPanel('live')
    calls = []
    panel.discover_requested.connect(lambda *args: calls.append(args))
    panel.apply_requested.connect(calls.append)
    panel.host.setText(host)
    panel.discover.click()
    panel.apply.click()
    assert not calls
    assert not panel.discovery_error.isHidden()
    assert not panel.validation.isHidden()


def test_manual_controls_reflect_acknowledged_state_and_do_not_share_commands(app):
    live, replay = CameraPanel('live'), CameraPanel('replay')
    live_takes, replay_takes, links = [], [], []
    live.take_requested.connect(live_takes.append)
    replay.take_requested.connect(replay_takes.append)
    replay.companion_requested.connect(lambda: links.append(True))
    slots = {2: 'Cat&Dog', 3: 'Fox'}
    live.render({}, slots, {2}, 'Fox', 'Live online')
    replay.render({}, slots, {3}, '', 'Replay online')
    assert live.buttons[1].accessibleName() == '2 · Cat&Dog'
    for panel in (live, replay):
        panel.buttons[1].click()
        panel.buttons[2].click()
    assert live_takes == [2]
    assert replay_takes == [3]
    assert live.active.text().endswith('Fox')
    assert replay.active.text() == 'Нет данных о камере'
    next(b for b in replay.findChildren(QPushButton) if 'Companion' in b.text()).click()
    assert links == [True]


def test_number_typed_as_guid_cannot_be_saved(app):
    panel = CameraPanel('replay')
    saved = []
    panel.apply_requested.connect(saved.append)
    panel.guids[0].edit.setText('42')
    panel.apply.click()
    assert not saved
    assert 'GUID' in panel.validation.text()


@pytest.mark.parametrize('role', ['live', 'replay'])
def test_repair_is_an_explicit_request(app, role):
    panel = CameraPanel(role)
    requests = []
    panel.repair_requested.connect(lambda: requests.append(True))
    panel.render({}, {}, set(), '', 'Подключено')
    assert not requests
    panel.repair.click()
    assert requests == [True]


def test_operator_view_fits_and_settings_preserve_drafts(app):
    panel = CameraPanel('replay')
    panel.resize(380, 650)
    panel.show()
    app.processEvents()
    assert panel.operation.isVisible()
    assert not panel.host.isVisible()
    assert not panel.guids[0].isVisible()
    assert panel.buttons[1].y() == panel.buttons[0].y() < panel.buttons[2].y()
    assert ''.join(tile.keycap.text() for tile in panel.buttons) == '1234567890-='
    panel.tabs.setCurrentIndex(1)
    assert panel.host.isVisible()
    assert panel.sources[11].isVisible()
    panel.guids[0].edit.setText('draft')
    panel.tabs.setCurrentIndex(0)
    panel.resize(1000, 650)
    app.processEvents()
    assert panel.buttons[5].y() == panel.buttons[0].y() < panel.buttons[6].y()
    panel.tabs.setCurrentIndex(1)
    assert panel.guids[0].edit.text() == 'draft'
    panel.close()


def test_fill_standard_pairs_only_changes_verified_empty_draft_fields(app):
    from uuid import UUID
    panel = CameraPanel('replay')
    keys = {i: str(UUID(int=i)) for i in range(1, 25)}
    inputs = {key: dict(number=i, type='Browser', virtual=i > 12) for i, key in keys.items()}
    saved = []
    panel.apply_requested.connect(saved.append)
    panel.render(inputs, {}, set(), '', 'Подключено', catalog_endpoint=('127.0.0.1', 8088))
    panel.host.setText('192.168.5.7')
    panel.fill_pairs.click()
    assert not panel.guids[0].edit.text()
    panel.host.setText('127.0.0.1')
    inputs[keys[24]]['virtual'] = False
    panel.fill_pairs.click()
    assert not panel.sources[0].edit.text() and '24' in panel.validation.text()
    inputs[keys[24]]['virtual'] = True
    panel.guids[3].edit.setText(COPY)
    panel.fill_pairs.click()
    assert not saved and panel.guids[3].value() == COPY
    for i in range(12):
        assert panel.sources[i].value() == keys[i + 1]
        if i != 3:
            assert panel.guids[i].value() == keys[i + 13]
    panel.close()
