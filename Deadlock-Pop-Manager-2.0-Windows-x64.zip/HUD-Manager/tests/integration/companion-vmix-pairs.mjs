import assert from 'node:assert/strict'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
const dist = process.argv[2]
if (!dist) throw Error('Pass path to compiled dist of companion-module-studiocoast-vmix v5.0.5')
const { inputValues } = await import(pathToFileURL(resolve(dist, 'variables/inputVariables.js')))
const { getActions } = await import(pathToFileURL(resolve(dist, 'actions/actions.js')))
const feeds = new Map([[1, 'program A'], [2, 'replay B']])
const commands = []
const instance = {
  config: {variablesShowInputNumbers:true}, data: {mix:[],inputs:[]},
  routingData: {mix: 1}, tcp: {sendCommand(s) {
    commands.push(s)
    const [proto, func, params] = s.split(' ')
    assert.equal(proto,'FUNCTION')
    assert.equal(func,'ActiveInput')
    const q = new URLSearchParams(params)
    feeds.set(1+Number(q.get('mix')), instance.data.inputs[Number(q.get('input')) - 1].key)
  }}
}
let order = Array.from({length:12},(_,i)=>i+1)
const update = () => {
  instance.data.inputs = [false,true].flatMap(v=>order.map((n,i)=>({
    number:i+1+(v?12:0), key:(v?'virtual':'original')+n, type:v?'Virtual':'Browser',
    shortTitle:'Player '+n+(v?' - Virtual':''), title:'Player '+n+(v?' - Virtual':''), loop:false
  })))
}
update()
const action = getActions(instance).programCut
for (let round=0;round<30;round++){
  order.push(order.shift());update()
  const vars = await inputValues(instance)
  for (let pos=1;pos<=12;pos++){
    const cam=order[pos-1]
    assert.equal(vars['input_'+pos+'_name'],'Player '+cam)
    assert.equal(vars['input_'+(pos+12)+'_name'],'Player '+cam+' - Virtual')
    await action.callback({options:{input:String(pos+12),mix:2}})
    assert.equal(feeds.get(2),'virtual'+cam)
    assert.equal(feeds.get(1),'program A')
  }
}
console.log('Module 5.0.5: verified 360 direct selections and 720 short names across 30 orders; example:',commands[6])
