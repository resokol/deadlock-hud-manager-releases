import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Event, Thread
from time import monotonic, sleep
from urllib.parse import parse_qs, urlsplit

import pytest

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

from PySide6.QtCore import QCoreApplication, QEvent, QSettings
from PySide6.QtWidgets import QApplication

from observer_assist import vmix_control
from observer_assist.hud_pov import VmixPovPanel


TARGET = '961935d1-a250-4a9b-8397-cb3be7c25499'
SOURCE_A = 'f2f903de-22e8-4af2-a795-d48c8dd48244'
INPUTS = f'''<vmix><inputs>
<input key="{TARGET}" number="12" title="Deadlock POV" />
<input key="{SOURCE_A}" number="8" title="POV A &amp; B" />
<input key="92394160-0c38-4c63-9829-4c0c62a4fed5" number="3" title="POV B" />
<input key="6315fd7f-ab86-496b-b8ff-9d66bfc18484" number="5" title="POV C" />
</inputs><active>1</active><preview>2</preview></vmix>'''.encode()


@pytest.fixture
def fake_api():
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            self.server.requests.append(self.path)
            status, headers, body = self.server.answer(self.path)
            self.send_response(status)
            for key, value in headers.items():
                self.send_header(key, value)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Connection', 'close')
            self.end_headers()
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def log_message(self, *args):
            pass

    with ThreadingHTTPServer(('127.0.0.1', 0), Handler) as server:
        server.requests = []
        server.answer = default_answer
        thread = Thread(target=server.serve_forever, kwargs={'poll_interval': 0.02}, daemon=True)
        thread.start()
        try:
            yield server
        finally:
            server.shutdown()
            thread.join()


@pytest.fixture(scope='session')
def app():
    return QApplication.instance() or QApplication([])


@pytest.fixture
def control(app):
    controller = vmix_control.VmixPovControl()
    yield controller
    controller.close()
    controller.deleteLater()
    app.sendPostedEvents(None, QEvent.Type.DeferredDelete)


def default_answer(path):
    return 200, {}, INPUTS if path == '/api/' else b''


def wait_for(check):
    for _ in range(200):
        if check():
            return
        process_events(10)
    assert check()


def process_events(milliseconds):
    until = monotonic() + milliseconds / 1000
    while monotonic() < until:
        QCoreApplication.processEvents()
        QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
        sleep(0.002)


def commands(paths):
    values = [parse_qs(urlsplit(path).query) for path in paths if urlsplit(path).query]
    assert all(query.get('Function') == ['SetLayer'] for query in values)
    return [(query['Input'][0], query['Value'][0]) for query in values]


@pytest.mark.parametrize(('target', 'source'), [('Deadlock POV', SOURCE_A.upper()),
                                               (TARGET, 'POV A & B'), ('12', '8')])
def test_only_switches_the_dedicated_composite_and_deduplicates_names(control, fake_api, target, source):
    control.configure('127.0.0.1', fake_api.server_port, target, 2, {'  Élise  Storm ': source}, True)
    control.observe('E\u0301LISE storm')
    wait_for(lambda: len(fake_api.requests) == 2)
    assert fake_api.requests[0] == '/api/'
    assert '%2C' in fake_api.requests[1]
    assert commands(fake_api.requests) == [(TARGET, '2,8')]
    control.observe(' élise  storm ')
    process_events(60)
    assert len(fake_api.requests) == 2


@pytest.mark.parametrize('blocked_request', ['/api/', '1%2C8'])
def test_latest_pov_wins_while_previous_request_is_in_flight(control, fake_api, blocked_request):
    release = Event()
    requests_before_switch = 1 if blocked_request == '/api/' else 2

    def answer(path):
        if (len(fake_api.requests) == requests_before_switch and blocked_request in path):
            release.wait(2)
        return default_answer(path)

    fake_api.answer = answer
    control.configure('127.0.0.1', fake_api.server_port, TARGET, 1,
                      {'A': '8', 'B': '3', 'C': '5'}, True)
    control.observe('A')
    try:
        wait_for(lambda: len(fake_api.requests) == requests_before_switch)
        control.observe('B')
        control.observe('C')
        process_events(60)
        assert len(fake_api.requests) == requests_before_switch
    finally:
        release.set()
    wait_for(lambda: len(fake_api.requests) == requests_before_switch + 2)
    expected = [(TARGET, '1,8')] if requests_before_switch == 2 else []
    assert commands(fake_api.requests) == expected + [(TARGET, '1,5')]


def test_reconfigure_discards_stale_lookup_and_reconciles_the_current_player(control, fake_api):
    release = Event()

    def answer(path):
        if path == '/api/' and len(fake_api.requests) == 1:
            release.wait(2)
        return default_answer(path)

    fake_api.answer = answer
    control.configure('127.0.0.1', fake_api.server_port, TARGET, 1, {'A': '8'}, True)
    control.observe('A')
    try:
        wait_for(lambda: len(fake_api.requests) == 1)
        control.configure('127.0.0.1', fake_api.server_port, TARGET, 4, {'A': '3'}, True)
        wait_for(lambda: len(fake_api.requests) == 3)
    finally:
        release.set()
    process_events(50)
    assert commands(fake_api.requests) == [(TARGET, '4,3')]


def test_disabling_cancels_pending_lookup_and_reenabling_uses_latest_player(control, fake_api):
    release = Event()

    def answer(path):
        if path == '/api/' and len(fake_api.requests) == 1:
            release.wait(2)
        return default_answer(path)

    fake_api.answer = answer
    config = ('127.0.0.1', fake_api.server_port, TARGET, 1, {'A': '8', 'B': '3'})
    control.configure(*config, True)
    control.observe('A')
    try:
        wait_for(lambda: len(fake_api.requests) == 1)
        control.configure(*config, False)
        control.observe('B')
    finally:
        release.set()
    process_events(60)
    assert fake_api.requests == ['/api/']
    control.configure(*config, True)
    wait_for(lambda: len(fake_api.requests) == 3)
    assert commands(fake_api.requests) == [(TARGET, '1,3')]


def test_retries_at_most_once_and_only_until_the_selected_player_changes(control, fake_api, monkeypatch):
    monkeypatch.setattr(vmix_control, 'RETRY_DELAY_MS', 25)
    fake_api.answer = lambda path: (500, {}, b'') if '1%2C8' in path else default_answer(path)
    control.configure('127.0.0.1', fake_api.server_port, TARGET, 1, {'A': '8', 'B': '3'}, True)
    control.observe('A')
    wait_for(lambda: len(fake_api.requests) == 4)
    control.observe(' a ')
    process_events(100)
    assert commands(fake_api.requests) == [(TARGET, '1,8'), (TARGET, '1,8')]
    control.observe('B')
    wait_for(lambda: len(fake_api.requests) == 6)
    assert commands(fake_api.requests)[-1] == (TARGET, '1,3')


def test_replacement_selection_cancels_delayed_retry(control, fake_api, monkeypatch):
    monkeypatch.setattr(vmix_control, 'RETRY_DELAY_MS', 800)
    fake_api.answer = lambda path: (500, {}, b'') if '1%2C8' in path else default_answer(path)
    messages = []
    control.status.connect(messages.append)
    control.configure('127.0.0.1', fake_api.server_port, TARGET, 1, {'A': '8', 'B': '3'}, True)
    control.observe('A')
    wait_for(lambda: any('500' in message for message in messages))
    control.observe('B')
    wait_for(lambda: len(fake_api.requests) == 4)
    process_events(850)
    assert commands(fake_api.requests) == [(TARGET, '1,8'), (TARGET, '1,3')]


def test_timeout_does_not_block_latest_selection(control, fake_api, monkeypatch):
    monkeypatch.setattr(vmix_control, 'REQUEST_TIMEOUT_MS', 100)
    release = Event()

    def answer(path):
        if path == '/api/' and len(fake_api.requests) == 1:
            release.wait(2)
        return default_answer(path)

    fake_api.answer = answer
    control.configure('127.0.0.1', fake_api.server_port, TARGET, 1, {'A': '8', 'B': '3'}, True)
    control.observe('A')
    try:
        wait_for(lambda: len(fake_api.requests) == 1)
        control.observe('B')
        wait_for(lambda: len(fake_api.requests) == 3)
    finally:
        release.set()
    assert commands(fake_api.requests) == [(TARGET, '1,3')]


def test_never_follows_redirects(control, fake_api):
    fake_api.answer = lambda path: (302, {'Location': '/other'}, b'')
    messages = []
    control.status.connect(messages.append)
    control.configure('127.0.0.1', fake_api.server_port, TARGET, 1, {'A': '8'}, True)
    control.observe('A')
    wait_for(lambda: any('302' in message for message in messages))
    process_events(60)
    assert fake_api.requests == ['/api/']


@pytest.mark.parametrize('source', ['not a real input', TARGET, 'POV A & B'])
def test_rejects_missing_self_referencing_and_ambiguous_inputs(control, fake_api, source):
    duplicated = INPUTS.replace(b'title="POV B"', b'title="POV A &amp; B"')
    fake_api.answer = lambda path: (200, {}, duplicated)
    messages = []
    control.status.connect(messages.append)
    control.configure('127.0.0.1', fake_api.server_port, TARGET, 1, {'A': source}, True)
    control.observe('A')
    wait_for(lambda: len(fake_api.requests) == 1 and len(messages) >= 2)
    process_events(60)
    assert fake_api.requests == ['/api/']


def test_remote_panorama_positions_rename_only_assigned_inputs_without_switching(app, fake_api, tmp_path):
    from observer_assist.hud_positions import PanoramaPositions

    settings = QSettings(str(tmp_path / 'positions.ini'), QSettings.Format.IniFormat)
    positions = PanoramaPositions(settings)
    panel = VmixPovPanel(settings)
    positions.slots_changed.connect(panel.set_hud_slots)
    slots = {str(i): 'Player ' + str(i) for i in range(1, 13)}
    slots['7'] = 'Игрок & +'
    slots['12'] = 'Snaps'
    titles = {}
    requests = []

    def answer(path):
        if path.startswith('/api/v1/stats'):
            return 200, {}, json.dumps({'hud_slots': slots, 'selected': {'player': slots.get('7')}}).encode()
        if path == '/api/':
            return default_answer(path)
        query = parse_qs(urlsplit(path).query)
        requests.append(query)
        titles[query['Input'][0]] = query['Value'][0]
        return 200, {}, b''

    fake_api.answer = answer
    try:
        panel.address.setText('127.0.0.1')
        panel.port.setValue(fake_api.server_port)
        for field in panel.slot_inputs:
            field.setValue(0)
        panel.slot_inputs[6].setValue(8)
        panel.slot_inputs[11].setValue(3)
        panel.rename_inputs.setChecked(True)
        panel._apply(save=True)
        positions.source.setCurrentIndex(positions.source.findData('remote'))
        positions.url.setText(f'http://127.0.0.1:{fake_api.server_port}/api/v1/stats?token=test')
        positions.connect_source()
        wait_for(lambda: len(requests) == 2)
        assert positions.observed == 7 and positions.table.item(11, 1).text() == 'Snaps'
        assert titles == {SOURCE_A: 'Игрок & +', '92394160-0c38-4c63-9829-4c0c62a4fed5': 'Snaps'}
        assert all(q['Function'] == ['SetInputName'] for q in requests)
        slots.clear()
        wait_for(lambda: not positions.slots)
        assert not panel.input_names.names
    finally:
        positions.stop()
        panel.shutdown()


def test_position_buttons_and_observer_switch_only_configured_mix_programs(app, fake_api, tmp_path):
    panel = VmixPovPanel(QSettings(str(tmp_path / 'mix.ini'), QSettings.Format.IniFormat))
    inputs = INPUTS.replace(b'</vmix>', b'<mix number="2"/><mix number="4"/></vmix>')
    fake_api.answer = lambda path: (200, {}, inputs if path == '/api/' else b'')
    panel.address.setText('127.0.0.1')
    panel.port.setValue(fake_api.server_port)
    panel.virtual_mixes.setText('2, 4')
    panel.slot_inputs[7].setValue(0)
    panel.copy_inputs[7].setValue(8)
    panel.mixes.setText('1')
    panel._apply(save=True)
    panel.set_hud_slots({'3': 'A', '8': 'B'})
    try:
        panel.buttons[7].click()
        wait_for(lambda: 'Program:' in panel.status.text())
        panel.set_observed(3)
        assert len(fake_api.requests) == 3
        panel.follow.setChecked(True)
        panel._apply(save=True)
        wait_for(lambda: len(fake_api.requests) == 5)
        values = [parse_qs(urlsplit(path).query) for path in fake_api.requests if '?' in path]
        assert [(v['Input'][0], v['Mix'][0]) for v in values] == [
            (SOURCE_A, '1'), (SOURCE_A, '3'),
            ('92394160-0c38-4c63-9829-4c0c62a4fed5', '0')]
        assert all(v['Function'] == ['ActiveInput'] for v in values)
        panel.mixes.setText('1, 6')
        panel._apply(save=True)
        wait_for(lambda: 'наличие' in panel.observer_status.text())
        assert len(fake_api.requests) == 6
    finally:
        panel.shutdown()


def test_match_id_with_remote_observer_and_companion_program_button(app, fake_api, tmp_path):
    from urllib.request import Request, urlopen
    from observer_assist.hud_manager import HudManager
    from observer_assist.match_stats import StatsLanServer

    settings = QSettings(str(tmp_path / 'network.ini'), QSettings.Format.IniFormat)
    window = HudManager(settings, tmp_path / 'huds', camera_controls=True)
    positions, pov = window.positions, window.pov
    selected = {'matchId': 'wrong', 'selected': {'player': 'ghoul'}}
    requests = []
    def answer(path):
        if path.startswith('/api/v1/stats'):
            return 200, {}, json.dumps(selected).encode()
        if path == '/api/':
            return 200, {}, INPUTS.replace(b'</vmix>', b'<mix number="2"/></vmix>')
        requests.append(parse_qs(urlsplit(path).query))
        return 200, {}, b''
    fake_api.answer = answer
    server = window._start_overlay_server()
    def take(slot):
        if not server.can_take(slot):
            return False
        window.live_stats.take_requested.emit(slot)
        return True
    lan = StatsLanServer('127.0.0.1/8', 'read', server.stats, port=0, take=take, control_token='control')
    rows = [dict(team=side, name=('ghoul' if i == 0 and side == 3 else f'{side}-{i}'), lane=lane)
            for side in (2, 3) for i, lane in enumerate([1, 4, 6, 1, 4, 6])]
    try:
        window.source_tv.consume(dict(type='snapshot', matchId='142986218', players=rows))
        positions.url.setText(f'http://127.0.0.1:{fake_api.server_port}/api/v1/stats')
        positions.timer.setInterval(80)
        positions.connect_source()
        pov.address.setText('127.0.0.1')
        pov.port.setValue(fake_api.server_port)
        pov.slot_inputs[6].setValue(8)
        pov.slot_inputs[7].setValue(7)
        pov.mixes.setText('1')
        pov.virtual_mixes.setText('2')
        pov.slot_inputs[2].setValue(0)
        pov.copy_inputs[2].setValue(3)
        pov.follow.setChecked(True)
        pov._apply(save=True)
        process_events(140)
        assert not requests
        with urlopen(lan.url, timeout=2) as reply:
            assert json.load(reply)['hud_slots']['7'] == 'ghoul'
        with urlopen(Request(lan.program_url(3), method='POST'), timeout=2) as reply:
            assert reply.status == 202
        wait_for(lambda: len(requests) == 1)
        selected['matchId'] = '142986218'
        wait_for(lambda: len(requests) == 2)
        assert [(v['Function'], v['Input'], v['Mix']) for v in requests] == [
            (['ActiveInput'], ['92394160-0c38-4c63-9829-4c0c62a4fed5'], ['1']),
            (['ActiveInput'], [SOURCE_A], ['0'])]
        assert server.stats()['hud_observed_slot'] == 7
    finally:
        lan.close()
        window.close()


def test_virtual_and_original_program_routes_survive_roster_changes(app, fake_api, tmp_path):
    settings = QSettings(str(tmp_path / 'virtual.ini'), QSettings.Format.IniFormat)
    panel = VmixPovPanel(settings)
    xml = INPUTS.replace(b'</inputs>', b'<input key="581147f7-8767-423f-82f5-c30d1f4c53ce" number="18" title="Virtual"/>'
                                      b'</inputs>').replace(b'</vmix>', b'<mix number="2"/></vmix>')
    fake_api.answer = lambda path: (200, {}, xml if path == '/api/' else b'')
    try:
        panel.address.setText('127.0.0.1')
        panel.port.setValue(fake_api.server_port)
        panel.mixes.setText('1')
        panel.virtual_mixes.setText('2')
        panel.copy_inputs[7].setValue(18)
        panel.follow.setChecked(True)
        panel._apply(save=True)
        panel.set_hud_slots({'8': 'ghoul'})
        panel.buttons[7].click()
        wait_for(lambda: 'Program:' in panel.status.text())
        panel.set_hud_slots({})
        panel.set_observed(None)
        panel.set_hud_slots({'8': 'Snaps'})
        panel.set_observed(8)
        wait_for(lambda: len(fake_api.requests) == 4)
        commands = [parse_qs(urlsplit(p).query) for p in fake_api.requests if '?' in p]
        assert [(c['Function'][0], c['Mix'][0], c['Input'][0]) for c in commands] == [
            ('ActiveInput', '1', '581147f7-8767-423f-82f5-c30d1f4c53ce'), ('ActiveInput', '0', SOURCE_A)]
        restored = VmixPovPanel(settings)
        try:
            restored.set_hud_slots({'8': 'Snaps'})
            assert restored.targets(8) == [(2, 18)]
            assert restored.targets(8, automatic=True) == [(1, 8)]
        finally:
            restored.shutdown()
        panel.copy_inputs[7].setValue(19)
        panel.follow.setChecked(False)
        panel._apply(save=True)
        panel.buttons[7].click()
        wait_for(lambda: 'наличие' in panel.status.text())
        assert len(fake_api.requests) == 5
    finally:
        panel.shutdown()


def test_urls_follow_nicks_and_observer_and_deck_have_independent_outputs(app, fake_api, tmp_path):
    settings = QSettings(str(tmp_path / 'players.ini'), QSettings.Format.IniFormat)
    panel = VmixPovPanel(settings)
    keys = {n: f'961935d1-a250-4a9b-8397-{n:012d}' for n in (2, 7, 14, 19)}
    xml = ('<vmix><inputs>' + ''.join(f'<input number="{n}" key="{key}" type="Browser"/>'
                                       for n, key in keys.items()) + '</inputs><mix number="2"/></vmix>').encode()
    pages = {'ghoul': 'https://pov.test/watch?id=seven&key=a%2Bb#feed',
             'Snaps': 'https://pov.test/two'}
    calls = []
    def answer(path):
        if path == '/api/':
            return 200, {}, xml
        q = parse_qs(urlsplit(path).query)
        calls.append({k: v[0] for k, v in q.items()})
        return 200, {}, b''
    fake_api.answer = answer
    def writes(function):
        return [(q['Input'], q.get('Mix', q.get('Value'))) for q in calls if q['Function'] == function]
    try:
        panel.address.setText('127.0.0.1')
        panel.port.setValue(fake_api.server_port)
        panel.mixes.setText('1')
        panel.virtual_mixes.setText('2')
        panel.copy_inputs[1].setValue(14)
        panel.copy_inputs[6].setValue(19)
        panel.rename_inputs.setChecked(True)
        panel.follow.setChecked(True)
        for nick, page in pages.items():
            panel._add_page(nick, page)
        panel._apply(save=True)
        panel.set_hud_slots({'2': 'Snaps', '7': 'ghoul'})
        panel.set_observed(7)
        wait_for(lambda: len(writes('ActiveInput')) == 1)
        panel.take(2)
        wait_for(lambda: len(writes('ActiveInput')) == 2 and panel.input_names.reply is None)
        assert writes('ActiveInput') == [(keys[7], '0'), (keys[14], '1')]
        assert sorted(writes('BrowserNavigate')) == sorted([(keys[7], pages['ghoul']), (keys[2], pages['Snaps'])])
        panel.input_names._refresh()
        wait_for(lambda: panel.input_names.reply is None)
        assert len(writes('BrowserNavigate')) == 2
        panel.set_hud_slots({'7': 'Snaps', '2': 'GHOUL'})
        assert not panel.targets(2)
        panel.set_observed(2)
        wait_for(lambda: len(writes('ActiveInput')) == 3 and panel.input_names.reply is None)
        assert writes('ActiveInput')[-1] == (keys[2], '0')
        assert sorted(writes('BrowserNavigate')[-2:]) == sorted([(keys[2], pages['ghoul']), (keys[7], pages['Snaps'])])
        assert (keys[2], 'GHOUL') in writes('SetInputName')
        assert (keys[14], 'GHOUL (Virtual)') in writes('SetInputName')
        panel.take(7)
        wait_for(lambda: len(writes('ActiveInput')) == 4)
        assert writes('ActiveInput')[-1] == (keys[19], '1')
        panel.set_hud_slots({'2': 'unknown'})
        assert not panel.targets(2) and not panel.targets(2, automatic=True)
        assert 'unknown' in panel.pages_status.text()
        restored = VmixPovPanel(settings)
        try:
            assert restored.player_pages == {k.casefold(): v for k, v in pages.items()}
        finally:
            restored.shutdown()
    finally:
        panel.shutdown()


def test_browser_navigation_retries_without_cutting_to_a_failed_url(app, fake_api, tmp_path):
    panel = VmixPovPanel(QSettings(str(tmp_path / 'failure.ini'), QSettings.Format.IniFormat))
    xml = INPUTS.replace(b'number="8"', b'type="Browser" number="8"')
    commands = []
    fail = True
    def answer(path):
        if path == '/api/':
            return 200, {}, xml
        q = parse_qs(urlsplit(path).query)
        commands.append(q['Function'][0])
        return (503 if fail else 200), {}, b''
    fake_api.answer = answer
    try:
        panel.address.setText('127.0.0.1')
        panel.port.setValue(fake_api.server_port)
        panel.mixes.setText('1')
        panel.follow.setChecked(True)
        panel._add_page('A', 'https://video.test/?key=private')
        panel._apply(save=True)
        panel.set_hud_slots({'8': 'A'})
        panel.set_observed(8)
        wait_for(lambda: '503' in panel.names_status.text())
        assert 'private' not in panel.names_status.text()
        assert commands == ['BrowserNavigate']
        fail = False
        panel.input_names._refresh()
        wait_for(lambda: 'ActiveInput' in commands)
        assert commands == ['BrowserNavigate', 'BrowserNavigate', 'ActiveInput']
    finally:
        panel.shutdown()
