import pytest

from observer_assist.camera_native_geometry import (
    neutral_issue, read_native_geometry, reset_commands,
)

LIVE = '96a935d1-a250-4a9b-8397-cb3be7c25499'
REPLAY = 'f2f903de-22e8-4af2-a795-d48c8dd48244'


def sample(live_position='zoomX="1.5"', replay_position='zoomX="1"', swap=False):
    live, replay = (2, 1) if swap else (1, 2)
    return f'''<vmix><inputs>
      <input key="{LIVE}" number="{live}" type="Browser" position="2800">
        <position {live_position}/>
        <overlay index="0"><position panX="0.8"/></overlay>
      </input>
      <input key="{REPLAY}" number="{replay}" type="Virtual"><position {replay_position}/></input>
      </inputs><active>{live}</active><mix number="2"><active>{replay}</active></mix>
      <outputs><output type="Output" number="2" source="Mix" mix="1"/></outputs></vmix>'''


def test_guard_programs_and_live_geometry_follow_guid_across_move():
    original = read_native_geometry(sample())
    moved = read_native_geometry(sample(live_position='zoomX="1.5000"', swap=True))
    assert original.mixes == {1: LIVE, 2: REPLAY}
    assert original.positions[LIVE] == {'zoomX': '1.5'}
    assert original.guard(moved, [LIVE]) == ''
    assert original.guard(read_native_geometry(sample(replay_position='zoomX="1.5"')), [LIVE]) == ''
    assert original.guard(read_native_geometry(sample(live_position='')), [LIVE])
    assert original.guard(read_native_geometry(sample(live_position='zoomX="1.8"')), [LIVE])
    changed_program = sample(swap=True).replace('<active>2</active>', '<active>1</active>', 1)
    assert 'Mix 1' in original.guard(read_native_geometry(changed_program), [LIVE])


def test_readback_preserves_configured_output2_route_without_claiming_signal():
    state = read_native_geometry(sample())
    assert state.external2
    assert state.guard(read_native_geometry(sample().replace('mix="1"', 'mix="2"')), [LIVE])
    missing = read_native_geometry(sample().replace('type="Output"', 'type="Fullscreen"'))
    assert not missing.external2
    assert state.guard(missing, [LIVE])


def test_reset_addresses_checked_guid_and_only_documented_functions():
    expected = {'SetZoom': '1', 'SetPanX': '0', 'SetPanY': '0', 'SetCrop': '0,0,1,1'}
    commands = reset_commands(REPLAY, {})
    assert {c['Function']: c['Value'] for c in commands} == expected
    assert all(c['Input'] == REPLAY for c in commands)
    assert reset_commands(REPLAY, {}, include_unreported=False) == []
    with pytest.raises(ValueError):
        reset_commands('13', {})
    with pytest.raises(ValueError):
        reset_commands('Replay', {})


def test_sparse_position_only_resets_non_neutral_when_readback_required():
    explicitly_neutral = dict(zoomX='1', zoomY='1.0', panX='0', panY='-0.0',
                              cropX1='0', cropY1='0', cropX2='1', cropY2='1')
    assert reset_commands(REPLAY, explicitly_neutral) == []
    assert neutral_issue(explicitly_neutral) == ''
    for field, expected, value in [('panX', 'SetPanX', '.1'), ('zoomY', 'SetZoom', '1.7'),
                                   ('cropX2', 'SetCrop', '0.7')]:
        position = dict(explicitly_neutral, **{field: value})
        assert [c['Function'] for c in reset_commands(REPLAY, position)] == [expected]
        assert field in neutral_issue(position)
    assert neutral_issue({'rotateZ': '2'}) and neutral_issue({'zoomX': 'NaN'})
    assert neutral_issue({}) == ''


def test_virtual_explicitly_overridden_aspect_ratio_requires_inspection():
    assert neutral_issue({'aspectRatio': 'Anamorphic'})
    assert neutral_issue({'aspectRatio': 'Source'}) == ''
    assert neutral_issue({'aspectRatio': 'Auto'}) == ''


def test_no_url_in_geometry_diagnostics_or_malformed_opacity_readback():
    from observer_assist.camera_native_geometry import read_input_alphas
    assert 'private' not in neutral_issue({'panX': 'https://private.invalid/'})
    xml = sample().replace('type="Browser"', 'type="Browser" alpha="https://private.invalid/"')
    xml = xml.replace('type="Virtual"', 'type="Virtual" alphaByte="1"')
    assert read_input_alphas(xml) == {REPLAY: 1}
    assert read_input_alphas(sample()) == {}


def test_percent_or_normalized_alpha_of_unknown_unit_never_drives_setalpha():
    from observer_assist.camera_native_geometry import read_input_alphas
    xml = sample().replace('type="Browser"', 'type="Browser" alpha="40"').replace(
        'type="Virtual"', 'type="Virtual" alpha="100"')
    assert read_input_alphas(xml) == {}
    assert read_input_alphas(xml.replace('alpha="100"', 'alpha="240"')) == {LIVE: 40, REPLAY: 240}
