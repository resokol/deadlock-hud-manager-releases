from dataclasses import replace
from urllib.parse import parse_qsl, urlsplit

import pytest
from PySide6.QtCore import QSettings

from observer_assist.camera_vdo_publish import AppliedBatch, AppliedInput
from observer_assist.camera_vdo_virtual import VirtualCopiesPanel
from test_camera_vdo_publish import Preset, guid
from test_vmix_control import app, fake_api, wait_for


@pytest.fixture
def copies(app, fake_api, tmp_path):
    api = Preset()
    rows = []
    # The first physical source is #7 and its already-prepared copy stays at #19.
    for i, number in enumerate(range(7, 19)):
        label = 'Алиса' if i == 0 else '-' if i > 7 else f'Гость {i}'
        api.add(number, virtual='False')
        api.inputs[guid(number)]['title'] = label
        if i == 0:
            api.add(number + 12)  # Real XML may expose a virtual Web Browser as an ordinary Browser.
        elif i % 2:
            api.add(number + 12, 'Virtual')
        else:
            api.add(number + 12, virtual='True')
        rows.append(AppliedInput(number, guid(number), label, label == '-'))
    api.add(31, 'Capture')
    api.add(32, virtual='False')
    takes = []
    def answer(path):
        if path == '/api/':
            status, headers, body = api.answer(path)
            return status, headers, body.replace(b'</vmix>', b'<active>7</active><mix number="2"><active>7</active></mix></vmix>')
        command = dict(parse_qsl(urlsplit(path).query))
        if command['Function'] == 'ActiveInput':
            takes.append(command)
            return 200, {}, b''
        return api.answer(path)
    fake_api.answer = answer
    settings = QSettings(str(tmp_path / 'test.ini'), QSettings.Format.IniFormat)
    page = VirtualCopiesPanel(settings)
    receipt = AppliedBatch(('127.0.0.1', fake_api.server_port), api.name, tuple(rows))
    page.set_distribution(receipt, 1)
    wait_for(lambda: bool(page.service.inputs))
    yield page, receipt, api, takes
    page.close_session()


def bind_all(page):
    for slot, combo in enumerate(page.choices, 1):
        combo.setCurrentIndex(combo.findData(guid(slot + 18)))
    wait_for(lambda: page.service.can_apply)


def test_logical_order_renames_exactly_twelve_and_replay_only_takes_copy(copies):
    page, receipt, api, takes = copies
    assert not page.complete and not page.route(1) and not page.apply_button.isEnabled()
    assert all(page.choices[0].findData(guid(n)) == -1 for n in [7, 18, 31, 32])
    bind_all(page)
    authorized = []
    page.service.authorize = lambda endpoint, guids: authorized.append((endpoint, guids)) or True
    page.apply_button.click()
    wait_for(lambda: page.complete)
    assert authorized == [(receipt.endpoint, {guid(i) for i in range(7, 31)})]
    assert api.writes == [('SetInputName', guid(r.number + 12), r.label) for r in receipt.rows]
    assert page.route(1) == dict(original_guid=guid(7), original_number=7, virtual_guid=guid(19),
                                 virtual_number=19, title='Алиса', empty=False)
    assert page.route(12)['empty'] and not page.take(12)
    assert not takes and page.take(1)
    wait_for(lambda: bool(takes))
    assert takes == [dict(Function='ActiveInput', Input=guid(19), Mix='1')]
    wait_for(lambda: not page.service.phase)
    page.apply_button.click()
    wait_for(lambda: page.complete)
    assert len(api.writes) == 12

    # Bound by GUID for each original, regardless of HUD ordering or copy input renumbering.
    page.set_distribution(None)
    assert not page.route(1) and not page.take(1)
    api.inputs[guid(19)]['number'] = '42'
    page.set_distribution(replace(receipt, rows=receipt.rows[::-1]), 2)
    wait_for(lambda: page.service.can_apply)
    assert page.choices[-1].currentData() == guid(19)
    page.apply_button.click()
    wait_for(lambda: page.complete)
    assert page.route(12)['virtual_number'] == 42 and page.route(12)['title'] == 'Алиса'


def test_ownership_changes_and_invalid_pairs_prevent_writes(copies):
    page, receipt, api, _ = copies
    bind_all(page)
    assert not page.service.bind(1, guid(8))
    assert not page.service.bind(1, guid(31))
    assert not page.service.bind(1, guid(32))
    assert page.service.bind(1, guid(20))
    assert not page.service.apply() and not api.writes
    page.service.bind(1, guid(19))
    wait_for(lambda: page.service.can_apply)
    def contradict(endpoint, guids):
        api.inputs[guid(8)]['title'] = 'Изменённый оригинал'
        return True
    page.service.authorize = contradict
    assert page.service.apply()
    wait_for(lambda: 'шаг 4' in page.service.issue)
    assert not page.complete and not api.writes
    api.inputs[guid(8)]['title'] = receipt.rows[1].label
    page.service.refresh()
    wait_for(lambda: page.service.can_apply)
    page.service.authorize = lambda *_: page.set_distribution(None) or True
    assert page.service.apply()
    wait_for(lambda: not page.service.receipt)
    assert not api.writes


def test_partial_error_and_stale_title_preset_and_input_fail_closed(copies):
    page, receipt, api, takes = copies
    bind_all(page)
    api.fail = {('SetInputName', guid(20)): 500}
    assert page.service.apply()
    wait_for(lambda: 'HTTP 500' in page.service.issue)
    assert not page.route(1) and api.writes == [('SetInputName', guid(19), 'Алиса'),
                                                ('SetInputName', guid(20), 'Гость 1')]
    api.fail.clear()
    page.service.refresh()
    wait_for(lambda: page.service.can_apply)
    page.apply_button.click()
    wait_for(lambda: page.complete)
    assert api.writes.count(('SetInputName', guid(19), 'Алиса')) == 1
    api.inputs[guid(7)]['title'] = 'Другой'
    assert page.take(1)
    wait_for(lambda: not page.complete)
    assert not takes
    api.inputs[guid(7)]['title'] = 'Алиса'
    page.service.refresh()
    wait_for(lambda: page.service.can_apply)
    page.apply_button.click()
    wait_for(lambda: page.complete)
    page.invalidate_claim(('127.0.0.2', receipt.endpoint[1]), {guid(19)})
    assert page.complete
    page.invalidate_claim(receipt.endpoint, {guid(19)})
    assert not page.complete
    page.service.refresh()
    wait_for(lambda: page.service.can_apply)
    page.apply_button.click()
    wait_for(lambda: page.complete)
    api.name = 'Новый пресет'
    assert page.take(1)
    wait_for(lambda: not page.complete)
    assert not takes and 'пресет' in page.service.issue
    api.name = receipt.preset
    del api.inputs[guid(19)]
    page.service.refresh()
    wait_for(lambda: 'отсутствует' in page.service.issue)
    assert not page.route(1) and not page.service.apply()


def test_only_manually_confirmed_pairs_auto_update_next_match_once(copies):
    page, receipt, api, takes = copies
    bind_all(page)
    # Draft bindings survive a restart but cannot authorize the first write.
    page.set_distribution(None)
    page.set_distribution(receipt, 2)
    wait_for(lambda: bool(page.service.inputs) and not page.service.phase)
    assert not api.writes and not page.complete
    page.apply_button.click()
    wait_for(lambda: page.complete)
    api.writes.clear()

    new_rows = list(receipt.rows)
    new_rows[0] = replace(new_rows[0], label='Новый игрок')
    api.inputs[new_rows[0].guid]['title'] = new_rows[0].label
    new = replace(receipt, rows=tuple(new_rows[::-1]))
    approved = []
    page.service.authorize_automatic = lambda endpoint, guids: approved.append((endpoint, guids)) or True
    page.set_distribution(new, 3)
    wait_for(lambda: page.complete)
    assert api.writes == [('SetInputName', guid(19), 'Новый игрок')] and not takes
    assert page.route(12)['original_guid'] == guid(7)
    page.service.refresh()
    wait_for(lambda: not page.service.phase)
    assert len(approved) == 1

    # A new writer protects the next receipt; releasing it later never makes this poll auto-apply.
    api.inputs[guid(19)]['title'] = 'Управляет Replay'
    api.writes.clear()
    page.service.authorize_automatic = lambda *_: False
    page.set_distribution(new, 4)
    wait_for(lambda: 'другой модуль' in page.service.issue)
    assert not page.complete and not api.writes
    page.service.authorize_automatic = lambda *_: True
    page.service.refresh()
    wait_for(lambda: not page.service.phase)
    assert not page.complete and not api.writes

    # Even reverting an edit requires fresh manual approval.
    assert page.service.bind(12, '') and page.service.bind(12, guid(19))
    page.set_distribution(None)
    page.set_distribution(new, 5)
    wait_for(lambda: bool(page.service.inputs) and not page.service.phase)
    assert not page.complete and not api.writes and not takes
