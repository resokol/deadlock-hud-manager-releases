from uuid import UUID

import pytest
from PySide6.QtCore import QObject, QSettings, Signal

from observer_assist.camera_panel import CameraPanel
from observer_assist.camera_preparation import camera_page, TRANSPARENT_PAGE
from observer_assist.camera_roster import CameraRoster
from observer_assist.camera_routing import CameraRouting, defaults


def guid(i):
    return str(UUID(int=i))


class Endpoint(QObject):
    changed = Signal()
    event = Signal(str)

    def __init__(self, parent):
        super().__init__(parent)
        self.inputs = {guid(i): dict(number=i, title=f'cam {i}', type='Browser') for i in range(1, 35)}
        self.mixes = {1: guid(30), 2: guid(31)}
        self.protected = {guid(30), guid(31)}
        self.protection_known = True
        self.layers = {}
        self.online = False
        self.pages = {}
        self.takes = []

    def configure(self, host, port, enabled):
        self.online = enabled

    def close(self):
        self.online = False

    def sync(self, names, pages):
        self.pages = pages
        self.names = names

    def ready(self, ref, page):
        return self.online and self.pages.get(ref) == page

    def cancel_take(self, *args):
        pass

    def take(self, ref, mix, target, layer, **guard):
        self.takes.append((ref, mix, target, layer))
        return True


def feed(roster, ids):
    players = [dict(accountId=a, name=f'n{a}', heroId=i) for i, a in enumerate(ids)]
    roster.update_match(dict(matchId='11', teams=[
        dict(side=2, players=players[:6]), dict(side=3, players=players[6:])]),
        {str(i): p['name'] for i, p in enumerate(players, 1)}, None, True)
    for account in roster.players:
        roster.set_page(account, f'https://vdo.ninja/?view={account}')


@pytest.fixture
def matrix(tmp_path):
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([])
    settings = QSettings(str(tmp_path / 'cameras.ini'), QSettings.Format.IniFormat)
    roster = CameraRoster(settings)
    feed(roster, range(1, 13))
    panels = {r: CameraPanel(r) for r in ('live', 'replay')}
    ctl = CameraRouting(settings, roster, panels, factory=Endpoint)
    cfg = {r: dict(defaults(r), enabled=True, guids=[guid(i + offset) for i in range(1, 13)])
           for r, offset in [('live', 0), ('replay', 12)]}
    yield ctl, cfg
    ctl.close()
    for w in [roster, ctl.bank_widget, *panels.values()]:
        w.close()


def test_four_modes_same_instance_and_conflict(matrix):
    ctl, cfg = matrix
    assert ctl.apply('live', cfg['live'])
    assert ctl.take('live', 7) and not ctl.take('replay', 7)
    assert ctl.apply('replay', cfg['replay'])
    ep = ctl.endpoints['127.0.0.1', 8088]
    assert len(ep.pages) == 12
    assert ctl.take('live', 7) and ctl.take('replay', 8)
    assert not ctl.apply('replay', dict(cfg['replay'], mix=1))
    assert ctl.config['replay']['mix'] == 2
    assert ctl.apply('live', dict(cfg['live'], enabled=False))
    assert len(ep.pages) == 12 and not ctl.take('live', 7) and ctl.take('replay', 8)
    assert ep.takes == [(guid(7), 1, '', 1), (guid(7), 1, '', 1),
                        (guid(20), 2, '', 1), (guid(20), 2, '', 1)]
    assert ctl.apply('replay', dict(cfg['replay'], enabled=False)) and not ep.online
    assert not ctl.take('replay', 8)
    assert ctl.roster.slots[8] == '8'


def test_replay_on_other_host_keeps_own_sources_while_live_is_off(matrix):
    ctl, cfg = matrix
    assert ctl.apply('live', cfg['live'])
    replay = dict(cfg['replay'], host='192.168.1.9', sources=[guid(n) for n in range(2, 14)],
                  guids=[guid(n) for n in range(14, 26)])
    assert ctl.apply('replay', replay)
    assert ctl.apply('live', dict(cfg['live'], enabled=False))
    ep = ctl.endpoints['192.168.1.9', 8088]
    assert ep.pages[guid(8)] == camera_page(ctl.roster.pages['7'])
    assert ctl.take('replay', 7) and ep.takes[-1][0] == guid(20)
    assert not ctl.endpoints['127.0.0.1', 8088].online


def test_substitute_waits_for_both_outputs_and_fresh_xml(matrix):
    ctl, cfg = matrix
    ctl.apply('live', cfg['live'])
    ctl.apply('replay', cfg['replay'])
    ep = ctl.endpoints['127.0.0.1', 8088]
    ep.protected.add(guid(19))
    feed(ctl.roster, [1, 2, 3, 4, 5, 6, 81, 8, 9, 10, 11, 12])
    ctl.refresh()
    assert ctl.owners[6] == '7' and not ctl.take('replay', 7)
    ep.protected.clear()
    ep.protection_known = False
    ctl.refresh()
    assert ctl.owners[6] == '7'
    ep.protection_known = True
    ctl.refresh()
    assert ctl.owners[6] == '81' and ep.pages[guid(7)] == camera_page(ctl.roster.pages['81'])


def test_missing_url_routes_a_transparent_input_only_on_take(matrix):
    ctl, config = matrix
    assert ctl.roster.set_page('7', '')
    ctl.apply('live', config['live'])
    ctl.apply('replay', config['replay'])
    ep = ctl.endpoints['127.0.0.1', 8088]
    assert ctl.owners[11] == '' and '7' not in ctl.owners
    assert (ep.names[guid(12)], ep.names[guid(24)]) == ('-', '-')
    assert ep.pages[guid(12)] == TRANSPARENT_PAGE and not ctl.take('replay', 7)
    assert not ep.takes and ctl.roster.players[ctl.roster.slots[7]]['name'] == 'n7'
    ctl.roster.set_page('7', 'https://vdo.ninja/?view=seven')
    ctl.refresh()
    assert ctl.owners[11] == '7'
    assert (ep.names[guid(12)], ep.names[guid(24)]) == ('n7', 'n7 (Virtual)')
    ctl.roster.set_page('7', '')
    ctl.refresh()
    assert ep.names[guid(12)] == ep.names[guid(24)] == '-'
    assert not ep.takes and ctl.take('live', 7) and not ctl.take('replay', 7)


def test_preparation_survives_restart_before_panorama_and_does_not_publish_nicks_as_slots(matrix):
    ctl, cfg = matrix
    ctl.roster.update_match(None, {}, None, False)
    original = ctl.preparation_rows()
    draft = list(original)
    draft[0] = ('', 'Player One', 'https://vdo.ninja/?view=one')
    draft[1] = ('222', '', 'https://vdo.ninja/?view=two')
    ctl.save_preparation(original, draft)
    ctl.apply('live', cfg['live'])
    assert ctl.roster.slots == {} and ctl.available['live'] == set()
    assert ctl.endpoints['127.0.0.1', 8088].pages[guid(3)] == TRANSPARENT_PAGE
    roster = CameraRoster(ctl.settings)
    panels = {role: CameraPanel(role) for role in cfg}
    restored = CameraRouting(ctl.settings, roster, panels, factory=Endpoint)
    try:
        assert restored.preparation_rows() == draft
        restored.refresh()
        assert restored.endpoints['127.0.0.1', 8088].pages[guid(1)] == camera_page(draft[0][2])
        invalid = list(draft)
        invalid[2] = draft[0]
        with pytest.raises(ValueError):
            restored.save_preparation(draft, invalid)
        assert restored.preparation_rows() == draft
    finally:
        restored.close()
        restored.bank_widget.close()
        roster.close()
        for panel in panels.values():
            panel.close()


def test_view_parameters_preserve_private_link_encoding_and_fragment():
    raw = 'https://vdo.ninja/?view=x%2By&pw=A%26B#anchor'
    assert camera_page(raw) == raw.replace('#', '&transparent&cleanoutput&style=1#')
    assert camera_page(raw.replace('#', '&st=4&chroma=0000#')) == camera_page(raw)
    assert camera_page(camera_page(raw)) == camera_page(raw)
    assert camera_page('https://example.org/player') == 'https://example.org/player'


def test_duplicate_manual_vdo_room_and_stream_block_both_outputs_without_leaking_url(matrix):
    ctl, cfg = matrix
    ctl.apply('live', cfg['live'])
    ctl.apply('replay', cfg['replay'])
    old = 'https://vdo.ninja/?view=Case%2B1&r=Match&password=private'
    same = 'https://www.vdo.ninja/?room=Match&v=Case%2B1&cleanoutput'
    original, draft = ctl.preparation_rows(), ctl.preparation_rows()
    draft[0] = (*draft[0][:2], old)
    draft[1] = (*draft[1][:2], same)
    with pytest.raises(ValueError, match='двум игрокам'):
        ctl.save_preparation(original, draft)
    ctl.roster.set_page('1', old)
    ctl.roster.set_page('2', same)
    ctl.refresh()
    assert not ctl.has_camera('1') and not ctl.has_camera('2')
    ep = next(iter(ctl.endpoints.values()))
    assert ep.pages[guid(1)] == ep.pages[guid(2)] == TRANSPARENT_PAGE
    assert not ctl.take('replay', 1) and not ctl.take('live', 2) and not ep.takes
    ctl.roster.set_page('2', same.replace('Match', 'Second'))
    ctl.refresh()
    assert ctl.has_camera('1') and ctl.has_camera('2') and ctl.take('replay', 1)
