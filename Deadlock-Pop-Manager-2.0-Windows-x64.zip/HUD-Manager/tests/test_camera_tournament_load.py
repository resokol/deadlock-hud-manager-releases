"""Repeat real HTTP/Qt match synchronizations with 24 permanent camera GUIDs."""
import gc
import os
import random
from pathlib import Path
from statistics import median
from time import perf_counter

from test_camera_native_sync import NativePreset
from test_vmix_control import app, fake_api, wait_for
from observer_assist.camera_native_sync import NativePairSync


def resident_kib():
    status = Path('/proc/self/status')
    if status.is_file():
        for line in status.read_text().splitlines():
            if line.startswith('VmRSS:'):
                return int(line.split()[1])
    return None


def test_consecutive_matches_keep_streams_and_fixed_pool(app, fake_api):
    mixer = NativePreset()
    fake_api.answer = mixer.answer
    endpoint = ('127.0.0.1', fake_api.server_port)
    sync = NativePairSync()
    durations = []
    warm_rss = None
    moves = 0
    rng = random.Random(712)
    cycles = max(5, int(os.environ.get('POP_TEST_MATCHES', '5')))
    players = list(mixer.pairs)
    all_guids = set(mixer.order)
    program = dict(mixer.active)
    try:
        for game in range(cycles):
            rng.shuffle(players)
            mixer.writes.clear()
            fake_api.requests.clear()
            begin = perf_counter()
            assert sync.start(endpoint, mixer.preset, players)
            wait_for(lambda: not sync.busy)
            assert sync.ready, sync.message
            durations.append(perf_counter() - begin)
            assert len(mixer.order) == 25 and set(mixer.order) == all_guids
            assert mixer.order[:12] == [p.original_guid for p in players]
            assert mixer.order[12:24] == [p.virtual_guid for p in players]
            assert mixer.order[24] not in mixer.order[:24]
            assert mixer.active == program
            assert all(cmd['Function'] in {'MoveInput', 'SetInputName'} for cmd in mixer.writes)
            moves += sum(c['Function'] == 'MoveInput' for c in mixer.writes)
            if game == 3:
                gc.collect()
                warm_rss = resident_kib()
            # Simulate repeated read-only health checks from the next match block.
            mixer.writes.clear()
            assert sync.verify(endpoint, mixer.preset, players)
            wait_for(lambda: not sync.busy)
            assert sync.ready and not mixer.writes
        gc.collect()
        print(f'{cycles} match orders, {moves} moves, zero navigation and Program writes, '
              f'median sync {median(durations):.3f}s, max {max(durations):.3f}s, '
              f'RSS after warmup/end {warm_rss}/{resident_kib()} KiB.')
    finally:
        sync.cancel()


def test_room_evidence_to_both_opacity_commands_on_loopback(app, fake_api):
    from urllib.parse import parse_qsl, urlsplit
    from observer_assist.camera_native_monitor import NativeCameraMonitor
    from observer_assist.camera_preparation import camera_page
    from observer_assist.camera_vdo_publish import VdoVmixPublisher

    mixer = NativePreset()
    endpoint = ('127.0.0.1', fake_api.server_port)
    publisher = VdoVmixPublisher()
    monitor = NativeCameraMonitor(publisher)
    evidence = {}
    for pair in mixer.pairs:
        page = 'https://vdo.ninja/?view=sample' + pair.original_guid
        evidence[pair.original_guid] = ('live', page)
        publisher.record_page(endpoint, mixer.preset, pair.original_guid, camera_page(page))
        for guid, title, alpha in ((pair.original_guid, pair.name, '173'),
                                   (pair.virtual_guid, pair.name + ' - Virtual', '224')):
            mixer.inputs[guid].update(title=title, alpha=alpha)

    def controller(path):
        command = dict(parse_qsl(urlsplit(path).query))
        if not command:
            return 200, {}, mixer.xml()
        if command['Function'] != 'SetAlpha':
            return 400, {}, b'Unexpected command'
        mixer.writes.append(command)
        mixer.inputs[command['Input']]['alpha'] = command['Value']
        return 200, {}, b''

    fake_api.answer = controller
    durations = []
    try:
        assert monitor.start(endpoint, mixer.preset, mixer.pairs, media=lambda: evidence, validate=lambda: True)
        for row in mixer.pairs:
            viewer = evidence[row.original_guid]
            for state, alpha in [(('absent', ''), '0'), (viewer, '224')]:
                evidence[row.original_guid] = state
                begin = perf_counter()
                monitor.refresh()
                wait_for(lambda: mixer.inputs[row.virtual_guid]['alpha'] == alpha)
                durations.append((perf_counter()-begin)*1000)
        assert len(mixer.writes) == 48
        assert all(cmd['Function'] == 'SetAlpha' for cmd in mixer.writes)
        print(f'24 confirmed room events, loopback median {median(durations):.1f} ms, '
              f'max {max(durations):.1f} ms through both alpha commands.')
    finally:
        monitor.stop()
