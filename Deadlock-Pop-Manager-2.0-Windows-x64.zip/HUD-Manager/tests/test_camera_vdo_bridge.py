import json
import subprocess
from http.client import HTTPConnection
from html.parser import HTMLParser
from urllib.parse import parse_qs, urlsplit

import pytest

from observer_assist.camera_vdo_bridge import VdoRoomBridge, _SCRIPT


class DirectorFrame(HTMLParser):
    def handle_starttag(self, tag, attrs):
        if tag == 'iframe':
            self.attrs = dict(attrs)


@pytest.fixture
def local_bridge():
    seen = []
    bridge = VdoRoomBridge('https://vdo.ninja/?director=fixture-room#password=fixture-secret&iframetarget=*', seen.append)
    try:
        yield bridge, seen
    finally:
        bridge.close()


def request(bridge, method='GET', suffix='', headers=None, body=None):
    url = urlsplit(bridge.url)
    client = HTTPConnection(url.hostname, url.port, timeout=3)
    try:
        client.request(method, url.path + suffix, body=body, headers=headers or {})
        response = client.getresponse()
        return response.status, dict(response.getheaders()), response.read()
    finally:
        client.close()


def test_private_page_and_restricted_report(local_bridge, capsys):
    bridge, reports = local_bridge
    url = urlsplit(bridge.url)
    origin = f'http://{url.netloc}'
    assert url.hostname == '127.0.0.1' and len(url.path) >= 40 and 'fixture-' not in bridge.url
    status, heads, body = request(bridge)
    assert status == 200
    assert heads['Referrer-Policy'] == 'no-referrer' and heads['Cache-Control'] == 'no-store'
    assert "frame-src https://vdo.ninja" in heads['Content-Security-Policy']
    frame = DirectorFrame()
    frame.feed(body.decode())
    source = urlsplit(frame.attrs['src'])
    query = parse_qs(source.query)
    assert source.hostname == 'vdo.ninja' and query['director'] == ['fixture-room']
    assert query['iframetarget'] == [origin] and frame.attrs['referrerpolicy'] == 'no-referrer'
    assert frame.attrs['data-poll-seconds'] == '3'
    assert parse_qs(source.fragment) == {'password':['fixture-secret']}
    headers = {'Origin': origin, 'Content-Type': 'application/json', 'X-Room-Tab': frame.attrs['data-tab']}
    rows = [{'streamID': 'abc', 'label': 'Игрок', 'video': 'live'}]
    for _ in range(2):
        assert request(bridge, 'POST', 'guests', headers, json.dumps(rows))[0] == 204
    assert request(bridge, 'POST', 'guests', headers, '[]')[0] == 204
    assert reports == [rows, rows, []]
    bridge.set_interval(12)
    code, updated, _ = request(bridge, suffix='active', headers=headers)
    assert code == 204 and updated['X-Room-Poll-Seconds'] == '12'
    request(bridge)
    assert request(bridge, suffix='active', headers=headers)[0] == 410
    assert request(bridge, 'POST', 'guests', headers, '[]')[0] == 410
    assert reports == [rows, rows, []]
    assert request(bridge, headers={'Host': 'attacker.test'})[0] == 404
    assert request(bridge, suffix='unknown')[0] == 404
    assert 'fixture-secret' not in capsys.readouterr().err


def test_invalid_reports_do_not_clear_last_list(local_bridge):
    bridge, reports = local_bridge
    origin = 'http://' + urlsplit(bridge.url).netloc
    frame = DirectorFrame()
    frame.feed(request(bridge)[2].decode())
    headers = {'Content-Type': 'application/json', 'Origin': origin, 'X-Room-Tab': frame.attrs['data-tab']}
    for row, body, expected in [
            ({'Origin': 'https://vdo.ninja'}, '[]', 403),
            ({'Host': 'attacker.test'}, '[]', 404),
            ({'Content-Type': 'text/plain'}, '[]', 415),
            ({}, '{}', 400), ({}, '[{"label":"missing-id"}]', 400),
            ({}, '[{"streamID":"abc","label":"name","video":"guessed"}]', 400),
            ({}, 'x' * 65537, 413)]:
        assert request(bridge, 'POST', 'guests', headers | row, body)[0] == expected
    assert reports == []
    assert request(bridge, 'POST', 'guests', headers, '[{"streamID":"abc","label":"name"}]')[0] == 204
    assert reports == [[{'streamID':'abc', 'label':'name', 'video':'unknown'}]]


def test_iframe_guest_messages_from_published_protocol():
    harness = """
const assert = require('node:assert/strict');
const vm = require('node:vm');
const calls = [], posts = [], status = {};
let receive, poll;
const frame = {
    dataset: {mode:'director', pollSeconds:'3'},
    src: 'https://vdo.ninja/?director=room',
    contentWindow: {postMessage: (request, origin) => calls.push({request, origin})},
    addEventListener: () => {},
};
vm.runInNewContext(SCRIPT, {
    document: {querySelector: id => id === '#director' ? frame : status},
    window: {addEventListener: (name, cb) => {receive = cb}},
    setInterval: cb => {poll = cb}, setTimeout, clearTimeout, performance, URL, AbortSignal,
    fetch: async (path, init) => {
        if (path === 'guests') posts.push([path, JSON.parse(init.body)]); return {ok:true};
    },
});
(async () => {
    const source = frame.contentWindow, origin = 'https://vdo.ninja';
    assert.equal(calls[0].request.getGuestList, true);
    assert.equal(calls[1].request.getStats, true);
    assert.equal(calls[0].request.cib, calls[1].request.cib);
    assert.equal(calls[0].origin, origin);
    const data = {cib:calls[0].request.cib, guestList:{
        '1':{streamID:'abc', label:'Игрок'}, '3':{streamID:'def', label:''}, '4':{streamID:'mycam',label:'host'},
        '5':{streamID:'mycam:s',label:'screen'}, '8':{streamID:'unseen',label:'No peer'},
    }};
    const peer = id => ({streamID:id, UUID:'peer-'+id, localStream:false, director:false,
                          videoVisible:true, label:'Player', miscellaneous:{token:'private'}});
    const detailedState = {mycam:{streamID:'mycam',localStream:true},
        abc:{...peer('abc'), videoMuted:false, videoVisible:false,
             miscellaneous:{video_muted_init:false,video_init_width:1280, video_init_height:720}},
        def:{...peer('def'), videoMuted:true, miscellaneous:{video_init_width:1280,video_init_height:720}},
    };
    await receive({data:{cib:data.cib,detailedState},source,origin});
    await receive({data, source:{}, origin});
    await receive({data, source, origin:'https://wrong.test'});
    await receive({data:{...data,cib:'stale'},source,origin});
    await receive({data:{cib:data.cib,streamIDs:{abc:'Игрок'}},source,origin});
    await receive({data:{...data,guestList:null},source,origin});
    await receive({data:{...data,guestList:{1:{uuid:'not-a-stream'}}},source,origin});
    assert.deepEqual(posts, []);
    await receive({data, source, origin});
    await receive({data:{cib:data.cib, stats:{inbound:{def:{audio:{type:'Audio Stream', Bitrate_in_kbps:64}}}}},
                   source,origin});
    assert.deepEqual(posts, [['guests', [{...data.guestList['1'],video:'live'},
        {...data.guestList['3'],video:'absent'}, {...data.guestList['8'],video:'unknown'}]]]);
    poll();
    await receive({data:{cib:calls.at(-1).request.cib,guestList:{}},source,origin});
    await receive({data:{cib:calls.at(-1).request.cib,detailedState},source,origin});
    // Old clients that omit getStats still deliver a full directory.
    await new Promise(done=>setTimeout(done,240));
    assert.deepEqual(posts.at(-1), ['guests', []]);
    for (let i=0; i<25; i++) poll();
    assert.equal(posts.length, 2);
})().catch(error => {console.error(error); process.exitCode=1;});
"""
    subprocess.run(['node', '-e', 'const SCRIPT = ' + json.dumps(_SCRIPT) + ';' + harness],
                   check=True, capture_output=True, timeout=10)


def test_scene_video_state_requires_fresh_evidence_from_the_same_remote_peer():
    harness = """
const assert = require('node:assert/strict');
const vm = require('node:vm');
const calls = [], posts = [];
let receive, poll;
let now = 100;
const frame = {
    dataset:{mode:'scene',pollSeconds:'3'}, src:'https://vdo.ninja/?scene&room=room',
    contentWindow:{postMessage: cmd => calls.push(cmd)}, addEventListener: () => {},
};
vm.runInNewContext(SCRIPT, {
    document:{querySelector:id => id === '#director' ? frame : {}},
    window:{addEventListener:(_name, cb) => {receive=cb}}, setInterval:cb => {poll=cb},
    setTimeout, clearTimeout, performance:{now:()=>now}, URL, AbortSignal,
    fetch:async (path, init) => {
        if (path === 'guests') posts.push(JSON.parse(init.body)); return {ok:true};
    },
});
(async () => {
    assert.equal(calls[0].getDetailedState,true);
    const remote = id => ({streamID:id, UUID:'peer-'+id, localStream:false, director:false,
                            label:'Player', miscellaneous:{private:true}, tally:[]});
    const self = {streamID:false, localStream:true, director:false};
    const send = async detailedState => receive({source:frame.contentWindow,origin:'https://vdo.ninja',
                                                data:{cib:calls.at(-1).cib,detailedState}});
    await send(null);
    await send({});
    await send({camera:remote('different-key'), false:self});
    await send({camera:{streamID:'camera'}, false:self});
    await send({camera:remote('camera')});
    assert.equal(posts.length,0);
    const directory = {false:self, director:{...remote('director'),director:true},
                camera:{...remote('camera'),videoMuted:false, videoVisible:false},
                'camera:s':remote('camera:s'), embed:{...remote('embed'),iframeSrc:'https://private.test'},
                muted:{...remote('muted'),videoMuted:true},
                unknown:{...remote('unknown'),videoVisible:true,videoMuted:false,label:false}};
    const stats = async frames => receive({source:frame.contentWindow,origin:'https://vdo.ninja',
        data:{cib:calls.at(-1).cib, stats:{inbound:{
            camera:{track:{type:'Video Stream',_decodeFrames:frames,_frameWidth:640,_frameHeight:480}},
            unknown:{track:{type:'Audio Stream',Bitrate_in_kbps:64}},
        }}}});
    await stats(20);
    await send(directory);
    const expected = [{streamID:'camera',label:'Player',video:'unknown'},
                      {streamID:'muted',label:'Player',video:'absent'},
                      {streamID:'unknown',label:'',video:'unknown'}];
    assert.deepEqual(posts,[expected]);
    poll(); await send(directory); await stats(24);
    assert.equal(posts.at(-1)[0].video,'live');
    now += 3000; poll(); await send(directory); await stats(24);
    assert.equal(posts.at(-1)[0].video,'live');
    now += 5000; poll(); await send(directory); await stats(24);
    assert.deepEqual(posts.at(-1),expected);
    now += 3000; poll(); directory.camera.UUID='replacement'; await send(directory); await stats(39);
    assert.deepEqual(posts.at(-1),expected);
    poll();
    await send({false:self});
    await stats(39);
    assert.deepEqual(posts.at(-1),[]);
})().catch(error => {console.error(error);process.exitCode=1});
"""
    subprocess.run(['node', '-e', 'const SCRIPT = ' + json.dumps(_SCRIPT) + ';' + harness],
                   check=True, capture_output=True, timeout=10)


def test_live_poll_interval_changes_without_replacing_room_or_starting_a_second_timer():
    harness = """
const assert = require('node:assert/strict');
const vm = require('node:vm');
const timers = new Map();
const requests = [];
let serial = 0, seconds = 45;
const frame = {
    dataset:{mode:'director',pollSeconds:'12'}, src:'https://vdo.ninja/?director=room',
    contentWindow:{postMessage:cmd=>{if(cmd.getDetailedState)requests.push(cmd)}}, addEventListener:()=>{},
};
vm.runInNewContext(SCRIPT, {
    document:{querySelector:id=>id==='#director'?frame:{}}, window:{addEventListener:()=>{}},
    setInterval:(fn,ms)=>{const id=++serial; timers.set(id,{fn,ms}); return id;},
    clearInterval:id=>timers.delete(id), clearTimeout, URL, AbortSignal,
    fetch:async()=>({ok:true,status:204,headers:{get:()=>String(seconds)}}),
});
(async()=>{
    const heartbeat = [...timers.values()].find(t=>t.ms===2000);
    assert.deepEqual([...timers.values()].map(t=>t.ms), [2000,12000]);
    assert.equal(requests.length,1);
    await heartbeat.fn();
    assert.deepEqual([...timers.values()].map(t=>t.ms), [2000,45000]);
    assert.equal(requests.length,2);
    await heartbeat.fn();
    assert.equal(requests.length,2);
    seconds=1;
    await heartbeat.fn();
    assert.deepEqual([...timers.values()].map(t=>t.ms),[2000,1000]);
    [...timers.values()].find(t=>t.ms===1000).fn();
    assert.equal(requests.length,4);
    assert.equal(frame.src,'https://vdo.ninja/?director=room');
})().catch(error=>{console.error(error);process.exitCode=1});
"""
    subprocess.run(['node', '-e', 'const SCRIPT = ' + json.dumps(_SCRIPT) + ';' + harness],
                   check=True, capture_output=True, timeout=10)
