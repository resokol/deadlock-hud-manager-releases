import json
from copy import deepcopy
from urllib.error import HTTPError
from urllib.request import urlopen

import pytest

from observer_assist.match_stats import StatsLanServer
from observer_assist.panorama_hud_mode import PanoramaTelemetryServer
from observer_assist.pov_match_data import POV_MATCH_ROUTE, read_pov_snapshot
from observer_assist.pov_remote import PovRemote
from test_vmix_control import app, fake_api, wait_for


def frame(accounts=False):
    teams = []
    for side in (2, 3):
        players = []
        for i in range((side - 2) * 6, (side - 1) * 6):
            player = dict(name=f'Guest {i + 1}', portraitX=24 * i, heroId=10 + i)
            if accounts:
                player['_accountId'] = 500 + i
            players.insert(0, player)
        teams.append({'side': side, 'players': players})
    return {'teams': teams, 'selected': {'player': 'Guest 7'}}


def test_observer_lan_supplies_verified_order_and_revokes_stale_state(app):
    server = PanoramaTelemetryServer(port=0)
    lan = StatsLanServer('127.0.0.1/8', 'read', server.stats, port=0, pov_snapshot=server.pov_snapshot)
    remote = PovRemote()
    notifications = []
    remote.changed.connect(notifications.append)
    try:
        payload = frame()
        roster = frame(accounts=True)
        for team in roster['teams']:
            for p in team['players']:
                p['accountId'] = p.pop('_accountId')
                p['sensitive_internal_field'] = 'never-export'
        server.set_pov_roster(dict(roster, matchId='321'))
        server.publish(payload, match_id='321')
        assert remote.set_url(lan.url)
        wait_for(lambda: remote.snapshot is not None)
        match = remote.snapshot
        assert match.match_id == '321' and match.names[6] == 'Guest 7' and match.observed == 7
        assert match.roster['teams'][1]['players'][0] == dict(accountId='506', name='Guest 7', heroId=16)
        assert 'never-export' not in repr(match)
        assert '506' not in urlopen(lan.url, timeout=2).read().decode()
        with pytest.raises(HTTPError) as exc:
            urlopen(lan.url.replace('/api/v1/stats', POV_MATCH_ROUTE).replace('token=read', 'token=bad'), timeout=2)
        assert exc.value.code == 403

        server.publish(payload, match_id='322')
        remote._poll()
        wait_for(lambda: remote.snapshot is not None and remote.snapshot.match_id == '322')
        assert remote.snapshot.roster is None
        server.publish(frame(accounts=True), match_id='322')
        remote._poll()
        wait_for(lambda: remote.snapshot is not None and remote.snapshot.roster is not None)
        server._pov_sample_at -= 10
        remote._poll()
        wait_for(lambda: remote.snapshot is None)
        assert notifications[-1] is None
    finally:
        remote.stop()
        lan.close()
        server.close()


def test_previous_hud_fallback_requires_portraits_and_revokes_on_error(app, fake_api):
    slots = {str(i): f'Nick {i}' for i in range(1, 13)}
    stats = dict(version=1, status='live', matchId='123', panorama_match_id='123',
                 hud_slots=slots, hud_observed_slot=1, panorama_slots=slots, panorama_observed_slot=12)
    code = 200
    fake_api.answer = lambda path: (404, {}, b'') if path.startswith(POV_MATCH_ROUTE) else (code, {}, json.dumps(stats).encode())
    remote = PovRemote()
    try:
        assert remote.set_url(f'http://127.0.0.1:{fake_api.server_port}/api/v1/stats?token=old-key')
        wait_for(lambda: remote.snapshot is not None)
        assert remote.snapshot.observed == 12 and remote.snapshot.roster is None
        assert fake_api.requests[:2] == ['/api/v1/pov/match?token=old-key', '/api/v1/stats?token=old-key']
        stats.pop('panorama_slots')
        remote._poll()
        wait_for(lambda: remote.snapshot is None)
        stats['panorama_slots'] = slots
        remote._poll()
        wait_for(lambda: remote.snapshot is not None)
        code = 503
        remote._poll()
        wait_for(lambda: remote.snapshot is None)
        code = 200
        remote._poll()
        wait_for(lambda: remote.snapshot is not None)
        remote.stop()
        assert remote.snapshot is None
    finally:
        remote.stop()


def test_invalid_accounts_or_observer_cannot_route():
    from observer_assist.pov_match_data import make_pov_snapshot

    good = make_pov_snapshot(frame(accounts=True), '123', None)
    assert read_pov_snapshot(good)
    for field, value in [('panorama_match_id', '999'), ('panorama_match_id', True),
                         ('panorama_observed_slot', True), ('panorama_observed_slot', 13),
                         ('panorama_slots', {'1': 'Guest 1'})]:
        assert read_pov_snapshot({**good, field: value}) is None
    corrupt = deepcopy(good)
    players = corrupt['panorama_roster']['teams'][0]['players']
    players[1]['accountId'] = players[0]['accountId']
    assert read_pov_snapshot(corrupt) is None
