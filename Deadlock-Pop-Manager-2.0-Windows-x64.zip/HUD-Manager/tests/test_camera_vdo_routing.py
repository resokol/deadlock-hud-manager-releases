import json
import os
from unittest.mock import Mock

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

import pytest
from PySide6.QtCore import QSettings
from PySide6.QtWidgets import QApplication

from observer_assist.camera_panel import CameraPanel
from observer_assist.camera_preparation import camera_page, TRANSPARENT_PAGE
from observer_assist.camera_roster import CameraRoster
from observer_assist.camera_routing import CameraRouting, defaults
from test_camera_routing import Endpoint, guid


def guest(stream, label='', page=None):
    return dict(streamID=stream, label=label, page=page or f'https://vdo.ninja/?view={stream}&password=secret')


@pytest.fixture
def create(tmp_path):
    app = QApplication.instance() or QApplication([])
    controllers = []
    settings = QSettings(str(tmp_path / 'vdo.ini'), QSettings.Format.IniFormat)

    def make():
        ctl = CameraRouting(settings, CameraRoster(settings),
                            {role: CameraPanel(role) for role in ('live', 'replay')}, factory=Endpoint)
        controllers.append(ctl)
        return ctl
    yield make
    for ctl in controllers:
        ctl.close()
        for widget in [ctl.roster, ctl.bank_widget, *ctl.panels.values()]:
            widget.close()


def confirm(ctl):
    players = [dict(accountId=i, name=f'player-{i}', heroId=i) for i in range(1, 13)]
    ctl.roster.update_match(dict(matchId='12', teams=[
        dict(side=2, players=players[:6]), dict(side=3, players=players[6:])]),
        {str(i): p['name'] for i, p in enumerate(players, 1)}, None, True)
    ctl.refresh()


def test_guest_order_rejoin_restart_and_transparent_disconnect(create, monkeypatch):
    ctl = create()
    a, b = guest('private-one', 'Alpha'), guest('private-two', 'Bravo')
    ctl.apply('live', dict(defaults('live'), enabled=True, guids=[guid(i) for i in range(1, 13)]))
    ctl.import_vdo_guests('room-key', [b, a])
    ep = next(iter(ctl.endpoints.values()))
    assert not ctl.roster.slots and ep.pages[guid(2)] == camera_page(a['page'])
    assert ctl.owners[:2] == ['nick:bravo', 'nick:alpha']
    save = Mock(wraps=ctl.save)
    monkeypatch.setattr(ctl, 'save', save)
    ctl.import_vdo_guests('room-key', [a, b])
    ctl.import_vdo_guests('room-key', [b, a])
    save.assert_not_called()
    renamed = dict(a, label='Gamma')
    ctl.import_vdo_guests('room-key', [renamed, b])
    assert ctl.owners[:2] == ['nick:bravo', 'nick:gamma']
    restored = create()
    msg = restored.import_vdo_guests('room-key', [b])
    ep = next(iter(restored.endpoints.values()))
    assert 'прозрачный' in msg and restored.owners[1] == 'nick:gamma'
    assert ep.pages[guid(2)] == TRANSPARENT_PAGE and not ep.takes
    restored.import_vdo_guests('room-key', [dict(a, label=''), b])
    assert restored.preparation_rows()[1] == ('', 'Gamma', '')
    assert restored.vdo_guest_bank('room-key', a['streamID']) is None
    restored.import_vdo_guests('room-key', [dict(a, label='Gamma'), b])
    assert restored.preparation_rows()[1] == ('', 'Gamma', a['page'])
    public = msg + restored.log.toPlainText() + json.dumps(restored.guest_banks)
    assert all(s not in public for s in ('private-one', 'private-two', 'password=', 'room-key'))


def test_provisional_becomes_account_then_follows_guest_without_name_overwrite(create):
    ctl = create()
    a = guest('private-player', 'player-3')
    ctl.import_vdo_guests('room', [a])
    confirm(ctl)
    assert ctl.owners[0] == '3' and ctl.roster.pages['3'] == a['page']
    ctl.import_vdo_guests('room', [dict(a, label='player-8')])
    assert ctl.owners[0] == '3' and ctl.preparation_rows()[0] == ('3', 'player-3', '')
    assert ctl.vdo_bank_status('3') == 'Конфликт Label'
    assert not ctl.has_camera('3') and not ctl.has_camera('8')
    ctl.import_vdo_guests('room', [])
    assert '3' not in ctl.roster.pages
    ctl.import_vdo_guests('room', [a])
    assert ctl.roster.pages['3'] == a['page']
    ctl.roster.set_page('3', 'https://example.org/manual')
    ctl.import_vdo_guests('room', [])
    ctl.import_vdo_guests('room', [a])
    assert ctl.roster.pages['3'] == 'https://example.org/manual'


def test_saved_account_url_wins_over_provisional_guest_even_if_same_page(create):
    ctl = create()
    a = guest('private-player', 'player-3')
    ctl.roster.update_pages({'3': a['page']})
    ctl.import_vdo_guests('room', [a])
    confirm(ctl)
    ctl.import_vdo_guests('room', [])
    assert ctl.roster.pages['3'] == a['page']


def test_manual_preparation_bank_replacement_room_collisions_and_ambiguous_labels(create):
    ctl = create()
    original, draft = ctl.preparation_rows(), ctl.preparation_rows()
    draft[5] = ('123', 'Alpha', '')
    draft[6] = ('124', 'Bravo', 'https://example.org/manual')
    ctl.save_preparation(original, draft)
    a = guest('private-a', 'Alpha')
    b = guest('private-b', 'Bravo')
    msg = ctl.import_vdo_guests('room-a', [guest('missing'), a, b, guest('dup-1','Charlie'), guest('dup-2','charlie')])
    assert 'проверки' in msg
    assert ctl.preparation_rows()[5][2] == a['page']
    assert ctl.preparation_rows()[6][2] == 'https://example.org/manual'
    assert len([v for v in ctl.owners if v]) == 2
    ctl.import_vdo_guests('room-b', [guest('private-a','Alpha')])
    assert ctl.preparation_rows()[5][2] == a['page']
    assert ctl.vdo_guest_bank('room-a', 'private-a') is None
    assert ctl.vdo_guest_bank('room-b', 'private-a') == 6
    ctl.import_vdo_guests('room-b', [])
    assert not ctl.preparation_rows()[5][2]
    original, draft = ctl.preparation_rows(), ctl.preparation_rows()
    draft[5] = ('234', 'Replacement', 'https://example.org/replacement')
    ctl.save_preparation(original, draft)
    ctl.import_vdo_guests('room-a', [])
    ctl.import_vdo_guests('room-a', [a])
    assert ctl.preparation_rows()[5] == draft[5]


def test_full_banks_and_invalid_packets_do_not_clear_sources(create):
    ctl = create()
    visitors = [guest(f'stream-{i}', f'player-{i:02d}') for i in range(13)]
    msg = ctl.import_vdo_guests('room', visitors)
    assert '12 пар заняты' in msg and len(set(ctl.owners)) == 12
    before = ctl.preparation_rows()
    ctl.import_vdo_guests('room', [{'bad': True}])
    assert ctl.preparation_rows() == before
    first = visitors[0]
    ctl.import_vdo_guests('room', [dict(first, page='broken'), first, *visitors[1:]])
    assert ctl.preparation_rows()[1:] == before[1:] and ctl.preparation_rows()[0] == ('', 'player-00', '')


def test_rollover_waits_for_departure_and_reuses_unique_guest_in_same_or_new_room(create):
    ctl = create()
    old = guest('old-stream', 'Alpha')
    new = guest('new-stream', 'Alpha')
    other = guest('other-stream', 'Bravo')
    ctl.import_vdo_guests('room', [old, other])
    ctl.import_vdo_guests('room', [new, old, other])
    assert ctl.vdo_guest_bank('room', 'old-stream') is None
    assert ctl.vdo_guest_bank('room', 'new-stream') is None
    msg = ctl.import_vdo_guests('room', [new, other])
    assert 'прозрачный режим' not in msg
    assert ctl.vdo_guest_bank('room', 'new-stream') == 1
    assert ctl.vdo_guest_bank('room', 'old-stream') is None
    assert ctl.preparation_rows()[0][2] == new['page']
    replacement = guest('entirely-different', 'Alpha')
    ctl.import_vdo_guests('new-room', [replacement])
    ctl.import_vdo_guests('room', [])
    assert ctl.preparation_rows()[0][2] == replacement['page']
    assert ctl.vdo_guest_bank('new-room', 'entirely-different') == 1


def test_numeric_guest_label_can_only_match_the_player_with_that_literal_nickname(create):
    ctl = create()
    original, rows = ctl.preparation_rows(), ctl.preparation_rows()
    rows[2] = ('45', 'Alpha', '')
    ctl.save_preparation(original, rows)
    numeric = guest('numeric', '45')
    ctl.import_vdo_guests('room', [numeric])
    assert ctl.owners[0] == 'nick:45' and not ctl.has_camera('45')
    players = [dict(accountId=i, name=f'player-{i}') for i in [17, 45, *range(101, 111)]]
    players[0]['name'], players[1]['name'] = '45', 'Alpha'
    ctl.roster.update_match(dict(matchId='12', teams=[
        dict(side=2, players=players[:6]), dict(side=3, players=players[6:])]),
        {str(i): p['name'] for i, p in enumerate(players, 1)}, None, True)
    ctl.refresh()
    ctl.import_vdo_guests('room', [numeric])
    assert ctl.owners[0] == '17' and ctl.has_camera('17')
    assert ctl.owners[2] == '45' and not ctl.has_camera('45')


def test_bulk_release_preserves_operator_banks_urls_and_unsaved_edits(create):
    ctl = create()
    original, rows = ctl.preparation_rows(), ctl.preparation_rows()
    rows[5] = ('123', 'Prepared', '')
    rows[6] = ('456', 'Operator', 'https://example.org/manual')
    ctl.save_preparation(original, rows)
    visitors = [guest('first', 'Alpha'), guest('second', 'Bravo'), guest('third', 'Prepared')]
    ctl.import_vdo_guests('room', visitors)
    original, draft = ctl.preparation_rows(), ctl.preparation_rows()
    draft[0] = ('', 'Alpha', 'https://example.org/override')
    released = ctl.released_vdo_rows(draft)
    assert released[0] == draft[0] and released[1] == ('', '', '')
    assert released[5] == ('123', 'Prepared', '') and released[6] == draft[6]
    ctl.save_preparation(original, released, release_vdo={1, 5})
    ctl.import_vdo_guests('new-room', [guest('new', 'Prepared'), guest('fourth', 'Delta')])
    assert ctl.vdo_guest_bank('new-room', 'new') == 6
    assert ctl.vdo_guest_bank('new-room', 'fourth') == 2
    assert ctl.vdo_guest_bank('room', 'first') is None
    assert ctl.preparation_rows()[0][2].endswith('override')


def test_release_button_only_applies_on_save(create):
    from PySide6.QtCore import QTimer
    from PySide6.QtWidgets import QDialogButtonBox, QPushButton
    ctl = create()
    ctl.import_vdo_guests('room', [guest('first', 'Alpha')])

    def edit(result):
        dialog = QApplication.activeModalWidget()
        release = next(b for b in dialog.findChildren(QPushButton) if 'Освободить пары' in b.text())
        release.click()
        dialog.findChild(QDialogButtonBox).button(result).click()

    for action, assigned in ((QDialogButtonBox.StandardButton.Cancel, 1), (QDialogButtonBox.StandardButton.Save, None)):
        QTimer.singleShot(0, lambda a=action: edit(a))
        ctl.edit_preparation(ctl.bank_widget)
        assert ctl.vdo_guest_bank('room', 'first') == assigned
    assert ctl.owners == [''] * 12


def test_full_director_list_allocates_in_arrival_order_when_hud_already_known(create):
    ctl = create()
    ctl.apply('live', dict(defaults('live'), enabled=True, guids=[guid(i) for i in range(1, 13)]))
    confirm(ctl)
    assert not any(ctl.owners)
    order = [8, 3, 12, 1, 7, 11, 2, 9, 6, 5, 4, 10]
    guests = [guest('stream-' + str(i), 'player-' + str(i)) for i in order]
    ctl.import_vdo_guests('room', guests)
    assert ctl.owners == list(map(str, order))
    ctl.import_vdo_guests('room', guests[::-1])
    assert ctl.owners == list(map(str, order))
    ep = next(iter(ctl.endpoints.values()))
    assert not ep.takes and all(ep.pages[guid(i)] == camera_page(g['page']) for i, g in enumerate(guests, 1))


def test_twelve_guests_safe_replacement_requires_both_match_departure_and_free_outputs(create):
    ctl = create()
    ctl.apply('live', dict(defaults('live'), enabled=True, guids=[guid(i) for i in range(1, 13)]))
    ctl.apply('replay', dict(defaults('replay'), enabled=True, guids=[guid(i) for i in range(13, 25)]))
    confirm(ctl)
    guests = [guest(f'stream-{i}', f'player-{i}') for i in range(1, 13)]
    ctl.import_vdo_guests('room', guests)
    new = guest('new-stream', 'player-21')
    ep = next(iter(ctl.endpoints.values()))
    ep.protected.add(guid(19))
    changed = guests[:6] + [new] + guests[7:]
    ctl.import_vdo_guests('room', changed)
    assert ctl.owners[6] == '7' and not ctl.has_camera('7') and not ctl.take('replay', 7)
    ids = [1, 2, 3, 4, 5, 6, 21, 8, 9, 10, 11, 12]
    players = [dict(accountId=i, name=f'player-{i}') for i in ids]
    ctl.roster.update_match(dict(matchId='77', teams=[
        dict(side=2, players=players[:6]), dict(side=3, players=players[6:])]),
        {str(i): p['name'] for i, p in enumerate(players, 1)}, None, True)
    ctl.refresh()
    ctl.import_vdo_guests('room', changed)
    assert ctl.owners[6] == '7' and ctl.vdo_guest_bank('room', 'new-stream') is None
    ep.protected.clear()
    ep.protection_known = False
    ctl.import_vdo_guests('room', changed)
    assert ctl.owners[6] == '7'
    ep.protection_known = True
    ctl.import_vdo_guests('room', changed)
    assert ctl.owners == list(map(str, ids))
    assert ctl.vdo_guest_bank('room', 'new-stream') == 7
    assert not ep.takes and ep.pages[guid(7)] == camera_page(new['page'])


def test_conflicting_labels_for_previously_linked_streams_clear_only_their_sources(create):
    ctl = create()
    confirm(ctl)
    guests = [guest(f'stream-{i}', f'player-{i}') for i in range(1, 13)]
    ctl.import_vdo_guests('room', guests)
    collision = [dict(guests[0], label=' PLAYER-2 '), *guests[1:]]
    ctl.import_vdo_guests('room', collision)
    assert ctl.owners == list(map(str, range(1, 13)))
    assert not ctl.has_camera('1') and not ctl.has_camera('2')
    assert all(ctl.has_camera(str(i)) for i in range(3, 13))
    ctl.import_vdo_guests('room', guests)
    assert all(ctl.has_camera(str(i)) for i in range(1, 13))


def test_new_roster_collision_quarantines_before_next_director_poll(create):
    ctl = create()
    confirm(ctl)
    ctl.import_vdo_guests('room', [guest('one', 'player-1')])
    assert ctl.has_camera('1')
    players = [dict(accountId=i, name=f'player-{i}') for i in range(1, 13)]
    players[1]['name'] = 'PLAYER-1'
    ctl.roster.update_match(dict(matchId='12', teams=[
        dict(side=2, players=players[:6]), dict(side=3, players=players[6:])]), {}, None, False)
    assert not ctl.has_camera('1') and ctl.vdo_bank_status('1') == 'Конфликт Label'
    assert ctl.vdo_guest_bank('room', 'one') is None


def test_all_twelve_depart_and_new_match_fills_the_banks_without_manual_reset(create):
    ctl = create()
    old = [guest(f'old-{i}', f'oldplayer-{i}') for i in range(12)]
    ctl.import_vdo_guests('same-room', old)
    upcoming = [guest(f'next-{i}', f'nextplayer-{i}') for i in range(12)]
    ctl.import_vdo_guests('same-room', upcoming)
    assert ctl.owners == [f'nick:nextplayer-{i}' for i in range(12)]
    assert all(ctl.vdo_guest_bank('same-room', g['streamID']) == i for i, g in enumerate(upcoming, 1))
    assert not any(ctl.vdo_guest_bank('same-room', g['streamID']) for g in old)


def test_guest_names_fold_case_and_edges_while_preserving_distinct_internal_spaces(create):
    ctl = create()
    original, draft = ctl.preparation_rows(), ctl.preparation_rows()
    draft[1], draft[5] = ('', 'Ab  Cd', ''), ('', 'AB CD', '')
    ctl.save_preparation(original, draft)
    single, double = guest('single', ' ab cd '), guest('double', ' AB  CD ')
    ctl.import_vdo_guests('room', [single, double])
    assert ctl.vdo_guest_bank('room', 'single') == 6 and ctl.vdo_guest_bank('room', 'double') == 2
    players = [dict(accountId=i, name=f'player-{i}') for i in range(1, 13)]
    players[0]['name'], players[1]['name'] = 'ab cd', 'AB  CD'
    ctl.roster.update_match(dict(matchId='12', teams=[
        dict(side=2, players=players[:6]), dict(side=3, players=players[6:])]), {}, None, False)
    ctl.roster.apply.click()
    ctl.refresh()
    assert ctl.owners[5] == '1' and ctl.owners[1] == '2'
    assert ctl.roster.pages['1'] == single['page'] and ctl.roster.pages['2'] == double['page']


def test_earlier_folded_preparation_spelling_recovers_and_import_waits_for_fresh_evidence(create):
    ctl = create()
    original, draft = ctl.preparation_rows(), ctl.preparation_rows()
    draft[4] = ('', 'Double  Space', '')
    ctl.save_preparation(original, draft)
    guest_row = guest('one', 'Double  Space')
    ctl.import_vdo_guests('room', [guest_row])
    saved = json.loads(ctl.settings.value('cameraRoutingV1'))
    saved.pop('labelMatching')
    key = saved['owners'][4]
    old_key = 'nick:double space'
    saved['owners'][4] = saved['vdoBanks'][4]['owner'] = old_key
    saved['labels'][old_key] = saved['labels'].pop(key)
    saved['pendingPages'][old_key] = saved['pendingPages'].pop(key)
    ctl.settings.setValue('cameraRoutingV1', json.dumps(saved))
    restored = create()
    assert restored.owners[4] == key and not restored.has_camera(key)
    assert restored.vdo_guest_bank('room', 'one') is None
    restored.import_vdo_guests('room', [guest_row])
    assert restored.vdo_guest_bank('room', 'one') == 5 and restored.has_camera(key)


def test_confirmed_steam_nickname_can_change_during_a_continuous_guest_session(create):
    ctl = create()
    ctl.apply('live', dict(defaults('live'), enabled=True, guids=[guid(i) for i in range(1, 13)]))
    confirm(ctl)
    g = guest('stable', 'player-1')
    ctl.import_vdo_guests('room', [g])
    players = [dict(accountId=i, name=f'player-{i}') for i in range(1, 13)]
    players[0]['name'] = 'New Nick'
    ctl.roster.update_match(dict(matchId='12', teams=[
        dict(side=2, players=players[:6]), dict(side=3, players=players[6:])]),
        {str(i): p['name'] for i, p in enumerate(players, 1)}, None, True)
    ctl.refresh()
    ep = next(iter(ctl.endpoints.values()))
    assert ctl.has_camera('1') and ep.names[guid(1)] == 'New Nick' and not ep.takes
    ctl.import_vdo_guests('room', [g])
    assert ctl.has_camera('1') and ctl.vdo_guest_bank('room', 'stable') == 1
    ctl.import_vdo_guests('room', [])
    ctl.import_vdo_guests('room', [g])
    assert not ctl.has_camera('1') and ep.pages[guid(1)] == TRANSPARENT_PAGE
    ctl.import_vdo_guests('room', [dict(g, label='New Nick')])
    assert ctl.has_camera('1') and not ep.takes


def test_reconnected_director_does_not_inherit_renamed_guest_trust(create):
    ctl = create()
    confirm(ctl)
    g = guest('stable', 'player-1')
    ctl.import_vdo_guests('room', [g])
    ctl.roster.players['1']['name'] = 'Renamed'
    assert ctl.has_camera('1')
    ctl.end_vdo_session()
    assert ctl.has_camera('1')  # hold the last output while the Director is offline
    ctl.import_vdo_guests('room', [g])
    assert not ctl.has_camera('1')


def test_grace_held_guest_retains_image_without_renewing_identity(create):
    ctl = create()
    confirm(ctl)
    g = guest('stable', 'player-1')
    ctl.import_vdo_guests('room', [g], observed_streams={'stable'})
    ctl.roster.players['1']['name'] = 'Renamed'
    ctl.import_vdo_guests('room', [g], observed_streams={'stable'})
    assert ctl.has_camera('1')
    ctl.import_vdo_guests('room', [g], observed_streams=set())
    assert ctl.has_camera('1')
    ctl.import_vdo_guests('room', [g], observed_streams={'stable'})
    assert not ctl.has_camera('1') and ctl.vdo_bank_status('1') == 'Конфликт Label'
    ctl.import_vdo_guests('room', [dict(g, label='Renamed')], observed_streams={'stable'})
    assert ctl.has_camera('1')


def test_confirmed_departure_allows_reissued_id_to_move_only_to_the_new_steam_player(create):
    ctl = create()
    confirm(ctl)
    first = guest('reused', 'player-1')
    ctl.import_vdo_guests('room', [first])
    ctl.import_vdo_guests('room', [])
    ctl.import_vdo_guests('room', [dict(first, label='player-8')])
    assert ctl.owners[:2] == ['1', '8']
    assert not ctl.has_camera('1') and ctl.has_camera('8')
    assert ctl.vdo_guest_bank('room', 'reused') == 2
    ctl.import_vdo_guests('room', [])
    assert not ctl.has_camera('8')
