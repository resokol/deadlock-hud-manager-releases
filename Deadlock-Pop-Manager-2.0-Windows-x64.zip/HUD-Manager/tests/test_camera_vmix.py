from threading import Event
from urllib.parse import parse_qsl, urlsplit

import pytest

from test_vmix_control import app, fake_api, wait_for, process_events
from observer_assist import camera_vmix


A = '96a935d1-a250-4a9b-8397-cb3be7c25499'
B = 'f2f903de-22e8-4af2-a795-d48c8dd48244'
C = '92394160-0c38-4c63-9829-4c0c62a4fed5'
D = '6315fd7f-ab86-496b-b8ff-9d66bfc18484'
PAGE = 'https://video.test/room?key=secret&codec=a%2Bb#video'


def state(preset='show', number=8):
    return f'''<vmix><preset>{preset}</preset><inputs>
    <input key="{{{A.upper()}}}" number="{number}" title="Camera" type="Browser"/>
    <input key="{B}" number="3" title="Composition" type="Colour">
      <overlay index="1" key="{C}"/></input>
    <input key="{C}" number="4" title="Nested" type="Colour">
      <overlay index="0" key="{A}"/></input>
    <input key="{D}" number="9" title="Other" type="Capture"/>
    </inputs><active>3</active><mix number="2"><active>4</active></mix>
    <outputs><output type="Output" number="1" source="Output"/></outputs></vmix>'''.encode()


@pytest.fixture
def endpoint(app, fake_api, monkeypatch):
    monkeypatch.setattr(camera_vmix, 'POLL_MS', 100)
    fake_api.answer = lambda path: (200, {}, state() if path == '/api/' else b'')
    obj = camera_vmix.CameraEndpoint()
    obj.configure('127.0.0.1', fake_api.server_port, True)
    wait_for(lambda: obj.online)
    yield obj
    obj.close()


def writes(server):
    return [dict(parse_qsl(urlsplit(p).query)) for p in server.requests if '?' in p]


def test_tally_and_conservative_protection(endpoint, fake_api):
    assert endpoint.inputs[A] == dict(number=8, title='Camera', type='Browser')
    assert endpoint.mixes == {1: B, 2: C}
    assert endpoint.layers == {(B, 2): C, (C, 1): A}
    assert endpoint.layer_source(B, 2) == C
    assert endpoint.protection_known and endpoint.protected == {A, B, C}
    fake_api.answer = lambda _: (200, {}, state().replace(b'source="Output"', b'source="Input" input="9"'))
    wait_for(lambda: D in endpoint.protected)
    fake_api.answer = lambda _: (200, {}, state().replace(b'source="Output"', b'source="MultiView"'))
    wait_for(lambda: not endpoint.protection_known)
    assert {A, B, C} <= endpoint.protected


def test_navigation_survives_disable_and_network_loss_but_not_new_preset(endpoint, fake_api):
    events = []
    endpoint.event.connect(events.append)
    address = '127.0.0.1', fake_api.server_port
    endpoint.sync({C: 'Player (Virtual)'}, {A: PAGE})
    wait_for(lambda: endpoint.ready(A, PAGE) and any(q['Function'] == 'SetInputName' for q in writes(fake_api)))
    endpoint.configure(*address, False)
    endpoint.sync({}, {})
    endpoint.sync({}, {A: PAGE})
    endpoint.configure(*address, True)
    wait_for(lambda: endpoint.ready(A, PAGE))
    fake_api.answer = lambda _: (503, {}, b'')
    wait_for(lambda: not endpoint.online)
    assert not endpoint.take(A)
    fake_api.answer = lambda path: (200, {}, state() if path == '/api/' else b'')
    wait_for(lambda: endpoint.ready(A, PAGE))
    navigations = lambda: [q for q in writes(fake_api) if q['Function'] == 'BrowserNavigate']
    assert navigations() == [dict(Function='BrowserNavigate', Input=A, Value=PAGE)]
    fake_api.answer = lambda path: (200, {}, state('other') if path == '/api/' else b'')
    wait_for(lambda: len(navigations()) == 2 and endpoint.ready(A, PAGE))
    assert all('secret' not in e for e in events)


def test_independent_destinations_and_fresh_layer_numbers(endpoint, fake_api):
    fake_api.answer = lambda path: (200, {}, state(number=7) if path == '/api/' else b'')
    assert endpoint.take(A, mix=1)
    assert endpoint.take(D, mix=2)
    assert endpoint.take(A, target=B, layer=2)
    assert not endpoint.take(B, target=B)
    assert not endpoint.take(A, mix=17)
    wait_for(lambda: len(writes(fake_api)) == 3)
    assert writes(fake_api) == [
        dict(Function='ActiveInput', Input=A, Mix='0'),
        dict(Function='ActiveInput', Input=D, Mix='1'),
        dict(Function='SetLayer', Input=B, Value='2,7')]
    assert endpoint.mixes[1] == B


def test_disconnect_and_cancel_prevent_queued_takes(endpoint, fake_api):
    release = Event()
    failure = [False]
    def answer(path):
        if path == '/api/':
            release.wait(2)
            return (503, {}, b'') if failure[0] else (200, {}, state())
        return 200, {}, b''
    fake_api.answer = answer
    try:
        assert endpoint.take(A)
        assert endpoint.take(D, mix=2)
        endpoint.cancel_take(1)
        wait_for(lambda: len(fake_api.requests) >= 2)
        failure[0] = True
    finally:
        release.set()
    wait_for(lambda: not endpoint.online)
    failure[0] = False
    wait_for(lambda: endpoint.online)
    process_events(70)
    assert not writes(fake_api)


def test_changed_original_cancels_copy_choice_and_selective_restore(endpoint, fake_api):
    endpoint.sync({}, {A: PAGE})
    wait_for(lambda: endpoint.ready(A, PAGE))
    assert endpoint.take(C, mix=2, original=A, page=PAGE)
    assert not endpoint.protection_known
    new_page = 'https://video.test/new'
    endpoint.sync({}, {A: new_page})
    wait_for(lambda: endpoint.ready(A, new_page))
    assert not any(q['Function'] == 'ActiveInput' for q in writes(fake_api))
    endpoint.forget_pages([A])
    assert not endpoint.ready(A, new_page)
    wait_for(lambda: endpoint.ready(A, new_page))
    assert [q['Value'] for q in writes(fake_api)] == [PAGE, new_page, new_page]


def test_newest_choice_per_mix_wins_and_cancel_keeps_other_mix(endpoint, fake_api):
    assert endpoint.take(A)
    assert endpoint.take(C, mix=2)
    assert endpoint.take(D)
    endpoint.cancel_take(2)
    wait_for(lambda: endpoint.protection_known)
    assert writes(fake_api) == [dict(Function='ActiveInput', Input=D, Mix='0')]


def test_failed_browser_allows_remaining_inputs_to_sync_and_redacts_url(endpoint, fake_api):
    messages = []
    endpoint.event.connect(messages.append)
    second = state().replace(b'type="Capture"', b'type="Browser"')
    fake_api.answer = lambda path: (200, {}, second) if path == '/api/' else (
        500 if dict(parse_qsl(urlsplit(path).query)).get('Input') == A else 200, {}, b'')
    endpoint.sync({}, {A: PAGE, D: PAGE + '2'})
    wait_for(lambda: endpoint.ready(D, PAGE + '2'))
    assert not endpoint.ready(A, PAGE)
    assert not endpoint.take(A)
    assert endpoint.online
    assert messages and all('secret' not in message for message in messages)


def test_virtual_browser_and_missing_external_routes(endpoint, fake_api):
    modified = state().replace(b'type="Browser"', b'type="Browser" virtual="True"')
    modified = modified.replace(b'<outputs>', b'<unreported>').replace(b'</outputs>', b'</unreported>')
    fake_api.answer = lambda path: (200, {}, modified if path == '/api/' else b'')
    wait_for(lambda: not endpoint.protection_known)
    endpoint.sync({A: 'Virtual Player'}, {A: PAGE})
    wait_for(lambda: writes(fake_api))
    assert writes(fake_api)[0]['Function'] == 'SetInputName'
    assert not any(q['Function'] == 'BrowserNavigate' for q in writes(fake_api))
