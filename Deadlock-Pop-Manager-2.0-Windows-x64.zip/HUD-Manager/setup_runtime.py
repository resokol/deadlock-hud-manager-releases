"""Install the exact Windows dependencies used by the portable Companion build."""
import hashlib
import json
import os
import shutil
import sys
import time
import urllib.request
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
CACHE = ROOT / '.setup-cache'


def digest(path):
    with path.open('rb') as fp:
        return hashlib.file_digest(fp, 'sha256').hexdigest()


def obtain(package):
    target = CACHE / package['name']
    if target.is_file() and digest(target) == package['sha256']:
        return target
    part = target.with_suffix('.part')
    for attempt in range(3):
        try:
            print('Downloading ' + package['name'], flush=True)
            with urllib.request.urlopen(package['url'], timeout=90) as response, part.open('wb') as output:
                shutil.copyfileobj(response, output, 1024*1024)
            if digest(part) != package['sha256']:
                raise ValueError('Checksum mismatch: ' + package['name'])
            os.replace(part, target)
            return target
        except (OSError, ValueError):
            part.unlink(missing_ok=True)
            if attempt == 2:
                raise
            time.sleep(2)
            

def install():
    packages = json.loads((ROOT / 'packages.json').read_bytes())
    stamp = digest(ROOT / 'packages.json')
    marker = ROOT / '.runtime-ready'
    if marker.is_file() and marker.read_text().strip() == stamp:
        return
    site = ROOT / 'runtime/Lib/site-packages'
    downloaded = []
    for package in packages['wheels']:
        archive = obtain(package)
        with ZipFile(archive) as z:
            z.extractall(site)
        downloaded.append(archive)
    archive = obtain(packages['node'])
    with ZipFile(archive) as z:
        for source, name in [('node.exe', 'node.exe'), ('LICENSE', 'NODE-LICENSE.txt')]:
            dest = ROOT / 'observer_assist/source_tv' / name
            with z.open('node-v22.22.0-win-x64/' + source) as src, dest.open('wb') as output:
                shutil.copyfileobj(src, output)
    downloaded.append(archive)
    marker.write_text(stamp)
    for archive in downloaded:
        archive.unlink(missing_ok=True)
    print('Ready.',flush=True)


if __name__ == '__main__':
    try:
        import msvcrt
        CACHE.mkdir(exist_ok=True)
        with (CACHE / 'install.lock').open('a+b') as lock:
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
            install()
    except Exception as error:
        print('Setup error:', error, file=sys.stderr)
        sys.exit(1)
