@echo off
setlocal
cd /d "%~dp0"
set "PATH=%~dp0runtime;%~dp0runtime\Lib\site-packages\PySide6;%PATH%"
"runtime\python.exe" -E -s start_portable.py %*
if errorlevel 1 pause
