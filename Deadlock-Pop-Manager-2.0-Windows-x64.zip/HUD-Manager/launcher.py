import sys


def main():
    if sys.argv[1:] == ['--check-release-config']:
        from observer_assist.release_ui import release_config

        try:
            release_config()
        except (ImportError, OSError, ValueError):
            return 1
        return 0
    if len(sys.argv) > 1 and sys.argv[1] == '--build-game-icons':
        from observer_assist.game_icons import main as build_icons

        return build_icons(sys.argv[2:])
    if len(sys.argv) in (3, 4) and sys.argv[1] == '--restore-panorama-pack':
        from pathlib import Path
        from observer_assist.panorama_mount import watch

        watch(Path(sys.argv[2]), *sys.argv[3:])
        return 0
    if len(sys.argv) > 1:
        from observer_assist.__main__ import main as observer_main

        return observer_main(sys.argv[1:])

    from observer_assist.hud_manager import main as manager_main

    return manager_main()

if __name__ == '__main__':
    raise SystemExit(main())
