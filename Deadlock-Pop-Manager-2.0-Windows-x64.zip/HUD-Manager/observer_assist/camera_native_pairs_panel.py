"""Select existing virtual copies by their actual GUIDs before rearranging the preset."""
from xml.etree.ElementTree import ParseError

from PySide6.QtCore import QSignalBlocker, Qt, QUrl, Signal
from PySide6.QtWidgets import (
    QComboBox, QDialog, QDialogButtonBox, QFormLayout, QHBoxLayout, QHeaderView, QLabel, QMessageBox,
    QPushButton, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget,
)

from .camera_native_setup import NativePoolSetup, pair_signature, pool_key
from .camera_native_sync import NativePair, read_native_catalog
from .camera_vdo_publish import VmixRequest
from .camera_vmix import browser_source, virtual_source


class NativePairBindings(QWidget):
    changed = Signal()
    pool_ready = Signal()

    def __init__(self, settings, parent=None, *, endpoint=None, can_setup=None):
        super().__init__(parent)
        self.settings = settings
        self.endpoint = endpoint
        self.can_setup = can_setup
        self.setup = NativePoolSetup(settings, self)
        self.setup.finished.connect(self._pool_finished)
        self.receipt = None
        self.parents = {}
        self.inputs = {}
        self.confirmed = False
        self.http = VmixRequest(self)
        layout = QVBoxLayout(self)
        self.hint = QLabel('После подготовки браузеров выберите их существующие виртуальные копии.')
        self.hint.setWordWrap(True)
        self.hint.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.hint)
        self.table = QTableWidget(12, 2)
        self.table.setHorizontalHeaderLabels(['Оригинал Web Browser', 'Виртуальная копия без кадрирования'])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.verticalHeader().hide()
        self.table.setMaximumHeight(350)
        self.choices = []
        for idx in range(12):
            self.table.setItem(idx, 0, QTableWidgetItem())
            choice = QComboBox()
            choice.setAccessibleName(f'Виртуальная копия оригинала {idx+1}')
            choice.currentIndexChanged.connect(self._edited)
            self.table.setCellWidget(idx, 1, choice)
            self.choices.append(choice)
        layout.addWidget(self.table)
        buttons = QHBoxLayout()
        self.refresh = QPushButton('Прочитать входы vMix')
        self.refresh.clicked.connect(self.read)
        self.accept = QPushButton('Подтвердить пары')
        self.accept.clicked.connect(self._confirm)
        buttons.addWidget(self.refresh)
        buttons.addWidget(self.accept)
        self.provision = QPushButton('Проверить пул и создать недостающие Virtual Input')
        self.provision.clicked.connect(self._provision)
        buttons.addWidget(self.provision)
        buttons.addStretch()
        layout.addLayout(buttons)
        self.pool_status = QLabel()
        self.pool_status.setTextFormat(Qt.TextFormat.PlainText)
        self.pool_status.setWordWrap(True)
        layout.addWidget(self.pool_status)
        self.set_receipt(None)

    def set_receipt(self, receipt):
        self.http.cancel()
        self.receipt = receipt if receipt and len(receipt.rows) == 12 else None
        self.inputs, self.parents = {}, {}
        self.confirmed = False
        self.table.setVisible(bool(self.receipt))
        self.refresh.setEnabled(bool(self.receipt))
        self.accept.setEnabled(False)
        self.changed.emit()
        if self.receipt:
            self.read()
        else:
            self.hint.setText('Подготовьте 12 существующих оригиналов на входах 1–12.')

    def _key(self, guid):
        return pool_key(self.receipt.endpoint, self.receipt.preset, guid)

    def read(self):
        receipt = self.receipt
        if not receipt:
            return
        self.http.cancel()
        self.confirmed = False
        self.accept.setEnabled(False)
        self.changed.emit()
        def receive(error, data):
            if self.receipt is not receipt:
                return
            try:
                if error:
                    raise ValueError('Нет ответа vMix.')
                state, parents = read_native_catalog(data)
                if state.preset != receipt.preset:
                    raise ValueError('Пресет vMix изменился. Повторите подготовку оригиналов.')
                for row in receipt.rows:
                    info = state.inputs.get(row.guid, {})
                    if not browser_source(info) or row.guid in parents or not 1 <= info['number'] <= 12:
                        raise ValueError('Банк 1–12 должен содержать подготовленные браузерные оригиналы.')
            except (ValueError, ParseError, KeyError) as exc:
                self.inputs, self.parents = {}, {}
                self.table.setEnabled(False)
                self.hint.setText(str(exc) if isinstance(exc, ValueError) else 'Не удалось прочитать каталог vMix.')
                self.changed.emit()
                return
            self.inputs, self.parents = state.inputs, parents
            self.table.setEnabled(True)
            self._populate()

        self.hint.setText('Чтение GUID из пресета…')
        host, port = receipt.endpoint
        self.http.send(QUrl(f'http://{host}:{port}/api/'), None, receive)

    def _populate(self):
        candidates = sorted(((info['number'], guid, info['title']) for guid, info in self.inputs.items()
                             if 13 <= info['number'] <= 24 and virtual_source(info)))
        for idx, row in enumerate(self.receipt.rows):
            actual = self.inputs[row.guid]
            self.table.item(idx, 0).setText(f"№ {actual['number']} · {actual['title']}")
            choice = self.choices[idx]
            with QSignalBlocker(choice):
                choice.clear()
                choice.addItem('Выберите копию', '')
                linked = []
                for number, guid, title in candidates:
                    if guid in self.parents and self.parents[guid] != row.guid:
                        continue
                    choice.addItem(f'№ {number} · {title}', guid)
                    if self.parents.get(guid) == row.guid:
                        linked.append(guid)
                saved = self.settings.value(self._key(row.guid), '', type=str)
                recommendation = linked[0] if len(linked) == 1 else saved
                choice.setCurrentIndex(max(0, choice.findData(recommendation)))
        selected = self.mapping()
        opposite = self.settings.value(self._key('approvedPairs'), '', type=str)
        self.confirmed = bool(selected and (self._signature(selected) == opposite
                              or all(self.parents.get(copy) == source for source, copy in selected.items())))
        self._render()

    @staticmethod
    def _signature(mapping):
        return pair_signature(mapping)

    def mapping(self):
        if not self.receipt or not self.inputs:
            return {}
        selected = {row.guid: self.choices[i].currentData() for i, row in enumerate(self.receipt.rows)}
        if len(selected) == 12 and all(selected.values()) and len(set(selected.values())) == 12:
            return selected
        return {}

    def _edited(self):
        self.confirmed = False
        self._render()

    def _render(self):
        ready = bool(self.mapping())
        self.accept.setEnabled(ready and not self.confirmed)
        self.hint.setText('Подтверждены 12 пар по GUID.' if self.confirmed else
                          'Проверьте в vMix, что выбранная копия создана из указанного оригинала. '
                          'Для каждого оригинала нужна своя копия из банка 13–24.')
        self.changed.emit()

    def _confirm(self):
        mapping = self.mapping()
        if not mapping:
            return
        for original, copy in mapping.items():
            self.settings.setValue(self._key(original), copy)
        self.settings.setValue(self._key('approvedPairs'), self._signature(mapping))
        self.confirmed = True
        self._render()

    def cancel(self):
        self.http.cancel()
        self.setup.cancel()

    def _provision(self):
        def target():
            return self.endpoint() if self.endpoint else self.receipt.endpoint if self.receipt else None

        endpoint = target()
        if not endpoint:
            self.pool_status.setText('Сначала укажите адрес и порт vMix.')
            return
        if self.can_setup and not self.can_setup():
            self.pool_status.setText('Дождитесь завершения текущей операции с входами.')
            return
        self.provision.setEnabled(False)
        self.pool_status.setText('Проверка нативных входов vMix…')
        self.setup.start(endpoint,
                         validate=lambda: endpoint == target() and (not self.can_setup or self.can_setup()),
                         confirm_pairs=self._confirm_existing, confirm_retry=self._confirm_retry)

    def _pool_finished(self, ok, message):
        self.provision.setEnabled(True)
        self.pool_status.setText(message)
        if ok:
            if self.receipt:
                self.read()
            self.pool_ready.emit()

    def _confirm_retry(self, number):
        answer = QMessageBox.question(self, 'Проверка предыдущей команды',
            f'vMix не показал новую копию оригинала {number}. Проверьте в vMix, что копия действительно '
            'отсутствует. Повторить создание?', QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        return answer == QMessageBox.StandardButton.Yes

    def _confirm_existing(self, inputs, originals, copies):
        dialog = QDialog(self)
        dialog.setWindowTitle('Происхождение виртуальных входов')
        form = QFormLayout(dialog)
        help_text = QLabel('vMix скрыл родительские GUID. Для каждой копии сверьте в пресете, '
                           'из какого браузера она создана, и выберите его в списке.')
        help_text.setWordWrap(True)
        form.addRow(help_text)
        choices = []
        for copy in copies:
            choice = QComboBox()
            choice.addItem('Укажите оригинал', None)
            for guid in originals:
                info = inputs[guid]
                choice.addItem(f"№ {info['number']} · {info['title']}", guid)
            choices.append(choice)
            info = inputs[copy]
            label = QLabel(f"Копия № {info['number']} · {info['title']}")
            label.setTextFormat(Qt.TextFormat.PlainText)
            form.addRow(label, choice)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        accept = buttons.button(QDialogButtonBox.StandardButton.Ok)
        accept.setText('Подтвердить пары')
        accept.setEnabled(False)
        def validate():
            selected = [choice.currentData() for choice in choices]
            accept.setEnabled(all(selected) and len(set(selected)) == len(choices))
        for choice in choices:
            choice.currentIndexChanged.connect(validate)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        form.addRow(buttons)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            return {choice.currentData(): copy for choice, copy in zip(choices, copies)}
        return None

    def pairs(self, originals):
        mapping = self.mapping()
        if not self.confirmed or len(originals) != 12 or {r.guid for r in originals} != mapping.keys():
            return ()
        return tuple(NativePair(r.guid, mapping[r.guid], r.name, operator_verified=True) for r in originals)
