"""Monitor video availability on verified native vMix pairs after an operator sync."""

from dataclasses import dataclass
from hashlib import sha256
from ipaddress import IPv4Address
from time import monotonic
from urllib.parse import parse_qsl, urlsplit
from xml.etree import ElementTree

from PySide6.QtCore import QObject, QTimer, QUrl, Signal

from .camera_native_geometry import read_input_alphas
from .camera_native_sync import NativePair, check_native_layout, read_native_catalog
from .camera_preparation import TRANSPARENT_PAGE, camera_identity, camera_page
from .camera_vdo_publish import VmixRequest
from .match_stats import is_lan_address


def _desired_page(evidence):
    if not isinstance(evidence, (list, tuple)) or len(evidence) != 2:
        return None
    media, viewer = evidence
    if media == 'absent':
        return TRANSPARENT_PAGE
    if media != 'live' or not isinstance(viewer, str) or not viewer:
        return None
    try:
        url = urlsplit(viewer)
        selectors = {key.casefold() for fields in (url.query, url.fragment.lstrip('?&'))
                     for key, _ in parse_qsl(fields, keep_blank_values=True, max_num_fields=180)}
        if selectors.intersection({'director', 'dir', 'push', 'scene'}):
            return None
        if (url.scheme == 'https' and url.username is None and url.password is None
                and url.port in (None, 443) and camera_identity(viewer)[0] == 'vdo'):
            return camera_page(viewer)
    except (ValueError, UnicodeError):
        pass
    return None


@dataclass
class _AlphaMask:
    original: int
    virtual: int
    touched: int = 0  # One recovery bit per GUID, written before each first SetAlpha.


class NativeCameraMonitor(QObject):
    """Mask verified native pairs; navigate only their shared original browser."""

    status = Signal(str)
    changed = Signal()
    source_navigated = Signal()
    interval_ms = 1000
    max_backoff_ms = 30000

    def __init__(self, publisher, parent=None, *, settings=None):
        super().__init__(parent)
        self.publisher = publisher
        self._http = VmixRequest(self)
        self._timer = QTimer(self, singleShot=True)
        self._timer.timeout.connect(self._tick)
        self._generation = 0
        self._running = False
        self._busy = False
        self._retries = {}
        self._last_desired = {}
        self._message = ''
        self._pairs = ()
        self._media = self._validate = None

        self._enabled = True
        self._settings = settings
        self._masks = {}
        self._hidden = set()
        self._masked_inputs = set()

    @property
    def active(self):
        return self._running and self._enabled

    def set_enabled(self, enabled):
        if self._enabled == bool(enabled):
            return
        self._enabled = bool(enabled)
        self._generation += 1
        self._http.cancel()
        self._timer.stop()
        self._busy = False
        self._hidden.clear()
        self._masked_inputs.clear()
        self.refresh()

    def set_interval_ms(self, milliseconds):
        self.interval_ms = max(1000, min(2000, int(milliseconds)))
        self.refresh()

    def start(self, endpoint, preset, pairs, *, media, validate, prematch=False):
        self.stop()
        try:
            host, port = endpoint
            ip = IPv4Address(host)
            pairs = tuple(pairs)
            if (not (ip.is_loopback or is_lan_address(ip)) or type(port) is not int or not 1 <= port <= 65535
                    or not isinstance(preset, str) or len(pairs) != 12
                    or any(not isinstance(p, NativePair) for p in pairs)
                    or not callable(media) or not callable(validate)):
                return False
        except (TypeError, ValueError):
            return False
        self._endpoint = (str(ip), port)
        self._url = QUrl(f'http://{ip}:{port}/api/')
        self._preset, self._pairs = preset, pairs
        self._prematch = prematch
        scope = sha256(f'{ip}:{port}/{preset}'.encode()).hexdigest()
        self._keys = {p.original_guid: f'nativeAlpha/{scope}/{p.original_guid}_{p.virtual_guid}' for p in pairs}
        if self._settings is not None:
            for key in self._keys.values():
                saved = self._settings.value(key, '', type=str).split(',')
                if len(saved) == 3 and all(v.isascii() and v.isdigit() and len(v) <= 3 for v in saved):
                    original, virtual, touched = map(int, saved)
                    if original <= 255 and virtual <= 255 and 0 < touched <= 3:
                        self._masks[key] = _AlphaMask(original, virtual, touched)
        self._media, self._validate = media, validate
        self._running = True
        self.refresh()
        return True

    def stop(self):
        self._generation += 1
        self._running = self._busy = False
        self._timer.stop()
        self._http.cancel()
        self._pairs = ()
        self._media = self._validate = None
        self._retries.clear()
        self._last_desired.clear()
        self._masks = {key: mask for key, mask in self._masks.items() if mask.touched and self._settings is None}
        self._hidden.clear()
        self._masked_inputs.clear()
        self._message = ''

    def refresh(self):
        if self.active and not self._busy:
            self._timer.start(0)

    def _report(self, message):
        if self._message != message:
            self._message = message
            self.status.emit(message)
            self.changed.emit()

    def _ready(self):
        try:
            return self.active and not self.publisher.busy and self._validate()
        except Exception:
            return False

    def _retry(self, key):
        previous = self._retries.get(key)
        delay = min(self.max_backoff_ms, previous[1] * 2) if previous else self.interval_ms
        self._retries[key] = monotonic() + delay / 1000, delay

    def _waiting(self, key):
        return self._retries.get(key, (0, 0))[0] > monotonic()

    def _remaining(self):
        try:
            evidence = self._media()
        except Exception:
            return
        if not isinstance(evidence, dict):
            return
        for pair in self._pairs:
            guid = pair.original_guid
            page = _desired_page(evidence.get(guid))
            if page is None:
                continue
            if self._last_desired.get(guid) != page:
                self._last_desired[guid] = page
                self._retries.pop(guid, None)
            if self._waiting(guid):
                continue
            masked = self._keys[guid] in self._masks
            if page == TRANSPARENT_PAGE and masked and guid in self._hidden:
                continue
            if masked or not self.publisher.page_acknowledged(self._endpoint, self._preset, guid, page):
                yield pair, page

    def _tick(self):
        if not self.active or self._busy:
            return
        if (not self._ready() or self._waiting(None)
                or (not self.publisher.needs_page_check(self._endpoint, self._preset)
                    and next(self._remaining(), None) is None)):
            self._timer.start(self.interval_ms)
            return
        generation = self._generation
        self._busy = True

        def catalog(error, xml):
            if self._generation != generation:
                return
            if error:
                self._retry(None)
                self._busy = False
                self._timer.start(self.interval_ms)
                self._report('Монитор камер: ожидание подключения к vMix.')
                return
            try:
                state, parents = read_native_catalog(xml)
                if state.preset != self._preset:
                    raise ValueError
                if self._prematch:
                    check_native_layout(state, parents, self._pairs, require_names=False)
                else:
                    check_native_layout(state, parents, self._pairs, sorted_names=True)
                self.publisher.observe_pages(self._endpoint, state, xml)
                alphas = read_input_alphas(xml)
            except (ElementTree.ParseError, ValueError):
                self._retry(None)
                self._busy = False
                self._timer.start(self.interval_ms)
                self._report('Монитор камер: проверьте пресет, порядок и связи входов vMix.')
                return
            self._retries.pop(None, None)
            desired = next(self._remaining(), None) if self._ready() else None
            if self._generation != generation:
                return
            if desired is None:
                self._busy = False
                self._timer.start(self.interval_ms)
                return
            pair, page = desired
            self._apply(pair, page, alphas, generation)

        self._http.send(self._url, None, catalog)

    def _bookmark(self, key, mask):
        """The two opacity values survive monitor handovers and process restarts."""
        if mask.touched:
            self._masks[key] = mask
        else:
            self._masks.pop(key, None)
        if self._settings is None:
            return True
        if mask.touched:
            values = f'{mask.original},{mask.virtual},{mask.touched}'
            self._settings.setValue(key, values)
        else:
            self._settings.remove(key)
        self._settings.sync()
        return self._settings.status() == self._settings.Status.NoError

    def _apply(self, pair, page, alphas, generation):
        guid = pair.original_guid
        key = self._keys[guid]
        mask = self._masks.get(key)
        ids = (guid, pair.virtual_guid)
        missing = page == TRANSPARENT_PAGE

        if not missing:
            self._hidden.discard(guid)
            self._masked_inputs.difference_update(ids)
        if missing and mask is None and all(g in alphas for g in ids):
            mask = _AlphaMask(*(alphas[g] for g in ids))

        # With unreadable alpha, changing the single source document leaves the
        # original and the copy's independent operator settings untouched.
        if ((not missing or mask is None)
                and not self.publisher.page_acknowledged(self._endpoint, self._preset, guid, page)):
            self.publisher.invalidate_page(self._endpoint, guid)
            self._write(pair, dict(Function='BrowserNavigate', Input=guid, Value=page), generation,
                        lambda: self.publisher.record_page(self._endpoint, self._preset, guid, page))
            return

        if mask is not None:
            for index, (target, previous) in enumerate(zip(ids, (mask.original, mask.virtual))):
                bit = 1 << index
                value = 0 if missing else previous
                if (missing and target in self._masked_inputs) or (not missing and not mask.touched & bit):
                    continue
                if alphas.get(target) == value:
                    if not missing:
                        mask.touched &= ~bit
                    continue
                if missing:
                    # Commit the recovery information before a command whose
                    # HTTP response could be lost after vMix applies it.
                    mask.touched |= bit
                    if not self._bookmark(key, mask):
                        self._busy = False
                        self._retry(guid)
                        self._timer.start(self.interval_ms)
                        self._report('Не удалось сохранить непрозрачность. Проверьте доступ к настройкам.')
                        return
                def accepted():
                    if not missing:
                        mask.touched &= ~bit
                        self._bookmark(key, mask)
                    else:
                        self._masked_inputs.add(target)
                        if all(g in self._masked_inputs or alphas.get(g) == 0 for g in ids):
                            self._hidden.add(guid)
                self._write(pair, dict(Function='SetAlpha', Input=target, Value=str(value)), generation, accepted)
                return
            if missing:
                self._hidden.add(guid)
                self._masks[key] = mask
            else:
                self._bookmark(key, mask)

        self._busy = False
        self.refresh()

    def _write(self, pair, command, generation, accepted):
        guid = pair.original_guid

        def finished(error, _):
            if self._generation != generation:
                return
            self._busy = False
            if error:
                self._retry(guid)
                self._report('Монитор камер: vMix не подтвердил команду. Повторю запрос.')
            else:
                self._retries.pop(guid, None)
                if self._ready():
                    accepted()
                    if command['Function'] == 'BrowserNavigate':
                        self.source_navigated.emit()
                    self._report('Монитор камер: доступность видео обновлена.')
            self.refresh()

        self._http.send(self._url, command, finished)
