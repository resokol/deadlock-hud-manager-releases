from dataclasses import dataclass
from math import hypot, sqrt


FORECAST_SECONDS = 3.0
MIN_CLOSING_SPEED = .015
MAX_ZONE_RADIUS = .095


@dataclass(frozen=True)
class Forecast:
    eta: float
    x: float
    y: float
    spread: float
    members: frozenset[int]
    penetration: float


def forecast_contact(a, b, distance, profile):
    """First entry into contact range under the current relative velocity."""
    if not profile.contact_radius < distance <= profile.approach_radius:
        return None
    dx, dy = b.x-a.x, b.y-a.y
    vx, vy = b.vx-a.vx, b.vy-a.vy
    closing = -(dx*vx+dy*vy)
    if closing <= MIN_CLOSING_SPEED*distance:
        return None
    speed_squared = vx*vx+vy*vy
    reach = profile.contact_radius
    discriminant = closing*closing - speed_squared*(distance*distance-reach*reach)
    if discriminant <= 0:
        return None
    # The equivalent form below avoids subtracting two nearly equal numbers.
    eta = (distance*distance-reach*reach)/(closing+sqrt(discriminant))
    if eta > FORECAST_SECONDS:
        return None
    ax, ay = a.x+a.vx*eta, a.y+a.vy*eta
    bx, by = b.x+b.vx*eta, b.y+b.vy*eta
    if not all(0 <= value <= 1 for value in (ax, ay, bx, by)):
        return None
    closest_time = min(closing/speed_squared, FORECAST_SECONDS)
    miss = hypot(dx+vx*closest_time, dy+vy*closest_time)
    return Forecast(eta, (ax+bx)/2, (ay+by)/2, reach/2, frozenset((a.id,b.id)), 1-miss/reach)


@dataclass
class InterestEvent:
    id: int
    kind: str
    x: float
    y: float
    radius: float
    rank: float
    reason: str
    members: frozenset
    first_seen: float
    last_seen: float
    intercept_since: float | None = None
    shortcut: str | None = None
    eta_seconds: float | None = None
    focus_members: frozenset[int] = frozenset()
    risk: str | None = None


class EventEngine:
    def __init__(self):
        self._next = 1
        self.reset()

    def reset(self):
        self._events = []
        self._last_time = None

    def update(self, tracks, now, profile, *, limit=3):
        if self._last_time is not None and not 0 < now-self._last_time <= 1:
            self.reset()
        self._last_time = now
        ts = [t for t in tracks if t.confidence >= .6 and t.age >= .2]
        visible_ids = {track.id for track in tracks}
        groups = []
        signals = {}
        for i,a in enumerate(ts):
            for j,b in enumerate(ts[i+1:],i+1):
                if a.team == b.team:
                    continue
                dist = hypot(a.x-b.x,a.y-b.y)
                objective = any(hypot(a.x-o.x,a.y-o.y) <= o.radius and
                                hypot(b.x-o.x,b.y-o.y) <= o.radius for o in profile.objectives)
                current = dist <= profile.contact_radius or objective
                forecast = None if current else forecast_contact(a,b,dist,profile)
                if not (current or forecast):
                    continue
                signals[i,j] = forecast
                merged = {i,j}
                others = []
                for g in groups:
                    if g & merged:
                        merged |= g
                    else:
                        others.append(g)
                groups = others + [merged]
        candidates = []
        used_old_ids = set()
        for g in sorted(groups,key=lambda group:(-len(group),min(group))):
            players = [ts[i] for i in g]
            counts = [sum(t.team == team for t in players) for team in (1,2)]
            kind, reason = 'CONTACT', 'Возможный контакт'
            group_signals = [(ts[a],ts[b],signal) for (a,b),signal in signals.items() if a in g and b in g]
            current_pairs = [(a,b) for a,b,signal in group_signals if signal is None]
            forecast = None
            risk = None
            if current_pairs:
                a,b = min(current_pairs,key=lambda pair: hypot(pair[0].x-pair[1].x,pair[0].y-pair[1].y))
                x,y = (a.x+b.x)/2,(a.y+b.y)/2
                spread = hypot(a.x-b.x,a.y-b.y)/2
                focus = frozenset((a.id,b.id))
            else:
                forecast = min((signal for _,_,signal in group_signals),key=lambda signal: signal.eta)
                x,y,spread,focus = forecast.x,forecast.y,forecast.spread,forecast.members
                kind,reason = 'APPROACH','Прогноз сближения'
                extra_players = len(players) > 2
                if forecast.eta <= 1.25 and (forecast.penetration >= .55 or extra_players):
                    risk = 'high'
                elif forecast.eta <= 2 or forecast.penetration >= .45 or extra_players:
                    risk = 'medium'
                else:
                    risk = 'low'
            rank = len(players) + 1/(.05+spread)
            if forecast:
                rank -= forecast.eta
            intercept = False
            if min(counts) == 1 and max(counts) >= 2:
                minority = 1 if counts[0]==1 else 2
                target = next(t for t in players if t.team==minority)
                has_ally = any(t.team==minority and t.id!=target.id
                               and hypot(t.x-target.x,t.y-target.y)<=profile.approach_radius for t in ts)
                approaching = 0
                for t in players:
                    if t.team==minority:
                        continue
                    dx,dy=t.x-target.x,t.y-target.y
                    closing=-(dx*(t.vx-target.vx)+dy*(t.vy-target.vy))/max(hypot(dx,dy),1e-6)
                    approaching += closing>MIN_CLOSING_SPEED
                intercept = not has_ally and approaching>=2
            for o in profile.objectives:
                if all(any(t.team == team and hypot(t.x-o.x,t.y-o.y) <= o.radius
                           for t in players) for team in (1,2)):
                    kind,reason = 'OBJECTIVE',f'Интерес у объекта · {o.name}'
                    x,y,spread = o.x,o.y,o.radius/2
                    focus = frozenset(t.id for t in players if hypot(t.x-x,t.y-y) <= o.radius)
                    rank += 3
                    break
            members = frozenset(t.id for t in players)
            matches = [e for e in self._events if e.id not in used_old_ids
                       and e.members & members and hypot(e.x-x,e.y-y) < .2]
            old = max(matches,key=lambda e: len(e.members & members)) if matches else None
            if old:
                used_old_ids.add(old.id)
            intercept_since = None
            if intercept:
                intercept_since = old.intercept_since if old and old.intercept_since is not None else now
                if kind!='OBJECTIVE' and now-intercept_since>=.25:
                    kind,reason='INTERCEPT',f'Возможный перехват · {counts[0]} на {counts[1]}'
                    rank+=1
            radius = min(MAX_ZONE_RADIUS,max(.035,spread+.02))
            event = InterestEvent(old.id if old else self._next,kind,x,y,radius,rank,reason,members,
                                  old.first_seen if old else now,now,intercept_since,
                                  eta_seconds=forecast.eta if forecast else None,
                                  focus_members=focus,risk=risk)
            if not old:
                self._next += 1
            candidates.append(event)
        # Brief observation gaps keep a marker steady; hard source failures clear
        # the entire engine through AnalysisSession rather than this hysteresis.
        claimed = set().union(*(e.members for e in candidates)) if candidates else set()
        for old in self._events:
            if (old.last_seen-old.first_seen>=.25 and now-old.last_seen <= .45
                    and old.members-visible_ids and not old.members & claimed):
                candidates.append(old)
        self._events = candidates
        return sorted([e for e in candidates if e.last_seen-e.first_seen >= .25],
                      key=lambda e:(-e.rank,e.id))[:limit]
