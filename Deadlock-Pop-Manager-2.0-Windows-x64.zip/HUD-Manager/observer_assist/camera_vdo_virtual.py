"""Bind prepared virtual copies to the current HUD positions and verify their vMix titles."""

from hashlib import sha256
from ipaddress import IPv4Address
from xml.etree import ElementTree

from PySide6.QtCore import QObject, QSignalBlocker, Qt, QTimer, QUrl, Signal
from PySide6.QtWidgets import (
    QComboBox, QHeaderView, QLabel, QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from .camera_vdo_publish import AppliedBatch, VmixRequest
from .camera_vmix import _read_state, browser_source, virtual_source
from .match_stats import is_lan_address
from .vmix_control import _guid


class VirtualCopies(QObject):
    changed = Signal()
    status = Signal(str)

    def __init__(self, settings, authorize=None, parent=None, *, authorize_automatic=None):
        super().__init__(parent)
        self.settings = settings
        self.authorize = authorize
        self.authorize_automatic = authorize_automatic
        self._auto_pending = False
        self.receipt = None
        self.revision = None
        self.bindings = {}
        self.inputs = {}
        self.complete = False
        self.issue = ''
        self.phase = ''
        self._verified = False
        self._generation = 0
        self._http = VmixRequest(self)
        self._timer = QTimer(self, singleShot=True, interval=2000)
        self._timer.timeout.connect(self.refresh)

    def _interrupt(self):
        self._generation += 1
        self._timer.stop()
        self._http.cancel()
        self.phase = ''

    def set_distribution(self, receipt, revision=None):
        if receipt is not None and not self._valid_receipt(receipt):
            receipt = None
        if self.receipt is receipt and self.revision == revision:
            return
        self._interrupt()
        self.receipt, self.revision = receipt, revision
        self._auto_pending = bool(receipt)
        self.inputs, self.bindings = {}, {}
        self._verified = self.complete = False
        self.issue = ''
        if receipt:
            for row in receipt.rows:
                self.bindings[row.guid] = _guid(self.settings.value(self._key(row.guid), '', type=str)) or ''
        self.changed.emit()
        self.refresh()

    @staticmethod
    def _valid_receipt(receipt):
        if not isinstance(receipt, AppliedBatch) or len(receipt.rows) != 12:
            return False
        try:
            host, port = receipt.endpoint
            ip = IPv4Address(host)
            return (bool(ip.is_loopback or is_lan_address(ip)) and type(port) is int and 1 <= port <= 65535
                    and len({r.number for r in receipt.rows}) == len({r.guid for r in receipt.rows}) == 12
                    and all(isinstance(r.guid, str) and _guid(r.guid) == r.guid and type(r.number) is int and r.number > 0
                            and isinstance(r.label, str) and r.label.strip()
                            and (not r.empty or r.label == '-') for r in receipt.rows))
        except (AttributeError, TypeError, ValueError):
            return False

    def _key(self, guid):
        host, port = self.receipt.endpoint
        preset = sha256(self.receipt.preset.encode()).hexdigest()[:24]
        return f'vdoVirtualCopies/{host}/{port}/{preset}/{guid}'

    def _signature(self):
        pairs = sorted(self.bindings.items())
        return sha256(repr(pairs).encode()).hexdigest()

    def bind(self, slot, copy):
        if not self.receipt or self.phase in ('apply', 'take') or not 1 <= slot <= 12:
            return False
        original = self.receipt.rows[slot - 1].guid
        if copy and (_guid(copy) != copy or copy in self.bindings or not virtual_source(self.inputs.get(copy, {}))):
            return False
        if self.bindings.get(original) == copy:
            return True
        self._interrupt()
        self._auto_pending = False
        self.settings.remove(self._key('approvedPairs'))
        self.bindings[original] = copy
        self.settings.setValue(self._key(original), copy)
        self._verified = self.complete = False
        self.issue = self._problem(self.inputs)
        self.status.emit('Проверьте пары и нажмите «Обновить виртуальные копии».')
        self.changed.emit()
        self.refresh()
        return True

    def _problem(self, inputs):
        selected = set()
        for slot, row in enumerate(self.receipt.rows, 1):
            info = inputs.get(row.guid, {})
            if not browser_source(info) or info.get('number') != row.number or info.get('title') != row.label:
                return f'Позиция {slot}: оригинал № {row.number} изменился. Повторите шаг 4.'
        for slot, row in enumerate(self.receipt.rows, 1):
            copy = self.bindings.get(row.guid)
            if not copy:
                return f'Позиция {slot}: выберите виртуальную копию оригинала № {row.number}.'
            if copy in selected or copy in self.bindings:
                return f'Позиция {slot}: один вход назначен дважды.'
            if not virtual_source(inputs.get(copy, {})):
                return f'Позиция {slot}: выбранная копия отсутствует или её тип изменился.'
            selected.add(copy)
        return ''

    @property
    def can_apply(self):
        return bool(self.receipt and self.inputs and not self.issue and self.phase not in ('apply', 'take'))

    def refresh(self):
        if self.receipt and not self.phase:
            self.phase = 'poll'
            self._read(self._poll_done)

    def _url(self):
        host, port = self.receipt.endpoint
        return QUrl(f'http://{host}:{port}/api/')

    def _read(self, continuation):
        generation = self._generation
        def receive(error, payload):
            if error:
                self.inputs = {}
                self._end(f'Нет связи с Web Controller ({error}).', invalid=False)
                return
            try:
                state = _read_state(payload)
            except (ValueError, ElementTree.ParseError):
                self.inputs = {}
                self._end('Некорректный список входов vMix.')
                return
            if self.receipt.preset and self.receipt.preset != state.preset:
                self.inputs = {}
                self._end('Открыт другой пресет. Повторите шаг 4.')
                return
            self.inputs = state.inputs
            self.issue = self._problem(self.inputs)
            if self.issue:
                self._end(self.issue)
            elif generation == self._generation:
                continuation(state)
        self._http.send(self._url(), None, receive)

    def _end(self, message, *, invalid=True):
        if self.phase in ('apply', 'take'):
            self.status.emit(message)
        self.phase = ''
        self.issue = message
        if invalid:
            self._verified = self._auto_pending = False
        self.complete = False
        self.changed.emit()
        if self.receipt:
            self._timer.start()

    def _poll_done(self, state):
        self.phase = ''
        self.complete = self._verified and self._titles_match(state)
        if self._auto_pending:
            self._auto_pending = False
            approved = self.settings.value(self._key('approvedPairs'), '', type=str)
            if approved == self._signature() and (self.authorize_automatic is not None or self.authorize is None):
                self.apply(automatic=True)
                return
        if self._verified and not self.complete:
            self._verified = False
            self.status.emit('Название копии изменилось. Примените шаг 5 повторно.')
        self.changed.emit()
        if self.receipt:
            self._timer.start()

    def _titles_match(self, state):
        return all(state.inputs[self.bindings[r.guid]]['title'] == r.label for r in self.receipt.rows)

    def apply(self, *, automatic=False):
        if not self.can_apply:
            return False
        self._interrupt()
        self.complete = self._verified = False
        self.phase = 'apply'
        self._auto_pending = False
        authorize = self.authorize_automatic if automatic else self.authorize
        generation = self._generation
        self.changed.emit()
        def plan(state):
            if authorize is not None:
                try:
                    approved = authorize(self.receipt.endpoint, set(self.bindings) | set(self.bindings.values()))
                except Exception:
                    approved = False
                if generation != self._generation:
                    return
                if not approved:
                    self._end('Входами управляет другой модуль. Нажмите «Обновить виртуальные копии» для передачи управления.'
                              if automatic else 'Обновление копий отменено.')
                    return
            self._read(lambda catalog: self._rename(catalog, set()))
        if generation == self._generation:
            self._read(plan)
        return True

    def _rename(self, state, attempted):
        for row in self.receipt.rows:
            copy = self.bindings[row.guid]
            if state.inputs[copy]['title'] == row.label:
                continue
            if copy in attempted:
                self._end(f'vMix не подтвердил название копии № {state.inputs[copy]["number"]}.')
                return
            attempted.add(copy)
            def sent(error, _):
                if error:
                    self._end(f'Не удалось переименовать копию ({error}).')
                else:
                    self._read(lambda catalog: self._rename(catalog, attempted))
            self._http.send(self._url(), dict(Function='SetInputName', Input=copy, Value=row.label), sent)
            return
        self.settings.setValue(self._key('approvedPairs'), self._signature())
        self._verified = self.complete = True
        self.phase = ''
        self.status.emit('Проверено 12 виртуальных копий. Порядок Replay соответствует позициям игры.')
        self.changed.emit()
        if self.receipt:
            self._timer.start()

    def route(self, slot):
        if not self.complete or not self.receipt or not isinstance(slot, int) or not 1 <= slot <= 12:
            return None
        row = self.receipt.rows[slot - 1]
        copy = self.bindings[row.guid]
        return dict(original_guid=row.guid, original_number=row.number, virtual_guid=copy,
                    virtual_number=self.inputs[copy]['number'], title=row.label, empty=row.empty)

    def take(self, slot, mix=2):
        route = self.route(slot)
        if (not route or route['empty'] or type(mix) is not int or mix < 1
                or self.phase in ('apply', 'take')):
            return False
        self._interrupt()
        self.phase = 'take'
        def checked(state):
            if not self._titles_match(state):
                self._end('Названия входов изменились. Примените шаг 5 повторно.')
            elif not state.mixes.get(mix):
                self._poll_done(state)
                self.status.emit(f'Mix {mix} отсутствует в пресете.')
            else:
                def sent(error, _):
                    if error:
                        self._end(f'Вывод Replay не подтверждён ({error}).', invalid=False)
                    else:
                        self.phase = ''
                        self.status.emit(f'vMix принял команду Replay для позиции {slot}, Mix {mix}.')
                        self.refresh()
                self._http.send(self._url(), dict(Function='ActiveInput', Input=route['virtual_guid'], Mix=mix - 1), sent)
        self._read(checked)
        return True

    def invalidate_claim(self, endpoint, guids):
        if self.receipt and endpoint == self.receipt.endpoint and set(guids) & (set(self.bindings) | set(self.bindings.values())):
            self._interrupt()
            self._auto_pending = False
            self._end('Управление входами изменилось. Проверьте шаги 4 и 5.')

    def close_session(self):
        self.set_distribution(None)


class VirtualCopiesPanel(QWidget):
    changed = Signal()

    def __init__(self, settings, authorize=None, parent=None, *, authorize_automatic=None):
        super().__init__(parent)
        self.service = VirtualCopies(settings, authorize, self, authorize_automatic=authorize_automatic)
        layout = QVBoxLayout(self)
        instruction = QLabel('Выберите для каждого оригинала его уже созданную виртуальную копию. '
                             'Проверьте пару в vMix: некоторые пресеты показывают обе стороны как Web Browser. '
                             'Менеджер запомнит пары по GUID и присвоит копиям имена из шага 4.')
        instruction.setWordWrap(True)
        layout.addWidget(instruction)
        self.table = QTableWidget(12, 4)
        self.table.setHorizontalHeaderLabels(['Позиция', 'Оригинал', 'Название', 'Виртуальная копия vMix'])
        self.table.verticalHeader().hide()
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.choices = []
        for i in range(12):
            for column, value in enumerate((str(i + 1), '—', '—')):
                self.table.setItem(i, column, QTableWidgetItem(value))
            combo = QComboBox()
            combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
            self.table.setCellWidget(i, 3, combo)
            self.choices.append(combo)
            combo.setProperty('hudSlot', i + 1)
            combo.currentIndexChanged.connect(self._select_copy)
        layout.addWidget(self.table)
        self.apply_button = QPushButton('Обновить виртуальные копии')
        self.apply_button.clicked.connect(self.service.apply)
        layout.addWidget(self.apply_button)
        self.message = QLabel()
        self.message.setWordWrap(True)
        self.message.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.message)
        self._last = ''
        self._displayed = None
        self.service.status.connect(self._status)
        self.service.changed.connect(self._render)
        self._render()

    def _select_copy(self):
        combo = self.sender()
        self.service.bind(combo.property('hudSlot'), combo.currentData() or '')

    def _status(self, message):
        self._last = message
        self.message.setText(message)

    def _render(self):
        s = self.service
        rows = s.receipt.rows if s.receipt else ()
        candidates = [(info['number'], guid, info['title']) for guid, info in s.inputs.items()
                      if guid not in s.bindings and virtual_source(info)]
        view = rows, tuple(sorted(candidates)), tuple(s.bindings.items())
        if self._displayed != view:
            self._displayed = view
            for i, combo in enumerate(self.choices):
                row = rows[i] if i < len(rows) else None
                self.table.item(i, 1).setText(f'№ {row.number}' if row else '—')
                self.table.item(i, 2).setText(row.label if row else '—')
                with QSignalBlocker(combo):
                    combo.clear()
                    combo.addItem('Выберите копию', '')
                    for number, guid, title in view[1]:
                        public = title if '://' not in title and not title.lower().startswith('data:') else 'Web Browser'
                        combo.addItem(f'№ {number} · {public}', guid)
                        index = combo.count() - 1
                        combo.setItemData(index, guid, Qt.ItemDataRole.ToolTipRole)
                    selected = s.bindings.get(row.guid) if row else ''
                    if selected and combo.findData(selected) < 0:
                        combo.addItem('Копия отсутствует', selected)
                    combo.setCurrentIndex(max(0, combo.findData(selected)))
        self.table.setEnabled(bool(rows and s.inputs) and s.phase not in ('apply', 'take'))
        self.apply_button.setEnabled(s.can_apply)
        if not rows:
            message = 'Примените все 12 позиций на шаге 4.'
        elif s.phase == 'apply':
            message = 'Проверяем входы и обновляем имена виртуальных копий…'
        else:
            message = s.issue or self._last or 'Проверьте пары и нажмите «Обновить виртуальные копии».'
        self.message.setText(message)
        self.changed.emit()

    @property
    def complete(self):
        return self.service.complete

    def set_distribution(self, receipt, revision=None):
        if (receipt, revision) != (self.service.receipt, self.service.revision):
            self._last = ''
        self.service.set_distribution(receipt, revision)

    def route(self, slot):
        return self.service.route(slot)

    def take(self, slot, mix=2):
        return self.service.take(slot, mix)

    def invalidate_claim(self, endpoint, guids):
        self.service.invalidate_claim(endpoint, guids)

    def close_session(self):
        self.service.close_session()
