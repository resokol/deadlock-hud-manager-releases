const noticeMs = 6000;
const isSide = side => side === 2 || side === 3;
const isTime = time => Number.isFinite(time) && time > 0;

function applyStyle() {
    if (document.getElementById('hud-player-status-style')) return;
    const style = document.createElement('link');
    style.id = 'hud-player-status-style';
    style.rel = 'stylesheet';
    style.href = '/hud-player-status.css';
    document.head.append(style);
}

export function setRejuvenatorBadge(portrait, state) {
    let badge = portrait.querySelector(':scope > .hud-rejuvenator');
    if (state !== 'ready' && state !== 'spent') {
        badge?.remove();
        portrait.classList.remove('hud-rejuvenator-host');
        return;
    }
    if (!badge) {
        applyStyle();
        portrait.classList.add('hud-rejuvenator-host');
        badge = document.createElement('span');
        badge.className = 'hud-rejuvenator';
        badge.setAttribute('role', 'img');
        portrait.append(badge);
    }
    if (badge.dataset.rejuvenator === state) return;
    badge.dataset.rejuvenator = state;
    const label = state === 'ready' ? 'Rejuvenator готов' : 'Rejuvenator израсходован';
    badge.title = label;
    badge.setAttribute('aria-label', label);
}

function teamName(side, settings, teams) {
    const standard = side === 2 ? 'Янтарные' : 'Сапфировые';
    const display = side === 2 ? settings?.leftName : settings?.rightName;
    const team = Array.isArray(teams) ? teams.find(team => team?.side === side)?.name : undefined;
    return [display, team].find(name => typeof name === 'string' && name.trim())?.trim().slice(0, 96) || standard;
}

export function createMidBossNotice(container, { floating = false, onVisibility } = {}) {
    applyStyle();
    const feed = document.createElement('aside');
    feed.className = floating ? 'hud-midboss-feed hud-midboss-floating' : 'hud-midboss-feed';
    feed.hidden = true;
    feed.setAttribute('role', 'status');
    const slots = [
        { kind: 'kill', title: 'Мид-босс', fallback: 'Убит', sideField: 'killedBy', timeField: 'killedAt' },
        { kind: 'capture', title: 'Rejuvenator', fallback: 'Получен', sideField: 'claimedBy', timeField: 'claimedAt' },
    ].map(details => {
        const card = document.createElement('div');
        card.className = 'hud-midboss-card';
        card.dataset.objective = details.kind;
        card.hidden = true;
        const title = document.createElement('strong');
        const role = document.createElement('small');
        card.append(title, role);
        feed.append(card);
        return { ...details, card, heading: title, role, seen: new Set() };
    });
    container.append(feed);

    function visibility() {
        const active = slots.some(slot => !slot.card.hidden);
        feed.hidden = !active;
        onVisibility?.(active);
    }

    function clear(slot) {
        clearTimeout(slot.timer);
        slot.active = undefined;
        slot.card.hidden = true;
    }

    function label(slot, event, settings, teams) {
        const side = event[slot.sideField];
        const title = slot.title + ' · ' + (isSide(side) ? teamName(side, settings, teams) : slot.fallback);
        const stolen = slot.kind === 'capture' && isTime(event.killedAt) && isSide(event.killedBy) &&
            isSide(side) && event.killedBy !== side;
        const message = slot.kind === 'kill' ? 'Добивание' : stolen ? 'Перехват награды' : 'Захват награды';
        if (slot.heading.textContent !== title) slot.heading.textContent = title;
        if (slot.role.textContent !== message) slot.role.textContent = message;
        slot.card.dataset.team = isSide(side) ? String(side) : '';
        slot.card.hidden = false;
    }

    return {
        update(event, { settings, teams, editing = false } = {}) {
            if (editing && (!event?.id || (!isTime(event.killedAt) && !isTime(event.claimedAt)))) {
                event = { id: 'preview', killedBy: 2, killedAt: 1 };
            }
            for (const slot of slots) {
                const time = event?.[slot.timeField];
                if (typeof event?.id !== 'string' || !event.id || !isTime(time)) {
                    clear(slot);
                    continue;
                }
                const claim = slot.kind === 'capture' && typeof event.claimId === 'string' ? event.claimId : null;
                const identity = JSON.stringify([event.id, claim || null]);
                if (editing || slot.active === identity) {
                    if (editing) clear(slot);
                    label(slot, event, settings, teams);
                } else {
                    clear(slot);
                    if (slot.seen.has(identity)) continue;
                    slot.seen.add(identity);
                    if (slot.seen.size > 64) slot.seen.delete(slot.seen.values().next().value);
                    const elapsed = Math.max(0, Date.now() - time);
                    if (elapsed >= noticeMs) continue;
                    slot.active = identity;
                    label(slot, event, settings, teams);
                    slot.timer = setTimeout(() => { clear(slot); visibility(); }, noticeMs - elapsed);
                }
            }
            visibility();
        },
        remove() {
            slots.forEach(clear);
            feed.remove();
        },
    };
}
