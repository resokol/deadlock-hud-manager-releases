'use strict';

const themedHud = new Set(['deadlock-default', 'amber-sapphire', 'contour-esports', 'deadlock-sideline']);
let paintRejuvenator;

function playerStateStyle() {
    if (document.getElementById('hud-player-status-style')) return;
    const style = document.createElement('link');
    style.id = 'hud-player-status-style';
    style.rel = 'stylesheet';
    style.href = '/hud-player-status.css';
    document.head.append(style);
}

function applyPlayerState(selected, themed) {
    const root = document.documentElement;
    const lowHp = selected?.lowHp === true;
    const spree = selected?.killingSpree === true;
    const streak = Number.isInteger(selected?.killStreak) ? String(selected.killStreak) : '';
    root.toggleAttribute('data-low-hp', lowHp);
    if (spree) root.dataset.killingSpree = streak;
    else delete root.dataset.killingSpree;
    if (themed) {
        const name = document.getElementById('player-name');
        if (name && spree) name.dataset.streakLabel = streak ? 'Серия ' + streak : 'Серия убийств';
        else if (name) delete name.dataset.streakLabel;
    }
}

function decoratePortrait(portrait, player) {
    if (!portrait) return;
    paintRejuvenator?.(portrait, player?.rejuvenator);
    const count = player?.killStreak;
    const streak = Number.isInteger(count) && count >= 3 && !(parseInt(player.respawn, 10) > 0)
        ? String(count) : '';
    if (streak) {
        playerStateStyle();
        if (portrait.dataset.portraitStreak !== streak) portrait.dataset.portraitStreak = streak;
    } else {
        delete portrait.dataset.portraitStreak;
    }
}

const renderedRawName = name => typeof name === 'string' ? name.replace(/<[^>]*>/g, '').trim() : '';

function ownName(label, appliedNames) {
    const previous = appliedNames.get(label);
    if (previous && previous.node === label.firstChild && label.childNodes.length === 1 &&
            previous.alias === label.textContent) return previous;
}

function matchesRawName(label, raw, formatted, appliedNames) {
    if (!label || typeof raw !== 'string' || !raw) return false;
    const previous = ownName(label, appliedNames);
    if (previous) return previous.raw === raw;
    return label.textContent === raw || Boolean(formatted && renderedRawName(label.textContent) === formatted);
}

function paintBroadcastName(label, raw, displayName, matched, appliedNames) {
    if (!label) return;
    const previous = ownName(label, appliedNames);
    const alias = typeof displayName === 'string' && displayName.trim() && displayName !== raw ? displayName : '';
    if (!alias) {
        const restore = previous && (raw == null || previous.raw === raw);
        if (restore) label.replaceChildren(...previous.original);
        if (!previous || restore || label.textContent === raw) appliedNames.delete(label);
        return;
    }
    if (!matched || label.textContent === alias) return;
    const original = previous && previous.raw === raw ? previous.original : [...label.childNodes];
    label.textContent = alias;
    appliedNames.set(label, { raw, alias, original, node: label.firstChild });
}

function decorateTeamRosters(teams, themed, appliedNames) {
    for (const [side, id] of [[2, 'left-roster'], [3, 'right-roster']]) {
        const roster = document.getElementById(id);
        if (!roster || roster.hidden) continue;
        const players = teams?.find(team => team.side === side)?.players ?? [];
        const names = players.map(player => renderedRawName(player?.name));
        const cards = roster.querySelectorAll('.studio-member, li');
        for (const [index, card] of cards.entries()) {
            const player = players[index];
            const label = card.querySelector('.name, strong');
            const raw = player?.name;
            const marker = card.dataset.rosterPlayer;
            const formatted = names[index];
            const unique = formatted && names.indexOf(formatted) === names.lastIndexOf(formatted);
            // An applied alias is never evidence of another player's identity.
            const matched = marker !== undefined ? marker === raw :
                matchesRawName(label, raw, unique ? formatted : '', appliedNames);
            if (themed) decoratePortrait(card.querySelector('.art, .studio-art'), matched ? player : null);
            paintBroadcastName(label, raw, player?.displayName, matched, appliedNames);
        }
    }
}

window.DeadlockHUD = Object.freeze({
    decoratePortrait,
    subscribe(onState, packageId) {
        const id = packageId ?? location.pathname.split('/')[3];
        const themed = themedHud.has(id);
        if (themed) playerStateStyle();
        const preview = new URLSearchParams(location.search).get('preview') === '1';
        const endpoint = '/api/v1/huds/' + encodeURIComponent(id);
        const query = preview ? '?preview=1' : '';
        let stopped = false;
        let timer;
        let stream;
        let last;
        let latest;
        let riftNotice;
        let midBossNotice;
        const appliedNames = new WeakMap();
        const watchedLabels = new WeakSet();
        const nameObserver = new MutationObserver(decoratePlayers);

        function decoratePlayers() {
            const { selected, teams } = latest?.telemetry ?? {};
            const playerName = document.getElementById('player-name');
            const raw = selected?.player;
            const matched = playerName?.textContent === raw ||
                matchesRawName(playerName, raw, renderedRawName(raw), appliedNames);
            paintBroadcastName(playerName, raw, selected?.displayName, matched, appliedNames);
            decorateTeamRosters(teams, themed, appliedNames);
        }

        function observeNames() {
            for (const rootId of ['player-name', 'left-roster', 'right-roster']) {
                const root = document.getElementById(rootId);
                if (!root || watchedLabels.has(root)) continue;
                watchedLabels.add(root);
                nameObserver.observe(root, { childList: true, characterData: true, subtree: true });
            }
        }
        if (themed) {
            import('/hud-rift.js').then(({ createRiftNotice }) => {
                if (stopped) return;
                riftNotice = createRiftNotice(document.body, { floating: true });
                riftNotice.update(latest?.telemetry?.rift);
            }).catch(() => {});
            import('/hud-mid-boss.js').then(({ createMidBossNotice, setRejuvenatorBadge }) => {
                if (stopped) return;
                paintRejuvenator = setRejuvenatorBadge;
                midBossNotice = createMidBossNotice(document.body, { floating: true });
                const teams = latest?.telemetry?.teams;
                midBossNotice.update(latest?.telemetry?.midBoss, { teams, settings: latest?.settings });
                decoratePlayers();
            }).catch(() => {});
        }

        function deliver(state) {
            if (stopped) return;
            // The outer page handles opacity for embedded overlays. Standalone links from
            // earlier versions still need it when opened directly in OBS.
            if (window === window.top && Number.isFinite(state.opacity)) {
                document.documentElement.style.opacity = state.opacity / 100;
            }
            const serialized = JSON.stringify(state);
            if (serialized !== last) {
                last = serialized;
                latest = state;
                const teams = state.telemetry?.teams;
                riftNotice?.update(state.telemetry?.rift);
                midBossNotice?.update(state.telemetry?.midBoss, { teams, settings: state.settings });
                onState(state);
                applyPlayerState(state.telemetry?.selected, themed);
                observeNames();
                decoratePlayers();
            }
        }

        async function update() {
            let state;
            try {
                const response = await fetch(endpoint + '/state' + query, { signal: AbortSignal.timeout(2000) });
                if (!response.ok) throw new Error('HUD unavailable');
                state = await response.json();
            } catch {
                state = { preview, telemetry: null, settings: {} };
            }
            if (stopped) return;
            timer = setTimeout(update, preview ? 200 : 50);
            deliver(state);
        }

        if (typeof EventSource === 'function') {
            stream = new EventSource(endpoint + '/events' + query);
            stream.onmessage = ({ data }) => deliver(JSON.parse(data));
            stream.onerror = () => {
                if (stopped) return;
                stream.close();
                stream = undefined;
                update();
            };
        } else {
            update();
        }
        return () => {
            stopped = true;
            clearTimeout(timer);
            stream?.close();
            riftNotice?.remove();
            midBossNotice?.remove();
            nameObserver.disconnect();
        };
    },
});
