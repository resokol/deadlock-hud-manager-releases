import { fit, loadArt, position, release, render } from './render.js';

const viewport = document.getElementById('viewport');
const canvas = document.getElementById('canvas');
const packageId = new URLSearchParams(location.search).get('package');
const assetRoot = packageId ? '/hud/packages/' + encodeURIComponent(packageId) + '/' : '';
const imagePath = /^images\/[0-9a-f]{32}\.(png|jpg|webp)$/;
const blocks = new Map();
let layers = [];
let latest;
let pov;
let revision;
let loaded;

function update() {
    for (const layer of layers) render(blocks.get(layer.id), layer, latest, false, undefined, pov);
}

function replaceLayout(next) {
    const ids = new Set(next.map(layer => layer.id));
    for (const [id, node] of blocks) {
        if (ids.has(id)) continue;
        release(node);
        node.remove();
        blocks.delete(id);
    }
    for (const [order, layer] of next.entries()) {
        let block = blocks.get(layer.id);
        if (!block) {
            block = document.createElement('div');
            block.className = 'studio-block';
            canvas.append(block);
            blocks.set(layer.id, block);
        }
        block.style.zIndex = order + 1;
        position(block, layer, imagePath.test(layer.image) ? assetRoot + layer.image : '');
    }
    layers = next;
    update();
}

async function loadLayout(wanted) {
    try {
        const url = assetRoot + 'studio.json' + (wanted ? '?v=' + encodeURIComponent(wanted) : '');
        const response = await fetch(url);
        if (!response.ok) throw new Error('HUD layout unavailable');
        const design = await response.json();
        if (wanted !== revision) return;
        replaceLayout(design.layers);
        loaded = wanted;
    } catch {
        if (wanted === revision && loaded !== wanted) setTimeout(() => loadLayout(wanted), 500);
    }
}

new ResizeObserver(() => fit(canvas, viewport)).observe(viewport);
fit(canvas, viewport);
revision = '';
loadLayout(revision);
window.DeadlockHUD.subscribe(({ telemetry, settings, studioRevision, povUrl, povFormat }) => {
    latest = settings?.series ? { ...telemetry, series: settings.series } : telemetry;
    pov = { url: povUrl, format: povFormat };
    if (studioRevision && studioRevision !== revision) {
        revision = studioRevision;
        loadLayout(revision);
    }
    update();
}, packageId);
loadArt().then(update);
setInterval(() => loadArt().then(update), 5000);
