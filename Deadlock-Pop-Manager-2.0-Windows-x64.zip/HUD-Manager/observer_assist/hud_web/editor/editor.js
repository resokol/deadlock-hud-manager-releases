import { WIDTH, HEIGHT, ROSTER_DEFAULTS, loadArt, panoramaPath, panoramaPaths, position, release, render } from './render.js';

const TYPES = {
    clock: ['Таймер матча', 200, 74, 40],
    score: ['Счёт команд', 280, 74, 42],
    series: ['Счёт серии', 300, 58, 26],
    networth: ['Души команд', 340, 62, 28],
    roster: ['Портреты команд', 1320, 122, 26],
    names: ['Ники игроков', 1320, 62, 24],
    player: ['Игрок в кадре', 390, 102, 38],
    health: ['Здоровье', 390, 70, 30, '#b5e5b9'],
    stamina: ['Выносливость', 220, 62, 26, '#94dfff'],
    ammo: ['Патроны', 190, 62, 26, '#ffd598'],
    'insecure-souls': ['Незакреплённые души', 270, 58, 27, '#b4f1bf'],
    'active-items': ['Активные предметы', 370, 62, 26],
    abilities: ['Способности', 370, 88, 32],
    items: ['Предметы', 370, 88, 32],
    purchase: ['Покупка предмета', 380, 70, 26],
    kda: ['K / D / A игрока', 220, 58, 28],
    boss: ['Таймер мид-босса', 215, 62, 32],
    midboss: ['Событие мид-босса', 380, 110, 24, '#eff9f1'],
    rift: ['Рифт', 320, 76, 24, '#f4eaff'],
    'rift-timer': ['До появления рифта', 320, 62, 26, '#f4eaff'],
    panorama: ['Кастомная плашка', 340, 62, 32],
    pov: ['Камера POV', 480, 270, 26],
    text: ['Текст', 380, 62, 32],
    panel: ['Цветная подложка', 390, 120, 26],
    image: ['Изображение', 420, 180, 26],
    code: ['HTML + CSS', WIDTH, HEIGHT, 28],
};

const PANORAMA_FIELDS = new Map([
    ['gameClock', 'Таймер матча'], ['midBossTimer', 'Таймер мид-босса'],
    ['series.bestOf', 'Длина серии матчей'], ['series.leftWins', 'Победы левой команды в серии'],
    ['series.rightWins', 'Победы правой команды в серии'],
    ['teams.0.kills', 'Счёт первой команды'], ['teams.1.kills', 'Счёт второй команды'],
    ['teams.0.netWorth', 'Души первой команды'], ['teams.1.netWorth', 'Души второй команды'],
    ['teams.0.rejuvenatorCharges', 'Заряды реювенатора первой команды'],
    ['teams.1.rejuvenatorCharges', 'Заряды реювенатора второй команды'],
    ['selected.displayName', 'Эфирный ник игрока'], ['selected.player', 'Игровой ник игрока'], ['selected.hp', 'Здоровье'],
    ['selected.maxHp', 'Максимум здоровья'], ['selected.regen', 'Регенерация здоровья'],
    ['selected.stamina', 'Выносливость'], ['selected.maxStamina', 'Максимум выносливости'],
    ['selected.ammo', 'Патроны'], ['selected.maxAmmo', 'Размер магазина'],
    ['selected.ammoInfinite', 'Бесконечный запас патронов'], ['selected.insecureSouls', 'Незакреплённые души'],
    ['selected.invisible', 'Невидимость игрока в кадре'], ['selected.itemPurchase.name', 'Купленный предмет'],
    ['rift.secondsUntil', 'Секунд до появления рифта'], ['rift.location', 'Линия появления рифта'],
    ['rift.estimated', 'Приблизительное время появления рифта'],
    ['selected.abilitySlots.0.cooldown', 'Способность 1 · Кулдаун'],
    ['selected.abilitySlots.0.level', 'Способность 1 · Уровень прокачки'],
    ['selected.itemSlots.0.cooldown', 'Предмет 1 · Кулдаун'],
    ['teams.0.players.0.displayName', 'Игрок 1 · Эфирный ник'], ['teams.1.players.0.displayName', 'Игрок 1 · Эфирный ник'],
    ['teams.0.players.0.name', 'Игрок 1 · Игровой ник'], ['teams.1.players.0.name', 'Игрок 1 · Игровой ник'],
]);
const MEMBER_FIELDS = new Map([
    ['name', 'Игровой ник'], ['displayName', 'Эфирный ник'], ['hero', 'Герой'], ['heroId', 'ID героя'],
    ['souls', 'Души'], ['level', 'Уровень'],
    ['kills', 'Убийства'], ['deaths', 'Смерти'], ['assists', 'Помощь'], ['respawn', 'Возрождение'],
    ['hp', 'Здоровье'], ['maxHp', 'Максимум здоровья'], ['hpPercent', 'Здоровье, %'],
    ['ultimate.ready', 'Ульта готова'], ['ultimate.unlocked', 'Ульта открыта'],
    ['ultimate.cooldown', 'Кулдаун ульты'], ['ultimate.level', 'Уровень ульты'],
    ['invisible', 'Невидимость'], ['rejuvenator', 'Реювенатор'],
]);
const SLOT_FIELDS = new Map([
    ['key', 'Клавиша'], ['name', 'Название'], ['id', 'ID'], ['cooldown', 'Кулдаун'], ['level', 'Уровень прокачки'],
]);

const CODE_HTML = `<div class="score">
  <span>{{teams.0.kills}}</span>
  <strong>{{gameClock}}</strong>
  <span>{{teams.1.kills}}</span>
</div>`;
const CODE_CSS = `.score {
  display: flex;
  justify-content: space-between;
  align-items: center;
  width: min(24rem, 90%);
  box-sizing: border-box;
  margin: 1.5rem auto;
  padding: .65rem 1.25rem;
  border-radius: .75rem;
  background: #121d22;
  color: #eef7f6;
  font: 700 1.75rem system-ui, sans-serif;
}
.score span { color: #a4e3d8; }`;

const $ = id => document.getElementById(id);
const board = $('board');
const stage = $('stage');
const snap = $('snap');
const GRID_STEP = 16;
const form = $('properties');
const layerList = $('layers');
const panoramaPicker = $('panorama-picker');
const nodes = new Map();
const images = new Map();
const committedImages = new Set();
const imageTypes = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp' };
const imageLimit = 4 * 1024 * 1024;
const projectImageLimit = 16 * 1024 * 1024;
const undo = [];
const redo = [];
let bridge;
let busy = false;
let source;
let selected;
let data;
let pov;
let dragging;
let dragSource;
let uploading = false;
let layout = starter('match');
let commitToken = 0;
let zoom = 1;
let viewX = 0;
let viewY = 0;
let fieldEdit;
let codeFieldEdit;
let openCodeLayer;
let codeHit;
let codeMatches = [];
let codeMatch = -1;
let panoramaFieldsSignature;

function serialize() { return JSON.stringify(layout); }
const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
const gridCoordinate = (value, min, max, step) => clamp(Math.round(value / step) * step, min, max);
const snapStep = event => snap.checked && !event?.altKey ? GRID_STEP : 1;
const selectedLayer = () => layout.layers.find(layer => layer.id === selected);

function block(type, x, y) {
    const [, w, h, size, color = '#eef7f6'] = TYPES[type];
    return { id: crypto.randomUUID(), type, x, y, w, h, size, color, background: '#121d22',
        fill: ['text', 'image', 'code', 'names', 'panorama', 'pov'].includes(type) ? 0 : 89, align: 'center', opacity: 100,
        text: type === 'text' ? 'Deadlock' : '', radius: 0, frameWidth: 0, frameColor: '#a4e3d8', image: '',
        imageFit: type === 'image' || type === 'pov' ? 'contain' : 'stretch',
        dataX: 0, dataY: 0, dataW: 100, dataH: 100,
        ...(['roster', 'names', 'player'].includes(type) ? { nameOverflow: 'ellipsis' } : {}),
        ...(type === 'roster' ? ROSTER_DEFAULTS : {}),
        ...(type === 'player' ? { playerShowRejuvenator: true, playerShowRespawn: true, playerShowInvisible: true } : {}),
        ...(type === 'abilities' ? { abilitiesShowLevels: true } : {}),
        ...(type === 'items' ? { itemsMode: 'all' } : {}),
        ...(type === 'names' ? { namesTeam: 'all', namesDirection: 'row' } : {}),
        ...(type === 'panorama' ? { panoramaPath: 'gameClock', panoramaPrefix: '', panoramaSuffix: '' } : {}),
        ...(type === 'rift' ? { background: '#1c1529', frameColor: '#9f7cc8', frameWidth: 1, radius: 7 } : {}),
        ...(type === 'midboss' ? { background: '#14231f', frameColor: '#7bbb9d', frameWidth: 1, radius: 7 } : {}),
        ...(type === 'code' ? { html: CODE_HTML, css: CODE_CSS } : {}) };
}

function starter(kind) {
    const layers = [];
    if (kind === 'match') {
        layers.push(block('clock', 860, 29), block('score', 565, 29), block('networth', 1075, 35),
                    block('roster', 300, 112));
    }
    if (kind === 'match' || kind === 'player') {
        layers.push(block('player', 62, 700), block('health', 62, 810),
                    block('active-items', 62, 885), block('abilities', 62, 952),
                    { ...block('items', 462, 952), itemsMode: 'passive' });
    }
    if (kind === 'code') layers.push(block('code', 0, 0));
    return { version: 1, name: 'Мой HUD', layers };
}

function message(value, error = false) {
    $('status').textContent = value;
    $('status').dataset.error = error;
}

function edit(before) {
    if (before !== serialize()) {
        undo.push(before);
        if (undo.length > 70) undo.shift();
        redo.length = 0;
        queueCommit();
    }
    updateButtons();
}

function mutate(action) {
    const before = serialize();
    action();
    edit(before);
    paint();
}

function history(back) {
    const pile = back ? undo : redo;
    if (!pile.length) return;
    const other = back ? redo : undo;
    other.push(serialize());
    layout = JSON.parse(pile.pop());
    showName();
    queueCommit();
    paint();
}

function choose(id) {
    if (selected === id) return;
    selected = id;
    paintInspector();
    paintList();
    paintPositions();
    syncCodeEditor();
    paintData();
    updateButtons();
}

function paintData() {
    const inspect = !$('code-editor').hidden && $('inspect-code').getAttribute('aria-pressed') === 'true';
    for (const layer of layout.layers) {
        const node = nodes.get(layer.id);
        if (node) render(node, layer, data, true, inspect && layer.id === selected ? inspectCode : undefined, pov);
    }
    const layer = selectedLayer();
    if (layer?.type === 'panorama') paintPanoramaFields(layer);
}

function paintPositions() {
    for (const layer of layout.layers) {
        const node = nodes.get(layer.id);
        if (node) position(node, layer, images.get(layer.image)?.url ?? '');
    }
    const layer = selectedLayer();
    $('selection').hidden = !layer;
    if (layer) {
        const { x, y, w, h } = layer;
        Object.assign($('selection').style, { left: x + 'px', top: y + 'px', width: w + 'px', height: h + 'px',
            borderRadius: (layer.radius ?? 0) + 'px' });
        $('data-guide').hidden = !layer.image || layer.type === 'image' || layer.type === 'panel';
        Object.assign($('data-guide').style, { left: layer.dataX + '%', top: layer.dataY + '%',
            width: layer.dataW + '%', height: layer.dataH + '%' });
    }
}

function paintScene() {
    const ids = new Set(layout.layers.map(layer => layer.id));
    for (const [id, node] of nodes) {
        if (ids.has(id)) continue;
        release(node);
        node.remove();
        nodes.delete(id);
    }
    for (const [index, layer] of layout.layers.entries()) {
        let node = nodes.get(layer.id);
        if (!node) {
            node = document.createElement('div');
            node.className = 'studio-block';
            node.dataset.id = layer.id;
            node.dataset.label = TYPES[layer.type][0];
            board.append(node);
            nodes.set(layer.id, node);
        }
        node.style.zIndex = index + 1;
    }
    paintPositions();
    paintData();
}

function paintList() {
    const list = layerList;
    const focus = list.contains(document.activeElement);
    list.replaceChildren(...[...layout.layers].reverse().map(layer => {
        const item = document.createElement('li');
        const button = document.createElement('button');
        button.type = 'button';
        const name = layer.type === 'text' && layer.text.trim() ? layer.text : TYPES[layer.type][0];
        button.textContent = name;
        button.title = name;
        button.setAttribute('aria-pressed', String(layer.id === selected));
        button.dataset.id = layer.id;
        item.dataset.id = layer.id;
        button.draggable = true;
        button.addEventListener('dragstart', event => startDrop(event, 'layer', layer.id));
        button.addEventListener('click', () => choose(layer.id));
        item.append(button);
        return item;
    }));
    if (focus) [...list.querySelectorAll('button')].find(button => button.dataset.id === selected)?.focus();
    $('empty-layers').hidden = Boolean(layout.layers.length);
}

function panoramaFieldGroup(path) {
    const team = /^teams\.([01])\.(players\.)?/.exec(path);
    if (team?.[1] === '0') return team[2] ? 'Игроки первой команды' : 'Первая команда';
    if (team?.[1] === '1') return team[2] ? 'Игроки второй команды' : 'Вторая команда';
    if (path.startsWith('selected.')) return 'Игрок в кадре';
    return 'Матч';
}

function panoramaFieldLabel(path) {
    if (PANORAMA_FIELDS.has(path)) return PANORAMA_FIELDS.get(path);
    const player = /^teams\.[01]\.players\.([0-9]+)\.(.+)$/.exec(path);
    if (player && MEMBER_FIELDS.has(player[2])) {
        return `Игрок ${Number(player[1]) + 1} · ${MEMBER_FIELDS.get(player[2])}`;
    }
    const slot = /^selected\.(abilitySlots|itemSlots)\.([0-9]+)\.([^.]+)$/.exec(path);
    if (slot && SLOT_FIELDS.has(slot[3])) {
        const label = slot[1] === 'abilitySlots' ? 'Способность' : 'Предмет';
        return `${label} ${Number(slot[2]) + 1} · ${SLOT_FIELDS.get(slot[3])}`;
    }
    return path;
}

function paintPanoramaFields(layer, syncSelection = false) {
    const live = panoramaPaths(data);
    const signature = live.join('\n');
    if (panoramaFieldsSignature !== signature) {
        panoramaFieldsSignature = signature;
        syncSelection = true;
        const groups = new Map();
        const fields = new Set([...PANORAMA_FIELDS.keys(), ...live]);
        for (const path of live) {
            if (/^teams\.[0-9]+\.players\.[0-9]+\.name$/.test(path)) fields.add(path.replace(/name$/, 'displayName'));
        }
        for (const path of fields) {
            const label = panoramaFieldGroup(path);
            if (!groups.has(label)) {
                const group = document.createElement('optgroup');
                group.label = label;
                groups.set(label, group);
            }
            groups.get(label).append(new Option(panoramaFieldLabel(path), path));
        }
        const placeholder = new Option('Выберите поле…', '');
        placeholder.disabled = true;
        panoramaPicker.replaceChildren(placeholder, ...groups.values());
    }
    if (syncSelection) {
        panoramaPicker.value = panoramaPath(layer.panoramaPath) ?? '';
        if (panoramaPicker.selectedIndex === -1) panoramaPicker.selectedIndex = 0;
    }
}

function paintInspector() {
    const layer = selectedLayer();
    form.hidden = !layer;
    $('no-selection').hidden = Boolean(layer);
    if (!layer) return;
    const camera = layer.type === 'pov';
    $('selection-name').textContent = TYPES[layer.type][0];
    $('text-field').hidden = layer.type !== 'text';
    $('pov-info').hidden = !camera;
    $('image-fit').hidden = !layer.image && !camera;
    $('clear-image').hidden = !layer.image;
    $('data-fields').hidden = !camera && (!layer.image || layer.type === 'image' || layer.type === 'panel');
    $('data-fields-name').textContent = camera ? 'Область видео' : 'Область данных на картинке';
    $('roster-fields').hidden = layer.type !== 'roster';
    $('roster-active-fields').hidden = layer.type !== 'roster';
    $('roster-active-style').disabled = !layer.rosterHighlight;
    $('names-fields').hidden = layer.type !== 'names';
    $('names-overflow').hidden = !['roster', 'names', 'player'].includes(layer.type);
    $('player-indicators').hidden = layer.type !== 'player';
    $('ability-fields').hidden = layer.type !== 'abilities';
    $('item-fields').hidden = layer.type !== 'items';
    $('panorama-fields').hidden = layer.type !== 'panorama';
    for (const control of form.elements) {
        if (!control.name || control.closest('[hidden]')) continue;
        if (control.type === 'checkbox') control.checked = Boolean(layer[control.name]);
        else control.value = layer[control.name] ?? '';
    }
    if (layer.type === 'panorama') {
        form.elements.panoramaPath.setCustomValidity('');
        paintPanoramaFields(layer, true);
    }
    form.elements.x.max = WIDTH - layer.w;
    form.elements.y.max = HEIGHT - layer.h;
    form.elements.w.max = WIDTH - layer.x;
    form.elements.h.max = HEIGHT - layer.y;
    form.elements.dataX.max = 100 - layer.dataW;
    form.elements.dataY.max = 100 - layer.dataH;
}

function updateButtons() {
    const index = layout.layers.findIndex(layer => layer.id === selected);
    $('undo').disabled = !undo.length;
    $('redo').disabled = !redo.length;
    $('up').disabled = index < 0 || index === layout.layers.length - 1;
    $('down').disabled = index < 1;
    $('duplicate').disabled = index < 0 || layout.layers.length >= 60;
    $('remove').disabled = index < 0;
    $('export').disabled = !bridge || busy || uploading;
    $('upload-image').disabled = uploading;
}

function paint() {
    paintScene();
    paintList();
    paintInspector();
    syncCodeEditor();
    updateButtons();
}

function syncCodeEditor() {
    const layer = selectedLayer();
    if (layer?.type !== 'code') {
        if (!$('code-editor').hidden) closeCodeEditor();
        return;
    }
    for (const field of ['html', 'css']) {
        const input = $('code-' + field);
        if (input.value !== layer[field]) input.value = layer[field];
    }
    if (openCodeLayer !== layer.id) {
        openCodeLayer = layer.id;
        clearCodeHit();
        resetCodeSearch();
    }
}

function openCodeEditor() {
    let layer = selectedLayer();
    if (layer?.type !== 'code') layer = layout.layers.find(layer => layer.type === 'code');
    if (!layer) {
        add('code');
        layer = selectedLayer();
    }
    if (layer?.type !== 'code') return;
    choose(layer.id);
    $('code-editor').hidden = false;
    syncCodeEditor();
    $('code-' + codeTab()).focus({ preventScroll: true });
    paintData();
}

const codeTab = () => $('code-html').hidden ? 'css' : 'html';

function setCodeTab(field, focus = true) {
    const html = field === 'html';
    $('code-html-tab').setAttribute('aria-pressed', String(html));
    $('code-css-tab').setAttribute('aria-pressed', String(!html));
    $('code-html').hidden = !html;
    $('code-css').hidden = html;
    $('code-bindings').hidden = !html;
    if (focus) $('code-' + field).focus({ preventScroll: true });
    showCodeHit();
}

function closeCodeEditor() {
    $('code-editor').hidden = true;
    $('code-find').hidden = true;
    openCodeLayer = undefined;
    clearCodeHit();
    paintData();
}

function selectCode(field, start, end, focus = true) {
    setCodeTab(field, focus);
    const input = $('code-' + field);
    input.setSelectionRange(start, end);
    const before = input.value.slice(0, start);
    const lines = before.split('\n');
    const style = getComputedStyle(input);
    input.scrollTop = Math.max(0, lines.length - 3) * parseFloat(style.lineHeight);
    const column = lines.at(-1).length;
    input.scrollLeft = Math.max(0, column - 12) * parseFloat(style.fontSize) * .6;
}

function showCodeHit() {
    const button = $('code-hit');
    const field = codeTab() === 'css' && codeHit?.css ? 'css' : 'html';
    const range = codeHit?.[field];
    if (!range) {
        button.textContent = 'Наведите на элемент на холсте';
        button.disabled = true;
        return;
    }
    const source = $('code-' + field).value;
    const line = source.slice(0, range.start).split('\n').length;
    button.textContent = field.toUpperCase() + ', строка ' + line + ' · ' + source.slice(range.start, range.end).trim();
    button.disabled = false;
}

function jumpToCodeHit() {
    if (!codeHit?.html) return;
    const field = codeTab() === 'css' && codeHit.css ? 'css' : 'html';
    const { start, end } = codeHit[field];
    selectCode(field, start, end);
}

function inspectCode(hit) {
    if (hit?.kind === 'find') {
        openCodeSearch();
        return;
    }
    if (!hit) return;
    codeHit = hit;
    showCodeHit();
    if (hit.kind === 'select') jumpToCodeHit();
}

function clearCodeHit() {
    codeHit = null;
    showCodeHit();
}

function showCodeSearchCount() {
    const query = $('code-query').value;
    const count = codeMatches.length;
    const hit = codeMatches[codeMatch];
    const position = hit ? ' · ' + hit.field.toUpperCase() + ', строка ' +
        $('code-' + hit.field).value.slice(0, hit.start).split('\n').length : '';
    $('code-find-count').textContent = !query ? '' : count ? (codeMatch + 1) + ' / ' + count + position : 'Совпадений нет';
    $('code-prev').disabled = !count;
    $('code-next').disabled = !count;
}

function resetCodeSearch() {
    codeMatch = -1;
    const query = $('code-query').value;
    const expression = query && new RegExp(query.replace(/[.*+?^$(){}|[\]\\]/g, '\\$&'), 'giu');
    const first = codeTab();
    codeMatches = expression ? [first, first === 'html' ? 'css' : 'html'].flatMap(field =>
        Array.from($('code-' + field).value.matchAll(expression), match =>
            ({ field, start: match.index, end: match.index + match[0].length }))) : [];
    showCodeSearchCount();
}

function findCode(direction, focus = false) {
    if (!codeMatches.length) return;
    codeMatch = (codeMatch < 0 ? (direction < 0 ? codeMatches.length - 1 : 0) :
        (codeMatch + direction + codeMatches.length) % codeMatches.length);
    const { field, start, end } = codeMatches[codeMatch];
    selectCode(field, start, end, focus);
    showCodeSearchCount();
}

function openCodeSearch() {
    const box = $('code-query');
    const input = $('code-' + codeTab());
    const text = input.value.slice(input.selectionStart, input.selectionEnd);
    if ($('code-find').hidden && text && text.length <= box.maxLength && !text.includes('\n')) box.value = text;
    $('code-find').hidden = false;
    box.focus({ preventScroll: true });
    box.select();
    resetCodeSearch();
    findCode(1);
}

function closeCodeSearch() {
    $('code-find').hidden = true;
    $('code-' + codeTab()).focus({ preventScroll: true });
}

function showName() { $('name').value = layout.name; }
function add(type, point, image = '') {
    if (layout.layers.length >= 60) {
        message('Достигнут предел в 60 блоков.', true);
        return;
    }
    mutate(() => {
        const offset = 16 * (layout.layers.length % 6);
        const layer = block(type, 0, 0);
        moveTo(layer, point ?? { x: WIDTH / 2 + offset, y: HEIGHT / 2 + offset, step: snapStep() });
        layer.image = image;
        layout.layers.push(layer);
        selected = layer.id;
    });
}

function moveTo(layer, { x, y, step }) {
    placeAt(layer, x - layer.w / 2, y - layer.h / 2, step);
}

function placeAt(layer, x, y, step) {
    layer.x = gridCoordinate(x, 0, WIDTH - layer.w, step);
    layer.y = gridCoordinate(y, 0, HEIGHT - layer.h, step);
}

function moveLayer(direction) {
    const index = layout.layers.findIndex(layer => layer.id === selected);
    const next = index + direction;
    if (index < 0 || next < 0 || next >= layout.layers.length) return;
    mutate(() => {
        [layout.layers[index], layout.layers[next]] = [layout.layers[next], layout.layers[index]];
    });
}

function duplicate() {
    const layer = selectedLayer();
    if (!layer || layout.layers.length >= 60) return;
    mutate(() => {
        const copy = { ...layer, id: crypto.randomUUID() };
        placeAt(copy, layer.x + 24, layer.y + 24, snapStep());
        layout.layers.push(copy);
        selected = copy.id;
    });
}

function remove() {
    if (!selectedLayer()) return;
    mutate(() => {
        layout.layers = layout.layers.filter(layer => layer.id !== selected);
        selected = layout.layers.at(-1)?.id;
    });
}

function startDrop(event, kind, id) {
    dragSource = { kind, id };
    event.dataTransfer.effectAllowed = kind === 'block' ? 'copy' : 'move';
    event.dataTransfer.setData('text/plain', id);
}

function clearDrop() {
    board.classList.remove('drop-ready');
    for (const row of layerList.querySelectorAll('[data-drop]')) delete row.dataset.drop;
}

document.addEventListener('dragend', () => {
    dragSource = undefined;
    clearDrop();
});

layerList.addEventListener('dragover', event => {
    const row = event.target.closest('li');
    if (dragSource?.kind !== 'layer' || !row) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
    clearDrop();
    const bounds = row.getBoundingClientRect();
    row.dataset.drop = event.clientY < bounds.top + bounds.height / 2 ? 'above' : 'below';
});
layerList.addEventListener('dragleave', event => {
    if (!layerList.contains(event.relatedTarget)) clearDrop();
});
layerList.addEventListener('drop', event => {
    const row = event.target.closest('li');
    if (dragSource?.kind !== 'layer' || !row) return;
    event.preventDefault();
    const above = row.dataset.drop === 'above';
    const { id } = dragSource;
    dragSource = undefined;
    clearDrop();
    if (id === row.dataset.id) return;
    const moving = layout.layers.find(layer => layer.id === id);
    if (!moving) return;
    mutate(() => {
        layout.layers = layout.layers.filter(layer => layer !== moving);
        const target = layout.layers.findIndex(layer => layer.id === row.dataset.id);
        layout.layers.splice(target + Number(above), 0, moving);
        selected = id;
    });
});

board.addEventListener('dragover', event => {
    if (!dragSource && !event.dataTransfer.types.includes('Files')) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = dragSource?.kind === 'layer' ? 'move' : 'copy';
    board.classList.add('drop-ready');
});
board.addEventListener('dragleave', event => {
    if (!board.contains(event.relatedTarget)) board.classList.remove('drop-ready');
});
board.addEventListener('drop', event => {
    if (!dragSource && !event.dataTransfer.files.length) return;
    event.preventDefault();
    const area = board.getBoundingClientRect();
    const point = { x: (event.clientX - area.left) * WIDTH / area.width,
        y: (event.clientY - area.top) * HEIGHT / area.height,
        step: snapStep(event) };
    const source = dragSource;
    dragSource = undefined;
    clearDrop();
    if (!source) {
        const id = event.target.closest('.studio-block')?.dataset.id;
        uploadImage(event.dataTransfer.files[0], id, point);
    } else if (source.kind === 'block') {
        add(source.id, point);
    } else {
        const layer = layout.layers.find(layer => layer.id === source.id);
        if (layer) mutate(() => { moveTo(layer, point); selected = layer.id; });
    }
});

function imageReferences(layers) {
    return new Set(layers.map(layer => layer.image).filter(Boolean));
}

function imageBytes(url) {
    const payload = url.split(',', 2)[1];
    return Math.floor(payload.length * 3 / 4) - (payload.endsWith('==') ? 2 : payload.endsWith('=') ? 1 : 0);
}

function readImage(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(new Error('Не удалось прочитать файл.'));
        reader.readAsDataURL(file);
    });
}

async function uploadImage(file, id, point) {
    if (!file || uploading) return;
    const extension = imageTypes[file.type];
    if (!extension || file.size > imageLimit) {
        message('Выберите PNG, JPEG или WebP до 4 МБ.', true);
        return;
    }
    if (!id && layout.layers.length >= 60) {
        message('Достигнут предел в 60 блоков.', true);
        return;
    }
    uploading = true;
    updateButtons();
    try {
        const url = await readImage(file);
        const image = new Image();
        image.src = url;
        await image.decode();
        if (image.naturalWidth > 4096 || image.naturalHeight > 4096) {
            throw new Error('Размер изображения должен быть до 4096 × 4096.');
        }
        const retained = imageReferences(layout.layers.filter(layer => layer.id !== id));
        const total = [...retained].reduce((sum, path) => sum + (images.get(path)?.bytes ?? 0), file.size);
        if (total > projectImageLimit) throw new Error('Изображения в макете занимают больше 16 МБ.');
        const layer = layout.layers.find(layer => layer.id === id);
        if (id && !layer) return;
        const path = 'images/' + crypto.randomUUID().replaceAll('-', '') + '.' + extension;
        images.set(path, { url, bytes: file.size });
        if (layer) {
            mutate(() => { layer.image = path; selected = id; });
        } else {
            add('image', point, path);
        }
        message('Изображение добавлено');
    } catch (error) {
        message(error instanceof DOMException ? 'Не удалось открыть изображение.' : error.message, true);
    } finally {
        uploading = false;
        updateButtons();
    }
}

function feed(useDemo) {
    source?.close();
    data = null;
    $('demo').setAttribute('aria-pressed', String(useDemo));
    $('live').setAttribute('aria-pressed', String(!useDemo));
    $('feed').textContent = useDemo ? 'Загрузка демо-матча…' : 'Ожидание Panorama…';
    paintData();
    source = new EventSource('/hud-editor/events' + (useDemo ? '?preview=1' : ''));
    source.onmessage = event => {
        const { telemetry, series, povUrl, povFormat } = JSON.parse(event.data);
        data = series ? { ...telemetry, series } : telemetry;
        pov = { url: povUrl, format: povFormat };
        const status = useDemo ? 'Демо-матч' : telemetry ? 'Данные Panorama' : 'Ожидание Panorama…';
        if ($('feed').textContent !== status) $('feed').textContent = status;
        paintData();
    };
    source.onerror = () => {
        data = null;
        $('feed').textContent = 'Связь с менеджером прервана';
        paintData();
    };
}

function payload(includeAllImages = false) {
    const assets = Object.fromEntries([...imageReferences(layout.layers)]
        .filter(path => includeAllImages || !committedImages.has(path))
        .map(path => [path, images.get(path)?.url]));
    return JSON.stringify({ layout, images: assets });
}

function queueCommit() {
    if (!bridge) return;
    if (!layout.name.trim()) {
        message('Укажите название HUD.', true);
        bridge.setDirty(true);
        return;
    }
    message('Применяю изменения…');
    bridge.queueSave(payload(), ++commitToken);
}

function exportHud() {
    if (!bridge || busy || uploading) return;
    if (!$('name').value.trim()) {
        $('name').focus();
        message('Укажите название HUD.', true);
        return;
    }
    $('name').blur();
    busy = true;
    updateButtons();
    bridge.export(payload(true), raw => {
        const result = JSON.parse(raw);
        busy = false;
        updateButtons();
        if (result.error) {
            message(result.error, true);
            return;
        }
        if (result.ok) message('Экспортирован «' + result.name + '»');
    });
}

$('name').addEventListener('change', () => mutate(() => { layout.name = $('name').value; }));
$('name').addEventListener('input', () => {
    if ($('name').value !== layout.name) bridge?.setDirty(true);
});
$('template').addEventListener('change', ({ target }) => {
    if (!target.value) return;
    const kind = target.value;
    mutate(() => {
        layout = { ...starter(kind), name: layout.name };
        selected = undefined;
    });
    target.value = '';
    if (kind === 'code') openCodeEditor();
});
$('open-code').onclick = openCodeEditor;
$('close-code').onclick = () => {
    closeCodeEditor();
    $('open-code').focus();
};
$('inspect-code').onclick = ({ currentTarget }) => {
    const active = currentTarget.getAttribute('aria-pressed') !== 'true';
    currentTarget.setAttribute('aria-pressed', String(active));
    $('code-hit').hidden = !active;
    clearCodeHit();
    paintData();
};
$('code-hit').onclick = jumpToCodeHit;
$('find-code').onclick = openCodeSearch;
$('code-find-close').onclick = closeCodeSearch;
$('code-query').addEventListener('input', () => { resetCodeSearch(); findCode(1); });
$('code-prev').onclick = () => findCode(-1, true);
$('code-find').addEventListener('submit', event => {
    event.preventDefault();
    findCode(1, document.activeElement !== $('code-query'));
});
$('code-query').addEventListener('keydown', event => {
    if (event.key === 'Enter' && event.shiftKey) {
        event.preventDefault();
        findCode(-1);
    }
});
$('insert-variable').onclick = () => {
    const input = $('code-html');
    const token = '{{' + $('code-variable').value + '}}';
    if (input.value.length + token.length - (input.selectionEnd - input.selectionStart) > input.maxLength) return;
    input.setRangeText(token, input.selectionStart, input.selectionEnd, 'end');
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.focus();
};
for (const field of ['html', 'css']) {
    $('code-' + field + '-tab').onclick = () => setCodeTab(field);
    const input = $('code-' + field);
    input.addEventListener('input', () => {
        const layer = selectedLayer();
        if (layer?.type !== 'code' || layer[field] === input.value) return;
        codeFieldEdit ??= { input, before: serialize() };
        layer[field] = input.value;
        clearCodeHit();
        if (!$('code-find').hidden) resetCodeSearch();
        paintData();
        queueCommit();
    });
    input.addEventListener('blur', () => {
        if (codeFieldEdit?.input !== input) return;
        edit(codeFieldEdit.before);
        codeFieldEdit = undefined;
    });
}
form.addEventListener('submit', event => event.preventDefault());
function updateField(target) {
    const layer = selectedLayer();
    if (!layer || !target.name) return false;
    if (target.type === 'number') {
        const value = target.valueAsNumber;
        if (!Number.isFinite(value)) return false;
        layer[target.name] = clamp(Math.round(value), Number(target.min), Number(target.max));
        layer.dataX = Math.min(layer.dataX, 100 - layer.dataW);
        layer.dataY = Math.min(layer.dataY, 100 - layer.dataH);
    } else if (target.name === 'panoramaPath') {
        layer.panoramaPath = target.value.trim();
    } else {
        layer[target.name] = target.type === 'checkbox' ? target.checked : target.value;
    }
    return true;
}
form.addEventListener('input', ({ target }) => {
    if (target.name === 'panoramaPath') {
        target.setCustomValidity('');
        return;
    }
    if (!target.name || !['text', 'number', 'color'].includes(target.type)) return;
    const before = serialize();
    if (!updateField(target) || before === serialize()) return;
    if (!fieldEdit || fieldEdit.target !== target) fieldEdit = { target, before };
    paintScene();
    if (target.name === 'text') paintList();
    queueCommit();
});
form.addEventListener('change', ({ target }) => {
    if (!target.name) return;
    if (target.name === 'panoramaPath' && panoramaPath(target.value) === null) {
        target.setCustomValidity('Укажите путь к полю, например teams.0.kills.');
        target.reportValidity();
        return;
    }
    const before = fieldEdit?.target === target ? fieldEdit.before : serialize();
    fieldEdit = undefined;
    updateField(target);
    edit(before);
    paint();
});
panoramaPicker.addEventListener('change', () => {
    const layer = selectedLayer();
    if (layer?.type === 'panorama' && panoramaPicker.value) {
        mutate(() => { layer.panoramaPath = panoramaPicker.value; });
    }
});
for (const [type, [title]] of Object.entries(TYPES)) {
    const button = document.createElement('button');
    button.type = 'button';
    button.textContent = title;
    button.title = title;
    button.draggable = true;
    button.addEventListener('dragstart', event => startDrop(event, 'block', type));
    button.addEventListener('click', () => {
        add(type);
        if (type === 'image' && selectedLayer()?.type === 'image') $('image-file').click();
        if (type === 'code' && selectedLayer()?.type === 'code') openCodeEditor();
    });
    $('palette').append(button);
}
$('undo').onclick = () => history(true);
$('redo').onclick = () => history(false);
$('up').onclick = () => moveLayer(1);
$('down').onclick = () => moveLayer(-1);
$('duplicate').onclick = duplicate;
$('remove').onclick = remove;
$('demo').onclick = () => feed(true);
$('live').onclick = () => feed(false);
$('upload-image').onclick = () => $('image-file').click();
$('clear-image').onclick = () => mutate(() => { selectedLayer().image = ''; });
$('image-file').onchange = ({ target }) => {
    uploadImage(target.files[0], selected);
    target.value = '';
};
$('export').onclick = exportHud;

board.style.setProperty('--grid-step', GRID_STEP + 'px');
function updateGrid() {
    board.classList.toggle('snap-active', snap.checked);
}
snap.addEventListener('change', updateGrid);
updateGrid();

board.addEventListener('pointerdown', event => {
    if (event.button !== 0) return;
    const resizing = event.target.id === 'handle';
    if (!resizing) choose(event.target.closest('.studio-block')?.dataset.id);
    const layer = selectedLayer();
    if (!layer) return;
    event.preventDefault();
    dragging = { id: event.pointerId, startX: event.clientX, startY: event.clientY,
        initial: { ...layer }, resizing, scale: board.getBoundingClientRect().width / WIDTH, before: serialize() };
    board.setPointerCapture(event.pointerId);
    board.classList.add('is-dragging');
});
board.addEventListener('pointermove', event => {
    if (!dragging || dragging.id !== event.pointerId) return;
    const layer = selectedLayer();
    const { initial, startX, startY, scale, resizing } = dragging;
    if (!layer || !scale) return;
    const dx = (event.clientX - startX) / scale, dy = (event.clientY - startY) / scale;
    if (Math.abs(event.clientX - startX) + Math.abs(event.clientY - startY) < 2) return;
    const step = snapStep(event);
    if (resizing) {
        if (dx) layer.w = gridCoordinate(initial.x + initial.w + dx, initial.x + 24, WIDTH, step) - initial.x;
        else layer.w = initial.w;
        if (dy) layer.h = gridCoordinate(initial.y + initial.h + dy, initial.y + 24, HEIGHT, step) - initial.y;
        else layer.h = initial.h;
    } else {
        placeAt(layer, initial.x + dx, initial.y + dy, step);
    }
    paintPositions();
    paintInspector();
});
function swapCameraAtPointer(event, layer, { initial, resizing }) {
    if (event.type !== 'pointerup' || event.altKey || resizing || layer?.type !== 'pov' ||
        (layer.x === initial.x && layer.y === initial.y)) return;
    const area = board.getBoundingClientRect();
    const x = (event.clientX - area.left) * WIDTH / area.width;
    const y = (event.clientY - area.top) * HEIGHT / area.height;
    const target = layout.layers.findLast(other => other !== layer && other.type === 'pov' &&
        x >= other.x && x < other.x + other.w && y >= other.y && y < other.y + other.h);
    if (!target) return;
    placeAt(layer, target.x, target.y, 1);
    placeAt(target, initial.x, initial.y, 1);
}

function endDrag(event) {
    if (!dragging || dragging.id !== event.pointerId) return;
    const before = dragging.before;
    if (event.type === 'pointercancel') layout = JSON.parse(before);
    else swapCameraAtPointer(event, selectedLayer(), dragging);
    dragging = undefined;
    board.classList.remove('is-dragging');
    edit(before);
    paintPositions();
    paintInspector();
}
board.addEventListener('lostpointercapture', endDrag);
board.addEventListener('pointerup', endDrag);
board.addEventListener('pointercancel', endDrag);
document.addEventListener('keydown', event => {
    const key = event.key.toLowerCase();
    if ((event.ctrlKey || event.metaKey) && key === 'f' && !$('code-editor').hidden) {
        event.preventDefault();
        openCodeSearch();
        return;
    }
    if (key === 'f3' && !$('code-editor').hidden && !$('code-find').hidden) {
        event.preventDefault();
        findCode(event.shiftKey ? -1 : 1, document.activeElement !== $('code-query'));
        return;
    }
    if (key === 'escape' && !$('code-editor').hidden && !$('code-find').hidden) {
        event.preventDefault();
        closeCodeSearch();
        return;
    }
    if ((event.ctrlKey || event.metaKey) && key === 's') {
        event.preventDefault();
        document.activeElement?.blur();
        bridge?.flush();
        return;
    }
    if (event.target.closest('input, select, textarea, [contenteditable]')) return;
    if (event.ctrlKey || event.metaKey) {
        if (key === 'z') { event.preventDefault(); history(!event.shiftKey); }
        if (key === 'y') { event.preventDefault(); history(false); }
        if (key === 'd') { event.preventDefault(); duplicate(); }
        return;
    }
    if (key === 'delete') remove();
    const layer = selectedLayer();
    const offset = { arrowleft: [-1, 0], arrowright: [1, 0], arrowup: [0, -1], arrowdown: [0, 1] }[key];
    if (!layer || !offset || event.target.closest('button')) return;
    event.preventDefault();
    const step = event.shiftKey ? 10 : 1;
    mutate(() => {
        layer.x = clamp(layer.x + offset[0] * step, 0, WIDTH - layer.w);
        layer.y = clamp(layer.y + offset[1] * step, 0, HEIGHT - layer.h);
    });
});

function paintView() {
    const fitScale = Math.min(stage.clientWidth / WIDTH, stage.clientHeight / HEIGHT) || 0.001;
    board.style.transform = 'translate(calc(-50% + ' + viewX + 'px), calc(-50% + ' + viewY
        + 'px)) scale(' + (zoom * fitScale) + ')';
    $('zoom-reset').textContent = Math.round(zoom * 100) + '%';
}

stage.addEventListener('wheel', event => {
    if (!event.shiftKey) return;
    event.preventDefault();
    if (dragging) return;
    const units = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? stage.clientHeight : 1;
    const next = clamp(zoom * Math.exp(-(event.deltaY || event.deltaX) * units / 360), 0.5, 5);
    if (next === zoom) return;
    const bounds = stage.getBoundingClientRect();
    const x = event.clientX - bounds.left - bounds.width / 2;
    const y = event.clientY - bounds.top - bounds.height / 2;
    const ratio = next / zoom;
    viewX = x - (x - viewX) * ratio;
    viewY = y - (y - viewY) * ratio;
    zoom = next;
    paintView();
}, { passive: false });
$('zoom-reset').onclick = () => {
    zoom = 1;
    viewX = viewY = 0;
    paintView();
};
new ResizeObserver(paintView).observe(stage);
showName();
paint();
feed(true);
loadArt().then(paintData);
setInterval(() => loadArt().then(paintData), 5000);
if (typeof window.QWebChannel === 'function' && window.qt?.webChannelTransport) {
    new window.QWebChannel(window.qt.webChannelTransport, channel => {
        bridge = channel.objects.studio;
        bridge.committed.connect((token, raw) => {
            const result = JSON.parse(raw);
            for (const path of result.images ?? []) committedImages.add(path);
            if (token !== commitToken) return;
            if (result.ok) message('Изменения применены');
            else message(result.error, true);
        });
        bridge.project(raw => {
            const project = JSON.parse(raw);
            layout = project.layout ?? layout;
            for (const [path, url] of Object.entries(project.images)) {
                images.set(path, { url, bytes: imageBytes(url) });
                committedImages.add(path);
            }
            selected = undefined;
            showName();
            paint();
            message('Изменения применяются автоматически');
        });
    });
} else {
    message('Для сохранения откройте редактор из HUD Manager.');
}
