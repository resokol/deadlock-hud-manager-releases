const frames = new WeakMap();
const binding = /\{\{\s*([A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)*)\s*\}\}/g;
const publicPaths = [
    /^(?:gameClock|midBossTimer)$/,
    /^series\.(?:bestOf|leftWins|rightWins)$/,
    /^midBoss\.(?:id|killedBy|killedAt|claimedBy|claimedAt)$/,
    /^rift\.(?:id|phase|location|gameClock|spawnedAt|secondsUntil|estimated)$/,
    /^selected\.(?:player|displayName|hp|maxHp|regen|hpPercent|lowHp|killingSpree|killStreak|stamina|maxStamina|ammo|maxAmmo|ammoInfinite|insecureSouls|invisible|respawn|rejuvenator)$/,
    /^selected\.(?:abilitySlots|itemSlots)\.(?:[0-9]|1[01])\.(?:id|key|name|cooldown|level|category|active)$/,
    /^selected\.itemPurchase\.(?:id|itemId|name|at)$/,
    /^teams\.[01]\.(?:side|kills|netWorth|rejuvenatorCharges)$/,
    /^teams\.[01]\.players\.(?:[0-9]|1[01])\.(?:name|displayName|hero|heroId|souls|level|kills|deaths|assists|respawn|rejuvenator|hp|maxHp|hpPercent|invisible)$/,
    /^teams\.[01]\.players\.(?:[0-9]|1[01])\.ultimate\.(?:unlocked|ready|cooldown|level)$/,
];

export function broadcastName(displayName, rawName) {
    return typeof displayName === 'string' && displayName.trim() ? displayName : rawName;
}

export function rawNamePath(path) {
    if (path === 'selected.displayName') return 'selected.player';
    if (/^teams\.[0-9]+\.players\.[0-9]+\.displayName$/.test(path)) return path.replace(/displayName$/, 'name');
    return null;
}

function bindingValues(paths, telemetry) {
    const values = {};
    const read = path => path.split('.').reduce((object, key) =>
        object != null && Object.hasOwn(object, key) ? object[key] : undefined, telemetry);
    for (const path of paths) {
        if (path === 'selected.hpPercent') {
            const { hp, maxHp } = telemetry?.selected ?? {};
            if (Number.isFinite(hp) && Number.isFinite(maxHp) && maxHp > 0) {
                values[path] = Math.round(Math.min(100, Math.max(0, hp * 100 / maxHp)) * 100) / 100;
            }
            continue;
        }
        const rawPath = rawNamePath(path);
        const value = rawPath ? broadcastName(read(path), read(rawPath)) : read(path);
        if (typeof value === 'string' || typeof value === 'boolean' || Number.isFinite(value)) values[path] = value;
    }
    return values;
}

// This function runs in an opaque-origin document and uses no module state.
function startFrame(parentOrigin, bindingPattern) {
    const token = new RegExp(bindingPattern, 'g');
    const tags = new Set(('address article aside b bdi bdo blockquote br caption cite code col colgroup '
        + 'data dd del details dfn div dl dt em figcaption figure footer h1 h2 h3 h4 h5 h6 header hgroup '
        + 'hr i img ins kbd li main mark meter ol p pre progress q rp rt ruby s samp section small span '
        + 'strong sub summary sup table tbody td th thead tfoot time tr u ul var wbr').split(' '));
    const attributes = new Set(('class id title role style lang dir alt width height value min max low high '
        + 'optimum colspan rowspan scope span datetime open start reversed').split(' '));
    const embeddedImage = /^data:image\/(?:png|jpeg|webp|gif|avif);base64,[A-Za-z0-9+/=\s]+$/i;
    const styles = document.createElement('style');
    document.head.append(styles);
    const sourceAttribute = 'data-hud-source-' + crypto.getRandomValues(new Uint32Array(2)).join('-');
    const hoverAttribute = sourceAttribute + '-hover';
    const inspectionStyles = document.createElement('style');
    inspectionStyles.textContent = `body, body * {pointer-events:auto!important}
        [${hoverAttribute}] {outline:2px solid #a4e3d8!important;outline-offset:-2px!important}`;
    let inspecting = false;
    let revision;
    let port;
    let sourceHtml = '';
    let bindings = [];
    let locations = new WeakMap();
    let rules = [];
    let hovered;

    function tagEnd(html, offset) {
        while (offset < html.length) {
            const char = html[offset++];
            if (char === '>') return offset;
            if (char !== '=') continue;
            while (/[\t\n\f\r ]/.test(html[offset] ?? '')) offset++;
            const quote = html[offset];
            if (quote === '"' || quote === "'") {
                const end = html.indexOf(quote, offset + 1);
                if (end === -1) return;
                offset = end + 1;
            } else {
                while (offset < html.length && !/[\t\n\f\r >]/.test(html[offset])) offset++;
            }
        }
    }

    // Attach locations before parsing so corrected markup and repeated elements retain their identity.
    function markHtml(html) {
        const ranges = [];
        const parts = [];
        const tag = /[a-zA-Z][^\t\n\f\r />]*/y;
        const commentEnd = /--!?>/g;
        const rawTag = /^(?:script|style|textarea|title|xmp|iframe|noembed|noframes|plaintext)$/;
        let offset = 0;
        let copied = 0;
        while ((offset = html.indexOf('<', offset)) !== -1) {
            const start = offset++;
            if (html.startsWith('!--', offset)) {
                offset += 3;
                if (html[offset] === '>') offset++;
                else if (html.startsWith('->', offset)) offset += 2;
                else {
                    commentEnd.lastIndex = offset;
                    offset = commentEnd.exec(html) ? commentEnd.lastIndex : html.length;
                }
                continue;
            }
            if (/[!/?]/.test(html[offset] ?? '')) {
                offset = tagEnd(html, offset) ?? html.length;
                continue;
            }
            tag.lastIndex = offset;
            const match = tag.exec(html);
            if (!match) continue;
            const name = match[0].toLowerCase();
            const nameEnd = tag.lastIndex;
            const end = tagEnd(html, nameEnd);
            if (end === undefined) break;
            if (tags.has(name)) {
                parts.push(html.slice(copied, nameEnd), ` ${sourceAttribute}="${ranges.length}"`);
                ranges.push({ start, end });
                copied = nameEnd;
            }
            offset = end;
            if (rawTag.test(name)) {
                const close = new RegExp('</' + name + '(?=[\\t\\n\\f\\r />])', 'ig');
                close.lastIndex = end;
                offset = name === 'plaintext' ? html.length : (close.exec(html)?.index ?? html.length);
            }
        }
        parts.push(html.slice(copied));
        return [parts.join(''), ranges];
    }

    function locateRules(css) {
        const entries = [];
        const groups = [];
        const tokens = /\/\*[\s\S]*?(?:\*\/|$)|"(?:[^"\\]|\\[\s\S])*"|'(?:[^'\\]|\\[\s\S])*'|\\[\s\S]|[()[\]{};]/g;
        let offset = 0;
        let nesting = 0;
        for (const { 0: token, index } of css.matchAll(tokens)) {
            if (token === '(' || token === '[') nesting++;
            if (token === ')' || token === ']') nesting = Math.max(0, nesting - 1);
            if (nesting) continue;
            if (token === '{') {
                const header = css.slice(offset, index);
                const start = offset + header.match(/^(?:\s|\/\*[\s\S]*?\*\/)*/)[0].length;
                const selector = css.slice(start, index).trimEnd();
                const query = selector.replace(tokens, value => value.startsWith('/*') ? '' : value).trim();
                const parent = groups.length ? groups.at(-1) : [];
                const group = query.match(/^@(media|supports|layer)\b\s*([\s\S]*)$/i);
                if (parent && query && !query.startsWith('@')) {
                    entries.push({ range: { start, end: start + selector.length, selector }, query, conditions: parent });
                }
                groups.push(parent && group ? [...parent, [group[1].toLowerCase(), group[2]]] : null);
            }
            if (token === '}') groups.pop();
            if (token === '{' || token === '}' || token === ';') offset = index + 1;
        }
        return entries;
    }

    function matchingRules(element) {
        return rules.filter(({ query, conditions }) => {
            try {
                return element.matches(query) && conditions.every(([kind, condition]) =>
                    kind === 'layer' || (kind === 'media' ? matchMedia(condition).matches : CSS.supports(condition)));
            } catch {
                return false;
            }
        }).slice(-12).map(({ range }) => range);
    }

    function report(detail) {
        port.postMessage({ revision, detail });
    }

    function clearHover(notify = true) {
        if (!hovered) return;
        hovered.removeAttribute(hoverAttribute);
        hovered = undefined;
        if (notify) report(null);
    }

    function point(event, kind) {
        if (!inspecting) return;
        let element = event.target;
        while (element && !locations.has(element)) element = element.parentElement;
        if (!element) {
            clearHover();
            return;
        }
        if (element === hovered && kind === 'hover') return;
        event.preventDefault();
        clearHover(false);
        hovered = element;
        element.setAttribute(hoverAttribute, '');
        const cssMatches = matchingRules(element);
        report({ kind, html: locations.get(element), css: cssMatches.at(-1), cssMatches,
            tag: element.localName, id: element.id, classes: [...element.classList] });
    }

    document.addEventListener('pointermove', event => point(event, 'hover'));
    document.addEventListener('click', event => point(event, 'select'));
    document.addEventListener('pointerout', event => {
        if (inspecting && !event.relatedTarget) clearHover();
    });
    document.addEventListener('keydown', event => {
        if (!inspecting || !(event.ctrlKey || event.metaKey) || event.key.toLowerCase() !== 'f') return;
        event.preventDefault();
        report({ kind: 'find' });
    });

    function bind(source, set, numeric = false) {
        if (source.search(token) !== -1) {
            bindings.push(values => {
                const value = source.replace(token, (_, path) => {
                    const item = Object.hasOwn(values, path) ? values[path] : undefined;
                    return numeric ? (typeof item === 'number' ? item : '') : (item ?? '—');
                });
                set(value);
            });
        } else {
            set(source);
        }
    }

    function copyContent(source, target, ranges) {
        for (const child of source.childNodes) {
            if (child.nodeType === Node.TEXT_NODE) {
                const text = document.createTextNode('');
                bind(child.data, value => { text.data = value; });
                target.append(text);
            } else if (child.namespaceURI === 'http://www.w3.org/1999/xhtml' && tags.has(child.localName)) {
                const element = document.createElement(child.localName);
                for (const { name, value } of child.attributes) {
                    if (name === sourceAttribute) {
                        locations.set(element, ranges[Number(value)]);
                        continue;
                    }
                    if (attributes.has(name) || /^(?:aria|data)-[a-z][a-z0-9-]*$/.test(name)) {
                        bind(value, next => element.setAttribute(name, next), name === 'style');
                    } else if (name === 'src' && child.localName === 'img' && embeddedImage.test(value)) {
                        element.setAttribute(name, value);
                    }
                }
                target.append(element);
                copyContent(child, element, ranges);
            }
        }
    }

    function receivePort(event) {
        if (event.source !== parent || event.origin !== parentOrigin || event.data !== 'hud-code' || !event.ports[0]) return;
        window.removeEventListener('message', receivePort);
        port = event.ports[0];
        port.onmessage = ({ data: { html, css, values, inspect, revision: nextRevision } }) => {
            revision = nextRevision;
            if (inspect !== undefined) {
                inspecting = inspect;
                if (inspect) document.head.append(inspectionStyles);
                else {
                    clearHover(false);
                    inspectionStyles.remove();
                    locations = new WeakMap();
                    rules = [];
                }
            }
            if (css !== undefined) {
                clearHover(inspecting);
                styles.textContent = css;
            }
            if (html !== undefined) sourceHtml = html;
            if (inspecting && (inspect || css !== undefined)) rules = locateRules(styles.textContent);
            if (html !== undefined || inspect) {
                // A template keeps parsed nodes inert before their visual parts are copied.
                clearHover(inspecting);
                const template = document.createElement('template');
                const [markup, ranges] = inspecting ? markHtml(sourceHtml) : [sourceHtml, []];
                template.innerHTML = markup;
                const content = document.createDocumentFragment();
                bindings = [];
                locations = new WeakMap();
                copyContent(template.content, content, ranges);
                document.body.replaceChildren(content);
            }
            for (const update of bindings) update(values);
        };
    }

    window.addEventListener('message', receivePort);
}

function mountFrame(block) {
    const frame = document.createElement('iframe');
    const nonce = crypto.getRandomValues(new Uint32Array(4)).join('-');
    const channel = new MessageChannel();
    frame.className = 'studio-code-frame';
    frame.title = 'Пользовательский HUD';
    frame.tabIndex = -1;
    frame.setAttribute('sandbox', 'allow-scripts');
    frame.setAttribute('referrerpolicy', 'no-referrer');
    frame.addEventListener('load', () => {
        frame.contentWindow?.postMessage('hud-code', '*', [channel.port2]);
    }, { once: true });
    // Only the app script is part of the initial document. Authors' HTML and CSS arrive as data.
    frame.srcdoc = `<!doctype html><meta charset="utf-8">
        <meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'nonce-${nonce}';
            style-src 'unsafe-inline'; img-src data:; base-uri 'none'; form-action 'none'">
        <style>html,body{margin:0;width:100%;height:100%;overflow:hidden;background:transparent;color-scheme:normal}
        body{font:24px system-ui,sans-serif;color:#eef7f6}</style>
        <body><script nonce="${nonce}">(${startFrame})(${JSON.stringify(location.origin)}, ${JSON.stringify(binding.source)});</script>`;
    block.replaceChildren(frame);
    const state = { frame, port: channel.port1, revision: 0 };
    state.port.onmessage = ({ data }) => {
        if (data.revision === state.revision) state.onInspect?.(data.detail);
    };
    frames.set(block, state);
    return state;
}

export function renderCode(block, layer, telemetry, onInspect) {
    const state = frames.get(block) ?? mountFrame(block);
    const html = typeof layer.html === 'string' ? layer.html : '';
    const css = typeof layer.css === 'string' ? layer.css : '';
    const change = {};
    if (state.html !== html) {
        state.html = change.html = html;
        state.paths = new Set([...html.matchAll(binding)].map(match => match[1])
            .filter(path => publicPaths.some(pattern => pattern.test(path))));
    }
    if (state.css !== css) state.css = change.css = css;
    if (Boolean(onInspect) !== Boolean(state.onInspect)) {
        change.inspect = Boolean(onInspect);
        state.frame.toggleAttribute('data-code-inspection', change.inspect);
    }
    state.onInspect = onInspect;
    const values = bindingValues(state.paths, telemetry);
    const signature = JSON.stringify(values);
    const sourceChanged = change.html !== undefined || change.css !== undefined || change.inspect !== undefined;
    if (sourceChanged || state.signature !== signature) {
        if (sourceChanged) state.revision++;
        state.signature = signature;
        state.port.postMessage({ ...change, values, revision: state.revision });
    }
}

export function clearCode(block) {
    const state = frames.get(block);
    if (!state) return;
    frames.delete(block);
    state.port.close();
    state.frame.remove();
}
