// The editor and the exported HUD both render on a 1920 × 1080 canvas.
import { inventory, ITEM_SLOTS } from '/hud-inventory.js';
import { createRiftNotice } from '/hud-rift.js';
import { createMidBossNotice, setRejuvenatorBadge } from '/hud-mid-boss.js';
import { broadcastName, clearCode, rawNamePath, renderCode } from './hud_code.js';

export const WIDTH = 1920;
export const HEIGHT = 1080;
export const ROSTER_DEFAULTS = Object.freeze({
    rosterFrameColor: '#52666a', rosterFrameWidth: 1, rosterFrameRadius: 6,
    rosterBackground: '#121d22', rosterFill: 0, rosterHighlight: true, rosterShowNames: true,
    rosterShowRejuvenator: true, rosterShowHealth: true, rosterShowUltimate: true,
    rosterShowRespawn: true, rosterShowInvisible: true,
    rosterActiveFrameColor: '#9bf2db', rosterActiveFrameWidth: 3, rosterActiveFrameRadius: 6,
    rosterActiveBackground: '#264941', rosterActiveFill: 65,
});
const defaultArt = '/hud/packages/deadlock-default/';
const localKey = value => String(value ?? '').normalize('NFKC').trim().toLowerCase();
const key = value => localKey(value).replace(/[^a-z0-9]/g, '');
const text = value => String(value ?? '—').replace(/<[^>]*>/g, '');
const panoramaPattern = /^[A-Za-z][A-Za-z0-9_-]*(?:\.(?:[A-Za-z][A-Za-z0-9_-]*|0|[1-9][0-9]*)|\[(?:0|[1-9][0-9]*)\])*$/;
const panoramaSegment = /^(?:[A-Za-z][A-Za-z0-9_-]*|0|[1-9][0-9]*)$/;
const allowedSegment = segment => panoramaSegment.test(segment) && segment !== 'constructor' && segment !== 'prototype';
const displayValue = value => value === null || typeof value === 'string' || typeof value === 'boolean' || Number.isFinite(value);
const teamPlayers = team => Array.isArray(team?.players) ? team.players : [];
const portraitSettings = ['rosterShowHealth', 'rosterShowUltimate', 'rosterShowRespawn',
    'rosterShowInvisible', 'rosterShowRejuvenator'];
const selectedPortraitSettings = ['playerShowRespawn', 'playerShowInvisible', 'playerShowRejuvenator'];
const purchaseMs = 5000;
let art = {};
let revision = 0;

export function panoramaPath(value) {
    if (typeof value !== 'string' || value.length > 160) return null;
    const path = value.trim();
    if (!path) return '';
    if (!panoramaPattern.test(path)) return null;
    const normalized = path.replace(/\[([0-9]+)\]/g, '.$1');
    return normalized.split('.').every(allowedSegment) ? normalized : null;
}

function ownValue(object, segment) {
    if (!object || typeof object !== 'object') return undefined;
    const descriptor = Object.getOwnPropertyDescriptor(object, segment);
    return descriptor?.enumerable && Object.hasOwn(descriptor, 'value') ? descriptor.value : undefined;
}

function panoramaValue(telemetry, path) {
    const normalized = panoramaPath(path);
    if (!normalized) return undefined;
    const read = key => key.split('.').reduce(ownValue, telemetry);
    const rawPath = rawNamePath(normalized);
    const value = rawPath ? broadcastName(read(normalized), read(rawPath)) : read(normalized);
    return displayValue(value) ? value : undefined;
}

export function panoramaPaths(telemetry) {
    const paths = [];
    function visit(value, path) {
        if (path && displayValue(value)) {
            paths.push(path);
        } else if (value && typeof value === 'object') {
            for (const key of Object.keys(value)) {
                if (paths.length >= 512) break;
                if (!allowedSegment(key) || (!path && !/^[A-Za-z]/.test(key))) continue;
                const next = path ? path + '.' + key : key;
                if (next.length <= 160) visit(ownValue(value, key), next);
            }
        }
    }
    visit(telemetry, '');
    return paths;
}

async function json(url) {
    const response = await fetch(url);
    if (!response.ok) throw new Error('Ресурс недоступен');
    return response.json();
}

export async function loadArt() {
    const [fallback, native] = await Promise.allSettled([
        art.fallback ?? json(defaultArt + 'icons.json'), json('/game-icons/catalog.json'),
    ]);
    if (!art.fallback && fallback.status === 'fulfilled') {
        art.fallback = { ...fallback.value, url: defaultArt + 'icons.webp' };
        revision++;
    }
    if (native.status === 'fulfilled' && /^icons-[0-9a-f]{16}\.webp$/.test(native.value.image)
        && art.native?.image !== native.value.image) {
        art.native = { ...native.value, url: '/game-icons/' + native.value.image,
            itemIds: new Set(native.value.items) };
        revision++;
    }
}

function el(tag, cls, value) {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (value != null) node.textContent = value;
    return node;
}

function tile(native, fallback, label) {
    const node = el('span', 'studio-art');
    const sheet = native ? art.native : art.fallback;
    const coords = native ?? sheet?.positions?.[fallback];
    if (coords && sheet) {
        node.style.backgroundImage = 'url("' + sheet.url + '")';
        node.style.backgroundSize = (sheet.columns * 100) + '% ' + (sheet.rows * 100) + '%';
        node.style.backgroundPosition =
            (coords[0] * 100 / Math.max(1, sheet.columns - 1)) + '% ' +
            (coords[1] * 100 / Math.max(1, sheet.rows - 1)) + '%';
        node.setAttribute('aria-label', label);
        node.setAttribute('role', 'img');
    } else {
        node.textContent = String(label || '—').slice(0, 2).toUpperCase();
    }
    return node;
}

function heroId(player) {
    return player?.heroId ?? art.native?.heroNames?.[localKey(player?.hero)];
}

function portrait(player) {
    return tile(art.native?.heroIcons?.[heroId(player)], art.fallback?.heroes?.[key(player?.hero)], player?.hero);
}

const slottedItem = item => /^[ZXCVЯЧСМ]$/i.test(String(item?.key ?? '').trim()) ||
    (Number.isInteger(item?.index) && item.index >= 0 && item.index < 4);
const activeItem = item => item && item.active !== false && item.category !== 'passive';
const itemIdentity = item => item && String(item.id ?? item.name ?? item.icon ?? item.image ?? '');

function activeItems(selected) {
    const reported = Array.isArray(selected?.itemSlots) ? selected.itemSlots : [];
    const owned = selected?.loadout?.filter(item => item.slot >= 4 && item.slot < 8);
    const active = reported.length === 4 ? reported.map(item => activeItem(item) ? item : null) :
        reported.filter(item => activeItem(item) && slottedItem(item));
    const slots = inventory(active, owned, art.native).slice(0, 4);
    for (const item of reported) {
        if (!activeItem(item) || (item.active !== true && item.category !== 'active') ||
                !itemIdentity(item) || slots.some(slot => itemIdentity(slot) === itemIdentity(item))) continue;
        const vacancy = slots.indexOf(null);
        if (vacancy >= 0) slots[vacancy] = item;
    }
    return slots;
}

function loadout(selected, type, itemsMode) {
    if (type === 'active-items') return activeItems(selected);
    if (type === 'items') {
        const full = inventory(selected?.itemSlots, selected?.loadout, art.native);
        if (itemsMode !== 'passive') return full;
        const active = new Set(activeItems(selected).map(itemIdentity).filter(Boolean));
        const passive = full.filter(item => item && (!activeItem(item) ||
            (!active.has(itemIdentity(item)) && !slottedItem(item))));
        return [...passive, ...Array(ITEM_SLOTS - passive.length).fill(null)];
    }
    const reported = selected?.abilitySlots;
    if (!Array.isArray(selected?.loadout)) return reported ?? [];
    const matches = new Map();
    for (const entry of selected.loadout) {
        if (entry.slot < 0 || entry.slot >= 4) continue;
        const index = entry.slot;
        if (matches.has(index) && matches.get(index).id !== entry.id) {
            matches.set(index, {});
        } else if (!matches.has(index)) {
            const native = reported?.find(slot => Number(slot?.key) === index + 1 || slot?.index === index)
                ?? (reported?.length === 4 ? reported[index] : null);
            matches.set(index, { ...native, index, id: entry.id });
        }
    }
    const result = [...matches.entries()].sort(([a], [b]) => a - b).map(([, value]) => value)
        .filter(entry => entry.id != null);
    return result.length ? result : reported ?? [];
}

function renderSlots(slots, player, type, showLevels) {
    const row = el('div', 'studio-slots' + (type === 'items' ? ' studio-inventory' : ''));
    for (const [index, slot] of slots.entries()) {
        if (!slot) {
            const empty = el('span', 'studio-slot empty-slot');
            empty.setAttribute('aria-label', 'Пустой слот ' + (index + 1));
            row.append(empty);
            continue;
        }
        const ability = type === 'abilities';
        const number = slot.index ?? (/^[1-4]$/.test(slot.key ?? '') ? Number(slot.key) - 1 : index);
        const id = slot.id ?? (ability ? art.native?.heroSlots?.[heroId(player)]?.[number + 1] : null)
            ?? art.native?.abilityNames?.[localKey(slot.name)];
        const kind = ability ? 'ability-' : 'item-';
        const slotName = key(slot.name);
        const fallback = (art.fallback?.positions?.[slot.icon] && slot.icon)
            || Object.keys(art.fallback?.positions ?? {}).find(value =>
                slotName && value.startsWith(kind) && key(value.slice(kind.length)) === slotName)
            || (ability && art.fallback?.heroAbilities?.[art.fallback?.heroes?.[key(player?.hero)]]?.[number]);
        const cell = el('span', 'studio-slot');
        cell.title = slot.name ?? '';
        cell.append(tile(art.native?.abilityIcons?.[id], fallback, slot.name ?? slot.key));
        if (slot.key) cell.append(el('small', 'studio-binding', slot.key));
        if (ability && showLevels && Number.isInteger(slot.level) && slot.level >= 0) {
            const badge = el('small', 'studio-ability-level', slot.level);
            badge.title = 'Уровень способности: ' + slot.level;
            cell.append(badge);
        }
        if (slot.cooldown > 0) {
            cell.classList.add('recharging');
            cell.append(el('b', 'studio-cooldown', slot.cooldown < 3 ? slot.cooldown.toFixed(1) : Math.ceil(slot.cooldown)));
        }
        row.append(cell);
    }
    return row;
}

const signatures = new WeakMap();
const cameras = new WeakMap();
const riftNotices = new WeakMap();
const midBossNotices = new WeakMap();
const purchaseTimers = new WeakMap();

const assetPath = /^images\/[0-9a-f]{32}\.(png|jpg|webp)$/;

function positionRoster(node, layer) {
    const value = field => layer[field] ?? ROSTER_DEFAULTS[field];
    node.toggleAttribute('data-roster-highlight', value('rosterHighlight'));
    node.toggleAttribute('data-roster-portraits-only', !value('rosterShowNames'));
    for (const [fieldPrefix, cssPrefix] of [['roster', '--roster-'], ['rosterActive', '--roster-active-']]) {
        const alpha = Math.round(value(fieldPrefix + 'Fill') * 255 / 100).toString(16).padStart(2, '0');
        node.style.setProperty(cssPrefix + 'background', value(fieldPrefix + 'Background') + alpha);
        node.style.setProperty(cssPrefix + 'frame-color', value(fieldPrefix + 'FrameColor'));
        node.style.setProperty(cssPrefix + 'frame-width', value(fieldPrefix + 'FrameWidth') + 'px');
        node.style.setProperty(cssPrefix + 'frame-radius', value(fieldPrefix + 'FrameRadius') + 'px');
    }
}

function playerLabel(tag, className, name) {
    const label = el(tag, className, name);
    if (name) label.title = name;
    return label;
}

function seconds(value) {
    if (Number.isFinite(value)) return value >= 0 ? Math.ceil(value) : null;
    if (typeof value !== 'string') return null;
    const match = /^(?:(\d{1,2}):([0-5]\d)|(\d{1,3})(?:\s*с)?)$/.exec(value.trim());
    return match ? (match[3] ? Number(match[3]) : Number(match[1]) * 60 + Number(match[2])) : null;
}

function hudClock(value) {
    return Math.floor(value / 60) + ':' + String(value % 60).padStart(2, '0');
}

function clampPercent(value) {
    return Math.max(0, Math.min(100, value));
}

function percentage(value, max) {
    return Number.isFinite(value) && Number.isFinite(max) && max > 0 ? clampPercent(value * 100 / max) : null;
}

function barAt(value, label) {
    const track = el('span', 'studio-track');
    track.setAttribute('role', 'meter');
    track.setAttribute('aria-label', label);
    track.setAttribute('aria-valuemin', '0');
    track.setAttribute('aria-valuemax', '100');
    const fill = el('span', 'studio-fill');
    track.append(fill);
    setBar(track, value);
    return track;
}

function setBar(track, value) {
    track.hidden = value === null;
    if (value === null) return;
    track.setAttribute('aria-valuenow', String(Math.round(value)));
    track.firstElementChild.style.width = value + '%';
}

function portraitMarks(image, player, { respawn, invisible, rejuvenator }) {
    if (rejuvenator) setRejuvenatorBadge(image, player.rejuvenator);
    window.DeadlockHUD?.decoratePortrait?.(image, rejuvenator ? player : { ...player, rejuvenator: null });
    const remaining = respawn ? seconds(player.respawn) : null;
    const hidden = invisible && player.invisible === true;
    if (!(remaining > 0) && !hidden) return;
    image.setAttribute('data-portrait-status', '');
    if (remaining > 0) {
        const timer = el('b', 'studio-respawn', remaining < 60 ? remaining : hudClock(remaining));
        timer.title = 'Возрождение через ' + remaining + ' с';
        image.append(timer);
    }
    if (hidden) {
        const mark = el('span', 'studio-invisible', 'Инвиз');
        mark.title = 'Невидимость';
        image.append(mark);
    }
}

function rosterSignals(item, member, layer) {
    if (layer.rosterShowHealth !== true && layer.rosterShowUltimate !== true) return;
    const signals = el('span', 'studio-member-signals');
    const hp = Number.isFinite(member.hpPercent) ? clampPercent(member.hpPercent) : percentage(member.hp, member.maxHp);
    if (layer.rosterShowHealth === true && hp !== null) {
        const meter = barAt(hp, 'Здоровье');
        meter.title = Number.isFinite(member.hp) && Number.isFinite(member.maxHp) ?
            `${member.hp} / ${member.maxHp} HP` : `${Math.round(hp)}% HP`;
        signals.append(meter);
    }
    const ultimate = member.ultimate;
    if (layer.rosterShowUltimate === true && ultimate) {
        const cooldown = seconds(ultimate.cooldown);
        let title, value;
        if (ultimate.unlocked === false) [title, value] = ['Ульта не открыта', '4 ×'];
        else if (ultimate.ready === true) [title, value] = ['Ульта готова', '4 ✓'];
        else if (cooldown > 0) [title, value] = [`Ульта через ${cooldown} с`, '4 · ' + cooldown];
        else if (ultimate.ready === false) [title, value] = ['Ульта не готова', '4 · …'];
        if (value) {
            const badge = el('small', 'studio-ultimate', value);
            badge.toggleAttribute('data-ready', ultimate.ready === true && ultimate.unlocked !== false);
            badge.title = title;
            badge.setAttribute('aria-label', title);
            signals.append(badge);
        }
    }
    if (signals.childElementCount) {
        item.setAttribute('data-signals', '');
        item.append(signals);
    }
}

function clearPurchase(block) {
    clearTimeout(purchaseTimers.get(block)?.timer);
    purchaseTimers.delete(block);
}

function recentPurchase(block, layer, telemetry, editing) {
    const purchase = telemetry?.selected?.itemPurchase;
    const at = purchase?.at;
    const until = Number.isFinite(at) && at > 0 ? at + purchaseMs - Date.now() : 0;
    if (until <= 0 || until > purchaseMs + 1000 || (purchase?.id == null && purchase?.itemId == null && !purchase?.name)) {
        clearPurchase(block);
        return null;
    }
    if (purchaseTimers.get(block)?.at !== at) {
        clearPurchase(block);
        const timer = setTimeout(() => {
            purchaseTimers.delete(block);
            if (block.isConnected) render(block, layer, telemetry, editing);
        }, until + 1);
        purchaseTimers.set(block, { at, timer });
    }
    return purchase;
}

export function position(node, layer, imageUrl = assetPath.test(layer.image) ? layer.image : '') {
    Object.assign(node.style, { left: layer.x + 'px', top: layer.y + 'px',
        width: layer.w + 'px', height: layer.h + 'px', color: layer.color,
        opacity: layer.opacity / 100, fontSize: layer.size + 'px', textAlign: layer.align,
        borderRadius: (layer.radius ?? 0) + 'px',
        backgroundImage: imageUrl ? 'url("' + imageUrl + '")' : 'none',
        backgroundSize: layer.imageFit === 'contain' || layer.imageFit === 'cover' ? layer.imageFit : '100% 100%',
        backgroundColor: layer.background + Math.round(layer.fill * 255 / 100).toString(16).padStart(2, '0') });
    node.style.setProperty('--frame-width', (layer.frameWidth ?? 0) + 'px');
    node.style.setProperty('--frame-color', layer.frameColor ?? '#a4e3d8');
    node.dataset.align = layer.align;
    node.toggleAttribute('data-image', Boolean(imageUrl));
    node.toggleAttribute('data-wrap-names', layer.nameOverflow === 'wrap');
    for (const [name, value] of Object.entries({
        x: layer.dataX ?? 0, y: layer.dataY ?? 0, w: layer.dataW ?? 100, h: layer.dataH ?? 100,
    })) {
        node.style.setProperty('--data-' + name, value + '%');
    }
    if (layer.type === 'roster') positionRoster(node, layer);
    if (layer.type === 'pov') {
        node.style.setProperty('--pov-fit', layer.imageFit === 'stretch' ? 'fill' : layer.imageFit ?? 'contain');
    }
}

export function fit(board, viewport) {
    const scale = Math.min(viewport.clientWidth / WIDTH, viewport.clientHeight / HEIGHT);
    board.style.transform = 'translate(-50%, -50%) scale(' + (scale || 0.001) + ')';
}

function cameraSource(pov) {
    const { url, format = 'video' } = pov ?? {};
    if (typeof url !== 'string' || !url || !['video', 'mjpeg', 'iframe'].includes(format)) return;
    try {
        const address = new URL(url);
        if (!['http:', 'https:'].includes(address.protocol) || address.username || address.password) return;
        if (format === 'iframe' && address.origin === location.origin) return;
        return { url: address.href, format };
    } catch {
        return;
    }
}

function cameraMedia(format) {
    const media = el(format === 'mjpeg' ? 'img' : format, 'studio-pov-media');
    media.setAttribute('referrerpolicy', 'no-referrer');
    media.draggable = false;
    if (format === 'video') {
        media.autoplay = media.defaultMuted = media.muted = media.playsInline = true;
    } else if (format === 'iframe') {
        media.title = 'Камера POV';
        media.tabIndex = -1;
        media.setAttribute('sandbox', 'allow-scripts allow-same-origin');
        media.setAttribute('allow', 'autoplay; fullscreen');
    } else {
        media.alt = '';
    }
    return media;
}

function clearPov(block) {
    const state = cameras.get(block);
    if (!state) return;
    cameras.delete(block);
    clearTimeout(state.retry);
    if (!state.media) return;
    state.media.remove();
    state.media.removeAttribute('src');
    if (state.format === 'video') state.media.load();
}

export function release(block) {
    clearCode(block);
    clearPov(block);
    clearNotice(block, riftNotices);
    clearNotice(block, midBossNotices);
    clearPurchase(block);
}

function clearNotice(block, notices) {
    const notice = notices.get(block);
    if (!notice) return;
    notice.remove();
    block.replaceChildren();
    notices.delete(block);
}

function noticeFor(block, notices, create) {
    let notice = notices.get(block);
    if (!notice) {
        const content = el('div', 'studio-content');
        block.replaceChildren(content);
        notice = create(content, { onVisibility: shown => { block.hidden = !shown; } });
        notices.set(block, notice);
        block.classList.remove('row-empty');
    }
    return notice;
}

function showCamera(block, state) {
    block.hidden = !state.editing && !state.ready && !block.hasAttribute('data-image');
    block.classList.toggle('row-empty', !state.ready);
    if (state.media) state.media.hidden = !state.ready;
}

function renderPov(block, pov, editing) {
    const { url, format } = cameraSource(pov) ?? {};
    let state = cameras.get(block);
    if (state && state.url === url && state.format === format) {
        state.editing = editing;
        showCamera(block, state);
        return;
    }
    clearPov(block);
    const media = url ? cameraMedia(format) : null;
    state = { url, format, media, editing, ready: false };
    cameras.set(block, state);
    block.replaceChildren();
    showCamera(block, state);
    if (!media) return;
    media.addEventListener(format === 'video' ? 'loadeddata' : 'load', () => {
        if (cameras.get(block) !== state) return;
        state.ready = true;
        showCamera(block, state);
    });
    media.addEventListener('error', () => {
        if (cameras.get(block) !== state) return;
        state.ready = false;
        showCamera(block, state);
        clearTimeout(state.retry);
        state.retry = setTimeout(() => {
            if (block.isConnected && cameras.get(block) === state) media.src = url;
        }, 2000);
    });
    media.src = url;
    block.append(media);
}

export function render(block, layer, telemetry, editing = false, onInspect, pov) {
    const { type } = layer;
    if (type !== 'purchase') clearPurchase(block);
    if (type !== 'pov') clearPov(block);
    if (type !== 'rift') clearNotice(block, riftNotices);
    if (type !== 'midboss') clearNotice(block, midBossNotices);
    if (type === 'code') {
        block.hidden = false;
        block.classList.remove('row-empty');
        signatures.delete(block);
        renderCode(block, layer, telemetry, editing ? onInspect : undefined);
        return;
    }
    clearCode(block);
    if (type === 'pov') {
        signatures.delete(block);
        renderPov(block, pov, editing);
        return;
    }
    if (type === 'rift') {
        signatures.delete(block);
        noticeFor(block, riftNotices, createRiftNotice).update(telemetry?.rift, editing);
        return;
    }
    if (type === 'midboss') {
        signatures.delete(block);
        noticeFor(block, midBossNotices, createMidBossNotice)
            .update(telemetry?.midBoss, { teams: telemetry?.teams, editing });
        return;
    }
    const teams = Array.isArray(telemetry?.teams) ? telemetry.teams : [];
    const selected = telemetry?.selected;
    const players = teams.flatMap(teamPlayers);
    const matches = selected?.player ? players.filter(member => member?.name === selected.player) : [];
    const player = matches.length === 1 ? matches[0] : undefined;
    const selectedName = broadcastName(selected?.displayName, selected?.player);
    const spree = type === 'player' && selected?.killingSpree === true
        ? 'Серия' + (Number.isInteger(selected.killStreak) && selected.killStreak > 0 ? ' ' + selected.killStreak : '')
        : '';
    let data;
    switch (type) {
        case 'clock': data = telemetry?.gameClock; break;
        case 'boss': data = telemetry?.midBossTimer; break;
        case 'score': data = teams.map(team => team?.kills); break;
        case 'networth': data = teams.map(team => team?.netWorth); break;
        case 'roster':
            data = players.length ? [players, selected?.player,
                layer.rosterShowHealth === true && [selected?.hp, selected?.maxHp, selected?.hpPercent],
                layer.rosterShowInvisible === true && selected?.invisible] : null;
            break;
        case 'names': {
            const scope = layer.namesTeam;
            const members = scope === 'first' ? teamPlayers(teams[0]) :
                scope === 'second' ? teamPlayers(teams[1]) :
                scope === 'selected' ? [{ name: selectedName }] : players;
            const names = members.map(member => broadcastName(member?.displayName, member?.name))
                .filter(name => typeof name === 'string' && name.trim());
            data = names.length ? [layer.namesDirection ?? 'row', names] : null;
            break;
        }
        case 'panorama': {
            const value = panoramaValue(telemetry, layer.panoramaPath ?? 'gameClock');
            data = value === undefined ? null : (layer.panoramaPrefix ?? '') + (value ?? '—') + (layer.panoramaSuffix ?? '');
            break;
        }
        case 'player': data = selected?.player && { ...player, name: selectedName,
            invisible: selected.invisible ?? player?.invisible, respawn: player?.respawn ?? selected.respawn,
            rejuvenator: player?.rejuvenator ?? selected.rejuvenator }; break;
        case 'health': data = selected && [selected.hp, selected.maxHp, selected.regen, selected.lowHp === true || undefined]; break;
        case 'series': {
            const { bestOf, leftWins, rightWins } = telemetry?.series ?? {};
            const maximum = Math.floor(bestOf / 2) + 1;
            data = Number.isInteger(bestOf) && bestOf >= 1 && bestOf <= 9 &&
                [leftWins, rightWins].every(wins => Number.isInteger(wins) && wins >= 0 && wins <= maximum) &&
                leftWins + rightWins <= bestOf ? `BO${bestOf} · ${leftWins}–${rightWins}` : null;
            break;
        }
        case 'stamina':
            data = Number.isFinite(selected?.stamina) ? [selected.stamina, selected.maxStamina] : null;
            break;
        case 'ammo':
            data = selected?.ammoInfinite === true ? ['∞', null] :
                Number.isFinite(selected?.ammo) ? [selected.ammo, selected.maxAmmo] : null;
            break;
        case 'insecure-souls':
            data = Number.isFinite(selected?.insecureSouls) ? String(selected.insecureSouls) : null;
            break;
        case 'rift-timer': {
            const rift = telemetry?.rift;
            const remaining = seconds(rift?.secondsUntil);
            const location = typeof rift?.location === 'string' ? rift.location.trim() : '';
            const countdown = remaining === null ? '' : (rift.estimated === true ? '≈ ' : '') + hudClock(remaining);
            data = rift?.phase === 'spawned' ? null :
                countdown ? [countdown, location].filter(Boolean).join(' · ') :
                rift?.phase === 'warning' && location ? 'Рифт · ' + location : null;
            break;
        }
        case 'purchase': data = recentPurchase(block, layer, telemetry, editing); break;
        case 'active-items': {
            const slots = loadout(selected, type);
            data = slots.some(Boolean) ? slots : null;
            break;
        }
        case 'abilities': case 'items': data = loadout(selected, type, layer.itemsMode); break;
        case 'kda': data = player && [player.kills, player.deaths, player.assists]; break;
        case 'text': data = layer.text; break;
        case 'panel': case 'image': data = true; break;
    }
    const hasImage = block.hasAttribute('data-image');
    const controls = type === 'roster' ? portraitSettings.map(key => layer[key]) :
        type === 'player' ? selectedPortraitSettings.map(key => layer[key]) :
        type === 'abilities' ? layer.abilitiesShowLevels : undefined;
    const signature = JSON.stringify([type, data, player?.hero, revision, editing, hasImage, spree, controls]);
    if (signatures.get(block) === signature) return;
    signatures.set(block, signature);

    const hasData = type === 'panorama' ? data !== null :
        type === 'items' || (Array.isArray(data) ? data.some(value => value != null) : Boolean(data));
    block.hidden = !editing && !hasData && !hasImage;
    block.classList.toggle('row-empty', !hasData || type === 'panel' || type === 'image');
    const node = block.firstElementChild ?? block.appendChild(el('div', 'studio-content'));
    if (!hasData) {
        node.replaceChildren();
        return;
    }
    switch (type) {
        case 'panel': case 'image':
            node.replaceChildren();
            break;
        case 'text': case 'panorama': case 'insecure-souls': case 'rift-timer': case 'series':
            node.replaceChildren(el('span', 'studio-line', data));
            break;
        case 'clock': case 'boss':
            node.replaceChildren(el('span', 'studio-line', text(data)));
            break;
        case 'score': case 'networth': case 'kda':
            node.replaceChildren(el('span', 'studio-line', data.map(text).join(type === 'kda' ? ' / ' : '  ·  ')));
            break;
        case 'roster': {
            const list = el('div', 'studio-roster');
            for (const member of players) {
                if (!member) continue;
                const item = el('span', 'studio-member');
                if (typeof member.name === 'string') item.dataset.rosterPlayer = member.name;
                const observed = member === player;
                if (observed) {
                    item.classList.add('observed');
                    item.setAttribute('aria-current', 'true');
                }
                const image = portrait(member);
                const status = observed ? { ...member, hp: member.hp ?? selected?.hp,
                    maxHp: member.maxHp ?? selected?.maxHp, hpPercent: member.hpPercent ?? selected?.hpPercent,
                    invisible: member.invisible ?? selected?.invisible } : member;
                portraitMarks(image, status, { respawn: layer.rosterShowRespawn === true,
                    invisible: layer.rosterShowInvisible === true, rejuvenator: layer.rosterShowRejuvenator !== false });
                item.append(image);
                rosterSignals(item, status, layer);
                item.append(playerLabel('strong', 'studio-nickname', broadcastName(member.displayName, member.name)));
                list.append(item);
            }
            node.replaceChildren(list);
            break;
        }
        case 'names': {
            const [direction, names] = data;
            const row = el('div', direction === 'column' ? 'studio-names column' : 'studio-names');
            row.append(...names.map(name => playerLabel('span', 'studio-line studio-nickname', name)));
            node.replaceChildren(row);
            break;
        }
        case 'player': {
            const identity = el('div', 'studio-player');
            const label = el('span', 'studio-player-label');
            label.append(playerLabel('strong', 'studio-nickname', data.name), el('small', '', data.hero ?? ''));
            if (spree) label.append(el('span', 'studio-spree', spree));
            const image = portrait(data);
            if (selectedPortraitSettings.some(key => layer[key] === true)) {
                portraitMarks(image, data, { respawn: layer.playerShowRespawn === true,
                    invisible: layer.playerShowInvisible === true, rejuvenator: layer.playerShowRejuvenator === true });
            }
            identity.append(image, label);
            node.replaceChildren(identity);
            break;
        }
        case 'health': {
            let meter = node.firstElementChild;
            const identity = String(selected?.player) + ':' + String(telemetry?.selection);
            if (!meter || meter.dataset.player !== identity) {
                meter = el('div', 'studio-health');
                meter.dataset.player = identity;
                const bar = el('span', 'studio-track');
                bar.append(el('span', 'studio-fill'));
                meter.append(el('strong', 'studio-line'), bar);
                node.replaceChildren(meter);
            }
            const [hp, max, regen, lowHp] = data;
            meter.toggleAttribute('data-low-hp', lowHp === true);
            meter.firstElementChild.textContent = text(hp) + ' / ' + text(max) + (regen ? '    ' + regen : '');
            meter.querySelector('.studio-fill').style.width = (max > 0 ? Math.min(100, Math.max(0, hp * 100 / max)) : 0) + '%';
            break;
        }
        case 'stamina': case 'ammo': {
            const [amount, max] = data;
            const display = Number.isFinite(max) && max > 0 ? `${amount} / ${max}` : String(amount);
            const meter = el('div', 'studio-health');
            const label = el('strong', 'studio-line', display);
            label.title = type === 'stamina' ? 'Выносливость' : 'Патроны';
            meter.append(label, barAt(percentage(amount, max), label.title));
            node.replaceChildren(meter);
            break;
        }
        case 'purchase': {
            const notice = el('div', 'studio-purchase');
            const name = typeof data.name === 'string' ? data.name.trim() : '';
            const native = art.native?.abilityIcons?.[data.itemId ?? art.native?.abilityNames?.[localKey(name)]];
            const fallback = Object.keys(art.fallback?.positions ?? {}).find(icon =>
                name && icon.startsWith('item-') && key(icon.slice(5)) === key(name));
            if (native || fallback) notice.append(tile(native, fallback, name || 'Предмет'));
            const title = el('span', 'studio-line', name ? 'Куплен · ' + name : 'Предмет куплен');
            title.title = title.textContent;
            notice.setAttribute('role', 'status');
            notice.append(title);
            node.replaceChildren(notice);
            break;
        }
        case 'abilities': case 'items': case 'active-items':
            node.replaceChildren(renderSlots(data, player, type, layer.abilitiesShowLevels === true));
            break;
    }
}
