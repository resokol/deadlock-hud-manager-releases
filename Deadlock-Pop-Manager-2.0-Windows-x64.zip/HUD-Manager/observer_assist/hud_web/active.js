'use strict';

let frame = document.getElementById('overlay');
const params = new URLSearchParams(location.search);
const preview = params.get('preview') === '1';
const packageId = params.get('package');
const variant = params.get('variant');
const endpoint = '/api/v1/huds/active' + (packageId ? '?package=' + encodeURIComponent(packageId) : '');
let activeUrl;

function showFrame(candidate) {
    if (candidate !== frame || !activeUrl) return;
    const child = candidate.contentDocument;
    if (!child?.documentElement || child.readyState !== 'complete' ||
            child.URL !== new URL(activeUrl, location.href).href) return;
    // Chromium paints an opaque canvas on frames with a different color scheme.
    const scheme = child.defaultView.getComputedStyle(child.documentElement).colorScheme;
    if (candidate.style.colorScheme !== scheme) candidate.style.colorScheme = scheme;
    candidate.hidden = false;
}

async function update() {
    try {
        const response = await fetch(endpoint, { signal: AbortSignal.timeout(2000) });
        if (!response.ok) throw new Error('HUD unavailable');
        const active = await response.json();
        const opacity = Number.isFinite(active.opacity) ? active.opacity / 100 : 1;
        const query = new URLSearchParams(active.studio ? { package: active.id } : { v: active.revision });
        if (preview) query.set('preview', '1');
        if (variant) query.set('variant', variant);
        const path = active.studio ? '/hud-editor/overlay.html' : '/hud/packages/' + encodeURIComponent(active.id) + '/';
        const url = path + '?' + query;
        if (url !== activeUrl) {
            const next = document.createElement('iframe');
            next.id = frame.id;
            next.title = frame.title;
            next.hidden = true;
            next.style.opacity = opacity;
            next.addEventListener('load', () => showFrame(next));
            next.src = url;
            const previous = frame;
            frame = next;
            activeUrl = url;
            previous.replaceWith(next);
        } else {
            frame.style.opacity = opacity;
            showFrame(frame);
        }
    } catch {
        if (activeUrl) frame.removeAttribute('src');
        frame.hidden = true;
        activeUrl = undefined;
    } finally {
        setTimeout(update, 200);
    }
}
update();
