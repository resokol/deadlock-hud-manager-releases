'use strict';

const node = id => document.getElementById(id);
const params = new URLSearchParams(location.search);
const token = params.get('token');
const preview = token === null && params.get('preview') === '1';
const number = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 0 });
const signed = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 0, signDisplay: 'exceptZero' });
const percentage = new Intl.NumberFormat('ru-RU', { style: 'percent', maximumFractionDigits: 1 });
const format = (value, formatter = number) => Number.isFinite(value) ? formatter.format(value) : '—';
const historyColumns = [
    ['Победы', 'winRate', percentage], ['Урон / матч', 'avgHeroDamage', number],
    ['Души / мин', 'soulsPerMinute', number], ['Хедшоты', 'headshotRate', percentage],
    ['Точность', 'accuracy', percentage],
];
const historyStatus = {
    disabled: 'История игроков выключена в HUD Manager',
    waiting: 'Ждём данные для истории игроков',
    loading: 'Загружается история игроков',
    unavailable: 'Сервис истории игроков временно недоступен',
};
let fallback;
let catalog;
let latest;
let lastRows;
let lastLanes;

function element(tag, className, content) {
    const result = document.createElement(tag);
    if (className) result.className = className;
    if (content != null) result.textContent = content;
    return result;
}

function portrait(player) {
    const art = element('span', 'portrait');
    art.setAttribute('aria-hidden', 'true');
    const key = (player.hero ?? '').toLowerCase().replace(/[^a-z0-9]/g, '');
    const localized = (player.hero ?? '').normalize('NFKC').trim().toLowerCase();
    const native = !preview && catalog?.heroIcons[player.heroId ?? catalog.heroNames[localized]];
    const tile = native || fallback?.positions[fallback.heroes[key]];
    const atlas = native ? catalog : fallback;
    if (tile && atlas) {
        art.style.backgroundImage = 'url("' + atlas.uri + '")';
        art.style.backgroundSize = (atlas.columns * 100) + '% ' + (atlas.rows * 100) + '%';
        art.style.backgroundPosition = (100 * tile[0] / Math.max(1, atlas.columns - 1)) + '% ' +
                                       (100 * tile[1] / Math.max(1, atlas.rows - 1)) + '%';
    } else {
        art.textContent = (player.hero || '—').slice(0, 2).toUpperCase();
    }
    return art;
}

function teamTable(team, title) {
    const section = element('section', 'team');
    section.append(element('h2', '', title));
    const table = element('table');
    table.setAttribute('aria-label', title);
    const sizes = element('colgroup');
    for (const kind of ['identity', 'rank', 'damage', ...historyColumns.map(() => '')]) {
        sizes.append(element('col', kind));
    }
    table.append(sizes);
    const head = table.createTHead();
    const first = head.insertRow();
    for (const label of ['Игрок', 'Ранг', 'Урон сейчас']) {
        const th = element('th', '', label);
        th.scope = 'col';
        th.rowSpan = 2;
        first.append(th);
    }
    const history = element('th', 'history-band', 'История на этом герое');
    history.colSpan = historyColumns.length;
    history.scope = 'colgroup';
    first.append(history);
    const second = head.insertRow();
    for (const [label] of historyColumns) {
        const th = element('th', '', label);
        th.scope = 'col';
        second.append(th);
    }
    const body = table.createTBody();
    for (const player of team?.players ?? []) {
        const row = body.insertRow();
        const identity = element('div', 'identity-cell');
        const label = element('span');
        label.append(element('strong', '', player.name), element('small', '', player.hero ?? ''));
        identity.append(portrait(player), label);
        row.insertCell().append(identity);
        row.insertCell().textContent = player.rank ?? '—';
        const damage = row.insertCell();
        damage.className = 'live-value';
        damage.textContent = format(player.heroDamage);
        for (const [, field, formatter] of historyColumns) {
            const cell = row.insertCell();
            cell.textContent = format(player.history?.[field], formatter);
            if (player.history?.matches) cell.title = 'Матчей: ' + number.format(player.history.matches);
        }
    }
    section.append(table);
    return section;
}

function laneCard(lane, names) {
    const card = element('article', 'matchup lane-' + lane.id);
    const duos = element('div', 'duos');
    const heroes = side => lane[side].map(id => names.get(id) ?? '—').join(' + ');
    duos.append(element('span', 'amber', heroes('amber')), element('span', '', '—'),
                element('span', 'sapphire', heroes('sapphire')));
    const values = element('div', 'values');
    values.append(element('b', '', 'WR ' + format(lane.winRate, percentage)),
                  element('span', '', 'n=' + format(lane.matches)),
                  element('b', '', 'Души 15:00 ' + format(lane.soulsDiff15, signed)),
                  element('span', '', 'n=' + format(lane.sampleMatches)));
    card.append(element('h3', '', lane.name + ' линия'), duos, values);
    return card;
}

function render(snapshot) {
    latest = snapshot;
    node('board').hidden = snapshot.status !== 'live';
    if (node('board').hidden) return;
    node('clock').textContent = snapshot.gameClock ?? '—';
    node('preview').hidden = !preview;
    const state = historyStatus[snapshot.historyStatus];
    node('history-status').hidden = !state;
    node('history-status').textContent = state ?? '';
    const rows = JSON.stringify(snapshot.teams);
    if (rows !== lastRows) {
        lastRows = rows;
        const team = side => snapshot.teams.find(entry => entry.side === side);
        node('teams').replaceChildren(teamTable(team(2), 'Янтарные'), teamTable(team(3), 'Сапфировые'));
    }
    node('lanes').hidden = !snapshot.lanes.length;
    const names = new Map(snapshot.teams.flatMap(team => team.players.map(player => [player.heroId, player.hero])));
    const lanes = JSON.stringify([snapshot.lanes, [...names]]);
    if (lanes !== lastLanes) {
        lastLanes = lanes;
        node('matchups').replaceChildren(...snapshot.lanes.map(lane => laneCard(lane, names)));
    }
}

function loadAtlas(url, update) {
    fetch(url).then(response => response.ok && response.json()).then(data => {
        if (data && update(data) && latest) {
            lastRows = undefined;
            render(latest);
        }
    }).catch(() => {});
}
const builtIn = '/hud/packages/deadlock-default/';
loadAtlas(builtIn + 'icons.json', data => {
    fallback = { ...data, uri: builtIn + 'icons.webp' };
    return true;
});
if (!preview) {
    loadAtlas('/game-icons/catalog.json', data => {
        if (!/^icons-[0-9a-f]{16}\.webp$/.test(data.image)) return false;
        catalog = { ...data, uri: '/game-icons/' + data.image };
        return true;
    });
}
const query = token !== null ? '?' + new URLSearchParams({ token }) : (preview ? '?preview=1' : '');
const stream = new EventSource('/api/v1/hero-stats/events' + query);
stream.onmessage = ({ data }) => render(JSON.parse(data));
stream.onerror = () => { node('board').hidden = true; };
