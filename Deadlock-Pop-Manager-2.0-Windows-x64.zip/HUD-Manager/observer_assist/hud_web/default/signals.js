export const ACTIVE_KEYS = ['Z', 'X', 'C', 'V'];

const AMMO_GAP_MS = 750;
const INFINITE_CONFIRM_MS = 1500;

export function createAmmoReading() {
    let camera;
    let lastSample;
    let finite;
    let finiteAt;
    let infiniteSince;
    return (selected, identity, at) => {
        if (!selected?.player || camera !== identity || at < lastSample) {
            finite = finiteAt = infiniteSince = undefined;
        }
        if (at - lastSample > AMMO_GAP_MS) infiniteSince = undefined;
        camera = identity;
        lastSample = at;
        if (!selected?.player) return null;

        const { ammo, maxAmmo, ammoInfinite } = selected;
        if (Number.isSafeInteger(ammo) && ammo >= 0) {
            finite = { ammo, maxAmmo };
            finiteAt = at;
            infiniteSince = undefined;
            return finite;
        }
        if (ammoInfinite === true) {
            if (infiniteSince === undefined) {
                infiniteSince = at;
                if (at - finiteAt > AMMO_GAP_MS) finite = undefined;
            }
            if (at - infiniteSince >= INFINITE_CONFIRM_MS) return { infinite: true };
            return finite ?? null;
        }
        infiniteSince = undefined;
        return finite && at - finiteAt <= AMMO_GAP_MS ? finite : null;
    };
}

export function splitInventory(slots) {
    const active = Array(ACTIVE_KEYS.length).fill(null);
    const passive = [];
    for (const item of slots) {
        if (!item) continue;
        const key = String(item.key ?? '').trim().toUpperCase();
        const index = Math.max(ACTIVE_KEYS.indexOf(key), ['Я', 'Ч', 'С', 'М'].indexOf(key));
        if (index >= 0 && !active[index]) active[index] = { ...item, key: ACTIVE_KEYS[index] };
        else passive.push(item);
    }
    return { active, passive };
}

export function meter(value, maximum) {
    if (!Number.isFinite(value) || !Number.isFinite(maximum) || maximum <= 0) return null;
    value = Math.max(0, Math.min(value, maximum));
    return { value, percent: 100 * value / maximum };
}

export function lowHealth(player) {
    const health = meter(player?.hp, player?.maxHp) ?? meter(player?.hpPercent, 100);
    if (health) return health.percent > 0 && health.percent <= 25;
    return typeof player?.lowHp === 'boolean' ? player.lowHp : null;
}

function defeated(player, observed) {
    return Number(observed?.respawn ?? player?.respawn) > 0 ||
        (observed?.hp ?? observed?.hpPercent ?? player?.hp ?? player?.hpPercent) === 0;
}

export function activeKillStreak(player, observed) {
    const count = observed?.killStreak ?? player?.killStreak;
    return Number.isInteger(count) && count >= 3 && !defeated(player, observed) ? count : null;
}

export function heroPortraitState(player, observed) {
    if (defeated(player, observed)) return 'normal';
    if (lowHealth(observed) ?? lowHealth(player)) return 'critical';
    return activeKillStreak(player, observed) ? 'gloat' : 'normal';
}

export function englishItemName(item, names, catalog) {
    const label = String(item.name ?? '').normalize('NFKC').trim().toLowerCase();
    const itemNames = names?.itemNames;
    for (const key of [item.itemId, item.id, catalog?.abilityNames?.[label], names?.itemAliases?.[label]]) {
        const name = key == null ? null : itemNames?.[key];
        if (typeof name === 'string' && name) return name;
    }
    return 'Unknown item';
}

export function seriesScore(settings) {
    const { bestOf, leftWins, rightWins } = settings.series ?? {};
    if (!Number.isInteger(bestOf) || bestOf < 1 || bestOf > 9) return null;
    const wins = [leftWins, rightWins];
    const validScore = wins.every(win => Number.isInteger(win) && win >= 0 && win <= Math.floor(bestOf / 2) + 1) &&
        leftWins + rightWins <= bestOf;
    return { bestOf, wins: validScore ? wins : null };
}

export function recentEvents(events, now) {
    if (!Array.isArray(events)) return [];
    return events.filter(event => event && ['kill', 'urnPickup', 'urnDelivery', 'midBossKilled', 'rejuvenatorClaimed'].includes(event.kind) &&
        typeof event.id === 'string' && event.id && Number.isFinite(event.at) && event.at > 0 &&
        now - event.at < 12000).sort((left, right) => right.at - left.at).slice(0, 4);
}

const playerName = value => typeof value === 'string' ? value.replace(/<[^>]*>/g, '').trim() : '';

export function eventParticipant(teams, value, side) {
    const name = playerName(value);
    if (!name) return null;
    const knownSide = side === 2 || side === 3 ? side : null;
    const matches = teams.filter(team => knownSide === null || team.side === knownSide).flatMap(team =>
        (team.players ?? []).filter(player => playerName(player.name) === name).map(player => ({ player, side: team.side })));
    if (matches.length !== 1) return { name, side: knownSide };
    const match = matches[0];
    return { ...match, name: match.player.displayName || name };
}

export function recentPurchases(history) {
    if (!Array.isArray(history)) return [];
    return history.filter(item => item && (typeof item.name === 'string' && item.name.trim() ||
        Number.isSafeInteger(item.itemId) && item.itemId > 0) &&
        Number.isFinite(item.gameSeconds) && item.gameSeconds >= 0)
        .sort((left, right) => left.gameSeconds - right.gameSeconds).slice(-6);
}

export function recentPlayerPurchases(selected, rosterPlayer) {
    if (!selected?.player) return [];
    const reported = recentPurchases(selected.purchaseHistory);
    const roster = rosterPlayer?.name === selected.player ? rosterPlayer.purchaseHistory : null;
    return (reported.length ? reported : recentPurchases(roster)).slice(-4).reverse();
}

export function purchaseOrder(slots, history = [], aliases, seen = new Set()) {
    const identity = item => {
        const name = String(item.name ?? '').normalize('NFKC').trim().toLowerCase();
        const id = Number(item.itemId ?? item.id ?? aliases?.[name]);
        return Number.isSafeInteger(id) && id > 0 ? String(id) : name || item.icon || item.image;
    };
    const bought = new Map();
    for (const [index, item] of (history ?? []).entries()) {
        if (!item || !Number.isFinite(item.gameSeconds) || item.gameSeconds < 0) continue;
        const key = identity(item);
        const previous = bought.get(key);
        if (key && (!previous || item.gameSeconds >= previous.time)) bought.set(key, {time: item.gameSeconds, index});
    }
    const owned = slots.filter(Boolean).map(item => ({item, key: identity(item)}));
    const keys = new Set(owned.map(({key}) => key));
    for (const key of seen) if (!keys.has(key)) seen.delete(key);
    for (const key of keys) seen.add(key);
    const seenOrder = new Map([...seen].map((key, index) => [key, index]));
    owned.sort((left, right) => {
        const a = bought.get(left.key), b = bought.get(right.key);
        return (a?.time ?? -1) - (b?.time ?? -1) ||
            (a?.index ?? seenOrder.get(left.key)) - (b?.index ?? seenOrder.get(right.key));
    });
    return [...owned.map(({item}) => item), ...Array(slots.length - owned.length).fill(null)];
}
