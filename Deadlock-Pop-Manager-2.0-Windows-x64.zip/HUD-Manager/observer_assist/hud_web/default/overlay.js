'use strict';

import { inventory } from '/hud-inventory.js';
import { setRejuvenatorBadge } from '/hud-mid-boss.js';
import { ACTIVE_KEYS, createAmmoReading, englishItemName, eventParticipant, heroPortraitState, meter, purchaseOrder, recentEvents, recentPlayerPurchases,
    recentPurchases, seriesScore, splitInventory } from './signals.js';

const node = id => document.getElementById(id);
const variant = new URLSearchParams(location.search).get('variant');
const format = value => value ?? '—';
const key = value => String(value ?? '').toLowerCase().replace(/[^a-z0-9]/g, '');
const localizedKey = value => String(value ?? '').normalize('NFKC').trim().toLowerCase();
let atlas;
let gameAtlas;
let battleAssets;
let latest;
let displayedSelection;
let purchaseTimer;
let eventSignature;
let historySignature;
let fixedPlayerLayout = false;
const purchases = new Set();
const bagSlotsSeen = new Map();
const previewStart = performance.now();
const tables = new Map();
const quantity = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 1 });
const ammoReading = createAmmoReading();

function element(tag, className, text = '') {
    const value = document.createElement(tag);
    value.className = className;
    if (text) value.textContent = text;
    return value;
}

function icon(key, caption, nativeTile, catalog, imageUrl) {
    const art = document.createElement('span');
    art.className = 'art';
    if (caption) {
        art.setAttribute('role', 'img');
        art.setAttribute('aria-label', caption);
    }
    const tile = nativeTile ?? atlas?.positions[key];
    const sheet = nativeTile ? catalog : atlas;
    if (tile) {
        art.classList.add('has-art');
        if (nativeTile) art.style.backgroundImage = 'url("' + (imageUrl ?? '/game-icons/' + catalog.image) + '")';
        art.style.backgroundSize = (sheet.columns * 100) + '% ' + (sheet.rows * 100) + '%';
        art.style.backgroundPosition = (100 * tile[0] / Math.max(1, sheet.columns - 1)) + '% ' +
                                       (100 * tile[1] / Math.max(1, sheet.rows - 1)) + '%';
    } else {
        art.textContent = (caption || '—').slice(0, 2).toUpperCase();
    }
    return art;
}

function nativeHero(player, catalog) {
    return player?.heroId ?? catalog?.heroNames[localizedKey(player?.hero)];
}

function portrait(player, catalog, state = 'normal') {
    const sheet = state === 'critical' ? battleAssets : state === 'gloat' ? battleAssets?.gloat : null;
    const alternate = sheet?.heroIcons[nativeHero(player, catalog)] ??
        sheet?.heroIcons[battleAssets.heroNames[localizedKey(player.hero)]];
    if (alternate) {
        const art = icon(undefined, player.hero, alternate, sheet, state + '-heroes.webp');
        art.classList.add(state + '-art');
        return art;
    }
    const tile = catalog?.heroIcons[nativeHero(player, catalog)];
    return icon(atlas?.heroes[key(player.hero)], player.hero, tile, catalog);
}

function paintRejuvenator(art, state) {
    setRejuvenatorBadge(art, state);
    // Installed managers can still serve the older translation of the badge.
    const badge = art.querySelector(':scope > .hud-rejuvenator');
    const label = state === 'ready' ? 'Rejuvenator готов' : 'Rejuvenator израсходован';
    if (badge && badge.title !== label) {
        badge.title = label;
        badge.setAttribute('aria-label', label);
    }
}

function healthPercent(player) {
    return (meter(player.hpPercent, 100) ?? meter(player.hp, player.maxHp))?.percent;
}

function rosterHealth(player, respawn, observedHealth) {
    const percent = fixedPlayerLayout && respawn ? 0 : observedHealth ?? healthPercent(player);
    if (percent === undefined && !fixedPlayerLayout) return null;
    const bar = element('span', 'roster-hp');
    if (percent === undefined) {
        bar.dataset.health = 'unknown';
        bar.title = 'Здоровье: нет данных';
        bar.setAttribute('role', 'img');
        bar.setAttribute('aria-label', bar.title);
        return bar;
    }
    bar.setAttribute('role', 'meter');
    bar.setAttribute('aria-label', 'Здоровье');
    bar.setAttribute('aria-valuemin', '0');
    bar.setAttribute('aria-valuemax', '100');
    bar.setAttribute('aria-valuenow', String(Math.round(percent)));
    bar.style.setProperty('--hp', percent + '%');
    bar.classList.toggle('critical', percent <= 25);
    return bar;
}

function rosterUltimate(ultimate) {
    if (!ultimate) return null;
    const { ready, unlocked, cooldown, level } = ultimate;
    if (typeof ready !== 'boolean' && typeof unlocked !== 'boolean' && !Number.isFinite(cooldown) &&
            !Number.isInteger(level)) return null;
    const locked = unlocked === false || level === 0;
    const available = !locked && ready === true;
    const remaining = !locked && !available && Number.isFinite(cooldown) && cooldown > 0 ? Math.ceil(cooldown) : null;
    const state = locked ? 'не изучена' : available ? 'готова' : remaining ? remaining + ' с' :
        ready === false ? 'недоступна' : 'изучена';
    const indicator = element('span', 'roster-ultimate', remaining ? String(remaining) : '');
    indicator.dataset.state = locked ? 'locked' : available ? 'ready' : 'waiting';
    indicator.setAttribute('role', 'img');
    indicator.setAttribute('aria-label', 'Ультимативная способность: ' + state);
    indicator.title = 'Ультимативная способность: ' + state;
    return indicator;
}

function playerRow(player, selected, catalog, observedHealth) {
    const row = document.createElement('li');
    const observed = player.name === selected?.player;
    if (observed) row.classList.add('observed');
    const seconds = String(player.respawn ?? '');
    const respawn = /^[1-9][0-9]{0,2}$/.test(seconds) ? seconds : null;
    row.title = [player.displayName || player.name, player.hero, respawn && 'Возрождение через ' + respawn + ' с',
                 player.invisible === true && 'Невидимость'].filter(Boolean).join(' · ');
    const frame = element('div', 'roster-portrait');
    const state = fixedPlayerLayout ? heroPortraitState(player, observed ? selected : undefined) : 'normal';
    frame.toggleAttribute('data-critical-portrait', state === 'critical');
    const art = portrait(player, catalog, state);
    frame.append(art);
    paintRejuvenator(fixedPlayerLayout ? frame : art, player.rejuvenator);
    if (respawn) {
        const timer = element('span', 'roster-respawn', respawn);
        timer.setAttribute('aria-label', 'Возрождение через ' + respawn + ' с');
        frame.append(timer);
        row.classList.add('is-respawning');
    }
    if (player.invisible === true) {
        const stealth = element('span', 'stealth');
        stealth.setAttribute('role', 'img');
        stealth.setAttribute('aria-label', 'Невидимость');
        frame.append(stealth);
        row.classList.add('is-invisible');
    }
    row.append(frame);
    const health = rosterHealth(player, respawn, observed ? observedHealth : undefined);
    const ultimate = rosterUltimate(player.ultimate);
    if (health || (!fixedPlayerLayout && ultimate)) {
        const status = element('div', 'roster-status');
        if (health) status.append(health);
        if (!fixedPlayerLayout && ultimate) status.append(ultimate);
        row.append(status);
    }
    for (const [kind, text] of [
        ['name', player.name || player.hero || '—'],
        ['record', [player.kills, player.deaths, player.assists].map(format).join('/')],
    ]) {
        row.append(element('span', kind, text));
    }
    if (fixedPlayerLayout && ultimate) row.append(ultimate);
    return row;
}

function estimateSouls(players) {
    if (!players || players.length !== 6) return null;
    const souls = players.map(({ souls }) => {
        const text = String(souls ?? '').replace(/<[^>]+>/g, '').trim();
        const thousands = /^(\d+(?:[,.]\d+)?)\s*(?:k|т(?:ыс)?)\.?$/i.exec(text);
        if (thousands) return Number(thousands[1].replace(',', '.')) * 1000;
        return /^\d(?:[\d\s\u202f]*\d)?$/.test(text) ? Number(text.replace(/\s/g, '')) : null;
    });
    if (souls.some(value => value == null)) return null;
    const total = souls.reduce((sum, value) => sum + value, 0);
    return '≈ ' + new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 1 }).format(total / 1000) + ' тыс.';
}

function renderTeam(side, team, name, color, selected, catalog) {
    document.documentElement.style.setProperty('--' + side, color);
    const teamName = node(side + '-name');
    teamName.textContent = name;
    teamName.title = name;
    const charges = node(side + '-rejuvenator');
    charges.hidden = !Number.isInteger(team?.rejuvenatorCharges) || team.rejuvenatorCharges <= 0;
    if (!charges.hidden) {
        charges.textContent = String(team.rejuvenatorCharges);
        charges.title = 'Заряды Rejuvenator: ' + charges.textContent;
        charges.setAttribute('aria-label', charges.title);
    }
    const worth = node(side + '-worth');
    worth.textContent = format(team?.netWorth || estimateSouls(team?.players));
    worth.title = worth.textContent.startsWith('≈') ? 'Сумма округлённых значений игроков' : 'Души команды';
    const score = node(side + '-kills');
    const kills = team?.players?.map(player => player.kills);
    const playerSum = kills?.length === 6 && kills.every(Number.isInteger)
        ? kills.reduce((sum, count) => sum + count, 0) : null;
    const total = playerSum ?? team?.kills;
    score.hidden = total == null;
    score.textContent = format(total);
    score.setAttribute('aria-label', 'Убийства команды: ' + format(total));
    const roster = node(side + '-roster');
    const players = team?.players ?? [];
    const target = selected && fixedPlayerLayout ? players.find(player => player.name === selected.player) : null;
    const targetState = target ? heroPortraitState(target, selected) : null;
    const observedHealth = target ? healthPercent(selected) : undefined;
    const signature = JSON.stringify([selected?.player, targetState, observedHealth, players, catalog?.fingerprint]);
    if (tables.get(side) !== signature) {
        roster.replaceChildren(...players.map(player => playerRow(player, selected, catalog, observedHealth)));
        tables.set(side, signature);
    }
}

function iconKey(slot, kind, hero, slotNumber) {
    if (atlas?.positions[slot.icon]) return slot.icon;
    const name = key(slot.name);
    const source = key((slot.image ?? '').split('/').at(-1)?.split('.')[0]);
    const selected = (name || source) && Object.keys(atlas?.positions ?? {}).find(candidate => {
        if (!candidate.startsWith(kind + '-')) return false;
        const short = key(candidate.slice(kind.length + 1));
        return short === name || source.endsWith(short);
    });
    if (selected) return selected;
    if (kind !== 'ability' || !atlas || slotNumber == null) return undefined;
    const portrait = atlas.heroes[key(hero)];
    return atlas.heroAbilities?.[portrait]?.[slotNumber];
}

function itemCaption(item, catalog) {
    return fixedPlayerLayout ? englishItemName(item, battleAssets, catalog) : item.name || 'Unknown item';
}

function renderSlots(list, slots, kind, elapsed, player, catalog, bindings = []) {
    list.parentElement.hidden = !slots?.length;
    if (!slots?.length) {
        list.replaceChildren();
        return;
    }
    const old = Array.from(list.children);
    const showUpgradePips = fixedPlayerLayout && kind === 'ability';
    const showBinding = !fixedPlayerLayout || kind === 'item' && list.id === 'active-item-slots';
    const rows = slots.map((slot, index) => {
        if (!slot) {
            if (old[index]?.classList.contains('empty-slot')) return old[index];
            const empty = element('li', 'empty-slot');
            empty.setAttribute('aria-label', 'Пустой слот ' + (bindings[index] ?? index + 1));
            if (bindings[index]) empty.append(element('span', 'binding', bindings[index]));
            return empty;
        }
        const bindingIndex = /^[1-4]$/.test(slot.key || '') ? Number(slot.key) - 1 : null;
        const slotIndex = slot.index ?? (slots.length === 4 ? index : bindingIndex);
        const id = slot.id ?? (kind === 'ability' && slotIndex != null
            ? catalog?.heroSlots[nativeHero(player, catalog)]?.[slotIndex + 1] : undefined)
            ?? catalog?.abilityNames[localizedKey(slot.name)];
        const tile = catalog?.abilityIcons[id];
        const caption = kind === 'item' ? itemCaption({ ...slot, id }, catalog) : slot.name;
        const image = tile ? undefined : iconKey({ ...slot, name: caption }, kind, player?.hero, slotIndex);
        const identity = JSON.stringify([id, image, caption, slot.key, catalog?.fingerprint]);
        let cell = old[index];
        if (!cell || cell.dataset.identity !== identity) {
            cell = document.createElement('li');
            cell.dataset.identity = identity;
            cell.title = caption || '';
            const artwork = icon(image, caption || slot.key, tile, catalog);
            cell.append(artwork);
            if (showBinding && slot.key) cell.append(element('span', 'binding', slot.key));
            if (kind === 'ability') {
                const level = element('span', showUpgradePips ? 'slot-level upgrade-pips' : 'slot-level');
                if (showUpgradePips) {
                    level.setAttribute('role', 'img');
                    level.append(...Array.from({ length: 3 }, () => element('span', 'upgrade-pip')));
                }
                cell.append(level);
                cell.append(element('span', 'slot-count ability-stacks'), element('span', 'slot-count ability-charges'));
            }
            cell.append(element('span', 'cooldown'));
        }
        if (kind === 'ability') {
            const level = cell.querySelector('.slot-level');
            level.hidden = !Number.isInteger(slot.level) || slot.level < 0;
            if (!level.hidden) {
                if (showUpgradePips) {
                    Array.from(level.children).forEach((pip, index) => pip.toggleAttribute('data-lit', index < slot.level));
                } else level.textContent = String(slot.level);
                level.setAttribute('aria-label', 'Уровень ' + slot.level);
            }
            for (const [field, prefix, label] of [['stacks', '×', 'Стаки'], ['charges', '', 'Заряды']]) {
                const counter = cell.querySelector('.ability-' + field);
                const count = slot[field];
                counter.hidden = !Number.isInteger(count) || count < 0;
                if (!counter.hidden) {
                    const text = prefix + count;
                    if (counter.textContent !== text) counter.textContent = text;
                    counter.title = label + ': ' + count;
                }
            }
        }
        const cooldown = Number.isFinite(slot.cooldown) ? Math.max(0, slot.cooldown - elapsed) : null;
        cell.classList.toggle('recharging', cooldown > 0);
        const clock = cell.lastElementChild;
        clock.textContent = cooldown > 0 ? (cooldown < 3 ? cooldown.toFixed(1).replace('.', ',') :
                            String(Math.ceil(cooldown))) : '';
        clock.hidden = !clock.textContent;
        return cell;
    });
    if (rows.some((row, index) => row !== old[index]) || rows.length !== old.length) list.replaceChildren(...rows);
}

function bySlot(reported, equipped, first) {
    const ids = new Map();
    for (const entry of equipped) {
        if (entry.slot < first || entry.slot > first + 3) continue;
        const index = entry.slot - first;
        if (!ids.has(index)) ids.set(index, new Set());
        ids.get(index).add(entry.id);
    }
    return Array.from(ids).sort(([left], [right]) => left - right).flatMap(([index, entries]) => {
        if (entries.size !== 1) return [];
        const id = entries.values().next().value;
        const visible = reported?.length === 4 ? reported[index] : null;
        return [{ ...visible, index, id }];
    });
}

function renderLoadout(selected, preview, player, catalog) {
    const elapsed = preview ? ((performance.now() - previewStart) / 1000) % 32 : 0;
    let abilities = selected.abilitySlots;
    if (!preview && catalog && Array.isArray(selected.loadout)) {
        const signatures = bySlot(abilities, selected.loadout, 0);
        if (signatures.length) abilities = signatures;
    }
    renderSlots(node('ability-slots'), abilities, 'ability', elapsed, player, catalog);
    const items = inventory(selected.itemSlots, preview ? null : selected.loadout, catalog);
    const { active, passive } = splitInventory(items);
    const activeSlots = fixedPlayerLayout || active.some(Boolean) ? active : [];
    renderSlots(node('active-item-slots'), activeSlots,
        'item', elapsed, undefined, catalog, ACTIVE_KEYS);
    let bag = passive;
    if (fixedPlayerLayout) {
        const key = JSON.stringify([selected.player, player?.heroId ?? player?.hero, preview]);
        const seen = bagSlotsSeen.get(key) ?? new Set();
        if (selected.player) bagSlotsSeen.set(key, seen);
        bag = purchaseOrder(items, selected.purchaseHistory ?? player?.purchaseHistory, battleAssets?.itemAliases, seen);
    }
    renderSlots(node('item-slots'), bag, 'item', elapsed, undefined, catalog);
}

function renderHealth(selected, changed) {
    const exact = meter(selected.hp, selected.maxHp);
    const health = exact ?? meter(selected.hpPercent, 100);
    node('health').hidden = !health;
    if (!health) return;
    const max = exact ? selected.maxHp : 100;
    node('health-value').textContent = exact ? quantity.format(health.value) + ' / ' + quantity.format(max) + ' HP' :
        quantity.format(health.value) + ' % HP';
    node('regen').textContent = selected.regen ?? '';
    node('health-bar').setAttribute('aria-valuemax', String(max));
    node('health-bar').setAttribute('aria-valuenow', String(health.value));
    const width = health.percent + '%';
    const bar = node('health-fill');
    if (changed) {
        // Commit the new player's HP before re-enabling animation for damage and healing.
        bar.style.transition = 'none';
        bar.style.width = width;
        bar.getBoundingClientRect();
        bar.style.removeProperty('transition');
    } else if (bar.style.width !== width) {
        bar.style.width = width;
    }
}

function formatQuantity(value, maximum) {
    if (!Number.isFinite(value) || value < 0) return '';
    return quantity.format(value) + (Number.isFinite(maximum) && maximum > 0 ? ' / ' + quantity.format(maximum) : '');
}

function paintVitals(selected, identity, sampledAt) {
    const values = [
        ['stamina', formatQuantity(selected.stamina, selected.maxStamina)],
        ['insecure', formatQuantity(selected.insecureSouls)],
    ];
    if (node('ammo')) {
        const reading = ammoReading(selected, identity, sampledAt ?? performance.now());
        values.push(['ammo', reading?.infinite ? '∞' : formatQuantity(reading?.ammo, reading?.maxAmmo)]);
    }
    for (const [field, value] of values) {
        node(field).hidden = !value;
        node(field + '-value').textContent = value;
    }
    const vitals = node('vitals');
    if (vitals) vitals.hidden = !values.some(([, value]) => value);
}

function hidePurchase() {
    clearTimeout(purchaseTimer);
    node('purchase').hidden = true;
}

function purchaseIcon(item, caption, catalog) {
    return icon(iconKey({ ...item, name: caption }, 'item'), caption, catalog?.abilityIcons[item.itemId], catalog);
}

function renderPurchase(item, enabled, catalog, hero) {
    if (!enabled) hidePurchase();
    if (!item || !['number', 'string'].includes(typeof item.id) || !String(item.id) ||
            (!(typeof item.name === 'string' && item.name.trim()) && !Number.isSafeInteger(item.itemId)) ||
            purchases.has(item.id)) return;
    purchases.add(item.id);
    if (purchases.size > 64) purchases.delete(purchases.values().next().value);
    if (!enabled) return;
    const elapsed = Number.isFinite(item.at) ? Math.max(0, Date.now() - item.at) : 0;
    if (elapsed >= 4000) return;
    hidePurchase();
    const caption = itemCaption(item, catalog);
    node('purchase-art').replaceChildren(purchaseIcon(item, caption, catalog));
    node('purchase-name').textContent = caption;
    const buyer = node('purchase-buyer');
    if (buyer) {
        buyer.hidden = !hero;
        buyer.textContent = hero ?? '';
    }
    node('purchase').hidden = false;
    purchaseTimer = setTimeout(hidePurchase, 4000 - elapsed);
}

function renderPurchaseHistory(items, catalog, visible = Boolean(items.length), hero) {
    const region = node('purchase-history');
    region.hidden = !visible;
    const headingHero = node('purchase-hero');
    if (headingHero) {
        headingHero.hidden = !hero;
        if (headingHero.textContent !== (hero ?? '')) headingHero.textContent = hero ?? '';
    }
    const signature = JSON.stringify([items, catalog?.fingerprint, Boolean(atlas)]);
    if (historySignature === signature) return;
    historySignature = signature;
    const list = node('purchase-history-list');
    list.replaceChildren(...items.map(item => {
        const seconds = Math.floor(item.gameSeconds);
        const time = Math.floor(seconds / 60) + ':' + String(seconds % 60).padStart(2, '0');
        const row = element('li', '');
        const caption = itemCaption(item, catalog);
        row.title = time + ' · ' + caption;
        row.append(purchaseIcon(item, caption, catalog), element('time', '', time), element('span', 'purchase-item-name', caption));
        return row;
    }));
}

function eventBadge(participant, catalog) {
    const badge = element('span', 'event-player', '');
    badge.dataset.side = participant.side ?? '';
    if (participant.player?.hero || participant.player?.heroId != null) badge.append(portrait(participant.player, catalog));
    badge.append(element('span', 'event-player-name', participant.name));
    badge.title = [participant.name, participant.player?.hero].filter(Boolean).join(' · ');
    return badge;
}

const objectiveLabels = {
    urnPickup: 'Урна подобрана', urnDelivery: 'Урна доставлена',
    midBossKilled: 'Мид-босса убили', rejuvenatorClaimed: 'Rejuvenator забрали',
};

function renderEventFeed(events, enabled, teams, catalog) {
    const feed = node('event-feed');
    const cards = enabled ? recentEvents(events, Date.now()) : [];
    const withPortraits = feed.hasAttribute('data-portraits');
    const mapped = cards.map(event => {
        const participants = withPortraits ? [
            eventParticipant(teams, event.actor, event.actorSide),
            eventParticipant(teams, event.target, event.targetSide),
        ].filter(Boolean) : [];
        return [event, participants];
    });
    feed.hidden = !cards.length;
    const signature = JSON.stringify([cards, mapped.map(([, who]) => who.map(({name, side, player}) =>
        [name, side, player?.heroId, player?.hero])), withPortraits && Boolean(atlas),
        withPortraits && catalog?.fingerprint]);
    if (eventSignature === signature) return;
    eventSignature = signature;
    feed.replaceChildren(...mapped.map(([event, participants]) => {
        const row = element('li', '');
        row.dataset.kind = event.kind;
        const objective = objectiveLabels[event.kind];
        const label = objective ?? (event.actor ? 'Убийство' : 'Выбытие');
        const names = [event.actor ?? event.teamName, event.target].filter(name => typeof name === 'string' && name.trim()).join(' → ');
        const awards = [Number.isFinite(event.souls) && '+' + quantity.format(event.souls) + ' душ',
                        Number.isFinite(event.durationSeconds) && event.durationSeconds + ' с в пути'].filter(Boolean);
        const details = [event.gameClock, ...awards].filter(Boolean);
        const compact = withPortraits && (objective || participants.length);
        if (compact) {
            row.dataset.compact = '';
            row.title = [label, names, ...details].filter(Boolean).join(' · ');
            row.setAttribute('aria-label', row.title);
        } else row.append(element('strong', '', label));
        if (participants.length || compact && objective) {
            const names = element('span', 'event-participants');
            if (participants.length) names.append(eventBadge(participants[0], catalog));
            else if (event.teamName) {
                const team = element('span', 'event-player');
                team.dataset.side = event.actorSide ?? '';
                team.append(element('span', 'event-player-name', event.teamName));
                names.append(team);
            }
            if (participants.length === 2) {
                const arrow = element('span', 'event-arrow', '→');
                arrow.setAttribute('aria-hidden', 'true');
                names.append(arrow, eventBadge(participants[1], catalog));
            }
            if (compact && objective) {
                const tag = element('span', 'event-objective');
                tag.dataset.side = event.actorSide ?? participants[0]?.side ?? '';
                tag.append(element('span', 'event-label', label));
                if (awards.length) tag.append(element('span', 'event-awards', awards.join(' · ')));
                names.append(tag);
            }
            row.append(names);
        } else if (names) row.append(element('span', 'event-names', names));
        if (!compact && details.length) row.append(element('small', '', details.join(' · ')));
        return row;
    }));
}

function renderRiftWarning(rift) {
    const warning = node('rift-warning');
    warning.hidden = rift?.phase !== 'warning';
    if (!warning.hidden) {
        const seconds = Number.isFinite(rift.secondsUntil) && rift.secondsUntil >= 0
            ? ' · ' + (rift.estimated === true ? '≈ ' : '') + Math.ceil(rift.secondsUntil) + ' с' : '';
        const message = 'Предупреждение о рифте' + seconds;
        if (warning.textContent !== message) warning.textContent = message;
    }
}

function observedHero(selected, teams) {
    const matches = teams.flatMap(team => team.players ?? []).filter(player => player.name === selected.player);
    return matches.length === 1 ? matches[0] : selected;
}

function renderPlayer(selected, teams, preview, catalog, selection, sampledAt, settings) {
    const player = observedHero(selected, teams);
    const identity = JSON.stringify([selection, selected.player, preview]);
    const changed = displayedSelection !== identity;
    if (changed) hidePurchase();
    displayedSelection = identity;
    const name = node('player-name');
    name.textContent = selected.player;
    name.title = selected.displayName || selected.player;
    node('hero-name').textContent = player.hero ?? '';
    node('player-stealth').hidden = selected.invisible !== true && player.invisible !== true;
    const frame = node('player-portrait');
    frame.hidden = !player.hero && player.heroId == null;
    const state = fixedPlayerLayout ? heroPortraitState(player, selected) : 'normal';
    const appearance = JSON.stringify([player.hero, player.heroId, catalog?.fingerprint, Boolean(atlas), state]);
    frame.toggleAttribute('data-critical-portrait', state === 'critical');
    if (!frame.hidden) {
        if (frame.dataset.appearance !== appearance) {
            frame.replaceChildren(portrait(player, catalog, state));
            frame.dataset.appearance = appearance;
        }
        paintRejuvenator(fixedPlayerLayout ? frame : frame.firstElementChild, selected.rejuvenator ?? player.rejuvenator);
    }
    renderHealth(selected, changed);
    paintVitals(selected, identity, sampledAt);
    renderLoadout(selected, preview, player, catalog);
    renderPurchase(selected.itemPurchase, settings.showItemPurchases !== false, catalog, player.hero);
    const history = fixedPlayerLayout ? recentPlayerPurchases(selected, player) : recentPurchases(selected.purchaseHistory);
    const showHistory = settings.showPurchaseHistory !== false;
    renderPurchaseHistory(showHistory ? history : [], catalog, showHistory && history.length > 0, player.hero);
}

function render({ telemetry, settings = {}, preview }) {
    node('hud').hidden = !telemetry;
    if (!telemetry) {
        displayedSelection = undefined;
        bagSlotsSeen.clear();
        ammoReading();
        hidePurchase();
        return;
    }
    const teams = telemetry.teams ?? [];
    const left = teams.find(team => team.side === 2);
    const right = teams.find(team => team.side === 3);
    const selected = telemetry.selected;
    const catalog = preview ? undefined : gameAtlas;
    node('preview').hidden = !preview;
    node('scoreboard').hidden = variant === 'player';
    node('rosters').hidden = settings.showRoster === false;
    const clock = node('clock');
    if (clock.textContent !== format(telemetry.gameClock)) clock.textContent = format(telemetry.gameClock);
    if (variant !== 'player') {
        renderEventFeed(telemetry.events, settings.showEventFeed !== false, teams, catalog);
        renderRiftWarning(telemetry.rift);
        const series = seriesScore(settings);
        const seriesBanner = node('series');
        seriesBanner.hidden = !series;
        if (series) {
            seriesBanner.textContent = 'BO' + series.bestOf + (series.wins ? ' · ' + series.wins.join('–') : '');
            seriesBanner.title = 'Формат серии: BO' + series.bestOf;
        }
        renderTeam('left', left, settings.leftName ?? '', settings.leftColor ?? '#f5b868', selected, catalog);
        renderTeam('right', right, settings.rightName ?? '', settings.rightColor ?? '#81c6ed', selected, catalog);
    }
    const showPlayer = variant !== 'scoreboard' && (variant === 'player' || settings.showPlayer !== false);
    node('player').hidden = !showPlayer || !selected?.player;
    if (showPlayer && selected?.player) renderPlayer(selected, teams, preview, catalog, telemetry.selection, telemetry.sampledAt, settings);
    else {
        displayedSelection = undefined;
        ammoReading();
        renderPurchase(selected?.itemPurchase, false, catalog);
    }
}

async function loadGameArt(paint) {
    try {
        const response = await fetch('/game-icons/catalog.json');
        if (!response.ok) return;
        const catalog = await response.json();
        if (!/^icons-[0-9a-f]{16}\.webp$/.test(catalog.image) ||
                catalog.image === gameAtlas?.image && catalog.shieldAtlas?.image === gameAtlas?.shieldAtlas?.image) return;
        gameAtlas = { ...catalog, itemIds: new Set(catalog.items) };
        tables.clear();
        if (latest && !latest.preview) paint(latest);
    } catch {}
}
export function startBroadcast({ transform = state => state, afterRender = () => {}, fixedLayout = false } = {}) {
    fixedPlayerLayout = fixedLayout;
    const paint = state => {
        render(state);
        afterRender(state, gameAtlas);
    };
    const refreshGameArt = () => loadGameArt(paint);
    refreshGameArt();
    setInterval(refreshGameArt, 10000);

    fetch('icons.json').then(response => response.ok ? response.json() : null).then(icons => {
        if (!icons) return;
        atlas = icons;
        tables.clear();
        for (const id of ['ability-slots', 'active-item-slots', 'item-slots']) node(id).replaceChildren();
        if (latest) paint(latest);
    }).catch(() => {});

    const subscribe = () => window.DeadlockHUD.subscribe(state => {
        latest = transform(state);
        paint(latest);
    });
    if (fixedPlayerLayout) {
        fetch('battle-assets.json').then(response => response.ok ? response.json() : null)
            .then(assets => { battleAssets = assets; })
            .catch(() => {}).finally(subscribe);
    } else subscribe();
    setInterval(() => {
        if (latest?.preview && latest.telemetry?.selected && !node('player').hidden) {
            const { selected, teams } = latest.telemetry;
            renderLoadout(selected, true, observedHero(selected, teams ?? []));
        }
    }, 150);
    setInterval(() => {
        if (variant !== 'player' && latest?.telemetry?.events?.length) {
            renderEventFeed(latest.telemetry.events, latest.settings?.showEventFeed !== false,
                latest.telemetry.teams ?? [], latest.preview ? undefined : gameAtlas);
        }
    }, 1000);
}

if (!document.documentElement.hasAttribute('data-custom-entry')) startBroadcast();
