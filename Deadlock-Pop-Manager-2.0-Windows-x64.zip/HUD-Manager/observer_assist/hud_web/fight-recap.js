'use strict';

const node = id => document.getElementById(id);
const query = new URLSearchParams(location.search);
const token = query.get('token');
const preview = token === null && query.get('preview') === '1';
const integer = new Intl.NumberFormat('ru-RU');
const count = value => Number.isFinite(value) ? integer.format(value) : '—';
const clock = seconds => Math.floor(seconds / 60) + ':' + String(seconds % 60).padStart(2, '0');
const playerName = player => player.displayName ?? player.name;
const standard = '/hud/packages/deadlock-default/';
let baked, native, latest;

function element(tag, className, content) {
    const item = document.createElement(tag);
    if (className) item.className = className;
    if (content != null) item.textContent = content;
    return item;
}

function portrait(player) {
    const art = element('span', 'portrait');
    art.setAttribute('aria-hidden', 'true');
    const name = String(player.hero ?? '');
    const localized = name.normalize('NFKC').trim().toLowerCase();
    const inGame = native?.heroIcons?.[player.heroId ?? native?.heroNames?.[localized]];
    const tile = inGame ?? baked?.positions?.[baked?.heroes?.[localized.replace(/[^a-z0-9]/g, '')]];
    const atlas = inGame ? native : baked;
    if (tile) {
        const [x, y] = tile;
        art.style.backgroundImage = `url("${atlas.uri}")`;
        art.style.backgroundSize = `${atlas.columns * 100}% ${atlas.rows * 100}%`;
        art.style.backgroundPosition = `${x * 100 / Math.max(1, atlas.columns - 1)}% ${y * 100 / Math.max(1, atlas.rows - 1)}%`;
    } else art.textContent = (name || player.name).slice(0, 2).toUpperCase();
    return art;
}

function label(player, full = false) {
    const result = element('span', full ? 'identity' : 'label');
    result.dataset.side = player.side;
    const words = element('span');
    words.append(element('strong', '', playerName(player)));
    if (full && player.hero) words.append(element('small', '', player.hero));
    result.title = [playerName(player), player.hero].filter(Boolean).join(' · ');
    result.append(portrait(player), words);
    return result;
}

function teamBlock(team) {
    const block = element('section', 'team');
    block.dataset.side = team.side;
    const head = element('header', 'team-head');
    const name = element('div');
    name.append(element('h2', '', team.name));
    if (team.soulsFromKills !== null) name.append(element('small', '', `${count(team.soulsFromKills)} душ за убийства`));
    const score = element('strong', 'score', count(team.kills));
    score.setAttribute('aria-label', `${team.kills} убийств`);
    head.append(name, score);
    const table = element('table');
    table.setAttribute('aria-label', team.name);
    const cols = element('colgroup');
    for (const kind of ['identity-col', 'kills-col', '']) cols.append(element('col', kind));
    table.append(cols);
    const titles = table.createTHead().insertRow();
    for (const title of ['Участники', 'Уб.', 'Урон']) {
        const th = element('th', '', title);
        th.scope = 'col';
        if (title === 'Уб.') { th.title = 'Убийства'; th.setAttribute('aria-label', 'Убийства'); }
        if (title === 'Урон') th.title = 'Прирост урона по героям за окно драки';
        titles.append(th);
    }
    const people = table.createTBody();
    for (const player of team.players) {
        const row = people.insertRow();
        row.insertCell().append(label(player, true));
        row.insertCell().textContent = count(player.kills);
        row.insertCell().textContent = count(player.heroDamage);
    }
    block.append(head, table);
    return block;
}

function timelineKill(event) {
    const row = element('li');
    const arrow = element('span', '', '→');
    arrow.setAttribute('aria-label', 'убивает');
    const award = Number.isFinite(event.souls) ? '+' + count(event.souls) : '';
    row.append(element('time', '', clock(event.gameSeconds)), label(event.actor), arrow,
        label(event.target), element('span', 'award', award));
    return row;
}

function render(snapshot) {
    latest = snapshot;
    const fight = snapshot?.recap;
    node('board').hidden = !fight;
    if (!fight) return;
    const leader = fight.teams.find(team => team.side === fight.winnerSide);
    node('outcome').textContent = leader ? `${leader.name} выиграли по убийствам` : 'Ничья по убийствам';
    node('interval').textContent = clock(fight.firstKillSeconds) + '–' + clock(fight.lastKillSeconds);
    node('preview').hidden = !preview;
    node('teams').replaceChildren(...fight.teams.map(teamBlock));
    node('events').replaceChildren(...fight.events.slice(-4).map(timelineKill));
}

async function loadArt(url, setArt) {
    try {
        const response = await fetch(url);
        if (!response.ok) return;
        setArt(await response.json());
        if (latest?.recap) render(latest);
    } catch {}
}

loadArt(standard + 'icons.json', data => { baked = { ...data, uri: standard + 'icons.webp' }; });
if (!preview) loadArt('/game-icons/catalog.json', data => {
    if (/^icons-[0-9a-f]{16}\.webp$/.test(data.image)) native = { ...data, uri: '/game-icons/' + data.image };
});
const options = token !== null ? new URLSearchParams({ token }) : new URLSearchParams(preview ? { preview: '1' } : {});
const stream = new EventSource('/api/v1/fight-recap/events?' + options);
stream.onmessage = ({ data }) => render(JSON.parse(data));
stream.onerror = () => render(null);
