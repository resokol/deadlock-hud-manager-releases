const HOTKEYS = ['Z', 'X', 'C', 'V'];
export const ITEM_SLOTS = 12;

function binding(slot, fallback) {
    const key = String(slot.key ?? '').trim().toUpperCase();
    const index = Math.max(HOTKEYS.indexOf(key), ['Я', 'Ч', 'С', 'М'].indexOf(key));
    return index >= 0 ? index : Number.isInteger(slot.index) ? slot.index : fallback;
}

function itemId(item, catalog) {
    const name = String(item.name ?? '').normalize('NFKC').trim().toLowerCase();
    return item.id ?? catalog?.abilityNames?.[name];
}

function hasIdentity(item) {
    return Boolean(item?.name || item?.image || item?.icon || item?.id);
}

export function inventory(reported = [], equipped, catalog) {
    const slots = Array(ITEM_SLOTS).fill(null);
    const known = new Set();
    const reportedIds = new Set();
    const loose = [];
    const live = new Map();
    for (const [index, item] of (reported ?? []).entries()) {
        const identified = hasIdentity(item);
        if (!identified && !(item?.cooldown > 0)) continue;
        const id = itemId(item, catalog);
        if (id != null) reportedIds.add(String(id));
        const where = binding(item, reported.length === HOTKEYS.length ? index : -1);
        if (where >= 0 && where < ITEM_SLOTS && !live.has(where)) live.set(where, item);
        else if (identified) loose.push(item);
    }
    const owned = (equipped ?? []).filter(item => catalog?.itemIds?.has(String(item.id)));
    const active = new Map();
    for (const item of owned) {
        const where = item.slot - 4;
        if (where < 0 || where >= HOTKEYS.length) continue;
        if (!active.has(where)) active.set(where, new Set());
        active.get(where).add(String(item.id));
    }
    function place(index, item) {
        const id = itemId(item, catalog);
        const identity = id == null ? null : String(id);
        if (identity && known.has(identity)) return;
        if (identity) known.add(identity);
        slots[index] = id == null ? item : { ...item, id };
    }
    for (let index = 0; index < ITEM_SLOTS; index += 1) {
        const visible = live.get(index);
        const ids = active.get(index);
        const id = ids?.size === 1 ? ids.values().next().value : undefined;
        // Prefer Panorama's identity when the replay is behind a purchase or a reassignment.
        const identified = hasIdentity(visible);
        const liveId = identified ? itemId(visible, catalog) : undefined;
        const fallbackId = identified || reportedIds.has(id) ? undefined : id;
        if (!identified && fallbackId == null) continue;
        place(index, { ...(index < HOTKEYS.length && { key: HOTKEYS[index] }), ...visible, id: liveId ?? fallbackId });
    }
    const passive = owned.filter(item => item.slot < 4 || item.slot >= 8);
    for (const item of [...loose, ...passive]) {
        const index = slots.findIndex((slot, i) => slot === null && i >= HOTKEYS.length);
        const free = index >= 0 ? index : slots.indexOf(null);
        if (free < 0) break;
        place(free, item);
    }
    return slots;
}
