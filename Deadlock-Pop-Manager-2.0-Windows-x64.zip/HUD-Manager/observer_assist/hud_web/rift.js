const announcementMs = 7000;

function applyStyle() {
    if (document.getElementById('hud-rift-style')) return;
    const style = document.createElement('link');
    style.id = 'hud-rift-style';
    style.rel = 'stylesheet';
    style.href = '/hud-rift.css';
    document.head.append(style);
}

export function createRiftNotice(container, { floating = false, onVisibility } = {}) {
    applyStyle();
    const card = document.createElement('aside');
    card.className = floating ? 'hud-rift-card hud-rift-floating' : 'hud-rift-card';
    card.hidden = true;
    card.setAttribute('role', 'status');
    const glyph = document.createElement('span');
    glyph.className = 'hud-rift-glyph';
    glyph.setAttribute('aria-hidden', 'true');
    const copy = document.createElement('span');
    copy.className = 'hud-rift-copy';
    const title = document.createElement('strong');
    title.textContent = 'Рифт появился';
    const location = document.createElement('span');
    location.className = 'hud-rift-location';
    copy.append(title, location);
    card.append(glyph, copy);
    container.append(card);

    const seen = new Set();
    let active;
    let timer;

    function visible(show) {
        card.hidden = !show;
        onVisibility?.(show);
    }

    function hide() {
        clearTimeout(timer);
        active = undefined;
        visible(false);
    }

    function showDetail(...options) {
        const name = options.find(value => typeof value === 'string' && value.trim())?.trim().slice(0, 96) ?? '';
        if (location.textContent !== name) location.textContent = name;
        location.hidden = !name;
    }

    return {
        update(event, editing = false) {
            const spawned = event?.phase === 'spawned' && typeof event.id === 'string' && event.id.length > 0;
            if (editing) {
                clearTimeout(timer);
                active = undefined;
                showDetail(spawned ? event.location : 'Цель матча', event?.gameClock);
                visible(true);
                return;
            }
            // An explicit null denotes a portal already present when the observer attached.
            if (!spawned || event.spawnedAt === null) {
                hide();
                return;
            }
            if (active === event.id) {
                showDetail(event.location, event.gameClock);
                return;
            }
            hide();
            if (seen.has(event.id)) return;
            seen.add(event.id);
            if (seen.size > 64) seen.delete(seen.values().next().value);
            const elapsed = Number.isFinite(event.spawnedAt) && event.spawnedAt > 0
                ? Math.max(0, Date.now() - event.spawnedAt) : 0;
            if (elapsed >= announcementMs) return;
            active = event.id;
            showDetail(event.location, event.gameClock);
            visible(true);
            timer = setTimeout(hide, announcementMs - elapsed);
        },
        remove() {
            clearTimeout(timer);
            card.remove();
        },
    };
}
