'use strict';

const node = id => document.getElementById(id);
const params = new URLSearchParams(location.search);
const token = params.get('token');
const preview = token === null && params.get('preview') === '1';
const number = new Intl.NumberFormat('ru-RU');
const schema = [
    ['Игрок', 'name', 'identity'],
    ['Герой', 'hero', 'hero'],
    ['K', 'kills', 'kda'],
    ['D', 'deaths', 'kda'],
    ['A', 'assists', 'kda'],
    ['Души', 'souls', 'souls'],
    ['Ур.', 'level', 'status'],
    ['Возр.', 'respawn', 'status'],
];
const tables = [
    { side: 2, slug: 'amber', name: 'Янтарные' },
    { side: 3, slug: 'sapphire', name: 'Сапфировые' },
];

function text(cell, value) {
    cell.textContent = typeof value === 'number' ? number.format(value) : (value ?? '—');
}

for (const table of tables) {
    const element = document.createElement('table');
    element.className = 'team ' + table.slug;
    element.setAttribute('aria-label', table.name);
    const group = document.createElement('colgroup');
    const header = element.createTHead().insertRow();
    for (const [heading, , kind] of schema) {
        const col = document.createElement('col');
        col.className = kind;
        group.append(col);
        const th = document.createElement('th');
        th.scope = 'col';
        th.textContent = heading;
        header.append(th);
    }
    element.prepend(group);
    table.body = element.createTBody();
    node('teams').append(element);
}

function render(snapshot) {
    node('board').hidden = snapshot.status !== 'live';
    if (node('board').hidden) return;
    node('preview').hidden = !preview;
    text(node('clock'), snapshot.gameClock);
    const selected = snapshot.selected?.player;
    const observed = node('observed');
    observed.hidden = typeof snapshot.selected?.hp !== 'number';
    if (!observed.hidden) {
        text(observed, selected + ' · HP ' + number.format(snapshot.selected.hp) +
                       ' / ' + number.format(snapshot.selected.maxHp));
    }
    for (const table of tables) {
        const team = snapshot.teams.find(entry => entry.side === table.side);
        text(node(table.slug + '-kills'), team?.kills);
        text(node(table.slug + '-souls'), team?.netWorth);
        const players = team?.players ?? [];
        const key = JSON.stringify([selected, players]);
        if (table.key === key) continue;
        table.key = key;
        table.body.replaceChildren(...players.map(player => {
            const row = document.createElement('tr');
            row.classList.toggle('observed', player.name === selected);
            for (const [, field] of schema) text(row.insertCell(), player[field]);
            return row;
        }));
    }
}

const endpoint = '/api/v1/stats';
const query = token !== null ? '?' + new URLSearchParams({ token }) : (preview ? '?preview=1' : '');
const stream = new EventSource(endpoint + '/events' + query);
stream.onmessage = ({ data }) => render(JSON.parse(data));
stream.onerror = () => { node('board').hidden = true; };
