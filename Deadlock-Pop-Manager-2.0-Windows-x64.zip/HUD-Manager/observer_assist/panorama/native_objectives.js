function doaReadNativeObjectiveRow(row) {
    if (!row?.IsValid() || row.visible === false || row.paneltype !== 'CitadelHudInfoFeed') return null;

    let kind;
    if (row.BHasClass('IdolPickedUp')) kind = 'urnPickup';
    else if (row.BHasClass('IdolReturned')) kind = 'urnDelivery';
    else if (['enemyDied', 'teammateDied', 'killedSelf'].some(name => row.BHasClass(name))) kind = 'kill';
    else return null;

    function text(panel, className) {
        if (!panel?.IsValid()) return null;
        const labels = panel.FindChildrenWithClassTraverse(className).filter(child =>
            child.IsValid() && child.visible !== false && child.paneltype === 'Label');
        if (labels.length !== 1 || typeof labels[0].text !== 'string') return null;
        const value = labels[0].text.trim();
        return value && !/^\{[^}]+\}$/.test(value) ? value.slice(0, 160) : null;
    }

    function side(panel) {
        if (!panel?.IsValid()) return null;
        const amber = panel.BHasClass('team_1');
        const sapphire = panel.BHasClass('team_2');
        return amber !== sapphire ? (amber ? 2 : 3) : null;
    }

    const killer = row.BHasClass('noKiller') || row.BHasClass('killedSelf')
        ? null : row.FindChildTraverse('KillerContainer');
    const victim = kind === 'kill' ? row.FindChildTraverse('VictimContainer') : null;
    const gold = row.BHasClass('hasGold') ? text(killer, 'gold') : null;
    const souls = gold && /^(?:\d+|\d{1,3}(?:[ ,\u00a0\u202f]\d{3})+)$/.test(gold)
        ? Number(gold.replace(/[ ,\u00a0\u202f]/g, '')) : null;

    return {
        kind,
        actor: text(killer, 'killerInfo'),
        actorSide: side(killer),
        target: text(victim, 'victimInfo'),
        targetSide: side(victim),
        souls: Number.isSafeInteger(souls) ? souls : null,
    };
}
