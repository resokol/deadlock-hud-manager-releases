(function () {
    const root = $.GetContextPanel();
    const hideDefaultLogo = false;
    let previous = '';
    let hiddenLogo = null;
    let savedOpacity = '';

    function defaultLogo() {
        const status = root.FindChildTraverse('ClientStatus');
        const defaultStatus = status && status.FindChildTraverse('DefaultStatus');
        if (!defaultStatus) return null;
        for (let panel = defaultStatus; panel; panel = panel.GetParent()) {
            if (panel.BHasClass('InEscapeMenu') || panel.BHasClass('SettingsVisible') || panel.BHasClass('InHideout')) {
                return null;
            }
        }
        const icons = defaultStatus.FindChildrenWithClassTraverse('GameLogoIcon');
        return icons.length === 1 && icons[0].IsValid() ? icons[0] : null;
    }

    function updateLogo() {
        const icon = defaultLogo();
        if (icon === hiddenLogo) return;
        if (hiddenLogo && hiddenLogo.IsValid()) hiddenLogo.style.opacity = savedOpacity;
        hiddenLogo = icon;
        if (icon) {
            savedOpacity = icon.style.opacity || '';
            icon.style.opacity = '0.0';
        }
    }

    function sample() {
        if (!root.IsValid()) return;
        const label = root.FindChildTraverse('ClientServerDebugStats');
        const numbers = label && typeof label.text === 'string' &&
            label.text.match(/\b[1-9][0-9]{7,19}\b/g);
        const matchId = numbers && numbers.length === 1 ? numbers[0] : '';
        if (matchId !== previous) {
            previous = matchId;
            $.Msg('[DOA-MATCH-ID] ' + matchId);
        }
        $.Schedule(0.5, sample);
        if (hideDefaultLogo) updateLogo();
    }
    $.Schedule(0.5, sample);
})();
