function doaSpectatorCards(team) {
    const container = team && team.FindChildTraverse('PlayersContainer');
    if (!container) return [];
    const cards = [];
    // The game uses the container's slots for camera keys. Layout and traversal can reorder the portraits.
    for (let index = 0; index < container.GetChildCount(); index += 1) {
        const card = container.GetChild(index);
        if (card.paneltype === 'CitadelHudTopBarPlayer' && /^TopBarPlayer\d+$/.test(card.id)) cards.push(card);
    }
    return cards;
}
