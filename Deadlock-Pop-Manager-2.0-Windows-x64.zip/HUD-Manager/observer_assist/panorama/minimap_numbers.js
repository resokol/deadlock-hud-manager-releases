(function () {
    const mode = 'off';
    if (mode === 'off' || typeof nativeHudOptions !== 'undefined' && nativeHudOptions?.elements?.minimap === false) return;

    const root = $.GetContextPanel();
    const keys = '1234567890-=';
    const bindings = new Map();
    const local = mode === 'local';
    $.Msg('[DOA-MINIMAP] ready ' + mode);
    let previousChoice = null;
    let previousMap = null;
    let reportedError = false;
    let viewportCorner = null;
    let publishedMarkers = false;
    let positionReport = '';

    function roster(top) {
        const cards = [];
        for (const [side, id] of ['TeamFriendly', 'TeamEnemy'].entries()) {
            const team = top.FindChildTraverse(id);
            for (const card of doaSpectatorCards(team)) {
                const name = card.FindChildrenWithClassTraverse('PlayerName')[0];
                const hero = card.FindChildrenWithClassTraverse('HeroName')[0];
                cards.push({card, side, name: name && name.text.trim(),
                            identity: JSON.stringify([card.id, name && name.text, hero && hero.text])});
            }
        }
        return cards.length <= keys.length ? cards : [];
    }

    function remove(marker) {
        const {portraits, label} = bindings.get(marker);
        for (const {panel, opacity} of portraits) {
            if (panel.IsValid()) panel.style.opacity = opacity;
        }
        if (label && label.IsValid()) label.DeleteAsync(0);
        bindings.delete(marker);
    }

    function bind(marker, card) {
        const icon = marker.FindChildTraverse('MainImage');
        if (!icon || icon.paneltype !== 'Image') return;

        if (local) {
            bindings.set(marker, {identity: card.identity, portraits: [], label: null});
            return;
        }
        const label = $.CreatePanel('Label', marker, 'DoaSpectatorKey');
        label.hittest = false;
        label.hittestchildren = false;
        const style = label.style;
        style.zIndex = '101';
        style.color = '#ffffff';
        style.fontWeight = 'bold';
        style.textAlign = 'center';
        style.horizontalAlign = mode === 'replace' ? 'center' : 'right';
        style.verticalAlign = mode === 'replace' ? 'center' : 'top';
        style.fontSize = mode === 'replace' ? '22px' : '16px';
        style.padding = mode === 'replace' ? '0px 4px' : '0px 3px';
        style.backgroundColor = '#131821ee';
        style.borderRadius = '5px';

        const portraits = [];
        if (mode === 'replace') {
            for (const panel of [icon, marker.FindChildTraverse('FrogImage')]) {
                if (!panel) continue;
                portraits.push({panel, opacity: panel.style.opacity || ''});
                panel.style.opacity = '0.0';
            }
        }
        bindings.set(marker, {identity: card.identity, portraits, label});
    }

    function hasAncestorClass(map, name) {
        for (let panel = map; panel; panel = panel.GetParent()) {
            if (panel.BHasClass(name)) return true;
        }
        return false;
    }

    function position(panel) {
        const point = panel.GetPositionWithinWindow();
        if (!point) return null;
        const x = point.x ?? point[0];
        const y = point.y ?? point[1];
        return Math.abs(x) < 100000 && Math.abs(y) < 100000 ? {x, y} : null;
    }

    function viewport() {
        if (!viewportCorner) {
            // Measure both corners in the same coordinate space as the minimap.
            // Layout dimensions alone depend on Panorama's UI scaling.
            viewportCorner = $.CreatePanel('Panel', root, 'DoaMinimapViewportCorner');
            viewportCorner.hittest = false;
            viewportCorner.hittestchildren = false;
            const style = viewportCorner.style;
            style.width = '1px';
            style.height = '1px';
            style.horizontalAlign = 'right';
            style.verticalAlign = 'bottom';
            style.opacity = '0.0';
            return null; // The corner is positioned on the next layout pass.
        }
        const origin = position(root);
        const corner = position(viewportCorner);
        if (!origin || !corner) return null;
        const width = root.actuallayoutwidth;
        const height = root.actuallayoutheight;
        const dx = corner.x - origin.x;
        const dy = corner.y - origin.y;
        return width > 100 && height > 100 && dx > 100 && dy > 100 ? {
            ...origin, width, height, windowWidth: dx * width / (width - 1),
            windowHeight: dy * height / (height - 1),
        } : null;
    }

    function visible(panel) {
        for (let node = panel; node; node = node.GetParent()) {
            if (node.visible === false) return false;
        }
        return true;
    }

    function publish(markers = [], space = 'normalized') {
        if (markers.length || publishedMarkers) {
            $.Msg('[DOA-MINIMAP-LOCAL] ' + JSON.stringify({version: 1, at: Date.now(), space, markers}));
        }
        publishedMarkers = markers.length > 0;
    }

    function portraitGeometry(marker) {
        const image = marker.FindChildTraverse(marker.BHasClass('Frog') ? 'FrogImage' : 'MainImage');
        const positionOf = (panel, scale) => {
            if (!panel) return null;
            const point = position(panel);
            const width = panel.actuallayoutwidth * scale;
            const height = panel.actuallayoutheight * scale;
            return point && width > 0 && height > 0 ? {
                ...point, width, height, scaleX: panel.actualuiscale_x || 1, scaleY: panel.actualuiscale_y || 1,
            } : null;
        };
        const picture = positionOf(image, 1);
        if (picture && (picture.x > 0 || picture.y > 0)) return picture;
        const outer = positionOf(marker, 0.85);
        if (!outer) return null;
        return { ...outer, x: outer.x + outer.width * 0.088 * outer.scaleX,
            y: outer.y + outer.height * 0.088 * outer.scaleY };
    }

    function publishPositions(map, slots) {
        if (!visible(map)) {
            publish();
            return;
        }
        const bounds = viewport();
        const normalized = [];
        const client = [];
        for (const [marker, {identity}] of bindings) {
            if (!marker.BHasClass('active') || !visible(marker)) continue;
            const point = portraitGeometry(marker);
            if (!point) continue;
            const [key, side] = slots.get(identity);
            if (bounds) {
                const w = Math.round(10000 * point.width / bounds.width);
                const h = Math.round(10000 * point.height / bounds.height);
                const x = Math.round(10000 * (point.x - bounds.x) / bounds.windowWidth + w / 2);
                const y = Math.round(10000 * (point.y - bounds.y) / bounds.windowHeight + h / 2);
                if (x >= 0 && x <= 10000 && y >= 0 && y <= 10000 && w > 0 && w <= 1500 && h > 0 && h <= 1500) {
                    normalized.push([key, side, x, y, w, h]);
                }
            }
            const w = Math.round(point.width * point.scaleX);
            const h = Math.round(point.height * point.scaleY);
            const x = Math.round(point.x + w / 2);
            const y = Math.round(point.y + h / 2);
            if (x >= 0 && x <= 20000 && y >= 0 && y <= 20000 && w > 0 && w <= 1500 && h > 0 && h <= 1500) {
                client.push([key, side, x, y, w, h]);
            }
        }
        const space = normalized.length >= client.length ? 'normalized' : 'client';
        if (bindings.size && space !== positionReport && (client.length || normalized.length)) {
            positionReport = space;
            $.Msg('[DOA-MINIMAP] coordinate space ' + space);
        } else if (bindings.size && !positionReport && !client.length && !normalized.length) {
            const marker = bindings.keys().next().value;
            const image = marker.FindChildTraverse('MainImage');
            const geometry = panel => panel && [position(panel), panel.actuallayoutwidth, panel.actuallayoutheight,
                panel.actualuiscale_x, panel.actualuiscale_y];
            positionReport = 'waiting';
            $.Msg('[DOA-MINIMAP] missing geometry ' + JSON.stringify({
                root: geometry(root), corner: geometry(viewportCorner), marker: geometry(marker),
                image: geometry(image), active: marker.BHasClass('active'), visible: visible(marker),
            }));
        }
        if (space === 'normalized') publish(normalized);
        else publish(client, space);
    }

    function update(map, top, target) {
        if (previousMap !== map || !map || !top) {
            for (const marker of bindings.keys()) remove(marker);
            previousChoice = null;
            previousMap = map;
        }
        if (!map || !top) return false;
        if (!hasAncestorClass(map, 'TeamSpectator')) {
            for (const marker of bindings.keys()) remove(marker);
            previousChoice = null;
            return false;
        }

        const cards = roster(top);
        const markers = map.FindChildrenWithClassTraverse('map_button')
            .filter(panel => panel.BHasClass('player'));
        if (!cards.length) return false;
        const slots = new Map(cards.map((card, index) => [card.identity, [keys[index], card.side]]));
        for (const [marker, binding] of bindings) {
            if (!marker.IsValid() || !markers.includes(marker) || !slots.has(binding.identity)) {
                remove(marker);
            }
        }

        // Both borders are set by the same spectator selection in the game.
        const selectedCards = cards.filter(({card}) => card.BHasClass('SpectatorTarget'));
        const selectedMarkers = markers.filter(marker => marker.visible && marker.BHasClass('spectate'));
        const targetName = target && target.FindChildrenWithClassTraverse('playerName')[0];
        const card = selectedCards.length === 1 && targetName &&
            selectedCards[0].name === targetName.text.trim() ? selectedCards[0] : null;
        const marker = selectedMarkers.length === 1 ? selectedMarkers[0] : null;
        if (card && marker && previousChoice &&
            previousChoice.identity === card.identity && previousChoice.marker === marker) {
            const current = bindings.get(marker);
            if (!current || current.identity !== card.identity) {
                for (const [oldMarker, binding] of bindings) {
                    if (oldMarker === marker || binding.identity === card.identity) remove(oldMarker);
                }
                bind(marker, card);
                $.Msg('[DOA-MINIMAP] bound ' + slots.get(card.identity)[0] + ' (' + bindings.size + '/' + cards.length + ')');
            }
        }
        previousChoice = card && marker ? {identity: card.identity, marker} : null;

        if (local) {
            publishPositions(map, slots);
        } else {
            for (const {identity, label} of bindings.values()) {
                const [key] = slots.get(identity);
                if (label.text !== key) label.text = key;
            }
        }
        return true;
    }

    function sample() {
        if (!root.IsValid()) return;
        try {
            const updated = update(root.FindChildTraverse('minimap_persp'), root.FindChildTraverse('TopBar'),
                                   root.FindChildTraverse('spectate_target'));
            if (local && !updated) publish();
        } catch (error) {
            if (local) publish();
            if (!reportedError) $.Msg('[DOA-MINIMAP] ' + String(error));
            reportedError = true;
        }
        $.Schedule(0.12, sample);
    }

    $.Schedule(0.12, sample);
})();
