// Resolve stock panels without changing their layout or the data read by Panorama.
function doaNativeHudPanels(hud, minimap, options) {
    const show = [];
    const hide = [];
    if (!hud || !options) return {show, hide};

    const selectors = {
        minimap: ['minimap_persp'],
        topBar: ['TopBar'],
        health: ['health_and_abilities_container'],
        abilities: ['hud_signature'],
        items: ['hud_passive_items', 'ActiveAbilitiesMenu', 'ModsContainer'],
        stats: ['hudPlayerStats', 'hudActivePlayerStats', 'gold_and_ap_container', 'APContainer'],
        killFeed: ['DataFeed'],
        spectatorControls: ['spectate_bar'],
        announcements: ['CitadelHudGameAnnouncements'],
        chat: ['Chat'],
    };
    for (const [key, ids] of Object.entries(selectors)) {
        const enabled = options.elements?.[key];
        if (typeof enabled !== 'boolean') continue;
        const targets = enabled ? show : hide;
        for (const id of ids) {
            const panel = key === 'minimap' ? minimap : hud.FindChildTraverse(id);
            if (panel?.IsValid()) targets.push(panel);
        }
    }

    if (options.minimapBackground === false && minimap?.IsValid()) {
        const container = minimap.FindChildTraverse('minimap_container');
        const map = container?.FindChildTraverse('hud_minimap');
        for (const panel of [container?.FindChildTraverse('minimap_frame'), container?.FindChildTraverse('minimap_blur'),
                             map?.FindChildTraverse('map_render')]) {
            if (panel?.IsValid()) hide.push(panel);
        }
        // The same background wrapper also contains the UICanvas used for ziplines.
        // Hide only the stock map textures so lane paths and minimap markers stay visible.
        const background = map?.FindChildTraverse('MinimapBackgroundTest');
        if (background?.IsValid()) {
            for (let index = 0; index < background.GetChildCount(); index += 1) {
                const image = background.GetChild(index);
                if (image?.IsValid() && image.paneltype === 'Image' &&
                    ['backgroundImage1', 'backgroundImage2', 'backgroundImage3'].some(name => image.BHasClass(name))) {
                    hide.push(image);
                }
            }
        }
    }
    return {show, hide};
}
