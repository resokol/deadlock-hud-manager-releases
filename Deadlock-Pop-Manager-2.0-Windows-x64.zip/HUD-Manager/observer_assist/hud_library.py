"""Qt controls for choosing, importing, and configuring browser overlays."""

import json
from pathlib import Path
from urllib.parse import urlencode

from PySide6.QtCore import Qt, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QColorDialog, QComboBox, QDialog, QDialogButtonBox, QFileDialog,
    QFormLayout, QGroupBox, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMessageBox, QPushButton,
    QScrollArea, QSlider, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget,
)

from .hud_desktop import screen_by_id, screen_id
from .hud_nicknames import MAX_ALIASES, MAX_DISPLAY_NAME, MAX_PLAYER_NAME, clean_aliases, roster_names
from .hud_packages import DEFAULT_ID


class HudLibrary(QGroupBox):
    studio_requested = Signal(object)
    desktop_monitor_changed = Signal(str)

    def __init__(self, packages, settings, start_server):
        super().__init__('Кастомные HUD')
        self.packages = packages
        self.settings = settings
        self.start_server = start_server
        try:
            self.player_aliases = clean_aliases(json.loads(settings.value('hudPlayerAliases', '{}', type=str)))
        except ValueError:
            self.player_aliases = {}
        self.setAcceptDrops(True)

        layout = QVBoxLayout(self)
        layout.setSpacing(8)
        studio = QHBoxLayout()
        self.create_hud = QPushButton('Создать HUD')
        self.create_hud.setObjectName('primary')
        self.create_hud.clicked.connect(lambda: self.studio_requested.emit(None))
        self.edit_layout = QPushButton('Редактировать HUD')
        self.edit_layout.clicked.connect(lambda: self.studio_requested.emit(self.selector.currentData()))
        studio.addWidget(self.create_hud)
        studio.addWidget(self.edit_layout)
        aliases = QPushButton('Эфирные ники…')
        aliases.clicked.connect(self.edit_player_aliases)
        studio.addWidget(aliases)
        studio.addStretch()
        layout.addLayout(studio)
        picker = QHBoxLayout()
        label = QLabel('&Активный HUD')
        self.selector = QComboBox()
        self.selector.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.selector.setMinimumContentsLength(16)
        label.setBuddy(self.selector)
        self.selector.setAccessibleName('Активный HUD')
        picker.addWidget(label)
        picker.addWidget(self.selector, 1)
        self.import_button = QPushButton('Импорт ZIP…')
        self.import_button.clicked.connect(self._select_zip)
        picker.addWidget(self.import_button)
        layout.addLayout(picker)

        actions = QHBoxLayout()
        self.preview = QPushButton('Предпросмотр')
        self.preview.clicked.connect(self._preview)
        self.copy_obs = QPushButton('Копировать URL OBS')
        self.copy_obs.clicked.connect(self._copy_active)
        self.edit = QPushButton('Настройки…')
        self.edit.clicked.connect(self._configure)
        self.remove = QPushButton('Удалить…')
        self.remove.clicked.connect(self._remove)
        for button in (self.preview, self.copy_obs, self.edit, self.remove):
            actions.addWidget(button)
        layout.addLayout(actions)

        variant_row = QHBoxLayout()
        self.variant_text = QLabel('Вариант')
        self.variants = QComboBox()
        self.variants.setAccessibleName('Вариант HUD')
        self.variant_text.setBuddy(self.variants)
        self.variant_url = QPushButton('Ссылка варианта')
        self.variant_url.clicked.connect(self._copy_variant)
        for widget in (self.variant_text, self.variants, self.variant_url):
            variant_row.addWidget(widget)
        variant_row.addStretch()
        self.export = QPushButton('Экспорт шаблона…')
        self.export.clicked.connect(self._export_template)
        variant_row.addWidget(self.export)
        layout.addLayout(variant_row)

        self.desktop_overlay = QCheckBox('Оверлей на рабочем столе')
        self.desktop_overlay.setToolTip('Показывает активный HUD поверх игры и на рабочем столе.')
        layout.addWidget(self.desktop_overlay)

        monitor_row = QHBoxLayout()
        monitor_label = QLabel('&Экран оверлея')
        self.desktop_monitor = QComboBox()
        self.desktop_monitor.setAccessibleName('Экран оверлея')
        self.desktop_monitor.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        self.desktop_monitor.setMinimumContentsLength(20)
        monitor_label.setBuddy(self.desktop_monitor)
        monitor_row.addWidget(monitor_label)
        monitor_row.addWidget(self.desktop_monitor, 1)
        layout.addLayout(monitor_row)
        app = QApplication.instance()
        app.screenAdded.connect(self._refresh_monitors)
        app.screenRemoved.connect(self._refresh_monitors)
        self._refresh_monitors()
        self.desktop_monitor.currentIndexChanged.connect(self._change_monitor)

        opacity_row = QHBoxLayout()
        opacity_label = QLabel('&Непрозрачность HUD')
        self.opacity = QSlider(Qt.Orientation.Horizontal)
        self.opacity.setRange(0, 100)
        self.opacity.setPageStep(10)
        self.opacity.setAccessibleName('Непрозрачность HUD')
        opacity_label.setBuddy(self.opacity)
        self.opacity_value = QLabel()
        self.opacity_value.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.opacity_value.setMinimumWidth(self.opacity_value.fontMetrics().horizontalAdvance('100 %'))
        opacity_row.addWidget(opacity_label)
        opacity_row.addWidget(self.opacity, 1)
        opacity_row.addWidget(self.opacity_value)
        layout.addLayout(opacity_row)
        self.opacity.setValue(settings.value('hudOpacity', 100, type=int))
        self.opacity.valueChanged.connect(self._change_opacity)
        self._change_opacity(self.opacity.value())

        self.message = QLabel()
        self.message.setTextFormat(Qt.TextFormat.PlainText)
        self.message.setObjectName('subtle')
        self.message.setWordWrap(True)
        layout.addWidget(self.message)
        for package in self.packages.all():
            self._load_settings(package)
        self.selector.currentIndexChanged.connect(self._activate)
        self._refresh(settings.value('activeHud', DEFAULT_ID, type=str))
        if self.packages.unreadable:
            self.show_message('Пропущены повреждённые HUD: ' + ', '.join(self.packages.unreadable))

    def show_message(self, message):
        self.message.setText(message)
        self.message.setVisible(bool(message))

    def edit_player_aliases(self):
        try:
            server = self.start_server()
        except OSError:
            server = None
        names = roster_names(server.telemetry) if server is not None else ()
        dialog = PlayerAliasesDialog(names, self.player_aliases, self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        self.player_aliases = dialog.aliases
        self.settings.setValue('hudPlayerAliases', json.dumps(self.player_aliases, ensure_ascii=False))
        if server is not None:
            server.set_player_aliases(self.player_aliases)
        self.show_message('Эфирные ники сохранены.')

    def _change_opacity(self, percent):
        self.packages.opacity = percent
        self.settings.setValue('hudOpacity', percent)
        self.opacity_value.setText(f'{percent} %')

    def _refresh_monitors(self):
        selected = self.settings.value('desktopHudMonitor', '', type=str)
        chooser = self.desktop_monitor
        chooser.blockSignals(True)
        chooser.clear()
        chooser.addItem('Автоматически', '')
        screens = QApplication.screens()
        selected_screen = screen_by_id(screens, selected)
        for index, screen in enumerate(screens, start=1):
            size = screen.geometry().size()
            name = screen.model().strip() or screen.name().removeprefix('\\\\.\\')
            label = f'{index}. {name} · {size.width()} × {size.height()}'
            chooser.addItem(label, selected if screen == selected_screen else screen_id(screen))
        current = chooser.findData(selected)
        if current < 0:
            chooser.addItem('Выбранный экран отключён', selected)
            current = chooser.count() - 1
        chooser.setCurrentIndex(current)
        chooser.blockSignals(False)

    def _change_monitor(self):
        monitor = self.desktop_monitor.currentData() or ''
        self.settings.setValue('desktopHudMonitor', monitor)
        self.desktop_monitor_changed.emit(monitor)

    def _refresh(self, active):
        self.selector.blockSignals(True)
        self.selector.clear()
        for package in self.packages.all():
            self.selector.addItem(package.name, package.id)
        index = self.selector.findData(active)
        self.selector.setCurrentIndex(max(0, index))
        self.selector.blockSignals(False)
        self._activate()

    def _activate(self):
        package = self.packages.get(self.selector.currentData())
        if package is None:
            return
        self.packages.activate(package.id)
        self.settings.setValue('activeHud', package.id)
        self.edit.setEnabled(bool(package.fields))
        studio = 'studio.json' in package.files
        self.edit_layout.setEnabled(studio or bool(package.source_files))
        self.edit_layout.setToolTip('Открыть визуальный редактор' if studio else
                                    'Открыть исходники HTML, CSS и JavaScript' if package.source_files else
                                    'Встроенный HUD можно экспортировать как шаблон и импортировать копию.')
        self.remove.setEnabled(not package.built_in)
        self.variants.clear()
        self.variants.addItem('Основной', '')
        for variant in package.variants:
            self.variants.addItem('Миникарта' if package.id == 'battle-report' and variant == 'minimap' else variant, variant)
        for widget in (self.variant_text, self.variants, self.variant_url):
            widget.setVisible(bool(package.variants))
        self.show_message(f'{package.author} · {package.version}')

    def _load_settings(self, package):
        values = {
            field.key: self.settings.value(f'customHud/{package.id}/{field.key}', field.default, type=type(field.default))
            for field in package.fields
        }
        self.packages.set_settings(package.id, values)

    def _select_zip(self):
        filename, _ = QFileDialog.getOpenFileName(self, 'Импорт HUD', '', 'Пакеты HUD (*.zip)')
        if filename:
            self.install_package(Path(filename))

    def _export_template(self):
        filename, _ = QFileDialog.getSaveFileName(self, 'Экспорт шаблона HUD', 'deadlock-hud-template.zip',
                                                  'Пакеты HUD (*.zip)')
        if filename:
            path = Path(filename)
            if path.suffix.lower() != '.zip':
                path = path.with_name(path.name + '.zip')
            try:
                self.packages.export_template(path)
            except OSError as exc:
                self.show_message(f'Не удалось сохранить шаблон. {exc}')
                return
            self.show_message(f'Шаблон сохранён · {path.name}')

    @staticmethod
    def _dropped_zip(event):
        urls = event.mimeData().urls()
        if len(urls) == 1 and urls[0].isLocalFile():
            path = Path(urls[0].toLocalFile())
            if path.suffix.lower() == '.zip':
                return path
        return None

    def dragEnterEvent(self, event):
        if self._dropped_zip(event):
            event.acceptProposedAction()

    def dropEvent(self, event):
        path = self._dropped_zip(event)
        if path and self.install_package(path):
            event.acceptProposedAction()

    def install_package(self, path):
        try:
            package = self.packages.install(path)
        except (OSError, ValueError) as exc:
            self.show_message(f'Не удалось импортировать HUD. {exc}')
            return False
        self._load_settings(package)
        self._refresh(package.id)
        self.show_message(f'Установлен «{package.name}» · {package.version}')
        return True

    def project_saved(self, package, activate):
        index = self.selector.findData(package.id)
        if activate or index < 0:
            self._load_settings(package)
            self._refresh(package.id if activate else self.selector.currentData())
        elif self.selector.itemText(index) != package.name:
            self.selector.setItemText(index, package.name)
        self.show_message(f'Сохранён «{package.name}»')

    def _remove(self):
        package = self.packages.get(self.selector.currentData())
        if package is None or package.built_in:
            return
        confirm = QMessageBox(self)
        confirm.setWindowTitle('Удалить HUD')
        confirm.setTextFormat(Qt.TextFormat.PlainText)
        confirm.setText(f'Удалить «{package.name}» из библиотеки менеджера?')
        confirm.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        confirm.setDefaultButton(QMessageBox.StandardButton.No)
        if confirm.exec() != QMessageBox.StandardButton.Yes:
            return
        try:
            self.packages.remove(package.id)
        except OSError as exc:
            self.show_message(f'Не удалось удалить HUD. {exc}')
            return
        self.settings.remove(f'customHud/{package.id}')
        self._refresh(DEFAULT_ID)

    def _open_url(self, path):
        try:
            return self.start_server().url + path
        except (OSError, ValueError) as exc:
            self.show_message(f'Сервер HUD недоступен. {exc}')
            return None

    def _package_route(self, preview=False, package_id=None):
        selected = self.selector.currentData()
        query = {'package': package_id or selected}
        variant = self.variants.currentData() if query['package'] == selected else None
        if variant:
            query['variant'] = variant
        if preview:
            query['preview'] = 1
        return '/hud/?' + urlencode(query)

    def _copy(self, path):
        url = self._open_url(path)
        if url:
            QApplication.clipboard().setText(url)
            self.show_message('Ссылка скопирована. Добавьте её в OBS как источник «Браузер».')

    def _copy_active(self):
        self._copy('/hud/')

    def _copy_variant(self):
        self._copy(self._package_route())

    def _preview(self):
        self.preview_package(self.selector.currentData())

    def preview_package(self, package_id):
        url = self._open_url(self._package_route(preview=True, package_id=package_id))
        if url and not QDesktopServices.openUrl(QUrl(url)):
            self.show_message(f'Откройте предпросмотр в браузере · {url}')

    def _configure(self):
        package = self.packages.get(self.selector.currentData())
        if package is None:
            return
        values = self.packages.settings(package.id)
        form = HudSettingsDialog(package, values, self)
        if form.exec() != QDialog.DialogCode.Accepted:
            return
        values = form.values()
        self.packages.set_settings(package.id, values)
        for key, value in values.items():
            self.settings.setValue(f'customHud/{package.id}/{key}', value)
        self.show_message('Настройки HUD сохранены.')


class PlayerAliasesDialog(QDialog):
    def __init__(self, names, aliases, parent):
        super().__init__(parent)
        self.setWindowTitle('Эфирные ники игроков')
        self.resize(540, 440)
        self.aliases = {}
        layout = QVBoxLayout(self)
        hint = QLabel('Укажите ник для графики. Оставьте поле пустым, чтобы показывать игровой ник.')
        hint.setWordWrap(True)
        layout.addWidget(hint)
        self.table = QTableWidget(0, 2)
        self.table.setAccessibleName('Ники игроков')
        self.table.setHorizontalHeaderLabels(['Ник в игре', 'Ник в эфире'])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.verticalHeader().hide()
        layout.addWidget(self.table)
        self._add = QPushButton('Добавить игрока')
        self._add.clicked.connect(self._new_row)
        layout.addWidget(self._add, alignment=Qt.AlignmentFlag.AlignLeft)
        self._error = QLabel()
        self._error.setWordWrap(True)
        self._error.hide()
        layout.addWidget(self._error)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Save).setText('Сохранить')
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText('Отмена')
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        for name in tuple(dict.fromkeys((*aliases, *names)))[:MAX_ALIASES]:
            self._append_row(name, aliases.get(name, ''))

    def _append_row(self, name, display):
        row = self.table.rowCount()
        self.table.insertRow(row)
        self.table.setItem(row, 0, QTableWidgetItem(name))
        self.table.setItem(row, 1, QTableWidgetItem(display))
        self._add.setEnabled(self.table.rowCount() < MAX_ALIASES)
        return row

    def _new_row(self):
        for row in range(self.table.rowCount()):
            if not self.table.item(row, 0).text().strip():
                break
        else:
            row = self._append_row('', '')
        self.table.setCurrentCell(row, 0)
        self.table.editItem(self.table.item(row, 0))

    def accept(self):
        values = {}
        for row in range(self.table.rowCount()):
            name, display = (self.table.item(row, column).text().strip() for column in (0, 1))
            if not display:
                continue
            if not name or len(name) > MAX_PLAYER_NAME or len(display) > MAX_DISPLAY_NAME or name in values:
                self.table.setCurrentCell(row, 0)
                self._error.setText(f'Укажите уникальный игровой ник и эфирный ник до {MAX_DISPLAY_NAME} символов.')
                self._error.show()
                return
            values[name] = display
        self.aliases = clean_aliases(values)
        super().accept()


class HudSettingsDialog(QDialog):
    def __init__(self, package, values, parent):
        super().__init__(parent)
        self.setWindowTitle(f'Настройки · {package.name}')
        self.setMinimumWidth(390)
        self._values = {}
        layout = QVBoxLayout(self)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        content = QWidget()
        form = QFormLayout(content)
        for field in package.fields:
            value = values[field.key]
            if field.kind == 'toggle':
                editor = QCheckBox()
                editor.setChecked(value)
                self._values[field.key] = editor.isChecked
            elif field.kind == 'color':
                editor = QPushButton(value)
                editor.clicked.connect(lambda checked=False, button=editor: self._select_color(button))
                self._values[field.key] = editor.text
            else:
                editor = QLineEdit(value)
                editor.setMaxLength(120)
                self._values[field.key] = editor.text
            editor.setAccessibleName(field.label)
            label = QLabel()
            label.setTextFormat(Qt.TextFormat.PlainText)
            label.setText(field.label)
            label.setBuddy(editor)
            form.addRow(label, editor)
        scroll.setWidget(content)
        layout.addWidget(scroll)
        controls = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        controls.button(QDialogButtonBox.StandardButton.Save).setText('Сохранить')
        controls.button(QDialogButtonBox.StandardButton.Cancel).setText('Отмена')
        controls.accepted.connect(self.accept)
        controls.rejected.connect(self.reject)
        layout.addWidget(controls)
        self.resize(455, min(560, 120 + 35 * len(package.fields)))

    def _select_color(self, button):
        color = QColorDialog.getColor(QColor(button.text()), self, 'Цвет HUD')
        if color.isValid():
            button.setText(color.name())

    def values(self):
        return {key: read() for key, read in self._values.items()}
