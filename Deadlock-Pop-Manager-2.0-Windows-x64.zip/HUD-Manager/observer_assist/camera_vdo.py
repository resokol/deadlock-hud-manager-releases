"""Deliver room snapshots from the loopback bridge to camera routing on the Qt thread."""
from functools import partial
from math import ceil
from time import monotonic

from PySide6.QtCore import QObject, QSignalBlocker, QTimer, QUrl, Signal
from PySide6.QtGui import QDesktopServices

from .camera_vdo_bridge import VdoRoomBridge
from .camera_vdo_room import parse_director


class VdoImport(QObject):
    received = Signal(int, object)
    freshness_changed = Signal(bool)

    def __init__(self, panel, cameras, parent=None, *, bridge_factory=VdoRoomBridge, open_url=None,
                 managed=False, session_factory=None):
        super().__init__(parent)
        self.panel, self.cameras = panel, cameras
        self.managed = managed
        self.session = None
        self._session_factory = session_factory
        self.bridge_factory = (partial(VdoRoomBridge, managed=True) if managed and bridge_factory is VdoRoomBridge
                               else bridge_factory)
        self.open_url = open_url or (self._open_managed if managed else QDesktopServices.openUrl)
        if managed:
            with QSignalBlocker(panel.poll_interval):
                panel.poll_interval.setRange(1, 2)
                panel.poll_interval.setValue(panel.settings.value('povManagedVdoPollSeconds', 1, type=int))
            panel.poll_interval.valueChanged.connect(lambda value: panel.settings.setValue('povManagedVdoPollSeconds', value))
            panel.poll_interval.setToolTip('Интервал фоновой проверки комнаты на этом компьютере.')
            panel.director_mode.hide()
            panel.mode_hint.hide()
            panel.reopen_button.setText('Показать вход VDO.Ninja')
            panel.reopen_button.setToolTip('Открыть форму входа в текущую фоновую сессию.')

        self.bridge = self.room = None
        self.generation = 0
        self.last_response = 0
        self._fresh = False
        self._session_open = False
        self.known = {}
        self.missing_since = {}
        self.seen_nonempty = False
        self.interval = panel.poll_interval.value()
        self.timer = QTimer(self, singleShot=True)
        self.timer.timeout.connect(self._check_connection)
        self.received.connect(self._accept)
        panel.start_requested.connect(self.start)
        panel.reopen_requested.connect(self.reopen)
        panel.stop_requested.connect(self.stop)
        panel.forward_to_modules.toggled.connect(self._change_forwarding)
        panel.poll_interval.valueChanged.connect(self._set_interval)

    def start(self, raw):
        self.stop(reset_panel=False)
        try:
            self.room = parse_director(raw)
        except ValueError as exc:
            self.panel.start_failed(str(exc))
            return
        generation = self.generation
        try:
            as_director = self.managed or self.panel.director_mode.isChecked() or self.room.codirector
            self.bridge = self.bridge_factory(raw, lambda guests: self.received.emit(generation, guests),
                                              scene=not as_director, interval=self.interval)
            if not self.open_url(QUrl(self.bridge.url)):
                raise OSError
        except (OSError, ValueError, ImportError, RuntimeError):
            self.stop(reset_panel=False)
            self.panel.start_failed('Не удалось запустить встроенный браузер. Проверьте установку Qt WebEngine.'
                                    if self.managed else
                                    'Не удалось открыть локальную вкладку. Проверьте браузер по умолчанию.')
            return
        self.last_response = monotonic()
        self._session_open = True
        self.panel.started()
        if self.managed:
            self.panel.status.setText('Подключение к комнате в фоне…')
        self._check_connection()

    def _open_managed(self, url):
        factory = self._session_factory
        if factory is None:
            from .camera_vdo_session import ManagedVdoSession
            factory = ManagedVdoSession
        self.session = factory(self.panel, url)
        generation = self.generation
        self.session.signaling_changed.connect(lambda online: self._link_changed(generation, online))
        return True

    def _link_changed(self, generation, online):
        if online or generation != self.generation or not self.session:
            return
        self.missing_since.clear()
        self.seen_nonempty = False
        self._end_session()
        self._set_fresh(False)
        self.panel.show_stale()
        self.panel.status.setText('Связь с комнатой потеряна. Ожидаем переподключения VDO.Ninja.')


    @property
    def stale_after(self):
        return max(6 if self.managed else 20, 3 * self.interval + 2)

    @property
    def fresh(self):
        return self._fresh and monotonic() - self.last_response < self.stale_after

    def _set_fresh(self, value):
        if self._fresh != value:
            self._fresh = value
            self.freshness_changed.emit(value)

    def _end_session(self):
        if self._session_open:
            self._session_open = False
            self.cameras.end_vdo_session()

    def _change_forwarding(self, enabled):
        if not enabled:
            self.cameras.end_vdo_session()

    def _set_interval(self, seconds):
        self.interval = seconds
        self.missing_since.clear()
        if self.bridge:
            self.bridge.set_interval(seconds)
            self._check_connection()

    def reopen(self):
        if self.managed:
            if self.session:
                self.session.reveal()
            return
        if self.bridge and self.open_url(QUrl(self.bridge.url)):
            self._end_session()
            self.missing_since.clear()
            self._set_fresh(False)

    def _accept(self, generation, guests):
        if not self.bridge or generation != self.generation or (self.session and self.session.online is False):
            return
        now = monotonic()
        if now - self.last_response >= self.stale_after:
            self._end_session()
            self.missing_since.clear()
            if self.managed:
                self.seen_nonempty = False
                self._set_fresh(False)
        self.last_response = now
        self.timer.start(self.stale_after * 1000)
        live = {g['streamID']: g for g in guests}
        if len(live) != len(guests):
            self.missing_since.clear()
            self._set_fresh(False)
            self.panel.set_guests([])
            self.panel.show_result(len(guests), 'В списке повторяется Stream ID. Назначения камер сохранены.')
            return
        if live:
            self.seen_nonempty = True
        if not self.seen_nonempty:
            # The Director DOM can return {} even before room authorization is complete.
            self.panel.set_guests([])
            self.panel.show_result(0, 'Ожидание гостей. При необходимости нажмите «Показать вход VDO.Ninja».'
                                   if self.managed else 'Ожидание гостей. Проверьте вход в комнату во вкладке браузера.')
            return
        for sid in self.known.keys() - live.keys():
            since = self.missing_since.setdefault(sid, now)
            grace = 0.45 if self.managed else 2 * self.interval
            if now - since >= grace:
                del self.known[sid]
                self.missing_since.pop(sid, None)
        for sid, guest in live.items():
            video = guest.get('video')
            self.known[sid] = dict(streamID=sid, label=guest['label'], page=self.room.viewer(sid),
                                   video=video if video in ('live', 'absent') else 'unknown')
            self.missing_since.pop(sid, None)
        self._session_open = True
        forwarding = self.panel.forward_to_modules.isChecked()
        summary = ''
        if forwarding:
            # Missing media clears only a source already owned by this room. Retain unknown
            # guests as unverified entries so routing leaves their previous assignments alone.
            named = {sid: dict(g, label=self.panel.guest_label(sid, g['label'])) for sid, g in self.known.items()}
            entries = [g for g in named.values() if g['video'] != 'absent']
            absent_labels = {g['label'].strip().casefold() for g in named.values() if g['video'] == 'absent'}
            verified = {sid for sid in live if self.known[sid]['video'] == 'live'
                        and named[sid]['label'].strip().casefold() not in absent_labels}
            summary = self.cameras.import_vdo_guests(self.room.key, entries, observed_streams=verified)
        rows = [dict(self.known[sid],
                     bank=self.cameras.vdo_guest_bank(self.room.key, sid) if forwarding else None)
                for sid in live]
        # Native monitoring keeps missing streams unknown while departure is being verified.
        self.panel.set_guests(rows, recent_guests=self.known.values())
        self.panel.show_result(len(live), summary)
        self._set_fresh(True)
        if self.session:
            self.session.confirmed()

    def _check_connection(self):
        if not self.bridge:
            return
        remaining = self.last_response + self.stale_after - monotonic()
        if remaining <= 0:
            self._end_session()
            if self.managed:
                self.seen_nonempty = False
            self.panel.show_stale()
            if self.managed:
                self.panel.status.setText('Фоновая сессия ожидает ответа VDO.Ninja. Последние назначения сохранены.')
            self.missing_since.clear()
            self._set_fresh(False)
        else:
            self.timer.start(ceil(remaining * 1000))

    def stop(self, *, reset_panel=True):
        self.timer.stop()
        self.generation += 1
        session, self.session = self.session, None
        if session:
            session.close()
            self.panel.reopen_button.setText('Показать вход VDO.Ninja')
        bridge, self.bridge = self.bridge, None
        if bridge:
            bridge.close()
        self._end_session()
        self.room = None
        self.known.clear()
        self.missing_since.clear()
        self.seen_nonempty = False
        self._set_fresh(False)
        if reset_panel:
            self.panel.stop()
