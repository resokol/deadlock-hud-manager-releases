from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
import cv2
import numpy as np
from .profile import Profile,Rect,TeamColor
from .vision import detect


REFERENCE=Path(__file__).parent/'assets'/'minimap-reference.png'


@dataclass
class CalibrationResult:
    profile: Profile
    detections: list
    map_details: dict
    message: str
    plausible: bool


def locate_minimap(frame):
    if frame is None or frame.ndim!=3 or min(frame.shape[:2])<100:
        raise ValueError('Не удалось определить карту: нужен полный кадр игры')
    ref=cv2.imread(str(REFERENCE),cv2.IMREAD_GRAYSCALE)
    if ref is None:
        raise ValueError('Нет опорного изображения карты. Переустановите приложение.')
    h,w=frame.shape[:2]
    scale=min(1,1600/w)
    small=cv2.resize(frame,None,fx=scale,fy=scale) if scale<1 else frame
    gray=cv2.cvtColor(small,cv2.COLOR_BGR2GRAY)
    sift=cv2.SIFT_create(nfeatures=1800,contrastThreshold=.018,edgeThreshold=12)
    # Exclude only the outer photographic backdrop of the reference. No hero
    # coordinates are used in matching; spatial coverage is checked below.
    rh,rw=ref.shape
    mask=np.zeros_like(ref)
    cv2.ellipse(mask,(rw//2,round(rh*.52)),(round(rw*.49),round(rh*.48)),0,0,360,255,-1)
    kp1,d1=sift.detectAndCompute(ref,mask)
    kp2,d2=sift.detectAndCompute(gray,None)
    if d1 is None or d2 is None or len(d2)<2:
        raise ValueError('Карта не найдена. Откройте матч или выделите карту рамкой.')
    matches=[a for a,b in cv2.BFMatcher().knnMatch(d1,d2,k=2) if a.distance<.7*b.distance]
    if len(matches)<10:
        raise ValueError('Карта не найдена уверенно. Можно выделить её рамкой.')
    src=np.float32([kp1[m.queryIdx].pt for m in matches])
    dst=np.float32([kp2[m.trainIdx].pt for m in matches])
    matrix,inliers=cv2.findHomography(src,dst,cv2.RANSAC,3)
    if matrix is None or inliers is None:
        raise ValueError('Не удалось подтвердить положение карты')
    good=inliers.ravel().astype(bool)
    coverage=np.ptp(src[good],axis=0)/np.array([rw,rh]) if good.any() else np.zeros(2)
    n=int(good.sum())
    if n<10 or good.mean()<.5 or min(coverage)<.4:
        raise ValueError('Совпадение карты недостаточно уверенное. Выделите её рамкой.')
    corners=np.float32([[[0,0],[rw,0],[rw,rh],[0,rh]]])
    mapped=cv2.perspectiveTransform(corners,matrix)[0]/scale
    x,y=np.min(mapped,axis=0)
    right,bottom=np.max(mapped,axis=0)
    sx,sy=(right-x)/rw,(bottom-y)/rh
    # The map is a screen HUD element: significant rotation/perspective is not
    # a valid match. Inliers confined to a hero portrait were rejected above.
    normalized=matrix/matrix[2,2]
    if (not np.isfinite(mapped).all() or not .7<sx/sy<1.3 or sx<.35 or sx>6
            or max(abs(normalized[0,1]),abs(normalized[1,0]))>max(normalized[0,0],normalized[1,1])*.15
            or max(abs(normalized[2,0]),abs(normalized[2,1]))>.001
            or x< -3 or y< -3 or right>w+3 or bottom>h+3):
        raise ValueError('Найденная область не похожа на карту HUD. Выделите карту рамкой.')
    left,top=max(0,round(float(x))),max(0,round(float(y)))
    rect=Rect(left,top,min(w-left,round(float(right-x))),min(h-top,round(float(bottom-y))))
    return rect,{'inliers':n,'matches':len(matches),'coverage':coverage.tolist()}


def autocalibrate(frame,base_profile=None,roi_hint=None):
    details={}
    if roi_hint is None:
        rect,details=locate_minimap(frame)
    else:
        rect=deepcopy(roi_hint)
        if rect.width<40 or rect.height<40 or not Rect(0,0,frame.shape[1],frame.shape[0]).contains(rect):
            raise ValueError('Выделите карту внутри кадра')
        details={'manual_region':True}
    mini=frame[rect.top:rect.top+rect.height,rect.left:rect.left+rect.width]
    hsv=cv2.cvtColor(mini,cv2.COLOR_BGR2HSV)
    profile=deepcopy(base_profile) if base_profile else Profile()
    profile.roi=rect
    profile.target_size=(frame.shape[1],frame.shape[0])
    profile.marker_mode='portraits'
    profile.teams=[]
    profile.exclusions=[]
    profile.objectives=[]
    for team,(low,high) in enumerate([(5,40),(95,135)],1):
        # Standard amber/blue HUD palette. Other palettes deliberately fail;
        # do not reinterpret arbitrary scene colours as team identities.
        pixels=(hsv[:,:,1]>=55)&(hsv[:,:,2]>=80)&(hsv[:,:,0]>=low)&(hsv[:,:,0]<=high)
        hues=hsv[:,:,0][pixels]
        if len(hues)<max(20,mini.shape[0]*mini.shape[1]*.002):
            raise ValueError('Цвета команд не распознаны. Нужен кадр со значками обеих команд.')
        hist=np.bincount(hues,minlength=180).astype(np.float32)
        smooth=np.convolve(hist,np.ones(7),mode='same')
        peak=int(low+np.argmax(smooth[low:high+1]))
        radius=max(2.5,rect.width/215*6)
        profile.teams.append(TeamColor(team,peak,tolerance=13,saturation_min=65,value_min=80,
                                       radius=radius))
    profile.validate()
    detections=detect(mini,profile)
    counts=[sum(d.team==t for d in detections) for t in (1,2)]
    plausible=all(1<=count<=6 for count in counts)
    message=f'Карта найдена. Возможные портреты: {counts[0]} и {counts[1]}. Сверьте кружки на увеличенной карте.'
    if not plausible:
        message=('Карта найдена, но герои не распознаны надёжно. Автоматический запуск заблокирован. '
                 'Откройте исходный кадр 1920×1080 без уменьшения или используйте дополнительную настройку.')
    return CalibrationResult(profile,detections,details,message,plausible)
