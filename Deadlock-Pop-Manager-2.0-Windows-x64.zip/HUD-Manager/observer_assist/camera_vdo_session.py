"""A single in-process-controlled, private Qt WebEngine room session in the operator panel."""

from secrets import token_hex

from PySide6.QtCore import QObject, Qt, QTimer, QUrl, Signal
from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineProfile, QWebEngineScript, QWebEngineSettings
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QWidget


# VDO's promptAlt/confirmAlt create .promptModal dynamically, including co-director passwords.
# Only the visibility bit crosses out of the frame. Never inspect the operator's answer.
_AUTH_SCRIPT = """
(() => {
  if (!['vdo.ninja', 'www.vdo.ninja'].includes(location.hostname)) return;
  let last = false, scheduled = false;
  function detect() {
    scheduled = false;
    const open = Array.from(document.querySelectorAll('.promptModal, .alertModal, input[type=password]'))
      .some(el => el.getClientRects().length && getComputedStyle(el).visibility !== 'hidden');
    if (last !== open) {
      last = open;
      console.info('SIGNAL' + (open ? '1' : '0'));
    }
  }
  new MutationObserver(() => {
    if (!scheduled) { scheduled = true; setTimeout(detect, 550); }
  }).observe(document.documentElement, {childList:true, subtree:true, attributes:true,
                                       attributeFilter:['hidden', 'class', 'style']});
  detect();
})();
"""


# VDO's own connection indicator (lib.js) tests session.ws.readyState === WebSocket.OPEN.
# Independently witness that bit in the embedded frame. A cached getGuestList response
# on a disconnected signaling socket must never count as departures.
_SIGNAL_SCRIPT = """
(() => {
  if (!['vdo.ninja', 'www.vdo.ninja'].includes(location.hostname) || parent === window) return;
  const target = new URLSearchParams(location.search).get('iframetarget');
  if (!target || new URL(target).hostname !== '127.0.0.1') return;
  let previous;
  function report() {
    let online = false;
    const media = {};
    try {
      online = navigator.onLine && window.session?.ws?.readyState === WebSocket.OPEN;
      if (online) for (const [uuid, pc] of Object.entries(window.session.rpcs || {})) {
        if (!pc?.streamID) continue;
        const el = pc.videoElement;
        const tracks = el?.srcObject?.getVideoTracks?.() || [];
        const count = el?.getVideoPlaybackQuality?.().totalVideoFrames;
        media[uuid] = {frames: Number.isSafeInteger(count) ? count : null,
          connected:pc.connectionState === 'connected',
          liveTrack:tracks.some(t => t.readyState === 'live'),
          endedTrack:tracks.length > 0 && tracks.every(t => t.readyState === 'ended')};
      }
    } catch {}
    if (Boolean(online) !== previous) {
      previous = Boolean(online);
      console.info('NETWORK_SIGNAL' + (previous ? 'up' : 'down'));
    }
    window.parent.postMessage({popMonitorSignaling:Boolean(online), popMonitorMedia:media}, target);
  }
  window.addEventListener('offline', report);
  window.addEventListener('online', report);
  setInterval(report, 1000);
  report();
})();
"""


class _RoomPage(QWebEnginePage):
    prompt = Signal(bool)
    signaling = Signal(bool)

    def __init__(self, profile, view, url):
        super().__init__(profile, view)
        self.room_url = QUrl(url)
        self.prefix = 'room-auth-' + token_hex(12) + '-'
        script = QWebEngineScript()
        script.setName('Room authorization visibility')
        script.setWorldId(QWebEngineScript.ScriptWorldId.ApplicationWorld)
        script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentReady)
        script.setRunsOnSubFrames(True)
        script.setSourceCode(_AUTH_SCRIPT.replace('SIGNAL', self.prefix))
        self.scripts().insert(script)
        health = QWebEngineScript()
        health.setName('Room signaling availability')
        health.setWorldId(QWebEngineScript.ScriptWorldId.MainWorld)
        health.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentReady)
        health.setRunsOnSubFrames(True)
        health.setSourceCode(_SIGNAL_SCRIPT.replace('NETWORK_SIGNAL', self.prefix))
        self.scripts().insert(health)

    def javaScriptConsoleMessage(self, level, message, line, source):
        # Console output from the remote page can contain sensitive room URLs.
        if message == self.prefix + '1':
            self.prompt.emit(True)
        elif message == self.prefix + '0':
            self.prompt.emit(False)
        elif message == self.prefix + 'up':
            self.signaling.emit(True)
        elif message == self.prefix + 'down':
            self.signaling.emit(False)

    def acceptNavigationRequest(self, url, navigation_type, is_main_frame):
        if is_main_frame and url != self.room_url and url.toString() != 'about:blank':
            return False
        return super().acceptNavigationRequest(url, navigation_type, is_main_frame)


class _PermissionBar(QWidget):
    """An explicit one-session decision inside the existing window, with no URL in the prompt."""

    def __init__(self, parent):
        super().__init__(parent)
        self.pending = None
        layout = QHBoxLayout(self)
        self.label = QLabel()
        self.label.setWordWrap(True)
        layout.addWidget(self.label, 1)
        self.allow = QPushButton('Разрешить')
        self.deny = QPushButton('Отклонить')
        for button, approved in ((self.allow, True), (self.deny, False)):
            button.clicked.connect(lambda _, decision=approved: self.finish(decision))
            layout.addWidget(button)
        self.hide()

    def ask(self, origin, kind, answer):
        if origin.scheme() != 'https' or origin.host() not in ('www.vdo.ninja', 'vdo.ninja') or self.pending:
            answer(False)
            return False
        labels = {'MediaAudioCapture':'микрофон', 'MediaVideoCapture':'камеру',
                  'MediaAudioVideoCapture':'камеру и микрофон', 'ClipboardReadWrite':'буфер обмена',
                  'Notifications':'уведомления', 'Geolocation':'геолокацию'}
        # Other features (e.g. screen capture) are outside the room monitor's operation.
        if kind not in labels:
            answer(False)
            return False
        self.pending = answer
        self.label.setText(f'VDO.Ninja запрашивает {labels[kind]}. Разрешить в этой сессии?')
        self.show()
        return True

    def finish(self, approved):
        callback, self.pending = self.pending, None
        self.hide()
        if callback:
            callback(approved)


class _RoomView(QWebEngineView):
    def hideEvent(self, event):
        super().hideEvent(event)
        # A parent tab can hide us independently of an authorization toggle.
        self.page().setVisible(True)


class ManagedVdoSession(QObject):
    """Revealing authorization reuses the active WebRTC session and its loopback token."""

    signaling_changed = Signal(bool)

    def __init__(self, panel, url):
        super().__init__(panel)
        self.panel = panel
        self.url = QUrl(url)
        self.closed = False
        self.online = False
        self.waiting = False
        self.retry_ms = 1000
        self.view = _RoomView(panel.room_page)
        self.view.setAccessibleName('Вход в комнату VDO.Ninja')
        self.view.setMinimumHeight(250)
        self.view.setContextMenuPolicy(Qt.ContextMenuPolicy.NoContextMenu)
        layout = panel.room_page.layout()
        self.permissions = _PermissionBar(panel.room_page)
        layout.insertWidget(layout.indexOf(panel.status) + 1, self.permissions)
        layout.insertWidget(layout.indexOf(self.permissions) + 1, self.view)
        self.view.hide()
        profile = QWebEngineProfile()
        if hasattr(profile, 'setPersistentPermissionsPolicy'):
            profile.setPersistentPermissionsPolicy(QWebEngineProfile.PersistentPermissionsPolicy.AskEveryTime)
        self.page = _RoomPage(profile, self.view, self.url)
        # A page needs its off-the-record profile for the entire lifetime of the WebEngine adapter.
        profile.setParent(self.page)
        self.view.setPage(self.page)
        self.page.setAudioMuted(True)
        self.page.settings().setAttribute(QWebEngineSettings.WebAttribute.PlaybackRequiresUserGesture, False)
        self.page.settings().setAttribute(QWebEngineSettings.WebAttribute.JavascriptCanOpenWindows, False)
        profile.downloadRequested.connect(lambda item: item.cancel())
        if hasattr(self.page, 'permissionRequested'):
            self.page.permissionRequested.connect(self._permission_requested)
        else:  # Qt 6.7
            self.page.featurePermissionRequested.connect(self._feature_requested)
        self.page.prompt.connect(self._prompt)
        self.page.signaling.connect(self._signaling)
        self._retry = QTimer(self, singleShot=True)
        self._retry.timeout.connect(self._reload)
        self.page.renderProcessTerminated.connect(lambda *_: self._schedule_retry())
        self.page.loadFinished.connect(self._loaded)
        self._reload()

    def _permission_requested(self, permission):
        def answer(allowed):
            if permission.isValid():
                (permission.grant if allowed else permission.deny)()
            self._notify_login()
        if self.permissions.ask(permission.origin(), permission.permissionType().name, answer):
            self._visible(True)
            self._notify_login()

    def _feature_requested(self, origin, feature):
        def answer(allowed):
            policy = (QWebEnginePage.PermissionPolicy.PermissionGrantedByUser if allowed else
                      QWebEnginePage.PermissionPolicy.PermissionDeniedByUser)
            self.page.setFeaturePermission(origin, feature, policy)
            self._notify_login()
        if self.permissions.ask(origin, feature.name, answer):
            self._visible(True)
            self._notify_login()

    def _signaling(self, online):
        if not self.closed and self.online != online:
            self.online = online
            self.signaling_changed.emit(online)

    def _schedule_retry(self):
        if self.closed or self._retry.isActive():
            return
        self._signaling(False)
        self._retry.start(self.retry_ms)
        self.retry_ms = min(30000, self.retry_ms * 2)

    def _loaded(self, ok):
        if self.closed:
            return
        if not ok:
            self._schedule_retry()
        else:
            self.page.setVisible(True)

    def _reload(self):
        if not self.closed:
            self.waiting = False
            self.page.setUrl(self.url)
            self.page.setVisible(True)

    def _visible(self, show):
        self.view.setVisible(show)
        # Keep Chromium's foreground timer budget when the authentication widget is hidden.
        self.page.setVisible(True)
        self.panel.reopen_button.setText('Скрыть вход VDO.Ninja' if show else 'Показать вход VDO.Ninja')

    def _prompt(self, active):
        if self.closed:
            return
        self.waiting = active
        self._notify_login()
        if active:
            self._visible(True)
            self.panel.status.setText('VDO.Ninja запрашивает подтверждение. Завершите вход ниже.')

    def _notify_login(self):
        if not self.closed:
            active = self.waiting or self.permissions.pending is not None
            self.page.runJavaScript("document.querySelector('#director')?.setAttribute('data-login',"
                                    + ("'1')" if active else "'0')"))

    def reveal(self):
        if not self.closed:
            self._visible(self.view.isHidden())

    def confirmed(self):
        if not self.closed:
            self.retry_ms = 1000
            if not self.waiting and self.permissions.pending is None and not self.view.isHidden():
                self._visible(False)

    def close(self):
        if not self.closed:
            self.closed = True
            self._retry.stop()
            self.permissions.finish(False)
            self.permissions.deleteLater()
            self.page.triggerAction(QWebEnginePage.WebAction.Stop)
            self.view.hide()
            self.page.setUrl(QUrl('about:blank'))
            self.view.deleteLater()
            self.deleteLater()
