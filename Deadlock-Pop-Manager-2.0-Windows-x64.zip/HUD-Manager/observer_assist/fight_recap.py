"""Group confirmed player kills on the game clock and summarize a finished fight."""

from collections import deque
from dataclasses import dataclass, replace
from math import isfinite
import re


FIGHT_RECAP_ROUTE = '/api/v1/fight-recap'
QUIET_SECONDS = 12
LEAD_SECONDS = 6
TEAMS = {2: 'Янтарные', 3: 'Сапфировые'}


def _seconds(clock):
    match = re.fullmatch(r'([0-9]{1,4}):([0-5][0-9])', clock) if isinstance(clock, str) else None
    return int(match[1]) * 60 + int(match[2]) if match else None


def _number(value):
    return type(value) in (int, float) and isfinite(value) and value >= 0


def _side(people, name, side):
    if not isinstance(name, str) or not name.strip():
        return None
    name = name.strip()
    if side in TEAMS:
        return (side, name) if (side, name) in people else None
    matches = [identity for identity in people if identity[1] == name]
    return matches[0] if len(matches) == 1 else None


def _native_time(event, snapshot, current):
    seconds = _seconds(event.get('gameClock'))
    if seconds is not None:
        return seconds
    at, sampled = event.get('at'), snapshot.get('sampledAt')
    if type(at) is int and type(sampled) is int and 0 <= sampled - at <= 30_000:
        return round(current - (sampled - at) / 1000)
    return None


@dataclass(frozen=True)
class _Kill:
    id: str
    seconds: int
    actor: tuple[int, str]
    target: tuple[int, str]
    souls: int | None
    assists: tuple[tuple[int, str], ...]
    native: bool
    matched: bool = False


def _parse_kill(event, snapshot, people, current, *, native):
    identifier = event.get('id')
    if event.get('kind') != 'kill' or not isinstance(identifier, str) or not 0 < len(identifier) <= 128:
        return None
    if native:
        if event.get('source') == 'sourcetv':
            return None
        seconds = _native_time(event, snapshot, current)
        actor = _side(people, event.get('actor'), event.get('actorSide'))
        target = _side(people, event.get('target'), event.get('targetSide'))
        assists = ()
    else:
        seconds = event.get('gameSeconds')
        killer, victim = event.get('killer') or {}, event.get('victim') or {}
        actor = _side(people, killer.get('name'), killer.get('team'))
        target = _side(people, victim.get('name'), victim.get('team'))
        assists = tuple(dict.fromkeys(_side(people, helper.get('name'), helper.get('team'))
                                     for helper in event.get('assists', ())))
    if (not _number(seconds) or not current - 30 <= seconds <= current or
            not actor or not target or actor[0] == target[0]):
        return None
    souls = event.get('souls')
    return _Kill(identifier, int(seconds), actor, target, souls if type(souls) is int and souls >= 0 else None,
                 tuple(helper for helper in assists if helper and helper[0] == actor[0] and helper != actor), native)


def _latest_finished(kills, current):
    group = []
    for kill in reversed(sorted(kills, key=lambda entry: entry.seconds)):
        if group and group[-1].seconds - kill.seconds > QUIET_SECONDS:
            if len(group) >= 2 and current - group[0].seconds >= QUIET_SECONDS:
                return group[::-1]
            group = []
        group.append(kill)
    if len(group) >= 2 and current - group[0].seconds >= QUIET_SECONDS:
        return group[::-1]
    return []


class FightRecap:
    def __init__(self):
        self._reset(None)

    def _reset(self, match_id):
        self._match_id = match_id
        self._available = False
        self._clock = None
        self._kills = []
        self._seen = {}
        self._damage = deque(maxlen=600)
        self._recap = None
        self._signature = None

    def _record(self, kill):
        stamp = kill.native, kill.id
        if stamp in self._seen:
            return False
        self._seen[stamp] = kill.seconds
        candidates = [(abs(other.seconds - kill.seconds), index) for index, other in enumerate(self._kills)
                      if other.native != kill.native and not other.matched and other.target == kill.target
                      and abs(other.seconds - kill.seconds) <= 2]
        if candidates:
            _, index = min(candidates)
            old = self._kills[index]
            native, relay = (kill, old) if kill.native else (old, kill)
            self._kills[index] = replace(native, id=old.id, matched=True, assists=relay.assists,
                                         souls=native.souls if native.souls is not None else relay.souls)
        else:
            self._kills.append(kill)
            self._kills = self._kills[-256:]
        return True

    def _sample_damage(self, seconds, people):
        if not _number(seconds):
            return False
        counters = {identity: player['heroDamage'] for identity, player in people.items()
                    if type(player.get('heroDamage')) is int and player['heroDamage'] >= 0}
        point = (int(seconds), counters)
        if not counters or (self._damage and point[0] < self._damage[-1][0]):
            return False
        if self._damage and point[0] == self._damage[-1][0]:
            if self._damage[-1] == point:
                return False
            self._damage[-1] = point
        else:
            self._damage.append(point)
        return True

    def observe(self, snapshot, match_id):
        if match_id is not None and self._match_id is not None and match_id != self._match_id:
            self._reset(match_id)
        elif match_id is not None:
            self._match_id = match_id
        snapshot = snapshot or {}
        clock = _seconds(snapshot.get('gameClock'))
        people = {(team['side'], player['name'].strip()): player
                  for team in snapshot.get('teams', ()) if team.get('side') in TEAMS
                  for player in team.get('players', ()) if isinstance(player.get('name'), str)}
        self._available = clock is not None and bool(people)
        if not self._available:
            return
        if self._clock is not None and clock < self._clock - 3:
            self._reset(self._match_id)
            self._available = True
        current = max(self._clock or 0, clock)
        clock_changed = current != self._clock
        self._clock = current
        source = snapshot.get('_fightSource') or {}
        updated = self._sample_damage(source.get('gameSeconds'), people)
        for events, native in ((snapshot.get('events') or (), True), (source.get('events') or (), False)):
            for event in events:
                if (native, event.get('id')) in self._seen:
                    continue
                if kill := _parse_kill(event, snapshot, people, current, native=native):
                    updated |= self._record(kill)
        if clock_changed:
            self._seen = {stamp: time for stamp, time in self._seen.items() if time >= current - 60}
        if not (updated or clock_changed):
            return
        group = _latest_finished(self._kills, current)
        if not group:
            self._recap = self._signature = None
            return
        signature = tuple(group)
        end = group[-1].seconds + QUIET_SECONDS
        if signature != self._signature or (updated and len(self._damage) and self._damage[-1][0] <= end):
            previous = self._recap if signature == self._signature else None
            self._recap = self._summarize(group, people, previous)
            self._signature = signature

    def _at(self, seconds):
        # Clamp to the measured window. An old counter cannot supply a credible boundary.
        return next((counts for time, counts in reversed(self._damage) if seconds - 3 <= time <= seconds), {})

    def _summarize(self, group, people, previous):
        first, last = group[0].seconds, group[-1].seconds
        start, end = max(0, first - LEAD_SECONDS), last + QUIET_SECONDS
        before, after = self._at(start), self._at(end)
        prior = {(team['side'], player['name']): player['heroDamage'] for team in (previous or {}).get('teams', ())
                 for player in team['players']}

        def player(identity):
            side, name = identity
            info = people.get(identity, {})
            return {'side': side, 'name': name, 'hero': info.get('hero'), 'heroId': info.get('heroId')}

        events = [{'id': kill.id, 'gameSeconds': kill.seconds, 'actor': player(kill.actor),
                   'target': player(kill.target), 'souls': kill.souls} for kill in group]
        identities = {identity for kill in group for identity in (kill.actor, kill.target, *kill.assists)}
        missing_assists = {kill.actor[0] for kill in group if kill.native and not kill.matched}
        rows = []
        for identity in identities:
            damage = prior.get(identity)
            if identity in before and identity in after:
                delta = after[identity] - before[identity]
                damage = delta if delta >= 0 else None
            assists = sum(identity in kill.assists for kill in group)
            rows.append({**player(identity), 'kills': sum(k.actor == identity for k in group),
                         'deaths': sum(k.target == identity for k in group),
                         'assists': assists if assists or identity[0] not in missing_assists else None,
                         'heroDamage': damage})
        rows.sort(key=lambda row: (-row['kills'], -(row['assists'] or 0), -(row['heroDamage'] or 0), row['name'].casefold()))
        teams = []
        for side, name in TEAMS.items():
            awards = [kill.souls for kill in group if kill.actor[0] == side]
            teams.append({'side': side, 'name': name, 'kills': len(awards),
                          'soulsFromKills': sum(awards) if None not in awards else None,
                          'players': [row for row in rows if row['side'] == side]})
        winner = max(teams, key=lambda team: team['kills'])['side'] if teams[0]['kills'] != teams[1]['kills'] else None
        return {'id': group[0].id, 'firstKillSeconds': first, 'lastKillSeconds': last,
                'windowStartSeconds': start, 'windowEndSeconds': end,
                'winnerSide': winner, 'teams': teams, 'events': events}

    def state(self, aliases=None):
        recap = self._recap if self._available else None
        if recap and aliases:
            def label(player):
                return {**player, 'displayName': aliases.get(player['name'], player['name'])}

            recap = {**recap, 'teams': [{**team, 'players': [label(player) for player in team['players']]}
                                       for team in recap['teams']],
                     'events': [{**kill, 'actor': label(kill['actor']), 'target': label(kill['target'])}
                                for kill in recap['events']]}
        return {'version': 1, 'status': 'live' if self._available else 'waiting',
                'matchId': self._match_id if self._available else None, 'recap': recap}


def example_recap(telemetry):
    fight = FightRecap()
    teams = (telemetry or {}).get('teams', ())
    if len(teams) < 2:
        return fight.state()
    amber, sapphire = [team['players'][:3] for team in teams]

    def participant(side, player):
        return {'team': side, 'name': player['name']}

    a = [participant(2, player) for player in amber]
    b = [participant(3, player) for player in sapphire]
    kills = [
        {'id': f'preview-{index}', 'kind': 'kill', 'gameSeconds': seconds, 'killer': killer,
         'victim': victim, 'assists': [helper], 'souls': souls}
        for index, (seconds, killer, victim, helper, souls) in enumerate((
            (868, b[1], a[0], b[0], 412), (873, a[1], b[0], a[2], 398),
            (877, b[1], a[2], b[2], 457), (883, b[2], a[1], b[1], 506),
        ))
    ]

    def snapshot(clock, seconds, damages, events):
        return {'gameClock': clock, '_fightSource': {'gameSeconds': seconds, 'events': events},
                'teams': [{**team, 'players': [{**player, 'heroDamage': 8000 + damage}
                                               for player, damage in zip(team['players'], totals)]}
                          for team, totals in zip(teams, damages)]}

    fight.observe(snapshot('14:22', 862, [[0, 0, 0], [0, 0, 0]], []), None)
    fight.observe(snapshot('14:55', 895, [[1631, 2903, 1142], [1518, 4460, 2574]], kills), None)
    return fight.state()
