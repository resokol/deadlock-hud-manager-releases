from dataclasses import dataclass
import cv2
import numpy as np


@dataclass(frozen=True)
class Detection:
    team: int
    x: float
    y: float
    confidence: float = 1.0


def detect(frame, profile):
    """Detect calibrated coloured marker components, not hero identities.

    Overlarge merged components are deliberately discarded. This detector needs
    validation against the actual HUD and cannot infer occluded heroes.
    """
    h, w = frame.shape[:2]
    if (w, h) != (profile.roi.width, profile.roi.height) or frame.ndim != 3:
        return []
    if profile.marker_mode=='portraits':
        return detect_portraits(frame,profile)
    hsv = cv2.cvtColor(frame[:, :, :3], cv2.COLOR_BGR2HSV)
    hue = hsv[:, :, 0].astype(np.int16)
    detections = []
    for t in profile.teams:
        delta = np.abs(hue - t.hue)
        distance = np.minimum(delta, 180 - delta)
        mask = ((distance <= t.tolerance) & (hsv[:, :, 1] >= t.saturation_min)
                & (hsv[:, :, 2] >= t.value_min)).astype(np.uint8) * 255
        for x, y, rw, rh in profile.exclusions:
            mask[int(y*h):int(np.ceil((y+rh)*h)), int(x*w):int(np.ceil((x+rw)*w))] = 0
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
        count, _, stats, centers = cv2.connectedComponentsWithStats(mask)
        for i in range(1, count):
            _, _, cw, ch, area = stats[i]
            if not (t.min_area <= area <= t.max_area and t.min_size <= cw <= t.max_size
                    and t.min_size <= ch <= t.max_size and .4 <= cw/ch <= 2.5):
                continue
            x, y = centers[i]
            detections.append(Detection(t.team, float(x/w), float(y/h)))
    # Overlapping colour ranges must not manufacture opposing heroes at one point.
    return [d for d in detections if not any(
        o.team != d.team and ((o.x-d.x)*w)**2 + ((o.y-d.y)*h)**2 < 36
        for o in detections)]


def detect_portraits(frame,profile):
    """Conservative coloured-ring proposals with a non-empty textured centre.

    This is a shape heuristic, not semantic hero identification. Its results
    must be inspected; small/overlapping/compressed portraits can be missed.
    """
    h,w=frame.shape[:2]
    hsv=cv2.cvtColor(frame[:,:,:3],cv2.COLOR_BGR2HSV)
    gray=cv2.cvtColor(frame[:,:,:3],cv2.COLOR_BGR2GRAY).astype(np.float32)
    hue=hsv[:,:,0].astype(np.int16)
    allowed=np.ones((h,w),np.float32)
    for x,y,rw,rh in profile.exclusions:
        allowed[int(y*h):int(np.ceil((y+rh)*h)),int(x*w):int(np.ceil((x+rw)*w))]=0
    proposals=[]
    for t in profile.teams:
        delta=np.abs(hue-t.hue)
        colour=((np.minimum(delta,180-delta)<=t.tolerance)&(hsv[:,:,1]>=t.saturation_min)
                &(hsv[:,:,2]>=t.value_min)).astype(np.float32)*allowed
        for r in range(max(2,round(t.radius*.72)),max(3,round(t.radius*1.28))+1):
            yy,xx=np.mgrid[-r-1:r+2,-r-1:r+2]
            distance=np.sqrt(xx*xx+yy*yy)
            ring=(np.abs(distance-r)<=.8).astype(np.float32)
            ring/=ring.sum()
            center=(distance<=max(1.5,r*.5)).astype(np.float32)
            center/=center.sum()
            support=cv2.filter2D(colour,-1,ring,borderType=cv2.BORDER_CONSTANT)
            mean=cv2.filter2D(gray,-1,center)
            variance=cv2.filter2D(gray*gray,-1,center)-mean*mean
            brightness=cv2.filter2D(hsv[:,:,2].astype(np.float32),-1,center)
            interior_colour=cv2.filter2D(colour,-1,center)
            # Empty objective diamonds have dark, almost uniform interiors.
            valid=((variance>=64)&(brightness>=75)&(support>=.48)&(allowed>0)
                   &(interior_colour<.65)&(support-interior_colour>=.28))
            peaks=(support>=cv2.dilate(support,np.ones((3,3),np.uint8))-1e-6)&valid
            ys,xs=np.where(peaks)
            for y,x in zip(ys,xs):
                if r<=x<w-r and r<=y<h-r:
                    proposals.append((float(support[y,x]),t.team,int(x),int(y),r))
    accepted=[]
    for score,team,x,y,r in sorted(proposals,reverse=True):
        if any((x-ox)**2+(y-oy)**2 < (.65*(r+orr))**2 for _,_,ox,oy,orr in accepted):
            continue
        accepted.append((score,team,x,y,r))
    return [Detection(team,x/w,y/h,min(.95,.55+score*.4)) for score,team,x,y,r in accepted]
