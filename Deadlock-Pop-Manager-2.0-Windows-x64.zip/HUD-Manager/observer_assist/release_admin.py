"""Issue licenses, run the Telegram bot, or sign an update channel."""

import argparse
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from getpass import getpass
from hashlib import file_digest
import json
import os
from pathlib import Path
import re
import sys
from time import sleep, time
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from .release_security import MAX_LICENSE_DAYS, UPDATE, encode, issue_license, signed_record
from .release_update import Update


@dataclass(frozen=True)
class IssuedLicense:
    code: str
    id: str
    days: int
    recipient: str
    usable_until: int


def license_recipient(value):
    if not isinstance(value, str):
        raise ValueError('Укажите получателя текстом.')
    label = ' '.join(value.split())
    if len(label) > 120:
        raise ValueError('Имя получателя должно быть не длиннее 120 символов.')
    return label


def _license_date(expiry):
    moscow = timezone(timedelta(hours=3), 'МСК')
    return datetime.fromtimestamp(expiry, moscow).strftime('%d.%m.%Y %H:%M:%S %Z')


def read_key(path):
    return path.read_text(encoding='ascii').strip()


def create_key(path):
    key = Ed25519PrivateKey.generate()
    path.parent.mkdir(parents=True, exist_ok=True)
    with os.fdopen(os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), 'w', encoding='ascii') as stream:
        stream.write(encode(key.private_bytes_raw()) + '\n')
    return encode(key.public_key().public_bytes_raw())


def admin_ids(raw):
    values = raw.split(',')
    if not values or any(not re.fullmatch(r'[1-9][0-9]{0,18}', value.strip()) for value in values):
        raise ValueError('Укажите числовые Telegram ID администраторов через запятую.')
    return frozenset(int(value) for value in values)


def bot_reply(update, admins, key, username, *, issuer=None, revoke=None):
    message = update.get('message') or {}
    chat = message.get('chat') or {}
    user = (message.get('from') or {}).get('id')
    if chat.get('type') != 'private' or type(user) is not int or chat.get('id') != user:
        return None
    tokens = (message.get('text') or '').split(maxsplit=2)
    if not tokens:
        return None
    command, _, bot = tokens[0].lower().partition('@')
    if bot and bot != username.lower():
        return None
    if command == '/whoami':
        return user, f'Telegram ID: {user}'
    if user not in admins:
        return None
    if command == '/revoke' and revoke:
        try:
            if len(tokens) == 2:
                return user, 'Лицензия отозвана.' if revoke(tokens[1]) else 'Лицензия не найдена.'
        except ValueError as exc:
            return user, str(exc)
        return user, 'Команда /revoke <ID лицензии или код>'
    if command != '/token':
        return None
    if len(tokens) < 2 or not re.fullmatch(r'[0-9]{1,4}', tokens[1]):
        return user, f'Команда /token <дни от 1 до {MAX_LICENSE_DAYS}> [получатель]'
    try:
        days = int(tokens[1])
        recipient = license_recipient(tokens[2] if len(tokens) == 3 else '')
        label = 'Получатель — ' + (recipient or 'не указан')
        if issuer:
            issued = issuer(days, recipient)
            return user, '\n'.join((issued.code, label, f'Срок лицензии — {issued.days} дн. с первой активации',
                                    f'Активировать код до {_license_date(issued.usable_until)}',
                                    'ID лицензии — ' + issued.id))
        now = int(time())
        return user, '\n'.join((issue_license(days, key, now=now), label,
                                f'Срок лицензии — {days} дн.', f'Действует до {_license_date(now + days * 86400)}'))
    except ValueError as exc:
        return user, str(exc)


def run_bot(key, admins, secret, *, issuer=None, revoke=None):
    if not re.fullmatch(r'[0-9]+:[A-Za-z0-9_-]+', secret):
        raise ValueError('Некорректный ключ Telegram-бота.')

    def call(method, body):
        url = 'https://api.telegram.org/bot' + secret + '/' + method
        request = Request(url, data=json.dumps(body).encode(), headers={'Content-Type': 'application/json'})
        try:
            with urlopen(request, timeout=35) as response:
                packet = json.load(response)
        except HTTPError as exc:
            if exc.code in (401, 404, 409):
                raise RuntimeError(f'Telegram Bot API вернул код {exc.code}.') from None
            raise ConnectionError(f'Telegram Bot API вернул код {exc.code}.') from None
        except (URLError, TimeoutError):
            raise ConnectionError('Telegram Bot API недоступен.') from None
        if packet.get('ok') is not True:
            raise RuntimeError('Telegram Bot API отклонил запрос.')
        return packet['result']

    # A task can start while Windows is still bringing up its network connection.
    while True:
        try:
            username = call('getMe', {})['username']
            break
        except ConnectionError as exc:
            print(exc, file=sys.stderr, flush=True)
            sleep(15)
    print(f'@{username} готов принимать команды.', flush=True)
    offset = None
    while True:
        try:
            body = {'timeout': 25, 'allowed_updates': ['message']}
            if offset is not None:
                body['offset'] = offset
            for update in call('getUpdates', body):
                reply = bot_reply(update, admins, key, username, issuer=issuer, revoke=revoke)
                if reply:
                    chat, message = reply
                    call('sendMessage', {'chat_id': chat, 'text': message})
                offset = update['update_id'] + 1
        except ConnectionError as exc:
            print(exc, file=sys.stderr, flush=True)
            sleep(4)


def start_telegram(admins, issue, revoke=None):
    secret = os.environ.get('DHM_TELEGRAM_BOT_TOKEN') or getpass('Новый ключ Telegram-бота: ').strip()
    run_bot(None, admins, secret, issuer=issue, revoke=revoke)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    keys = commands.add_parser('keygen')
    keys.add_argument('path', type=Path)
    issue = commands.add_parser('issue')
    issue.add_argument('key', type=Path)
    issue.add_argument('days', type=int)
    manifest = commands.add_parser('manifest')
    manifest.add_argument('key', type=Path)
    manifest.add_argument('version')
    manifest.add_argument('installer', type=Path)
    manifest.add_argument('url')
    manifest.add_argument('output', type=Path)
    bot = commands.add_parser('bot')
    bot.add_argument('key', type=Path)
    bot.add_argument('--admins', default=os.environ.get('DHM_TELEGRAM_ADMIN_IDS', ''))
    args = parser.parse_args()
    try:
        if args.command == 'keygen':
            print(create_key(args.path))
        elif args.command == 'issue':
            print(issue_license(args.days, read_key(args.key)))
        elif args.command == 'manifest':
            with args.installer.open('rb') as stream:
                digest = file_digest(stream, 'sha256').hexdigest()
            record = {'version': args.version, 'url': args.url, 'size': args.installer.stat().st_size, 'sha256': digest}
            Update.parse(record)
            args.output.write_text(signed_record(UPDATE, record, read_key(args.key)) + '\n', encoding='ascii')
        else:
            admins = admin_ids(args.admins) if args.admins else frozenset()
            config = os.environ.get('DHM_TELEGRAM_BOT_TOKEN') or getpass('Новый ключ Telegram-бота: ').strip()
            run_bot(read_key(args.key), admins, config)
    except (OSError, ValueError, RuntimeError) as exc:
        parser.exit(1, str(exc) + '\n')
    except KeyboardInterrupt:
        return 0
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
