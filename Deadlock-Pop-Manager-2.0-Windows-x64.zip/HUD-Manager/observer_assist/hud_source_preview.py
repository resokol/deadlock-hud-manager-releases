"""Inspect an installed HUD from an isolated Qt WebEngine world."""

from dataclasses import dataclass
from functools import lru_cache
from html.parser import HTMLParser
import json
from pathlib import PurePosixPath
import re
from urllib.parse import unquote, urlsplit

from PySide6.QtCore import QTimer, Qt, QUrl, Signal
from PySide6.QtWebEngineCore import QWebEngineScript
from PySide6.QtWebEngineWidgets import QWebEngineView

from .hud_desktop import HudPage


_INSPECTOR = r"""
(() => {
    if (location.pathname !== '/hud/') return;
    let dom, hovered, target, picked, marker, pickingStyle;

    function matchingRules(node) {
        const results = [];
        const visited = new Set();
        const win = node.ownerDocument.defaultView;
        function visit(sheet, container) {
            let rules;
            try { rules = container.cssRules; } catch { return; }
            for (const rule of rules ?? []) {
                if (results.length >= 160) return;
                if (rule.selectorText) {
                    try {
                        if (node.matches(rule.selectorText)) results.push([sheet.href, rule.selectorText]);
                    } catch { /* A nested rule can contain a relative selector. */ }
                }
                if (rule.styleSheet) addSheet(rule.styleSheet);
                if (!rule.cssRules) continue;
                if (rule.type === 4 && !win.matchMedia(rule.conditionText).matches) continue;
                if (rule.type === 12 && !win.CSS.supports(rule.conditionText)) continue;
                visit(sheet, rule);
            }
        }
        function addSheet(sheet) {
            if (sheet.disabled || sheet.ownerNode === pickingStyle || visited.has(sheet)) return;
            visited.add(sheet);
            visit(sheet, sheet);
        }
        for (const sheet of node.ownerDocument.styleSheets) addSheet(sheet);
        return results;
    }

    function describe(node) {
        const nodes = [];
        for (let el = node; el && !['body', 'html'].includes(el.localName) && nodes.length < 10; el = el.parentElement) {
            const ordinal = [...el.parentElement?.children ?? []].filter(sibling => sibling.localName === el.localName).indexOf(el);
            nodes.push({tag: el.localName, id: el.id || '', classes: [...el.classList].slice(0, 24), ordinal});
        }
        return nodes.length ? {url: dom.URL, nodes, rules: matchingRules(node)} : null;
    }

    function clear() {
        marker?.remove();
        hovered = target = marker = null;
    }

    function outline() {
        if (!hovered?.isConnected) { clear(); return; }
        const rect = hovered.getBoundingClientRect();
        if (!marker) {
            marker = dom.createElement('div');
            marker.setAttribute('aria-hidden', 'true');
            Object.assign(marker.style, {position: 'fixed', zIndex: '2147483647',
                margin: '0', padding: '0', boxSizing: 'border-box',
                border: '2px solid #a4e3d8', background: '#a4e3d833'});
            marker.style.setProperty('pointer-events', 'none', 'important');
            dom.body.append(marker);
        }
        Object.assign(marker.style, {left: rect.left + 'px', top: rect.top + 'px',
            width: rect.width + 'px', height: rect.height + 'px'});
    }

    function hover(event) {
        const next = event.target?.nodeType === 1 ? event.target : null;
        if (next !== hovered) {
            hovered = next;
            target = next ? describe(next) : null;
        }
        if (target) outline();
        else clear();
    }

    function pick(event) {
        hover(event);
        if (!target) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        picked = target;
    }

    globalThis.doaReadSourcePreview = () => {
        const frameDocument = document.getElementById('overlay')?.contentDocument;
        const next = frameDocument?.readyState === 'loading' ? null : frameDocument;
        if (next !== dom) {
            dom?.removeEventListener('pointermove', hover, true);
            dom?.removeEventListener('click', pick, true);
            dom?.documentElement?.removeEventListener('pointerleave', clear);
            clear();
            pickingStyle?.remove();
            dom = next;
            if (dom?.URL.startsWith(location.origin + '/hud/packages/')) {
                // HUDs often disable hit-testing so the game can receive mouse clicks.
                pickingStyle = dom.createElement('style');
                pickingStyle.textContent = '* { pointer-events: auto !important; }';
                dom.head.append(pickingStyle);
                dom.addEventListener('pointermove', hover, true);
                dom.addEventListener('click', pick, true);
                dom.documentElement.addEventListener('pointerleave', clear);
            }
        }
        if (hovered?.isConnected === false) clear();
        const result = {hover: target, pick: picked};
        picked = null;
        return result;
    };
})();
"""


class PackagePreview(QWebEngineView):
    inspection = Signal(dict)

    def __init__(self, url, parent=None):
        super().__init__(parent)
        self.setAccessibleName('Интерактивный предпросмотр HUD')
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.NoContextMenu)
        page = HudPage(url, self)
        self.setPage(page)
        script = QWebEngineScript()
        script.setName('HUD source inspection')
        script.setWorldId(QWebEngineScript.ScriptWorldId.ApplicationWorld)
        script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentReady)
        script.setSourceCode(_INSPECTOR)
        page.scripts().insert(script)
        self._reading = False
        self._poll = QTimer(self, interval=75)
        self._poll.timeout.connect(self._read)
        self.setUrl(QUrl(url))

    def showEvent(self, event):
        super().showEvent(event)
        self._poll.start()

    def hideEvent(self, event):
        self._poll.stop()
        super().hideEvent(event)

    def _read(self):
        if not self._reading:
            self._reading = True
            self.page().runJavaScript('JSON.stringify(globalThis.doaReadSourcePreview?.())',
                                      QWebEngineScript.ScriptWorldId.ApplicationWorld, self._received)

    def _received(self, result):
        self._reading = False
        if self.isVisible() and isinstance(result, str) and result:
            self.inspection.emit(json.loads(result))


@dataclass(frozen=True)
class SourceSpan:
    file: str
    start: int
    end: int


@dataclass(frozen=True)
class _Tag:
    name: str
    identity: str
    classes: frozenset[str]
    ordinal: int
    start: int
    end: int
    parent: int | None


class _HTML(HTMLParser):
    _void = frozenset('area base br col embed hr img input link meta param source track wbr'.split())

    def __init__(self, text):
        super().__init__()
        self._line_starts = [0, *(m.end() for m in re.finditer('\n', text))]
        self.tags = []
        self._open = []
        self._counts = {}
        self.feed(text)
        self.close()

    def _tag(self, tag, attrs):
        attrs = dict(attrs)
        row, col = self.getpos()
        start = self._line_starts[row - 1] + col
        parent = self._open[-1] if self._open else None
        counter = parent, tag
        ordinal = self._counts.get(counter, 0)
        self._counts[counter] = ordinal + 1
        self.tags.append(_Tag(tag, attrs.get('id') or '', frozenset((attrs.get('class') or '').split()), ordinal,
                              start, start + len(self.get_starttag_text()), parent))

    def handle_starttag(self, tag, attrs):
        self._tag(tag, attrs)
        if tag not in self._void:
            self._open.append(len(self.tags) - 1)

    def handle_startendtag(self, tag, attrs):
        self._tag(tag, attrs)

    def handle_endtag(self, tag):
        for pos in range(len(self._open) - 1, -1, -1):
            if self.tags[self._open[pos]].name == tag:
                del self._open[pos:]
                break


@lru_cache(maxsize=8)
def _html_tags(source):
    return _HTML(source).tags


def _normalize_selector(selector):
    selector = re.sub(r'/\*.*?\*/', ' ', selector, flags=re.S).strip().replace("'", '"')
    selector = ' '.join(selector.split())
    return re.sub(r'\s*([,>+~])\s*', r'\1', selector)


@lru_cache(maxsize=16)
def _css_spans(source, inline):
    content = ([(match.start(1), match.group(1))
                for match in re.finditer(r'<style\b[^>]*>(.*?)</style\s*>', source, re.I | re.S)]
               if inline else [(0, source)])
    selectors = {}
    for offset, css in content:
        # Mask comments and quoted values so braces inside them do not divide CSS rules.
        masked = re.sub(r'/\*.*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',
                        lambda value: ' ' * len(value.group()) if value.group().startswith('/*') else
                        value.group().replace('{', ' ').replace('}', ' '), css, flags=re.S)
        for rule in re.finditer(r'[^{};]+(?=\{)', masked):
            start = rule.start() + len(rule.group()) - len(rule.group().lstrip())
            end = rule.start() + len(rule.group().rstrip())
            if start < end:
                selectors[_normalize_selector(css[start:end])] = offset + start, offset + end
    return selectors


_JS_ASSIGNMENT = re.compile(r'''\.(className|id)\s*=\s*(['"])([^'"\n]+)\2
    |\.classList\.(?:add|toggle)\s*\(\s*(['"])([^'"\n]+)\4
    |\.setAttribute\s*\(\s*['"](class|id)['"]\s*,\s*(['"])([^'"\n]+)\7''', re.X)


@lru_cache(maxsize=16)
def _js_spans(source):
    identities, classes = {}, {}
    for match in _JS_ASSIGNMENT.finditer(source):
        if match[1]:
            field, value = match[1], match[3]
        elif match[5]:
            field, value = 'class', match[5]
        else:
            field, value = match[6], match[8]
        if field == 'id':
            identities.setdefault(value, []).append(match.span())
        else:
            for name in value.split():
                classes.setdefault(name, []).append(match.span())
    return identities, classes


_JS_ID_LOOKUP = re.compile(r'''\b(?:node|getElementById)\s*\(\s*(['"])([\w-]+)\1\s*\)''')
_JS_TEXT_PROPERTY = re.compile(r'\s*\.(?:textContent|innerText)\s*=(?!=)')
_JS_TEXT_HELPER = re.compile(r'\b(?:write|setText)\s*\(\s*$')
_JS_ARGUMENT = re.compile(r'\s*,')
_JS_TARGET_ID = re.compile(r'[\w-]+')


@lru_cache(maxsize=16)
def _js_text_spans(source):
    targets = {}
    for match in _JS_ID_LOOKUP.finditer(source):
        start = source.rfind('\n', 0, match.start()) + 1
        head = source[start:match.start()]
        assignment = _JS_TEXT_PROPERTY.match(source, match.end())
        helper = _JS_TEXT_HELPER.search(head) and _JS_ARGUMENT.match(source, match.end())
        if assignment or helper:
            end = source.find('\n', (assignment or helper).end())
            targets.setdefault(match[2], []).append((start + len(head) - len(head.lstrip()),
                                                       len(source) if end < 0 else end))
    return targets


class SourceMap:
    def __init__(self, package_id, files, read):
        self.prefix = '/hud/packages/' + package_id + '/'
        self.files = frozenset(files)
        self.read = read

    def _file(self, url, index=False):
        if not isinstance(url, str):
            return None
        path = unquote(urlsplit(url).path)
        if path.startswith(self.prefix):
            name = path.removeprefix(self.prefix) or ('index.html' if index else '')
            if name in self.files:
                return name
        return None

    @staticmethod
    def _html_span(file, tags, nodes):
        node = nodes[0]
        identity = node['id']
        classes = set(node['classes'])
        candidates = [tag for tag in tags if tag.name == node['tag']]
        if identity:
            candidates = [tag for tag in candidates if tag.identity == identity]
        elif classes:
            candidates = [tag for tag in candidates if tag.classes and tag.classes <= classes]
        else:
            return None
        if len(candidates) > 1:
            def matches(candidate):
                for ancestor in nodes[1:]:
                    if candidate.parent is None:
                        break
                    parent = tags[candidate.parent]
                    if parent.name != ancestor['tag'] or (ancestor['id'] and parent.identity != ancestor['id']):
                        return False
                    if parent.classes and not parent.classes <= set(ancestor['classes']):
                        return False
                    candidate = parent
                return True
            candidates = [tag for tag in candidates if tag.ordinal == node['ordinal'] and matches(tag)]
        return SourceSpan(file, candidates[0].start, candidates[0].end) if len(candidates) == 1 else None

    def _css_span(self, file, node, rules, *, ancestors=None):
        candidates = []
        classes = set(node['classes'])
        parents = ancestors or ()
        for order, (url, selector) in enumerate(rules):
            name = self._file(url) if url else file
            if not name:
                continue
            # Prefer selectors that refer to an id or class on the selected element.
            class_names = set(re.findall(r'\.([\w-]+)', selector))
            ids = set(re.findall(r'#([\w-]+)', selector))
            score = (node['id'] in ids, len(classes & class_names))
            nearest = next((len(parents) - i for i, ancestor in enumerate(parents)
                            if ancestor['id'] in ids or class_names.intersection(ancestor['classes'])), 0)
            span = _css_spans(self.read(name), url is None).get(_normalize_selector(selector))
            if span:
                candidates.append((score, nearest, order if ancestors is not None else 0, SourceSpan(name, *span)))
        score, _, _, span = max(candidates, key=lambda item: item[:3], default=((False, 0), 0, 0, None))
        return score, span

    def _js_span(self, node):
        candidates = set()
        for file in self.files:
            if PurePosixPath(file).suffix not in ('.js', '.mjs'):
                continue
            identities, classes = _js_spans(self.read(file))
            candidates.update(SourceSpan(file, *span) for span in identities.get(node['id'], ()))
            for name in node['classes']:
                candidates.update(SourceSpan(file, *span) for span in classes.get(name, ()))
        return next(iter(candidates)) if len(candidates) == 1 else None

    def related(self, inspection):
        if not isinstance(inspection, dict) or not inspection.get('nodes'):
            return {}
        file = self._file(inspection['url'], index=True)
        if not file:
            return {}
        node, *ancestors = inspection['nodes']
        _, style = self._css_span(file, node, inspection['rules'], ancestors=ancestors)
        return {'css': style, 'text': self._text_writer(node['id'])}

    def _text_writer(self, identity):
        if not identity:
            return None
        writers = []
        for name in self.files:
            if PurePosixPath(name).suffix.lower() in ('.js', '.mjs'):
                writers.extend(SourceSpan(name, *span)
                               for span in _js_text_spans(self.read(name)).get(identity, ()))
        return writers[0] if len(writers) == 1 else None

    def text_at(self, file, source, start, end):
        if PurePosixPath(file).suffix.lower() in ('.js', '.mjs'):
            line_start = source.rfind('\n', 0, start) + 1
            writers = [SourceSpan(file, left, right) for matches in _js_text_spans(source).values()
                       for left, right in matches if line_start <= left <= start and end <= right]
            if writers:
                return (writers[0] if len(writers) == 1 else None), True
        identity = source[start:end].strip().strip('\'"').removeprefix('#')
        if _JS_TARGET_ID.fullmatch(identity):
            return self._text_writer(identity), True
        return None, False

    def locate(self, inspection):
        if not isinstance(inspection, dict) or not inspection.get('nodes'):
            return None
        file = self._file(inspection['url'], index=True)
        if not file:
            return None
        nodes = inspection['nodes']
        tags = _html_tags(self.read(file))
        direct = self._html_span(file, tags, nodes)
        if direct:
            return direct
        specificity, css = self._css_span(file, nodes[0], inspection['rules'])
        if css and any(specificity):
            return css
        script = self._js_span(nodes[0])
        if script:
            return script
        for index in range(1, len(nodes)):
            ancestor = self._html_span(file, tags, nodes[index:])
            if ancestor:
                return ancestor
        return css
