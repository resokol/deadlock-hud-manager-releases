"""Backfill incomplete Panorama KDA from the same SourceTV broadcast clock."""

from collections import deque
import json
import math
from time import monotonic

from PySide6.QtCore import QObject, QProcess

from .game_icons import icon_root
from .source_tv_panel import SOURCE_TV, node_executable


STATS = ('kills', 'deaths', 'assists')
PROFILE_STATS = {'heroId': 1, 'heroDamage': 0, 'rank': 1, 'lane': 1, 'killStreak': 0}


def _clock(text):
    if not isinstance(text, str):
        return None
    minutes, delimiter, seconds = text.partition(':')
    if not delimiter or not minutes.isascii() or not seconds.isascii() or not minutes.isdecimal() or not seconds.isdecimal():
        return None
    return int(minutes) * 60 + int(seconds)


def _item_names():
    try:
        catalog = json.loads((icon_root() / 'catalog.json').read_text(encoding='utf-8'))
        names = {int(item): None for item in catalog['items']}
        for name, item in catalog['abilityNames'].items():
            if not isinstance(name, str) or not name or name.startswith(('upgrade_', 'ability_')):
                continue
            key = int(item)
            if key in names and (' ' in name or names[key] is None):
                names[key] = name[:1].upper() + name[1:]
        return names
    except (OSError, KeyError, TypeError, ValueError):
        return {}


def _timed_events(events, clock, limit=100):
    if not isinstance(events, list):
        return []
    output = []
    for event in events[-limit:]:
        if not isinstance(event, dict):
            continue
        at, identifier = event.get('gameSeconds'), event.get('id')
        if type(at) in (int, float) and 0 <= at <= clock and isinstance(identifier, str) and 0 < len(identifier) <= 128:
            output.append(event)
    return output


def _purchases(replay, clock, item_names):
    result = []
    for row in _timed_events(replay.get('purchaseHistory'), clock):
        item = row.get('itemId')
        if type(item) is not int or item not in item_names:
            continue
        event = {field: row[field] for field in ('itemId', 'id', 'gameSeconds')}
        if item_names[item]:
            event['name'] = item_names[item]
        result.append(event)
    return result


def _relay_kills(source, current, snapshot):
    sampled_at = snapshot.get('sampledAt')
    if type(sampled_at) is not int or sampled_at <= 0:
        return []
    result = []
    for row in _timed_events(source.get('events'), current, 12):
        age = current - row['gameSeconds']
        victim = row.get('victim')
        if row.get('kind') != 'kill' or age > 12 or not isinstance(victim, dict) or not victim.get('name'):
            continue
        event = {'id': row['id'], 'kind': 'kill', 'target': victim['name'],
                 'targetSide': victim.get('team'), 'at': sampled_at - round(age * 1000), 'source': 'sourcetv'}
        killer = row.get('killer')
        if isinstance(killer, dict) and killer.get('name'):
            event.update(actor=killer['name'], actorSide=killer.get('team'))
        if type(row.get('souls')) is int and row['souls'] >= 0:
            event['souls'] = row['souls']
        result.append(event)
    return result


def fill_kda(snapshot, history, item_names=None):
    current = _clock(snapshot.get('gameClock'))
    if current is None:
        return snapshot
    source = next((row for row in reversed(history) if 0 <= current - row['gameSeconds'] <= 7), None)
    if source is None:
        return snapshot
    identities = {}
    for player in source['players']:
        name = (player.get('name') or '').strip()
        key = player.get('team'), name
        if not name or key in identities or any(type(player.get(field)) is not int for field in STATS):
            return snapshot
        identities[key] = player
    native = [(team['side'], player['name'].strip()) for team in snapshot['teams'] for player in team['players']]
    if len(native) not in (8, 12) or len(set(native)) != len(native) or set(native) != set(identities):
        return snapshot

    changed = False
    enriched = False
    item_names = item_names or {}
    by_player = {}
    teams = []
    for team in snapshot['teams']:
        players = []
        for player in team['players']:
            replay = identities[team['side'], player['name'].strip()]
            stats = {field: max(player.get(field) or 0, replay[field]) for field in STATS}
            changed |= any(player.get(field) != stats[field] for field in STATS)
            merged = {**player, **stats}
            profile = {key: replay[key] for key, minimum in PROFILE_STATS.items()
                       if type(replay.get(key)) is int and replay[key] >= minimum}
            account = replay.get('accountId')
            if type(account) is int and 0 < account <= 0xffffffff:
                profile['_accountId'] = account
            hp, maximum = replay.get('health'), replay.get('maxHealth')
            if (player.get('hpPercent') is None and type(hp) is int and type(maximum) is int and
                    0 <= hp <= maximum and maximum > 0):
                profile['hpPercent'] = round(100 * hp / maximum)
            purchases = _purchases(replay, current, item_names)
            if purchases:
                profile['purchaseHistory'] = purchases
                by_player[team['side'], player['name'].strip()] = purchases
            merged.update(profile)
            enriched |= bool(profile)
            players.append(merged)
        kills = sum(player['kills'] for player in players)
        changed |= kills != team.get('kills')
        teams.append({**team, 'kills': kills, 'players': players})
    result = {**snapshot, 'teams': teams} if changed or enriched else snapshot
    if changed:
        result['kdaSource'] = 'panorama+sourcetv'
    if source.get('events') or any('heroDamage' in player for player in source['players']):
        result = {**result, '_fightSource': {'gameSeconds': source['gameSeconds'], 'events': source.get('events') or []}}
    native_events = snapshot.get('events') or []
    if not any(event.get('kind') == 'kill' for event in native_events if isinstance(event, dict)):
        kills = _relay_kills(source, current, snapshot)
        if kills:
            result = {**result, 'events': [*native_events, *kills][-12:]}
    selected = snapshot.get('selected', {})
    selected_name = (selected.get('player') or '').strip()
    matching = [(key, player) for key, player in identities.items() if key[1] == selected_name]
    if len(matching) == 1:
        key, replay = matching[0]
        extra = {}
        if isinstance(replay.get('loadout'), list):
            extra['loadout'] = replay['loadout']
        if type(replay.get('killStreak')) is int and replay['killStreak'] >= 0:
            extra['killStreak'] = replay['killStreak']
        purchases = by_player.get(key)
        if purchases:
            extra['purchaseHistory'] = purchases
            newest = purchases[-1]
            age = current - newest['gameSeconds']
            if age < 4 and type(snapshot.get('sampledAt')) is int and snapshot['sampledAt'] > 0:
                extra['itemPurchase'] = {**newest, 'at': snapshot['sampledAt'] - round(1000 * age)}
        if extra:
            result = {**result, 'selected': {**selected, **extra}}
    return result


def use_current_team_kills(snapshot):
    teams = []
    for team in snapshot['teams']:
        kills = [player.get('kills') for player in team['players']]
        # The native team label can retain the previous match's result.
        if len(kills) == 6 and all(type(value) is int for value in kills):
            team = {**team, 'kills': sum(kills)}
        teams.append(team)
    return {**snapshot, 'teams': teams}


class BroadcastKda(QObject):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.process = QProcess(self)
        self.process.readyReadStandardOutput.connect(self._read)
        self.process.readyReadStandardError.connect(self.process.readAllStandardError)
        self.source = None
        self._worker_source = None
        self._retry_at = 0
        self.history = deque(maxlen=180)
        self._item_names = {}

    def update(self, source, snapshot):
        if source != self.source:
            self.source, self._retry_at = source, 0
            self.history.clear()
            self._item_names = _item_names() if source else {}
            if self.process.state() != QProcess.ProcessState.NotRunning:
                self.process.kill()
        if source and snapshot and self.process.state() == QProcess.ProcessState.NotRunning and monotonic() >= self._retry_at:
            self._retry_at = monotonic() + 12
            node = node_executable()
            if node and (SOURCE_TV / 'node_modules' / '@deademx' / 'deadlock').is_dir():
                self.process.readAllStandardOutput()
                self._worker_source = source
                self.process.start(node, [str(SOURCE_TV / 'reader.mjs'), source, '60'])
        if not snapshot:
            return None
        snapshot = use_current_team_kills(snapshot)
        return fill_kda(snapshot, self.history, self._item_names)

    def _read(self):
        while self.process.canReadLine():
            line = bytes(self.process.readLine())
            if self._worker_source != self.source:
                continue
            try:
                row = json.loads(line)
                seconds = row.get('gameSeconds')
                if (row.get('type') == 'snapshot' and isinstance(row.get('players'), list) and
                        type(seconds) in (float, int) and math.isfinite(seconds) and seconds >= 0):
                    self.history.append(row)
            except (TypeError, ValueError, AttributeError):
                continue

    def close(self):
        self.source = None
        if self.process.state() != QProcess.ProcessState.NotRunning:
            self.process.kill()
            self.process.waitForFinished(1000)
