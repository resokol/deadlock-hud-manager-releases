from pathlib import Path
import cv2
from .vision import detect


def replay(path: Path, profile):
    profile.validate()
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise ValueError(f"Не удалось открыть видео: {path}")
    try:
        fps = cap.get(cv2.CAP_PROP_FPS)
        if not 0 < fps < 1000:
            raise ValueError("В видео нет корректной частоты кадров")
        index, next_time = 0, 0.0
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            now = index/fps
            index += 1
            if (frame.shape[1], frame.shape[0]) != tuple(profile.target_size):
                raise ValueError("Размер видео не соответствует профилю")
            if now + 1e-8 < next_time:
                continue
            next_time = now + 1/profile.fps
            r = profile.roi
            yield now, detect(frame[r.top:r.top+r.height, r.left:r.left+r.width], profile)
    finally:
        cap.release()
