"""Live hero figures and optional public match history for the browser graphic."""

from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from itertools import groupby
import json
from math import isfinite
from threading import RLock, Thread
from time import monotonic
from urllib.parse import urlencode
from urllib.request import Request, urlopen


HERO_STATS_ROUTE = '/api/v1/hero-stats'
API = 'https://api.deadlock-api.com/v1'
LANES = {1: 'Жёлтая', 4: 'Синяя', 6: 'Зелёная'}
RANKS = ('', 'Initiate', 'Seeker', 'Acolyte', 'Sentinel', 'Mystic', 'Ritualist',
         'Emissary', 'Oracle', 'Phantom', 'Ascendant', 'Eternus')


def public_telemetry(snapshot):
    if snapshot and '_fightSource' in snapshot:
        snapshot = {key: value for key, value in snapshot.items() if key != '_fightSource'}
    if not snapshot or not any('_accountId' in player for team in snapshot.get('teams', ())
                               for player in team.get('players', ())):
        return snapshot
    return {**snapshot, 'teams': [
        {**team, 'players': [{key: value for key, value in player.items() if key != '_accountId'}
                             for player in team['players']]}
        for team in snapshot['teams']
    ]}


def _api(path, **query):
    request = Request(API + path + '?' + urlencode(query), headers={
        'Accept': 'application/json', 'User-Agent': 'DeadlockHUDManager/0.2',
    })
    with urlopen(request, timeout=8) as response:
        rows = json.loads(response.read(2 * 1024 * 1024))
    return [row for row in rows if isinstance(row, dict)] if isinstance(rows, list) else []


def _number(value):
    return value if type(value) in (int, float) and isfinite(value) else None


def _rate(wins, matches):
    if type(matches) is int and type(wins) is int and 0 <= wins <= matches and matches > 0:
        return wins / matches
    return None


def _rank(packed):
    if type(packed) is int:
        tier, division = divmod(packed, 10)
        if 0 < tier < len(RANKS):
            return RANKS[tier] + (f' {division}' if division else '')
    return None


def _read_history(api, pairs):
    result = {}
    accounts, heroes = zip(*pairs)
    wanted = set(pairs)
    for row in api('/players/hero-stats',
                   account_ids=','.join(map(str, sorted(set(accounts)))),
                   hero_ids=','.join(map(str, sorted(set(heroes))))):
        pair = row.get('account_id'), row.get('hero_id')
        if pair not in wanted:
            continue
        matches = row.get('matches_played')
        rate = _rate(row.get('wins'), matches)
        if rate is None:
            continue
        damage = _number(row.get('total_player_damage'))
        result[pair] = {
            'matches': matches,
            'winRate': rate,
            'avgHeroDamage': round(damage / matches) if damage is not None else None,
            'soulsPerMinute': _number(row.get('networth_per_min')),
            'headshotRate': _number(row.get('crit_shot_rate')),
            'accuracy': _number(row.get('accuracy')),
        }
    return result


def _read_lane(api, pairs):
    amber, sapphire = pairs
    for row in api('/analytics/lane-matchup-stats', hero_ids=','.join(map(str, amber)),
                   enemy_hero_ids=','.join(map(str, sapphire)), group_by='hero_ids,enemy_hero_ids',
                   sample_time_s=900):
        if row.get('hero_ids') != list(amber) or row.get('enemy_hero_ids') != list(sapphire):
            continue
        samples = row.get('sample_matches')
        return {
            'matches': row.get('matches_played'),
            'winRate': _rate(row.get('wins'), row.get('matches_played')),
            'sampleMatches': samples,
            'soulsDiff15': _number(row.get('net_worth_diff')) if samples and row.get('sample_time_s') == 900 else None,
        }
    return {}


class _Lookup:
    """Coalesce requests for the current roster and ignore results for an old roster."""

    def __init__(self):
        self._lock = RLock()
        self.clear()

    def clear(self):
        with self._lock:
            self._generation = object()
            self._key = None
            self._value = {}
            self.state = 'idle'
            self._retry_at = 0

    def get(self, key, fetch):
        with self._lock:
            if key != self._key:
                self.clear()
                self._key = key
            if self.state != 'ready' and monotonic() >= self._retry_at:
                self._retry_at = float('inf')
                self.state = 'loading'
                Thread(target=self._load, args=(self._generation, fetch), daemon=True).start()
            return self._value, self.state

    def _load(self, generation, fetch):
        with self._lock:
            if generation is not self._generation:
                return
        try:
            value = fetch()
            status = 'ready'
        except (OSError, ValueError, TypeError):
            value, status = {}, 'unavailable'
        with self._lock:
            if generation is self._generation:
                self._value, self.state = value, status
                self._retry_at = monotonic() + 90


def _player_key(player):
    return player.get('_accountId'), player.get('heroId')


def _matchups(teams):
    players = [(player['lane'], team['side'], player['heroId'])
               for team in teams for player in team['players']
               if player.get('lane') in LANES and player.get('heroId')]
    result = []
    for lane, rows in groupby(sorted(players), key=lambda row: row[0]):
        rows = list(rows)
        amber = tuple(hero for _, side, hero in rows if side == 2)
        sapphire = tuple(hero for _, side, hero in rows if side == 3)
        if len(amber) == len(sapphire) == 2:
            result.append((lane, amber, sapphire))
    return tuple(result)


class HeroStatistics:
    def __init__(self, api=_api):
        self._api = api
        self._lock = RLock()
        self._history = _Lookup()
        self._lanes = _Lookup()
        self._history_enabled = False

    def enable_history(self, enabled):
        with self._lock:
            self._history_enabled = enabled
            if not enabled:
                self._history.clear()

    def _fetch_history(self, pairs):
        # Check again in the worker in case the option was switched off while it started.
        with self._lock:
            if not self._history_enabled:
                return {}
        return _read_history(self._api, pairs)

    def _lane_batch(self, matchups):
        def fetch(entry):
            try:
                return entry[0], _read_lane(self._api, entry[1:])
            except (OSError, ValueError, TypeError):
                return entry[0], None

        with ThreadPoolExecutor(max_workers=len(matchups)) as workers:
            rows = {lane: data for lane, data in workers.map(fetch, matchups) if data is not None}
        if not rows:
            raise OSError('Lane statistics unavailable')
        return rows

    def state(self, stats, preview=False):
        if preview:
            return _preview(stats)
        history, lanes = {}, {}
        status = 'disabled'
        teams = stats['teams']
        with self._lock:
            if self._history_enabled:
                pairs = tuple(sorted({_player_key(player) for team in teams for player in team['players']
                                      if all(_player_key(player))}))
                status = 'waiting'
                if pairs:
                    history, status = self._history.get((stats['matchId'], pairs), lambda: self._fetch_history(pairs))
            matchups = _matchups(teams)
            if matchups:
                lanes, _ = self._lanes.get((stats['matchId'], matchups), lambda: self._lane_batch(matchups))
        return _graphic(stats, history, status, matchups, lanes)


def _graphic(stats, history, status, matchups, lanes):
    return {
        'version': 1,
        'status': stats['status'],
        'matchId': stats['matchId'],
        'gameClock': stats['gameClock'],
        'historyStatus': status,
        'teams': [
            {'side': team['side'], 'players': [
                {'name': player['name'], 'hero': player.get('hero'), 'heroId': player.get('heroId'),
                 'lane': player.get('lane'), 'rank': _rank(player.get('rank')),
                 'heroDamage': player.get('heroDamage'), 'history': history.get(_player_key(player))}
                for player in team.get('players', ())
            ]}
            for team in stats['teams']
        ],
        'lanes': [{'id': lane, 'name': LANES[lane], 'amber': amber, 'sapphire': sapphire, **lanes.get(lane, {})}
                  for lane, amber, sapphire in matchups],
    }


def _preview(stats):
    stats = deepcopy(stats)
    history = {}
    for team in stats['teams']:
        for index, player in enumerate(team['players']):
            hero = team['side'] * 10 + index
            player.update(heroId=hero, lane=(1, 4, 6)[index // 2], _accountId=hero,
                          rank=71 + index, heroDamage=6820 + 315 * index + 220 * team['side'])
            history[hero, hero] = {
                'matches': 16 + 3 * index, 'winRate': (42 + 4 * index) / 100,
                'avgHeroDamage': 19286 + 874 * index, 'soulsPerMinute': 1082 + 19 * index,
                'headshotRate': (12 + index) / 100, 'accuracy': (54 - index) / 100,
            }
    return _graphic(stats, history, 'ready', _matchups(stats['teams']), {
        1: {'matches': 22, 'sampleMatches': 21, 'winRate': .409, 'soulsDiff15': 1287},
        4: {'matches': 37, 'sampleMatches': 37, 'winRate': .541, 'soulsDiff15': -575},
        6: {'matches': 34, 'sampleMatches': 31, 'winRate': .706, 'soulsDiff15': -278},
    })
