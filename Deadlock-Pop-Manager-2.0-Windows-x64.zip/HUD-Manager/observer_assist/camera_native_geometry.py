"""Evidence from vMix Web API snapshots and spatial shortcuts for native Replay copies."""

from dataclasses import dataclass
from math import isclose, isfinite
from xml.etree import ElementTree

from .camera_vmix import _read_state
from .vmix_control import _guid


# vMix 29 Shortcut Function Reference, Input section. SetPosition controls
# playback time. The documented spatial setters target the input's own
# position, independently of SetLayer* and of the original Browser.
_RESET = (
    ('SetPanX', '0', {'panX': 0}),
    ('SetPanY', '0', {'panY': 0}),
    ('SetZoom', '1', {'zoomX': 1, 'zoomY': 1}),
    ('SetCrop', '0,0,1,1', {'cropX1': 0, 'cropY1': 0, 'cropX2': 1, 'cropY2': 1}),
)
_NEUTRAL = {field: value for _, _, fields in _RESET for field, value in fields.items()}
_NEUTRAL.update({field: 0 for field in ('rotate', 'rotateX', 'rotateY', 'rotateZ',
                                          'rotation', 'rotationX', 'rotationY', 'rotationZ')})
_GEOMETRY_FIELDS = {*_NEUTRAL, 'aspectRatio', 'sourceRotation', 'mirror', 'flipX', 'flipY'}


def _equal(left, right):
    try:
        a, b = float(left), float(right)
    except (ValueError, TypeError):
        return left == right
    return isfinite(a) and isfinite(b) and isclose(a, b, rel_tol=0, abs_tol=1e-7)


def reset_commands(virtual_guid, observed_position, *, include_unreported=True):
    """Apply to a native virtual GUID after the caller has validated the pair.

    Many XML variants omit default values or do not expose crop at all. Send
    the documented absolute values even in that case during explicit sync.
    """
    guid = _guid(virtual_guid)
    if not guid:
        raise ValueError('Для сброса геометрии нужен GUID виртуального входа.')
    commands = []
    for function, value, fields in _RESET:
        needs_reset = any(
            (include_unreported if field not in observed_position else not _equal(observed_position[field], neutral))
            for field, neutral in fields.items()
        )
        if needs_reset:
            commands.append({'Function': function, 'Input': guid, 'Value': value})
    return commands


def neutral_issue(observed_position):
    """Report demonstrable drift. An empty result says nothing about omitted XML fields."""
    for field, neutral in _NEUTRAL.items():
        if field in observed_position and not _equal(observed_position[field], neutral):
            return f'Проверьте значение {field} виртуального входа в Position vMix.'
    if 'sourceRotation' in observed_position and not _equal(observed_position['sourceRotation'], 0):
        return 'Проверьте угол Source Rotation виртуального входа в vMix.'
    aspect = str(observed_position.get('aspectRatio', '')).strip().casefold()
    if aspect in {'anamorphic', 'widescreen', 'normal', 'stretch', '4:3', '16:9'}:
        return 'У виртуального входа заданы пропорции кадра. Выберите General → Aspect Ratio → Source.'
    for field in ('mirror', 'flipX', 'flipY'):
        if field in observed_position and str(observed_position[field]).casefold() not in ('0', 'false', 'off'):
            return f'Проверьте отражение {field} виртуального входа в vMix.'
    return ''


@dataclass
class GeometryEvidence:
    positions: dict
    mixes: dict
    # Source configured for Output 2. Physical External 2 playout is not
    # observable here, and an empty string means no route was exposed.
    external2: str

    def guard(self, current, original_guids):
        for guid in original_guids:
            if guid not in self.positions or guid not in current.positions:
                return 'Оригинальный вход исчез из списка vMix.'
            before, after = self.positions[guid], current.positions[guid]
            if before.keys() != after.keys() or any(not _equal(value, after[field]) for field, value in before.items()):
                return f'Изменилась геометрия оригинала {guid}. Проверьте кадрирование в vMix.'
        for number in self.mixes.keys() | current.mixes.keys():
            if self.mixes.get(number) != current.mixes.get(number):
                return f'Изменился Program в Mix {number}. Проверьте текущий выход в vMix.'
        if self.external2 != current.external2:
            return 'Изменился маршрут Output 2. Проверьте External 2 в vMix.'
        return ''


def read_native_geometry(xml):
    state = _read_state(xml)
    root = ElementTree.fromstring(xml)
    positions = {}
    for entry in root.findall('./inputs/input'):
        # Do not use the input's position attribute (milliseconds) or an
        # overlay/position node (one of the ten independent layers).
        spatial = entry.find('position')
        direct = {key: value for key, value in entry.attrib.items() if key in _GEOMETRY_FIELDS}
        if spatial is not None:
            direct.update({key: value for key, value in spatial.attrib.items() if key in _GEOMETRY_FIELDS})
        positions[_guid(entry.get('key'))] = direct

    external2 = ''
    for output in root.findall('./outputs/output'):
        if output.get('type', '').casefold() != 'output' or output.get('number') != '2':
            continue
        source = output.get('source', '').casefold()
        if source == 'mix':
            number = output.get('mix', '')
            if number.isascii() and number.isdigit() and len(number) <= 2:
                external2 = f'mix={int(number)}'
        elif source == 'input':
            reference = output.get('key') or output.get('input') or output.get('inputNumber')
            guid = _guid(reference) or next(
                (key for key, value in state.inputs.items() if str(value['number']) == reference), None)
            if guid:
                external2 = f'input={guid}'
        elif source in ('output', 'program', 'preview', 'multiview', 'multiview2', 'replay'):
            external2 = source
        break
    return GeometryEvidence(positions, state.mixes, external2)


def read_input_alphas(xml):
    """Optional input opacity readback; sparse Web API XML provides no default.

    Accept only byte-valued input opacity, never an overlay, colour-key alpha
    channel, or decimal normalised coefficient. A bare "1" can represent full
    opacity in a normalised schema, so only accept it with explicit byte units.
    """
    alphas, explicit_guids = {}, set()
    for entry in ElementTree.fromstring(xml).findall('./inputs/input'):
        raw = entry.get('alphaByte', entry.get('alpha', ''))
        if not (raw.isascii() and raw.isdigit() and len(raw) <= 3):
            continue
        value = int(raw)
        if value == 1 and 'alphaByte' not in entry.attrib:
            continue
        if value <= 255 and (guid := _guid(entry.get('key'))):
            alphas[guid] = value
            if 'alphaByte' in entry.attrib:
                explicit_guids.add(guid)
    # Raw input/@alpha has no published XML unit. A vMix/adapter snapshot
    # using only 0–100 could be reporting percentages. Treat those values as
    # unknown unless byte scale is explicit or evidenced in this catalogue.
    byte_evidence = any(v > 100 for v in alphas.values())
    if not byte_evidence:
        alphas = {key: value for key, value in alphas.items() if value == 0 or key in explicit_guids}
    return alphas
