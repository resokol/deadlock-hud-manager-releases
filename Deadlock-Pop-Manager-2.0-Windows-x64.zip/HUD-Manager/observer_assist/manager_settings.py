"""Independent POV operator preferences, imported once from the combined manager."""

from PySide6.QtCore import QSettings


def pov_settings(previous=None, current=None):
    if current is None:
        current = QSettings('DeadlockHUDManager', 'DeadlockPOVManager')
    if current.value('importedCombinedSettings', False, type=bool):
        return current
    if previous is None:
        previous = QSettings('DeadlockHUDManager', 'DeadlockHUDManager')
    for key in previous.allKeys():
        if key.startswith('camera') or key in ('povVmix', 'positionsMode', 'positionsRemote', 'positionsUrl',
                                               'statsExportAddress'):
            if not current.contains(key):
                current.setValue(key, previous.value(key))
    if not current.contains('povHudUrl') and previous.contains('positionsUrl'):
        current.setValue('povHudUrl', previous.value('positionsUrl'))
    if not current.contains('povMatchSource'):
        mode = previous.value('positionsMode', '', type=str)
        current.setValue('povMatchSource', 'remote' if mode == 'remote' else 'match')
    current.setValue('importedCombinedSettings', True)
    current.sync()
    return current
