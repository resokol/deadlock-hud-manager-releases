from dataclasses import dataclass
from time import monotonic
import numpy as np
from .profile import Rect


@dataclass(frozen=True)
class SourceValidity:
    valid: bool
    reason: str = ""


@dataclass(frozen=True)
class WindowTarget:
    hwnd: int
    pid: int


@dataclass(frozen=True)
class WindowSnapshot:
    hwnd: int
    pid: int
    rect: Rect
    dpi: int
    visible: bool
    minimized: bool
    title: str = ""


@dataclass
class Frame:
    image: np.ndarray | None
    captured_at: float
    validity: SourceValidity


def physical_to_logical(rect, monitor, logical_origin, scale):
    return (round(logical_origin[0]+(rect.left-monitor.left)/scale),
            round(logical_origin[1]+(rect.top-monitor.top)/scale),
            round(rect.width/scale), round(rect.height/scale))


def desktop_roi(snapshot, profile):
    r = profile.roi
    return Rect(snapshot.rect.left+r.left,snapshot.rect.top+r.top,r.width,r.height)


def validate_snapshot(baseline, current, roi, occluders):
    if current is None or (baseline.hwnd,baseline.pid) != (current.hwnd,current.pid):
        return SourceValidity(False,"Окно игры закрыто или заменено. Выберите его снова.")
    if not current.visible or current.minimized:
        return SourceValidity(False,"Окно игры свёрнуто или скрыто")
    if baseline.rect != current.rect or baseline.dpi != current.dpi:
        return SourceValidity(False,"Геометрия окна или DPI изменились. Перепроверьте калибровку.")
    if not current.rect.contains(roi):
        return SourceValidity(False,"Миникарта находится вне выбранного окна")
    if any(roi.intersects(r) for r in occluders):
        return SourceValidity(False,"Миникарта перекрыта другим окном")
    return SourceValidity(True)


class MssSource:
    def __init__(self, api, baseline, profile, ignored=(), capture_excluded=False):
        if not capture_excluded:
            raise RuntimeError("Не подтверждено исключение оверлея из захвата")
        import mss
        self.api, self.baseline, self.profile = api,baseline,profile
        self.ignored = set(ignored)
        self._mss = mss.mss()

    def grab(self, roi=None):
        if roi is None:
            roi = desktop_roi(self.baseline,self.profile)
        current = self.api.snapshot(self.baseline.hwnd)
        validity = validate_snapshot(self.baseline,current,roi,
                                     self.api.occluders(self.baseline.hwnd,self.ignored))
        if not validity.valid:
            return Frame(None,monotonic(),validity)
        image = np.asarray(self._mss.grab(dict(left=roi.left,top=roi.top,width=roi.width,height=roi.height)))[:,:,:3].copy()
        # Recheck after capture to reject a window move/Alt+Tab during the grab.
        validity = validate_snapshot(self.baseline,self.api.snapshot(self.baseline.hwnd),roi,
                                     self.api.occluders(self.baseline.hwnd,self.ignored))
        if image.max() < 4 or image.std() < .5:
            validity = SourceValidity(False,"Нет изображения игры. Используйте оконный режим без рамки.")
        return Frame(image,monotonic(),validity)

    def close(self):
        self._mss.close()
