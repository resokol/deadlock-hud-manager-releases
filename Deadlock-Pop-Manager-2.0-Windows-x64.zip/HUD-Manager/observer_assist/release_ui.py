"""License gate and update controls for the distributed Windows application."""

from datetime import datetime
from http.client import HTTPException
import json
from pathlib import Path
from queue import SimpleQueue
import subprocess
from threading import Thread
from time import monotonic, time

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import (
    QDialog, QDialogButtonBox, QInputDialog, QLabel, QLineEdit, QMenu, QMessageBox, QToolButton, QVBoxLayout,
)

from . import steam
from .activation import ActivationRejected, RENEW_AFTER_SECONDS, TOKEN_PATTERN, activation_origin
from .release_security import check_license, decode
from .release_update import available_update, download_update, https_url, version_tuple


TOKEN_SETTING = 'release/license'
CHANNEL_SETTING = 'release/channel'


def release_config(path=None):
    if path is None:
        from ._release_keys import RELEASE

        value = RELEASE.copy()
    else:
        value = json.loads(Path(path).read_text(encoding='utf-8'))
    if not isinstance(value, dict):
        raise ValueError('Некорректная конфигурация выпуска.')
    version = version_tuple(value.get('version'))
    for field in ('licenseKey', 'updateKey'):
        if len(decode(value.get(field))) != 32:
            raise ValueError('Некорректный ключ выпуска.')
    if value['licenseKey'] == value['updateKey']:
        raise ValueError('Лицензии и обновления используют разные ключи.')
    channel = value.get('channel')
    if channel is None or isinstance(channel, str) and not channel.strip():
        value['channel'] = ''
    else:
        value['channel'] = https_url(channel)
    origin = value.get('activation', '')
    if origin or version >= (0, 4, 0):
        value['activation'] = activation_origin(origin)
    return value


def _expiry_text(expiry):
    return datetime.fromtimestamp(expiry).astimezone().strftime('%d.%m.%Y %H:%M %Z')


class LicenseDialog(QDialog):
    def __init__(self, config, settings, parent=None, *, current=None, message=''):
        super().__init__(parent)
        self.setWindowTitle('Лицензия Deadlock HUD Manager')
        self.setMinimumWidth(430)
        self.settings = settings
        self.key = config['licenseKey']
        self.expiry = current
        layout = QVBoxLayout(self)
        details = QLabel('Для этой сборки нужен офлайн-токен, который начинается с dhm1.')
        details.setWordWrap(True)
        layout.addWidget(details)
        self.token = QLineEdit(placeholderText='Вставьте токен dhm1…')
        self.token.setAccessibleName('Лицензионный токен')
        self.token.setMaxLength(1024)
        self.token.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addWidget(self.token)
        self.status = QLabel(message or (f'Действует до {_expiry_text(current)}' if current else ''))
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText('Активировать')
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText('Закрыть')
        buttons.accepted.connect(self._activate)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _activate(self):
        token = self.token.text().strip()
        if TOKEN_PATTERN.fullmatch(token):
            self.status.setText('Код из Telegram требует сборку с серверной активацией. Здесь нужен офлайн-токен dhm1.')
            return
        try:
            expiry = check_license(token, self.key)
        except ValueError as exc:
            self.status.setText(str(exc))
            return
        self.settings.setValue(TOKEN_SETTING, token)
        self.settings.sync()
        self.expiry = expiry
        self.accept()


def activate(config, settings):
    saved = settings.value(TOKEN_SETTING, '', type=str)
    try:
        if saved:
            return check_license(saved, config['licenseKey'])
    except ValueError as exc:
        dialog = LicenseDialog(config, settings, message=str(exc))
    else:
        dialog = LicenseDialog(config, settings)
    return dialog.expiry if dialog.exec() == QDialog.DialogCode.Accepted else None


class ReleaseControls(QToolButton):
    def __init__(self, config, expiry, window, activation=None):
        super().__init__(window)
        self.config = config
        self.expiry = expiry
        self.started = monotonic()
        self.wall = time()
        self.window = window
        self.activation = activation
        self._lease_jobs = SimpleQueue()
        self._renew_at = self.started
        self._renewing = False
        self._detaching = False
        self._detach_results = SimpleQueue()
        self._jobs = SimpleQueue()
        self._busy = False
        self.setText('Программа')
        self.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        menu = QMenu(self)
        menu.addAction(f'Версия {config["version"]}').setEnabled(False)
        self.license_action = menu.addAction('Лицензия…', self._license)
        if activation:
            self.detach_action = menu.addAction('Отвязать лицензию от этого ПК…', self._detach)
        self.check_action = menu.addAction('Проверить обновления', self._check)
        menu.addAction('Адрес канала обновлений…', self._edit_channel)
        self.setMenu(menu)
        self._poll = QTimer(self, interval=150)
        self._poll.timeout.connect(self._consume)
        self._watch = QTimer(self, interval=5000)
        self._watch.timeout.connect(self._expire)
        self._watch.start()
        self._detach_poll = QTimer(self, interval=150)
        self._detach_poll.timeout.connect(self._finish_detach)
        QTimer.singleShot(1800, self, lambda: self._check(quiet=True))

    def _license(self):
        if self.activation:
            if self.activation.open_dialog(self.window):
                self.expiry = self.activation.record['until']
                self._renew_at = monotonic() + RENEW_AFTER_SECONDS
            return
        dialog = LicenseDialog(self.config, self.window.settings, self.window, current=self.expiry)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.expiry = dialog.expiry

    def _expire(self):
        if self._detaching:
            return
        if self.activation:
            self._refresh_lease()
        if max(time(), self.wall + monotonic() - self.started) >= self.expiry:
            if self.window.close():
                self._watch.stop()

    def _detach(self):
        access = self.activation
        if self._detaching or not access.record:
            return
        answer = QMessageBox.question(
            self.window, 'Перенос лицензии',
            'HUD Manager закроется после отвязки. Для активации на другом ПК понадобится исходный код из Telegram. '
            'Дата окончания лицензии сохранится. Отвязать лицензию?',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes or not access.record:
            return
        license_id = access.record['license']
        self._detaching = True
        self.license_action.setEnabled(False)
        self.detach_action.setEnabled(False)

        def worker():
            try:
                access.detach(license_id)
            except (OSError, HTTPException, ValueError) as exc:
                self._detach_results.put(exc)
            else:
                self._detach_results.put(None)

        Thread(target=worker, daemon=True).start()
        self._detach_poll.start()

    def _finish_detach(self):
        if self._detach_results.empty():
            return
        failure = self._detach_results.get()
        self._detach_poll.stop()
        self._detaching = False
        if failure is not None:
            self.license_action.setEnabled(True)
            self.detach_action.setEnabled(True)
            QMessageBox.warning(self.window, 'Перенос лицензии', f'Сервер не подтвердил отвязку. {failure}')
            return
        self.activation.revoke()
        self.expiry = 0
        self._watch.stop()
        QMessageBox.information(self.window, 'Лицензия отвязана',
                                'Активируйте исходный код из Telegram на другом ПК.')
        if not self.window.close():
            self._watch.start()

    def _refresh_lease(self):
        access = self.activation
        if not self._lease_jobs.empty():
            license_id, result, failure = self._lease_jobs.get()
            self._renewing = False
            if access.record and access.record['license'] == license_id:
                if isinstance(failure, ActivationRejected):
                    access.revoke()
                    self.expiry = 0
                elif failure:
                    self._renew_at = monotonic() + 15 * 60
                else:
                    access.save(result)
                    self.expiry = access.record['until']
        if self._renewing or not access.record or monotonic() < self._renew_at:
            return
        license_id = access.record['license']
        self._renew_at = monotonic() + RENEW_AFTER_SECONDS
        self._renewing = True
        queue = self._lease_jobs

        def worker():
            try:
                queue.put((license_id, access.renew(license_id), None))
            except (OSError, HTTPException, ValueError) as exc:
                queue.put((license_id, None, exc))

        Thread(target=worker, daemon=True).start()

    def _channel(self):
        return self.window.settings.value(CHANNEL_SETTING, self.config['channel'], type=str)

    def _edit_channel(self):
        value, accepted = QInputDialog.getText(self.window, 'Канал обновлений', 'HTTPS-адрес канала', text=self._channel())
        if not accepted:
            return
        value = value.strip()
        try:
            if value:
                self.window.settings.setValue(CHANNEL_SETTING, https_url(value))
            else:
                self.window.settings.remove(CHANNEL_SETTING)
        except ValueError as exc:
            QMessageBox.warning(self.window, 'Обновления', str(exc))

    def _start(self, operation, complete, *, quiet=False):
        self._busy = True
        self.check_action.setEnabled(False)
        jobs = self._jobs

        def worker():
            try:
                jobs.put((complete, operation(), None, quiet))
            except (OSError, HTTPException, ValueError) as exc:
                jobs.put((complete, None, exc, quiet))

        Thread(target=worker, daemon=True).start()
        self._poll.start()

    def _consume(self):
        if self._jobs.empty():
            return
        callback, result, error, quiet = self._jobs.get()
        self._poll.stop()
        self._busy = False
        self.check_action.setEnabled(True)
        if error:
            if not quiet:
                QMessageBox.warning(self.window, 'Обновления', f'Не удалось получить обновление. {error}')
        else:
            callback(result)

    def _check(self, *, quiet=False):
        if self._busy:
            return
        channel = self._channel()
        if not channel:
            if not quiet:
                self._edit_channel()
            return
        self._start(lambda: available_update(channel, self.config['updateKey'], self.config['version']),
                    lambda release: self._offer(release, quiet), quiet=quiet)

    def _offer(self, release, quiet):
        if release is None:
            if not quiet:
                QMessageBox.information(self.window, 'Обновления', 'Установлена актуальная версия.')
            return
        if QMessageBox.question(self.window, 'Обновления',
                                f'Доступна версия {release.version}. Скачать и установить её?') != QMessageBox.StandardButton.Yes:
            return
        self._start(lambda: download_update(release), self._install)

    def _install(self, installer):
        try:
            if steam.is_deadlock_running():
                QMessageBox.information(self.window, 'Обновления',
                                        'Закройте Deadlock и запустите скачанный установщик:\n' + str(installer))
                return
            subprocess.Popen([str(installer), '/CLOSEAPPLICATIONS', '/NORESTART'],
                             cwd=installer.parent, close_fds=True)
            self.window.close()
        except (OSError, subprocess.SubprocessError) as exc:
            QMessageBox.warning(self.window, 'Обновления', f'Не удалось запустить установщик. {exc}')
