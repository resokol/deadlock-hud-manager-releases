"""Build the broadcast icon atlas from a locally installed Deadlock VPK."""

from argparse import ArgumentParser
from collections import defaultdict
from hashlib import sha256
import json
import os
from pathlib import Path, PurePosixPath
import re
import struct
import subprocess
import sys
from tempfile import TemporaryDirectory
import unicodedata

import cv2
import numpy as np


METADATA_PATHS = ('scripts/heroes.vdata_c', 'scripts/abilities.vdata_c')
IMAGE_PREFIX = 'panorama/images/'
SHIELD_ICONS = {
    'bulletShield': IMAGE_PREFIX + 'hud/core/icon_damage_force.vsvg_c',
    'techShield': IMAGE_PREFIX + 'hud/core/icon_damage_mystic.vsvg_c',
}
SECTION = re.compile(r'^\t([^\s=]+)\s*=\s*(?=\n\t\{)', re.MULTILINE)
FIELD = re.compile(r'^\t\t(\w+)\s*=\s*(?:panorama:)?"([^"\r\n]+)"', re.MULTILINE)
SIGNATURE = re.compile(r'^\t\t\tESlot_Signature_([1-4]) = "([^"]+)"', re.MULTILINE)
LOCALIZED = re.compile(r'^\s*"([^"]+)"\s+"((?:\\.|[^"\\])*)"', re.MULTILINE)
IMAGE_SUFFIXES = {'.png', '.psd', '.tga', '.jpg', '.webp', '.jpeg', '.vtex'}
SHOP_TIER_TEMPLATE = re.compile(r'(?:armor|weapon|tech)_upgrade_t[1-5]')


def app_data():
    return Path(os.environ.get('LOCALAPPDATA') or os.environ.get('XDG_DATA_HOME') or Path.home() / '.local/share') / 'DeadlockHUDManager'


def icon_root():
    return app_data() / 'GameIcons'


def index_fingerprint(index):
    stat = index.stat()
    return f'{stat.st_size}-{stat.st_mtime_ns}'


def refresh(citadel):
    """Keep the local atlas current when the portable extractor is configured."""
    directory = icon_root()
    try:
        fingerprint = index_fingerprint(citadel / 'pak01_dir.vpk')
    except OSError:
        return
    try:
        existing = json.loads((directory / 'catalog.json').read_text(encoding='utf-8'))
    except (OSError, ValueError):
        existing = {}
    if existing.get('fingerprint') == fingerprint and 'shieldAtlas' in existing:
        return
    tool = next(iter(sorted((app_data() / 'Tools').glob('Source2Viewer-*/Source2Viewer-CLI.exe'),
                            reverse=True)), None)
    if tool is None:
        return
    command = [sys.executable, '--build-game-icons'] if getattr(sys, 'frozen', False) else [
        sys.executable, '-m', 'observer_assist.game_icons']
    subprocess.Popen([*command, str(citadel), str(tool)], stdin=subprocess.DEVNULL,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                     creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))


def string_token(text):
    """Valve's CUtlStringToken hash used for ability subclass IDs."""
    m = 0x5bd1e995
    mask = 0xffffffff
    data = text.lower().encode('utf-8')
    h = 0x31415926 ^ len(data)
    whole = len(data) // 4 * 4
    for (word,) in struct.iter_unpack('<I', data[:whole]):
        word = word * m & mask
        word = ((word ^ (word >> 24)) * m) & mask
        h = ((h * m) & mask) ^ word
    if whole < len(data):
        h = ((h ^ int.from_bytes(data[whole:], 'little')) * m) & mask
    h = ((h ^ (h >> 13)) * m) & mask
    return h ^ (h >> 15)


def definitions(text):
    entries = list(SECTION.finditer(text))
    return {entry[1].strip('"'): text[entry.end():entries[i + 1].start() if i + 1 < len(entries) else len(text)]
            for i, entry in enumerate(entries)}


def archive_assets(index):
    data = index.read_bytes()
    magic, version, tree_length = struct.unpack_from('<III', data)
    if magic != 0x55AA1234 or version != 2:
        raise ValueError('Unsupported VPK index')
    stop = 28 + tree_length
    offset = 28

    def word():
        nonlocal offset
        end = data.index(b'\0', offset, stop)
        value = data[offset:end].decode('utf-8')
        offset = end + 1
        return value

    assets = set()
    while extension := word():
        while directory := word():
            while name := word():
                preload, = struct.unpack_from('<H', data, offset + 4)
                offset += 18 + preload
                if directory.startswith(IMAGE_PREFIX) and extension in ('vtex_c', 'vsvg_c'):
                    assets.add(f'{directory}/{name}.{extension}')
    return assets


def resolve_image(ref, assets, variants):
    if not ref:
        return None
    if ref.startswith('file://{images}/'):
        ref = IMAGE_PREFIX + ref.removeprefix('file://{images}/')
    elif ref.startswith('s2r://'):
        ref = ref.removeprefix('s2r://')
    if not ref.startswith(IMAGE_PREFIX):
        return None
    path = PurePosixPath(ref.lower())
    if path.suffix in IMAGE_SUFFIXES:
        stem = str(path.with_suffix(''))
        if path.suffix != '.vtex':
            stem += '_' + path.suffix[1:]
        target = stem + '.vtex_c'
    elif path.suffix in ('.svg', '.vsvg'):
        target = str(path.with_suffix('.vsvg_c'))
    elif path.suffix in ('.vtex_c', '.vsvg_c'):
        target = str(path)
    else:
        return None
    if target in assets:
        return target
    return variants.get(target)


def aliases(value):
    value = re.sub(r'#\|[^|]+\|#', '', value).replace(r'\"', '"').strip()
    return unicodedata.normalize('NFKC', value).lower()


def read_localization(citadel, keys):
    result = defaultdict(set)
    root = citadel / 'resource' / 'localization'
    for group in ('citadel_gc_hero_names', 'citadel_gc_mod_names', 'citadel_heroes', 'citadel_mods'):
        for path in (root / group).glob('*.txt'):
            raw = path.read_bytes()
            encoding = 'utf-16' if raw.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig'
            for match in LOCALIZED.finditer(raw.decode(encoding, errors='replace')):
                token = match[1].lower().removesuffix(':n')
                if token in keys:
                    name = aliases(match[2])
                    if name:
                        result[token].add(name)
    return result


def collect(citadel, work, assets):
    variants = {}
    for path in sorted(assets, reverse=True):
        variants[re.sub(r'_[a-f0-9]{8}(?=\.vtex_c$)', '', path)] = path
    ability_defs = definitions((work / 'scripts/abilities.vdata').read_text(encoding='utf-8-sig'))
    hero_defs = definitions((work / 'scripts/heroes.vdata').read_text(encoding='utf-8-sig'))
    names = read_localization(citadel, ability_defs.keys() | hero_defs.keys())
    portraits, spells, slots, upgrades, hero_names, ability_names = {}, {}, {}, set(), {}, {}
    playable, playable_portraits, shop = set(), set(), set()

    for name, body in hero_defs.items():
        match = re.search(r'^\t\tm_HeroID = (\d+)', body, re.MULTILINE)
        if not match or match[1] == '0':
            continue
        hero_id = match[1]
        fields = dict(FIELD.findall(body))
        image = next((path for key in ('m_strIconImageSmall', 'm_strIconHeroCard', 'm_strIconImage')
                      if (path := resolve_image(fields.get(key), assets, variants))), None)
        if not re.search(r'^\t\t(?:m_bPlayerSelectable = false|m_bDisabled = true|m_bInDevelopment = true)',
                         body, re.MULTILINE):
            playable.add(hero_id)
        if image:
            portraits[hero_id] = image
            if hero_id in playable:
                playable_portraits.add(hero_id)
        slots[hero_id] = {n: str(string_token(ability)) for n, ability in SIGNATURE.findall(body)}
        for label in names[name] | {aliases(name)}:
            hero_names.setdefault(label, set()).add(hero_id)

    for name, body in ability_defs.items():
        fields = dict(FIELD.findall(body))
        ability_id = str(string_token(name))
        is_item = fields.get('m_eAbilityType') == 'EAbilityType_Item'
        choices = ('m_strShopIconLarge', 'm_strAbilityImage', 'm_strShopIconSmall') if is_item else (
            'm_strAbilityImage', 'm_strSmallAbilityImage', 'm_strShopIconLarge')
        image = next((path for key in choices
                      if (path := resolve_image(fields.get(key), assets, variants))), None)
        if image:
            spells[ability_id] = image
            for label in names[name] | {aliases(name)}:
                ability_names.setdefault(label, set()).add(ability_id)
        if is_item:
            upgrades.add(ability_id)
            if (fields.get('m_iItemTier') and not SHOP_TIER_TEMPLATE.fullmatch(name) and
                    not re.search(r'^\t\tm_bDisabled = true', body, re.MULTILINE)):
                shop.add(ability_id)

    unique = lambda labels: {name: next(iter(keys)) for name, keys in labels.items() if len(keys) == 1}
    previewable = {spell for hero in playable for spell in slots.get(hero, {}).values()}
    return portraits, spells, {
        'heroSlots': slots,
        'heroNames': unique(hero_names),
        'abilityNames': unique(ability_names),
        'items': sorted(upgrades),
        'coverage': {'playableHeroes': len(playable), 'playablePortraits': len(playable_portraits),
                     'itemDefinitions': len(upgrades), 'itemIcons': len(upgrades & spells.keys()),
                     'shopItems': len(shop), 'shopItemIcons': len(shop & spells.keys()),
                     'missingShopItems': sorted(shop - spells.keys()),
                     'abilityIcons': len(spells), 'heroAbilities': len(previewable),
                     'heroAbilityIcons': len(previewable & spells.keys()),
                     'missingPlayablePortraits': sorted(playable - playable_portraits),
                     'missingHeroAbilities': sorted(previewable - spells.keys())},
    }


def _export(tool, index, work, paths):
    command = [str(tool), '-i', str(index), '-o', str(work), '-d', '-f', ','.join(paths), '--threads', '4']
    result = subprocess.run(command, capture_output=True, timeout=180, encoding='utf-8', errors='replace')
    if result.returncode:
        raise RuntimeError((result.stderr or result.stdout)[-2500:])


def _read_tile(resource, work, max_size):
    source = work / PurePosixPath(resource).with_suffix('.svg' if resource.endswith('.vsvg_c') else '.png')
    if not source.is_file():
        return None
    if source.suffix == '.svg':
        from PySide6.QtCore import QRectF
        from PySide6.QtGui import QImage, QPainter
        from PySide6.QtSvg import QSvgRenderer

        renderer = QSvgRenderer(str(source))
        if not renderer.isValid():
            return None
        qimage = QImage(max_size, max_size, QImage.Format.Format_RGBA8888)
        qimage.fill(0)
        painter = QPainter(qimage)
        renderer.render(painter, QRectF(0, 0, max_size, max_size))
        painter.end()
        rgba = np.frombuffer(qimage.bits(), dtype=np.uint8).reshape(max_size, max_size, 4)
        return cv2.cvtColor(rgba, cv2.COLOR_RGBA2BGRA)
    image = cv2.imdecode(np.fromfile(source, dtype=np.uint8), cv2.IMREAD_UNCHANGED)
    if image is None:
        return None
    if image.ndim == 2:
        image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGRA)
    elif image.shape[2] == 3:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2BGRA)
    height, width = image.shape[:2]
    scale = min(max_size / height, max_size / width)
    return cv2.resize(image, (max(1, round(width * scale)), max(1, round(height * scale))), interpolation=cv2.INTER_AREA)


def build_shields(index, tool, destination, assets):
    paths = [(key, path) for key, path in SHIELD_ICONS.items() if path in assets]
    if not paths:
        return {}
    cell = 56
    with TemporaryDirectory(prefix='shields-', dir=destination) as temporary:
        work = Path(temporary)
        _export(tool, index, work, [path for _, path in paths])
        pixels = np.zeros((cell, len(paths) * cell, 4), dtype=np.uint8)
        tiles = {}
        for column, (key, path) in enumerate(paths):
            tile = _read_tile(path, work, cell - 6)
            if tile is not None:
                y = (cell - tile.shape[0]) // 2
                x = column * cell + (cell - tile.shape[1]) // 2
                pixels[y:y+tile.shape[0], x:x+tile.shape[1]] = tile
                tiles[key] = [column, 0]
        ok, encoded = cv2.imencode('.webp', pixels, [cv2.IMWRITE_WEBP_QUALITY, 101])
        if not tiles or not ok:
            return {}
        data = encoded.tobytes()
        image = f'icons-{sha256(data).hexdigest()[:16]}.webp'
        (work / image).write_bytes(data)
        (work / image).replace(destination / image)
    return {'image': image, 'columns': len(paths), 'rows': 1, 'tiles': tiles}


def build(citadel, tool, destination):
    index = citadel / 'pak01_dir.vpk'
    fingerprint = index_fingerprint(index)
    destination.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix='building-', dir=destination) as temporary:
        work = Path(temporary)
        _export(tool, index, work, METADATA_PATHS)
        assets = archive_assets(index)
        hero_images, icons, catalog = collect(citadel, work, assets)
        paths = sorted(set(hero_images.values()) | set(icons.values()))
        for start in range(0, len(paths), 90):
            _export(tool, index, work, paths[start:start + 90])
        columns, cell = 20, 62
        rows = (len(paths) + columns - 1) // columns
        pixels = np.zeros((rows * cell, columns * cell, 4), dtype=np.uint8)
        positions = {}
        for i, path in enumerate(paths):
            icon = _read_tile(path, work, cell - 6)
            if icon is None:
                continue
            row, column = divmod(i, columns)
            h, w = icon.shape[:2]
            y, x = row * cell + (cell - h) // 2, column * cell + (cell - w) // 2
            pixels[y:y+h, x:x+w] = icon
            positions[path] = [column, row]

        ok, encoded = cv2.imencode('.webp', pixels, [cv2.IMWRITE_WEBP_QUALITY, 84])
        if not ok or len(positions) < 100:
            raise RuntimeError('The installed game did not produce a usable icon atlas')
        atlas = encoded.tobytes()
        sheet = f'icons-{sha256(atlas).hexdigest()[:16]}.webp'
        catalog.update({
            'columns': columns, 'rows': rows, 'image': sheet, 'fingerprint': fingerprint,
            'heroIcons': {key: positions[path] for key, path in hero_images.items() if path in positions},
            'abilityIcons': {key: positions[path] for key, path in icons.items() if path in positions},
            'shieldAtlas': build_shields(index, tool, destination, assets),
        })
        catalog['coverage']['renderedAssets'] = len(positions)
        catalog['coverage']['unrenderedAssets'] = sorted(set(paths) - positions.keys())
        if fingerprint != index_fingerprint(index):
            raise RuntimeError('The game installation changed while building icons')
        (work / sheet).write_bytes(atlas)
        (work / 'catalog.json').write_text(json.dumps(catalog, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
        if not (destination / sheet).exists():
            (work / sheet).replace(destination / sheet)
        (work / 'catalog.json').replace(destination / 'catalog.json')
    return catalog['coverage']


def main(argv=None):
    from PySide6.QtGui import QGuiApplication

    parser = ArgumentParser(description=__doc__)
    parser.add_argument('citadel', type=Path)
    parser.add_argument('tool', type=Path)
    parser.add_argument('--output', type=Path, default=icon_root())
    args = parser.parse_args(argv)
    os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
    app = QGuiApplication.instance() or QGuiApplication([])
    coverage = build(args.citadel, args.tool, args.output)
    print(json.dumps(coverage, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
