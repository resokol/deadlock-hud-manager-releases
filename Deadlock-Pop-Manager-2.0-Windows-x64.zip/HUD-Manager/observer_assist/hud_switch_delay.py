"""Time-shift spectator selection changes while keeping the match timeline live."""

from collections import deque
from dataclasses import dataclass
from time import monotonic


MAX_SWITCH_DELAY_MS = 30_000


@dataclass
class _Switch:
    identity: tuple
    ready_at: float
    fields: dict


class SpectatorSwitchDelay:
    def __init__(self):
        self._match = None
        self._delay_ms = 0
        self._active = None
        self._pending = deque()

    def update(self, telemetry, match, delay_ms, *, now=None):
        now = monotonic() if now is None else now
        if match != self._match:
            self._match = match
            self._active = None
            self._pending.clear()
        if delay_ms != self._delay_ms:
            self._delay_ms = delay_ms
            self._pending.clear()

        selected = (telemetry or {}).get('selected')
        if not selected or not selected.get('player'):
            self._active = None
            self._pending.clear()
            return {}

        fields = {'selected': selected}
        if 'selection' in telemetry:
            fields['selection'] = telemetry['selection']
        identity = (selected['player'], fields.get('selection'))
        latest = self._pending[-1] if self._pending else self._active
        if latest and latest.identity == identity:
            latest.fields = fields
        else:
            self._pending.append(_Switch(identity, now + delay_ms / 1000, fields))

        while self._pending and self._pending[0].ready_at <= now:
            self._active = self._pending.popleft()
        return self._active.fields if self._active else {}


def with_spectator_fields(telemetry, fields):
    if telemetry is None:
        return None
    delayed = dict(telemetry)
    delayed.pop('selection', None)
    delayed['selected'] = {}
    delayed.update(fields)
    return delayed
