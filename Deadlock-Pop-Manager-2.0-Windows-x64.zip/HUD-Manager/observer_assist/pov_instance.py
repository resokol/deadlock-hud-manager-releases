"""Let a camera operator open the current POV window from either launcher."""
from hashlib import sha256
from pathlib import Path
import sys

from PySide6.QtCore import QIODevice, QLockFile, QObject, QProcess, QStandardPaths, Signal
from PySide6.QtNetwork import QLocalServer, QLocalSocket


def start_pov_manager():
    root = Path(__file__).resolve().parent.parent
    if getattr(sys, 'frozen', False):
        # The installed HUD build and the portable camera distribution have separate launchers.
        camera_exe = Path(sys.executable).with_name('DeadlockPOVManager.exe')
        if not camera_exe.is_file():
            return False
        executable, args = camera_exe, []
    else:
        executable, args = Path(sys.executable), ['-m', 'observer_assist.pov_manager']
    started, _pid = QProcess.startDetached(str(executable), args, str(root))
    return started


class PovInstance(QObject):
    activate = Signal()

    def __init__(self, folder=None):
        super().__init__()
        if folder is None:
            base = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.GenericDataLocation)
            folder = Path(base) / 'DeadlockPOVManager'
        folder.mkdir(parents=True, exist_ok=True)
        self._lock = QLockFile(str(folder / 'operator.lock'))
        self._lock.setStaleLockTime(0)
        key = sha256(str(folder.resolve()).encode()).hexdigest()[:24]
        self._name = 'DeadlockPOVManager-' + key
        self._server = QLocalServer(self)
        self._server.setSocketOptions(QLocalServer.SocketOption.UserAccessOption)
        self._server.newConnection.connect(self._focus)

    def acquire(self):
        if self._lock.tryLock(0):
            QLocalServer.removeServer(self._name)
            if not self._server.listen(self._name):
                self._lock.unlock()
                raise OSError('Не удалось открыть локальный канал окна POV Manager.')
            return True
        if self._lock.error() != QLockFile.LockError.LockFailedError:
            raise OSError('Не удалось открыть настройки запуска POV Manager.')
        client = QLocalSocket()
        client.connectToServer(self._name, QIODevice.OpenModeFlag.WriteOnly)
        client.waitForConnected(400)
        client.disconnectFromServer()
        return False

    def _focus(self):
        while self._server.hasPendingConnections():
            self._server.nextPendingConnection().deleteLater()
        self.activate.emit()

    def close(self):
        self._server.close()
        self._lock.unlock()
