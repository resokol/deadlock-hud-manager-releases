"""SQLite-backed device activation and a loopback HTTP service for a TLS proxy."""

import argparse
from contextlib import closing, contextmanager
from hashlib import sha256
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import secrets
import sqlite3
from threading import BoundedSemaphore
from time import time

from .activation import (
    CHALLENGE_PATTERN, ID_PATTERN, LEASE, LEASE_SECONDS, TOKEN_PATTERN, ActivationRejected,
    fingerprint, verify_proof,
)
from .release_admin import IssuedLicense, admin_ids, license_recipient, read_key, start_telegram
from .release_security import MAX_LICENSE_DAYS, signed_record


CODE_VALIDITY = 7 * 86400
CHALLENGE_SECONDS = 60


def _code_hash(code):
    if not isinstance(code, str) or not TOKEN_PATTERN.fullmatch(code):
        raise ActivationRejected('Некорректный код активации.')
    return sha256(code.encode('ascii')).hexdigest()


def _license_id(value):
    if not isinstance(value, str) or not ID_PATTERN.fullmatch(value):
        raise ActivationRejected('Некорректный ID лицензии.')
    return value


class ActivationStore:
    def __init__(self, path, private_key, *, clock=time):
        self.path, self.private_key, self.clock = Path(path), private_key, clock
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with closing(self._connect()) as db:
            db.execute('PRAGMA journal_mode=WAL')
            db.executescript("""
                CREATE TABLE IF NOT EXISTS license (
                    id TEXT PRIMARY KEY, code_hash TEXT NOT NULL UNIQUE, days INTEGER NOT NULL,
                    usable_until INTEGER NOT NULL, device TEXT, expires INTEGER, revoked INTEGER NOT NULL DEFAULT 0
                );
                CREATE TABLE IF NOT EXISTS challenge (
                    nonce TEXT PRIMARY KEY, license_id TEXT NOT NULL, until INTEGER NOT NULL
                );
                CREATE INDEX IF NOT EXISTS challenge_until ON challenge(until);
                CREATE INDEX IF NOT EXISTS challenge_license ON challenge(license_id);
            """)
        with self._write() as db:
            fields = {row['name'] for row in db.execute('PRAGMA table_info(license)')}
            for name, kind in (('recipient', "TEXT NOT NULL DEFAULT ''"), ('detached_device', 'TEXT'),
                               ('detach_nonce', 'TEXT')):
                if name not in fields:
                    db.execute(f'ALTER TABLE license ADD COLUMN {name} {kind}')

    def _connect(self):
        db = sqlite3.connect(self.path, timeout=5)
        db.row_factory = sqlite3.Row
        return db

    @contextmanager
    def _write(self):
        with closing(self._connect()) as db, db:
            db.execute('BEGIN IMMEDIATE')
            yield db

    def issue(self, days):
        return self.issue_details(days).code

    def issue_details(self, days, recipient=''):
        if type(days) is not int or not 1 <= days <= MAX_LICENSE_DAYS:
            raise ValueError(f'Укажите количество дней от 1 до {MAX_LICENSE_DAYS}.')
        recipient = license_recipient(recipient)
        code = 'dhma1_' + secrets.token_urlsafe(24)
        identifier = secrets.token_hex(16)
        usable_until = int(self.clock()) + CODE_VALIDITY
        with self._write() as db:
            db.execute('INSERT INTO license (id, code_hash, days, usable_until, recipient) VALUES (?, ?, ?, ?, ?)',
                       (identifier, _code_hash(code), days, usable_until, recipient))
        return IssuedLicense(code, identifier, days, recipient, usable_until)

    def revoke(self, value):
        with self._write() as db:
            if isinstance(value, str) and ID_PATTERN.fullmatch(value):
                result = db.execute('UPDATE license SET revoked=1 WHERE id=?', (value,))
            else:
                result = db.execute('UPDATE license SET revoked=1 WHERE code_hash=?', (_code_hash(value),))
            return bool(result.rowcount)

    def redeem(self, code, device):
        fingerprint(device)
        now = int(self.clock())
        with self._write() as db:
            row = db.execute('SELECT * FROM license WHERE code_hash=?', (_code_hash(code),)).fetchone()
            if not row or row['revoked']:
                raise ActivationRejected('Код недействителен или отозван.')
            expires = row['expires']
            if row['device']:
                if row['device'] != device:
                    raise ActivationRejected('Код уже активирован на другом ПК.')
            else:
                if expires is None:
                    if row['usable_until'] <= now:
                        raise ActivationRejected('Срок первой активации истёк.')
                    expires = now + row['days'] * 86400
                elif expires <= now:
                    raise ActivationRejected('Срок лицензии истёк.')
                db.execute('UPDATE license SET device=?, expires=? WHERE id=?', (device, expires, row['id']))
            return self._lease(row['id'], device, expires, now)

    def challenge(self, license_id, device):
        fingerprint(device)
        now = int(self.clock())
        with self._write() as db:
            self._licensed(db, _license_id(license_id), now, device)
            return self._issue_challenge(db, license_id, now)

    def _issue_challenge(self, db, license_id, now):
        nonce = secrets.token_urlsafe(32)
        db.execute('DELETE FROM challenge WHERE until<=?', (now,))
        count, = db.execute('SELECT COUNT(*) FROM challenge WHERE license_id=?', (license_id,)).fetchone()
        if count >= 10:
            db.execute('DELETE FROM challenge WHERE nonce = (SELECT nonce FROM challenge '
                       'WHERE license_id=? ORDER BY until LIMIT 1)', (license_id,))
        db.execute('INSERT INTO challenge VALUES (?, ?, ?)', (nonce, license_id, now + CHALLENGE_SECONDS))
        return nonce

    @staticmethod
    def _check_proof_input(nonce, proof):
        if not isinstance(nonce, str) or not CHALLENGE_PATTERN.fullmatch(nonce) or not isinstance(proof, str) or len(proof) > 100:
            raise ActivationRejected('Некорректное подтверждение установки.')

    @staticmethod
    def _open_challenge(db, license_id, nonce, now):
        challenge = db.execute('SELECT until FROM challenge WHERE nonce=? AND license_id=?',
                               (nonce, license_id)).fetchone()
        if not challenge or challenge['until'] <= now:
            raise ActivationRejected('Запрос на подтверждение истёк.')

    def renew(self, license_id, nonce, proof):
        _license_id(license_id)
        self._check_proof_input(nonce, proof)
        now = int(self.clock())
        with self._write() as db:
            row = self._licensed(db, license_id, now)
            self._open_challenge(db, license_id, nonce, now)
            verify_proof(row['device'], license_id, nonce, proof)
            db.execute('DELETE FROM challenge WHERE nonce=?', (nonce,))
            return self._lease(row['id'], row['device'], row['expires'], now)

    def detach_challenge(self, license_id, device):
        fingerprint(device)
        now = int(self.clock())
        with self._write() as db:
            row = self._active_license(db, _license_id(license_id), now)
            if row['device'] == device:
                return self._issue_challenge(db, license_id, now)
            if row['detached_device'] == device:
                return row['detach_nonce']
            raise ActivationRejected('Лицензия прикреплена к другому ПК.')

    def detach(self, license_id, nonce, proof):
        _license_id(license_id)
        self._check_proof_input(nonce, proof)
        now = int(self.clock())
        with self._write() as db:
            row = self._active_license(db, license_id, now)
            # A lost response may be retried after the next PC has activated the same license.
            if nonce == row['detach_nonce']:
                verify_proof(row['detached_device'], license_id, nonce, proof, action='detach')
                return True
            if not row['device']:
                raise ActivationRejected('Лицензия уже отвязана.')
            self._open_challenge(db, license_id, nonce, now)
            verify_proof(row['device'], license_id, nonce, proof, action='detach')
            db.execute('UPDATE license SET detached_device=device, detach_nonce=?, device=NULL WHERE id=?',
                       (nonce, license_id))
            db.execute('DELETE FROM challenge WHERE license_id=?', (license_id,))
            return True

    @staticmethod
    def _active_license(db, license_id, now):
        row = db.execute('SELECT * FROM license WHERE id=?', (license_id,)).fetchone()
        if not row or row['revoked'] or row['expires'] is None or row['expires'] <= now:
            raise ActivationRejected('Лицензия истекла, отозвана или недействительна.')
        return row

    def _licensed(self, db, license_id, now, device=None):
        row = self._active_license(db, license_id, now)
        if not row['device']:
            raise ActivationRejected('Лицензия отвязана от этого ПК.')
        if device is not None and row['device'] != device:
            raise ActivationRejected('Лицензия прикреплена к другому ПК.')
        return row

    def _lease(self, license_id, device, expires, now):
        if now >= expires:
            raise ActivationRejected('Срок лицензии истёк.')
        return signed_record(LEASE, {
            'license': license_id, 'device': fingerprint(device), 'issued': now,
            'until': min(now + LEASE_SECONDS, expires), 'expires': expires,
        }, self.private_key)


class ActivationHttp(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, store, port):
        self.store = store
        self.slots = BoundedSemaphore(32)
        super().__init__(('127.0.0.1', port), _Handler)

    def process_request(self, request, address):
        if not self.slots.acquire(blocking=False):
            try:
                request.sendall(b'HTTP/1.0 503 Service Unavailable\r\nContent-Length: 0\r\n\r\n')
            except OSError:
                pass
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, address)
        except BaseException:
            self.slots.release()
            raise

    def process_request_thread(self, request, address):
        try:
            super().process_request_thread(request, address)
        finally:
            self.slots.release()


class _Handler(BaseHTTPRequestHandler):
    def setup(self):
        self.request.settimeout(4)
        super().setup()

    def log_message(self, *args):
        pass

    def do_GET(self):
        if self.path == '/health':
            self._json(200, {'ready': True})
        else:
            self._json(404, {'error': 'Неизвестный метод.'})

    def do_POST(self):
        store = self.server.store
        operations = {
            '/v1/redeem': ('lease', store.redeem, ('code', 'device')),
            '/v1/challenge': ('nonce', store.challenge, ('license', 'device')),
            '/v1/renew': ('lease', store.renew, ('license', 'nonce', 'proof')),
            '/v1/detach-challenge': ('nonce', store.detach_challenge, ('license', 'device')),
            '/v1/detach': ('detached', store.detach, ('license', 'nonce', 'proof')),
        }
        operation = operations.get(self.path)
        if operation is None:
            self._json(404, {'error': 'Неизвестный метод.'})
            return
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if self.headers.get_content_type() != 'application/json' or not 1 <= size <= 4096:
                raise ValueError('Некорректный запрос.')
            body = json.loads(self.rfile.read(size))
            field, call, keys = operation
            if not isinstance(body, dict) or tuple(sorted(body)) != tuple(sorted(keys)):
                raise ValueError('Некорректный запрос.')
            response = {field: call(*(body[key] for key in keys))}
        except ActivationRejected as exc:
            self._json(403, {'error': str(exc)})
        except (KeyError, TypeError, ValueError):
            self._json(400, {'error': 'Некорректный запрос или подтверждение установки.'})
        except (OSError, sqlite3.Error):
            self._json(503, {'error': 'Сервис временно недоступен.'})
        else:
            self._json(200, response)

    def _json(self, status, data):
        raw = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(raw)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        try:
            self.wfile.write(raw)
        except OSError:
            pass


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db', type=Path, required=True)
    parser.add_argument('--key', type=Path, required=True)
    commands = parser.add_subparsers(dest='command', required=True)
    serve = commands.add_parser('serve')
    serve.add_argument('--port', type=int, default=53891)
    issue = commands.add_parser('issue')
    issue.add_argument('days', type=int)
    revoke = commands.add_parser('revoke')
    revoke.add_argument('value', metavar='CODE_OR_ID')
    bot = commands.add_parser('bot')
    bot.add_argument('--admins', default='')
    args = parser.parse_args()
    try:
        store = ActivationStore(args.db, read_key(args.key))
        if args.command == 'serve':
            with ActivationHttp(store, args.port) as service:
                print(f'Activation engine on 127.0.0.1:{service.server_port}', flush=True)
                service.serve_forever(poll_interval=0.25)
        elif args.command == 'issue':
            print(store.issue(args.days))
        elif args.command == 'revoke':
            print('Лицензия отозвана.' if store.revoke(args.value) else 'Лицензия не найдена.')
        else:
            start_telegram(admin_ids(args.admins) if args.admins else frozenset(), store.issue_details, store.revoke)
    except (OSError, ValueError, RuntimeError, sqlite3.Error) as exc:
        parser.exit(1, str(exc) + '\n')
    except KeyboardInterrupt:
        return 0
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
