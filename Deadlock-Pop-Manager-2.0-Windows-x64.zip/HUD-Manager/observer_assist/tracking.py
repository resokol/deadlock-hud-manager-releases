from dataclasses import dataclass, replace
from math import hypot


@dataclass
class Track:
    id: int
    team: int
    x: float
    y: float
    vx: float = 0
    vy: float = 0
    confidence: float = 1
    age: float = 0
    seen: float = 0


class Tracker:
    def __init__(self):
        self._next = 1
        self.reset()

    def reset(self):
        self._tracks = {}
        self._last_time = None

    def update(self, detections, now):
        if self._last_time is not None and not 0 < now-self._last_time <= 1:
            self.reset()
        self._last_time = now
        self._tracks = {i:t for i,t in self._tracks.items() if now-t.seen <= .4}
        # Suppress detector duplicates before association.
        ds = []
        for d in sorted(detections, key=lambda d: -d.confidence):
            if not any(d.team == o.team and hypot(d.x-o.x, d.y-o.y) < .015 for o in ds):
                ds.append(d)
        candidates = {}
        for n,d in enumerate(ds):
            candidates[n] = [t for t in self._tracks.values() if t.team == d.team
                             and hypot(t.x-d.x,t.y-d.y) <= max(.03,min(.18,(now-t.seen)*.8))]
        used = set()
        visible = []
        for n,d in enumerate(ds):
            matches = candidates[n]
            # Ambiguous merges/crossings yield no claimed identity or extra hero.
            if len(matches) > 1 or (matches and sum(matches[0] in ms for ms in candidates.values()) > 1):
                continue
            old = matches[0] if matches else None
            if old and old.id not in used:
                dt = now-old.seen
                tr = replace(old, x=d.x, y=d.y, vx=(d.x-old.x)/dt, vy=(d.y-old.y)/dt,
                             age=old.age+dt, seen=now, confidence=d.confidence)
            elif not old:
                tr = Track(self._next, d.team, d.x,d.y,confidence=d.confidence,seen=now)
                self._next += 1
            else:
                continue
            used.add(tr.id)
            self._tracks[tr.id] = tr
            visible.append(tr)
        return visible
