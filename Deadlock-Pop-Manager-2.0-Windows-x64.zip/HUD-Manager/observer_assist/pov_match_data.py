"""Read-only match data shared by the observer HUD and the camera director."""

from dataclasses import dataclass

from .broadcast_tables import observed_hud_slot, players_by_portrait


POV_MATCH_ROUTE = '/api/v1/pov/match'


@dataclass(frozen=True)
class RemoteMatch:
    match_id: str
    names: tuple[str, ...]
    observed: int | None
    roster: dict | None

    @property
    def source(self):
        return f'Panorama по сети · портреты слева направо · матч {self.match_id}'


def _number(value, maximum_digits):
    if type(value) not in (int, str):
        return None
    text = str(value)
    if text.isascii() and text.isdecimal() and len(text) <= maximum_digits and int(text) > 0:
        return str(int(text))
    return None


def _ordered_names(slots):
    if not isinstance(slots, dict) or len(slots) != 12:
        return ()
    values = [slots.get(str(i)) for i in range(1, 13)]
    if not all(isinstance(name, str) and name.strip() and len(name) <= 256 and name.isprintable()
               for name in values):
        return ()
    names = tuple(name.strip() for name in values)
    return names if len({name.casefold() for name in names}) == 12 else ()


def _roster(match, teams, names, account_field):
    """Join only complete, unique account identities for exactly these 12 nicknames."""
    if not isinstance(teams, list) or len(teams) != 2:
        return None
    found = {}
    accounts = set()
    sides = set()
    for team in teams:
        if not isinstance(team, dict) or type(team.get('side')) is not int:
            return None
        side, players = team['side'], team.get('players')
        if side not in (2, 3) or side in sides or not isinstance(players, list) or len(players) != 6:
            return None
        sides.add(side)
        for player in players:
            if not isinstance(player, dict) or not isinstance(player.get('name'), str):
                return None
            name = player['name'].strip().casefold()
            account = _number(player.get(account_field), 10)
            if not account or int(account) > 0xffffffff or account in accounts or name in found:
                return None
            accounts.add(account)
            item = {'accountId': account}
            if isinstance(player.get('hero'), str) and len(player['hero']) <= 96:
                item['hero'] = player['hero']
            if type(player.get('heroId')) is int and player['heroId'] > 0:
                item['heroId'] = player['heroId']
            found[name] = side, item
    if found.keys() != {name.casefold() for name in names}:
        return None
    groups = {2: [], 3: []}
    for name in names:
        side, row = found[name.casefold()]
        groups[side].append({**row, 'name': name})
    return {'matchId': match, 'teams': [{'side': side, 'players': rows} for side, rows in groups.items()]}


def make_pov_snapshot(telemetry, match_id, source_roster):
    match = _number(match_id, 20)
    teams = (telemetry or {}).get('teams') or []
    if (not match or not isinstance(teams, list) or len(teams) != 2
            or not all(isinstance(t, dict) and type(t.get('side')) is int and isinstance(t.get('players'), list)
                       and all(isinstance(p, dict) and isinstance(p.get('name'), str) for p in t['players'])
                       for t in teams) or {t['side'] for t in teams} != {2, 3}):
        return {'version': 1, 'status': 'waiting'}
    slots = players_by_portrait(teams)
    names = _ordered_names(slots)
    if not names:
        return {'version': 1, 'status': 'waiting'}
    roster = _roster(match, teams, names, '_accountId')
    if not roster and source_roster and _number(source_roster.get('matchId'), 20) == match:
        roster = _roster(match, source_roster.get('teams'), names, 'accountId')
    return {'version': 1, 'status': 'live', 'panorama_match_id': match, 'panorama_slots': slots,
            'panorama_observed_slot': observed_hud_slot(slots, telemetry.get('selected')),
            'panorama_roster': roster}


def read_pov_snapshot(data, *, legacy=False):
    if (not isinstance(data, dict) or data.get('status') != 'live'
            or type(data.get('version')) is not int or data['version'] != 1):
        return None
    match = _number(data.get('panorama_match_id'), 20)
    names = _ordered_names(data.get('panorama_slots'))
    if not match or not names or (legacy and data.get('matchId') and _number(data['matchId'], 20) != match):
        return None
    observed = data.get('panorama_observed_slot')
    if observed is not None and (type(observed) is not int or not 1 <= observed <= 12):
        return None
    roster = None
    if not legacy and data.get('panorama_roster') is not None:
        supplied = data['panorama_roster']
        if not isinstance(supplied, dict) or _number(supplied.get('matchId'), 20) != match:
            return None
        roster = _roster(match, supplied.get('teams'), names, 'accountId')
        if not roster:
            return None
    return RemoteMatch(match, names, observed, roster)
