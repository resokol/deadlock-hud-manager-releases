"""SourceTV connection and decoded roster in the manager."""

import json
from pathlib import Path
import re
from shutil import which
from time import monotonic
from urllib.parse import urlsplit

from PySide6.QtCore import QProcess, QTimer, Signal
from PySide6.QtWidgets import (
    QAbstractItemView, QHBoxLayout, QLabel, QLineEdit, QPushButton, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QWidget,
)


from .broadcast_tables import players_by_match_position


SOURCE_TV = Path(__file__).resolve().parent / 'source_tv'


def _display(value):
    return '—' if value is None else str(value)


def node_executable():
    bundled = SOURCE_TV / 'node.exe'
    return str(bundled) if bundled.is_file() else which('node')


class SourceTvPanel(QWidget):
    connection_requested = Signal(bool)
    roster_changed = Signal()
    target_changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.roster = None
        self._last_snapshot = None
        self._stopping = False
        self._terminal_record = None
        self._pending_source = None
        self._requested_source = None
        self._retry_seconds = 2
        self.retry_timer = QTimer(self, singleShot=True)
        self.retry_timer.timeout.connect(self._retry)
        self.watchdog = QTimer(self, singleShot=True, interval=60000)
        self.watchdog.timeout.connect(self._stalled)
        self._match_id = None
        self.process = QProcess(self)
        self.process.readyReadStandardOutput.connect(self._read_output)
        self.process.readyReadStandardError.connect(self.process.readAllStandardError)
        self.process.finished.connect(self._finished)
        self.process.errorOccurred.connect(self._process_error)
        self.timer = QTimer(self, interval=1000)
        self.timer.timeout.connect(self._update_age)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.connection = QWidget()
        controls = QHBoxLayout(self.connection)
        controls.setContentsMargins(0, 0, 0, 0)
        self.url = QLineEdit(placeholderText='ID матча или URL SourceTV')
        self.url.setAccessibleName('ID матча или URL SourceTV')
        self.connect_button = QPushButton('Подключить')
        self.connect_button.clicked.connect(self._connect_or_switch)
        self.url.returnPressed.connect(self._connect_or_switch)
        self.stop_button = QPushButton('Отключить')
        self.stop_button.setEnabled(False)
        self.stop_button.clicked.connect(self.stop)
        controls.addWidget(self.url, 1)
        controls.addWidget(self.connect_button)
        controls.addWidget(self.stop_button)
        layout.addWidget(self.connection)
        self.status = QLabel('Введите ID текущего матча или адрес трансляции.')
        self.status.setWordWrap(True)
        self.source_delay = QLabel()
        self.age = QLabel()
        layout.addWidget(self.status)
        layout.addWidget(self.source_delay)
        layout.addWidget(self.age)

        self.players = QTableWidget(0, 4)
        self.players.setHorizontalHeaderLabels(['Команда', 'Игрок', 'K / D / A', 'Стоимость сборки'])
        self.players.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.players.verticalHeader().hide()
        self.players.horizontalHeader().setStretchLastSection(True)
        self.players.setColumnWidth(0, 75)
        self.players.setColumnWidth(1, 160)
        self.players.setColumnWidth(3, 128)
        layout.addWidget(self.players)

    @property
    def requested_match_id(self):
        value = self._requested_source or ''
        return value if value.isascii() and value.isdecimal() else None

    @property
    def public_roster(self):
        """Preserve the existing SourceTV fallback schema on the public statistics endpoint."""
        if self.roster is None:
            return None
        return {**self.roster, 'teams': [
            {**team, 'players': [{k: v for k, v in player.items() if k not in ('accountId', 'heroId')}
                                 for player in team['players']]}
            for team in self.roster['teams']
        ]}

    def _connect_or_switch(self):
        self.connection_requested.emit(True)
        source = self.url.text().strip()
        try:
            url = urlsplit(source)
            valid = bool(re.fullmatch(r'[0-9]{1,20}', source) or (url.scheme in ('http', 'https') and url.hostname))
        except ValueError:
            valid = False
        if not valid:
            self.status.setText('Введите числовой ID матча или HTTP(S) URL трансляции.')
            return
        self.retry_timer.stop()
        self.watchdog.stop()
        self._requested_source = source
        self.target_changed.emit()
        self._retry_seconds = 2
        if self.process.state() != QProcess.ProcessState.NotRunning:
            self._pending_source = source
            self._stopping = True
            self._clear_players()
            self.source_delay.clear()
            self.status.setText('Переключаю источник SourceTV…')
            self.process.kill()
            return
        self._start(source)

    def _start(self, source):
        node = node_executable()
        if not node:
            self.status.setText('Для модуля SourceTV нужен Node.js 22 или новее.')
            return
        if not (SOURCE_TV / 'node_modules' / '@deademx' / 'deadlock').is_dir():
            self.status.setText('Установите парсер по инструкции в README и повторите подключение.')
            return
        self._stopping = False
        self._terminal_record = None
        self._clear_players()
        self.source_delay.clear()
        self._match_id = source if source.isascii() and source.isdecimal() else None
        if self._match_id:
            self.status.setText(f'Ищу трансляцию матча {self._match_id}…')
        else:
            self.status.setText('Подключаюсь к SourceTV…')
        self.connect_button.setText('Переключить')
        self.stop_button.setEnabled(True)
        self.watchdog.start()
        self.process.start(node, [str(SOURCE_TV / 'reader.mjs'), source])

    def _retry(self):
        if self._requested_source and not self._stopping and self.process.state() == QProcess.ProcessState.NotRunning:
            self._start(self._requested_source)

    def _stalled(self):
        if self._requested_source and self.process.state() != QProcess.ProcessState.NotRunning:
            self._terminal_record = 'error'
            self._clear_players()
            self.status.setText('SourceTV не передаёт состав.')
            self.process.kill()

    def _read_output(self):
        while self.process.canReadLine():
            line = bytes(self.process.readLine())
            if self._stopping:
                continue
            try:
                record = json.loads(line)
            except ValueError:
                continue
            self.consume(record)

    def consume(self, record):
        kind = record.get('type')
        if kind == 'sync':
            segment_lag = record.get('segmentLagSeconds')
            seconds = record.get('delaySeconds') if segment_lag is None else segment_lag
            label = 'Задержка по данным SourceTV' if segment_lag is None else 'Отставание от последнего тика SourceTV'
            delay = '—' if seconds is None else f'{seconds:.1f} с'.replace('.', ',')
            self.source_delay.setText(f'{label} · {delay}')
            if self._last_snapshot is None:
                self.status.setText('Трансляция найдена, ждём данные игроков.')
        elif kind == 'snapshot':
            stream_match = record.get('matchId')
            if self._match_id and stream_match and str(stream_match) != self._match_id:
                self._terminal_record = 'error'
                self._clear_players()
                self.status.setText('ID матча SourceTV отличается от запрошенного.')
                self.process.kill()
                return
            if self._requested_source:
                self.watchdog.start()
            self._retry_seconds = 2
            rows = record['players']
            teams = []
            for side in (2, 3):
                players = [{key: player.get(key) for key in ('name', 'kills', 'deaths', 'assists', 'lane', 'assignedLane', 'accountId', 'heroId')}
                           for player in rows if player.get('team') == side and player.get('name')]
                teams.append({'side': side, 'players': players})
            roster = {'teams': teams, 'matchId': record.get('matchId') or self._match_id}
            slots = players_by_match_position(roster)
            if slots:
                order = {name: pos for pos, name in slots.items()}
                rows = sorted(rows, key=lambda p: int(order.get(p.get('name'), 13)))
            self.players.setRowCount(len(rows))
            for index, player in enumerate(rows):
                kda = ' / '.join(_display(player.get(key)) for key in ('kills', 'deaths', 'assists'))
                values = (player.get('team'), player.get('name') or None, kda, player.get('netWorth'))
                for column, value in enumerate(values):
                    self.players.setItem(index, column, QTableWidgetItem(_display(value)))
            if roster != self.roster:
                self.roster = roster
                self.roster_changed.emit()
            self._last_snapshot = monotonic()
            match = f'Матч {self._match_id} · ' if self._match_id else ''
            self.status.setText(f'{match}Получены данные игроков · {len(rows)}')
            self._update_age()
            if not self.timer.isActive():
                self.timer.start()
        elif kind in ('error', 'end'):
            self._terminal_record = kind
            self.watchdog.stop()
            self._clear_players()
            self.status.setText(record.get('message') or 'Поток SourceTV завершён.')

    def _update_age(self):
        if self._last_snapshot is None:
            return
        seconds = round(monotonic() - self._last_snapshot)
        self.age.setText(f'С последнего обновления · {seconds} с')
        if seconds >= 10:
            if self.roster is not None:
                self.roster = None
                self.roster_changed.emit()
            self.status.setText('Данные игроков не обновляются.')

    def _clear_players(self):
        self._last_snapshot = None
        self.players.setRowCount(0)
        if self.roster is not None:
            self.roster = None
            self.roster_changed.emit()
        self.timer.stop()
        self.age.clear()

    def stop(self):
        self.retry_timer.stop()
        self.watchdog.stop()
        self._requested_source = None
        self.target_changed.emit()
        self._reset_controls()
        self._stopping = True
        self._pending_source = None
        self._match_id = None
        self._clear_players()
        self.source_delay.clear()
        self.status.setText('SourceTV отключён.')
        if self.process.state() != QProcess.ProcessState.NotRunning:
            self.process.kill()

    def _reset_controls(self):
        self.connect_button.setText('Подключить')
        self.stop_button.setEnabled(False)

    def _finished(self, exit_code, exit_status):
        self._read_output()
        self.watchdog.stop()
        self._reset_controls()
        if self._pending_source is not None:
            source, self._pending_source = self._pending_source, None
            self._start(source)
            return
        if self._terminal_record == 'end':
            self._requested_source = None
        if self._stopping or self._terminal_record == 'end':
            return
        self._clear_players()
        if self._terminal_record != 'error':
            failed = exit_code or exit_status == QProcess.ExitStatus.CrashExit
            self.status.setText('Чтение SourceTV прервано.' if failed else 'Поток SourceTV закрыт.')
        if self._requested_source:
            delay = self._retry_seconds
            self._retry_seconds = min(60, 2 * delay)
            self.status.setText(f'{self.status.text()} Повтор через {delay} с.')
            self.connect_button.setText('Переключить')
            self.stop_button.setEnabled(True)
            self.retry_timer.start(delay * 1000)

    def _process_error(self, error):
        if error == QProcess.ProcessError.FailedToStart:
            self.watchdog.stop()
            self._requested_source = None
            self._pending_source = None
            self._reset_controls()
            self.status.setText('Не удалось запустить Node.js.')
