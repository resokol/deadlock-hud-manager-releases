"""Standalone production camera workspace. Match acquisition is optional before camera setup."""
from dataclasses import dataclass
from ipaddress import IPv4Address
import json
import sys
from pathlib import Path
from secrets import token_urlsafe

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFormLayout, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QMessageBox,
    QPushButton, QScrollArea, QSpinBox, QStackedWidget, QTabWidget, QVBoxLayout, QWidget,
    QHeaderView, QTableWidget, QTableWidgetItem,
)

from .broadcast_tables import players_by_match_position
from .camera_mapping import operator_camera_mapping
from .camera_panel import CameraPanel
from .camera_roster import CameraRoster
from .camera_routing import CameraRouting, endpoint_key
from .camera_vdo import VdoImport
from .camera_vdo_panel import HOST_KEY, PORT_KEY, VdoRoomPanel
from .camera_vdo_publish import VdoVmixPublisher, publish_room_cameras
from .camera_native_pairs_panel import NativePairBindings
from .camera_native_sync import NativePairSync
from .camera_native_monitor import NativeCameraMonitor
from .pop_prematch import NativePrematch
from .pop_match_mapping import MatchCameraBindings, camera_matches, player_keys
from .hud_pov import VmixPovPanel
from .live_stats_panel import lan_interfaces
from .match_stats import STATS_PORT, StatsLanServer, is_lan_address
from .pov_remote import PovRemote
from .source_tv_panel import SourceTvPanel
from .ui import STYLE
from .win32 import set_dpi_awareness


@dataclass(frozen=True)
class MatchLayout:
    room: str
    match: str
    endpoint: tuple
    preset: str
    pairs: tuple

    @property
    def guids(self):
        return {guid for p in self.pairs for guid in (p.original_guid, p.virtual_guid)}


class CompanionPanel(QWidget):
    """Publish completed Qt snapshots; deliver replay requests back to the GUI thread."""
    take_requested = Signal(int, str, str, str, str, int)

    def __init__(self, settings):
        super().__init__()
        self.settings = settings
        self.server = None
        self.payload = {}
        form = QFormLayout(self)
        self.share = QCheckBox('Доступ для Companion')
        self.network = QComboBox()
        for name, addr in lan_interfaces():
            self.network.addItem(f'{name} · {addr.ip}', str(addr))
        self.network.addItem('На этом ПК · 127.0.0.1', '127.0.0.1/8')
        selected = self.network.findData(settings.value('statsExportAddress', '', type=str))
        self.network.setCurrentIndex(max(0, selected))
        self.port = QSpinBox()
        self.port.setRange(1, 65535)
        self.port.setValue(settings.value('povCompanionPort', STATS_PORT + 1, type=int))
        self.port.setKeyboardTracking(False)
        self.copy = QPushButton('Копировать URL JSON для Companion')
        self.copy.clicked.connect(self._copy_json)
        self.slot = QSpinBox()
        self.slot.setRange(1, 12)
        post = QHBoxLayout()
        post.addWidget(self.slot)
        self.copy_post = QPushButton('Копировать URL POST для Replay')
        self.copy_post.clicked.connect(self._copy_post)
        post.addWidget(self.copy_post)
        self.status = QLabel()
        self.status.setWordWrap(True)
        form.addRow(self.share)
        form.addRow('Сетевой интерфейс', self.network)
        form.addRow('Порт', self.port)
        form.addRow(self.copy)
        form.addRow('Позиция кнопки', post)
        form.addRow(self.status)
        self.share.setChecked(settings.value('statsExportEnabled', False, type=bool))
        self.share.toggled.connect(self._configure)
        self.network.currentIndexChanged.connect(self._configure)
        self.port.valueChanged.connect(self._configure)
        self._configure()

    def _configure(self):
        self.stop()
        s = self.settings
        s.setValue('statsExportEnabled', self.share.isChecked())
        address = self.network.currentData()
        s.setValue('statsExportAddress', address)
        s.setValue('povCompanionPort', self.port.value())
        text = ''
        if self.share.isChecked():
            def token(key):
                value = s.value(key, '', type=str) or token_urlsafe(24)
                s.setValue(key, value)
                return value

            try:
                self.server = StatsLanServer(address, token('statsExportToken'), lambda: self.payload,
                                            port=self.port.value(), take=self._queue_take,
                                            control_token=token('povControlToken'))
                text = f'Доступно · {self.server.address}:{self.server.port}'
            except (ValueError, OSError) as exc:
                text = f'Подключение недоступно. {exc}'
        self.status.setText(text)
        for item in (self.copy, self.slot, self.copy_post):
            item.setEnabled(self.server is not None)

    def _queue_take(self, slot):
        row = self.payload.get('camera_slots', {}).get(str(slot), {})
        if row.get('replay_ready'):
            self.take_requested.emit(slot, row.get('account_id') or '', row['match_id'], row['name'],
                                     row['replay_guid'], row['replay_mix'])
            return True
        return False

    def _copy_json(self):
        if self.server:
            QApplication.clipboard().setText(self.server.url)

    def _copy_post(self):
        if self.server:
            QApplication.clipboard().setText(self.server.program_url(self.slot.value()))

    def stop(self):
        if self.server:
            self.server.close()
            self.server = None


class PovManager(QWidget):
    def __init__(self, settings):
        super().__init__()
        self.settings = settings
        self.setWindowTitle('Pop Manager 2.0')
        self.setStyleSheet(STYLE + '''
            QLabel#title { font-size: 17pt; color: #d8e6ea; }
            QLabel#workflowTitle { font-size: 19pt; font-weight: 600; color: #f2f7f8; }
            QLabel#roomHelp { color: #b7c7cc; }
            QTableWidget { background: #192229; alternate-background-color: #1f2a32;
                color: #e8eef2; gridline-color: #35424c; border: 1px solid #35424c;
                selection-background-color: #31544f; selection-color: white; }
            QHeaderView::section { background: #26323c; color: #dae5e9;
                border: 0; padding: 5px 7px; font-weight: 600; }
            QScrollArea { border: 0; }
            QPushButton[onProgram="true"] { border: 2px solid #91d6bf; background: #2e524a; }
        ''')
        self.setMinimumSize(600, 420)
        self.resize(1120, 760)
        layout = QVBoxLayout(self)
        heading = QLabel('Pop Manager 2.0')
        heading.setObjectName('title')
        header = QHBoxLayout()
        header.addWidget(heading)
        header.addStretch()
        self.tools_button = QPushButton('Инструменты')
        self.tools_button.setCheckable(True)
        header.addWidget(self.tools_button)
        layout.addLayout(header)
        self.workspaces = QStackedWidget()
        layout.addWidget(self.workspaces, 1)
        self.tabs = QTabWidget()
        self.main_tabs = QTabWidget()
        self._fixed = None
        self._fixed_meta = {}
        self._requested_meta = {}
        self._closing = False
        self._last_follow = None
        self._pending_follow = None
        self.match_cameras = MatchCameraBindings(settings)
        self._desired_sync = None
        self._native_owner = False
        self._authorized_sync = None
        self._monitor_key = None
        self._native_refreshing = False

        self.source_tv = SourceTvPanel(self)
        self.remote = PovRemote(self)
        self.camera_roster = CameraRoster(settings)
        self.camera_panels = {role: CameraPanel(role) for role in ('live', 'replay')}
        self.cameras = CameraRouting(settings, self.camera_roster, self.camera_panels, self)
        self.pov = VmixPovPanel(settings, suspended=self.cameras.managed)
        self.cameras.activated.connect(self.pov.suspend)
        self.vdo_panel = VdoRoomPanel(settings)
        self.vdo_panel.setParent(self)
        self.vdo_panel.hide()
        self.vdo_import = VdoImport(self.vdo_panel, self.cameras, self, managed=True)
        self.vdo_publisher = VdoVmixPublisher(self, settings=settings)
        self.vdo_panel.apply_vmix_requested.connect(self._publish)
        self.vdo_publisher.result.connect(self.vdo_panel.vmix_result)
        self.vdo_publisher.position_result.connect(self.vdo_panel.vmix_position_result)
        self.vdo_publisher.batch_completed.connect(self.vdo_panel.vmix_counts)
        self.vdo_publisher.batch_completed.connect(self._capture_preparation)
        self.vdo_publisher.finished.connect(self.vdo_panel.vmix_finished)
        self.vdo_import.freshness_changed.connect(self.vdo_panel.set_room_fresh)
        self.vdo_import.freshness_changed.connect(self._room_fresh)
        self.cameras.inputs_claimed.connect(self._claimed)
        self.camera_roster.bind_camera_mapping(self._account_map)
        self.companion = CompanionPanel(settings)
        self.companion.take_requested.connect(self._take)
        self.names, self.match_id, self.observed = (), '', None
        self._update_in_progress = False
        room, inputs, former_distribution = self.vdo_panel.enable_workflow()
        self.vdo_panel.use_native_inputs()
        # Keep the original controller alive for its receipt and evidence signals.
        former_distribution.setParent(self.vdo_panel)
        former_distribution.hide()
        self.native = NativePairSync(self, settings=settings)
        self.monitor = NativeCameraMonitor(self.vdo_publisher, self, settings=settings)
        self.native.pending_title = self.monitor.allows_pending_title
        self.bindings = NativePairBindings(settings, endpoint=self._endpoint, can_setup=self._can_setup)
        self.prematch = NativePrematch(self.vdo_panel, self.vdo_import, self.bindings, self.vdo_publisher,
                                      self, authorize=self._unclaimed_virtual, monitor=self.monitor)
        self.vdo_panel.apply_preparation.hide()
        for page, title in ((self._room_page(room, inputs), 'VDO Ninja'), (self._match_page(), 'Match'),
                            (self._output_page('live'), 'Live'), (self._output_page('replay'), 'Replay')):
            self.main_tabs.addTab(self._scroll(page), title)
        self.workspaces.addWidget(self.main_tabs)
        self.workspaces.addWidget(self.tabs)
        self.tools_button.toggled.connect(self._show_tools)
        self._add_tab(self._roster_tools(), 'Игроки')
        for role in ('live', 'replay'):
            self._add_tab(self.camera_panels[role], role.title())
        self._companion_index = self._add_tab(self.companion, 'Companion')
        self._add_tab(self.cameras.bank_widget, 'Пары и журнал')
        self._add_tab(self.pov, 'POV vMix')
        self.camera_panels['replay'].companion_requested.connect(self._show_companion)
        self.remote.changed.connect(self._read_source)
        self.remote.status.connect(self.remote_status.setText)
        self.source_tv.roster_changed.connect(self._read_source)
        self.source_tv.target_changed.connect(self._source_target)
        self.prematch.status.connect(self.prep_status.setText)
        self._last_log = {}
        self.prematch.status.connect(lambda text: self._log('VDO', text))
        self.monitor.status.connect(lambda text: self._log('Камеры', text))
        self.bindings.setup.finished.connect(lambda ok, text: self._log('Пул vMix', text))
        self.native.finished.connect(lambda ok, text: self._log('vMix', text))
        self.vdo_panel.poll_interval.valueChanged.connect(lambda seconds: self.monitor.set_interval_ms(seconds * 1000))
        self.monitor.set_interval_ms(self.vdo_panel.poll_interval.value() * 1000)
        self.prematch.changed.connect(self._sync_preview)
        self.bindings.pool_ready.connect(self.prematch.refresh)
        self.camera_roster.changed.connect(self._render_order)
        self.cameras.changed.connect(self._export)
        self.native.changed.connect(self._native_changed)
        self.native.finished.connect(self._sync_finished)
        self.bindings.changed.connect(self._sync_preview)
        self.vdo_panel.originals_changed.connect(self._sync_preview)
        self.vdo_panel.room_guests_changed.connect(self._export)
        self.monitor.status.connect(self.media_status.setText)
        self.vdo_publisher.finished.connect(self._sync_preview)
        self.pov.mappings_changed.connect(self._export)
        self.vdo_panel.positions.edited.connect(self._export)
        self.vdo_panel.position_media_changed.connect(self._export)
        self.mode.currentIndexChanged.connect(self._switch_source)
        self.mode.setCurrentIndex(max(0, self.mode.findData(settings.value('povMatchSource', 'remote', type=str))))
        self._restore_timer = QTimer(self, interval=2500, singleShot=True)
        self._restore_timer.timeout.connect(self._restore)
        self.recover_button.clicked.connect(self._recover)
        self.room_monitor.toggled.connect(self._monitor_toggled)
        self.vdo_panel.vmix_host.editingFinished.connect(self._endpoint_changed)
        self.vdo_panel.vmix_port.valueChanged.connect(self._endpoint_changed)
        self._restore()
        self._monitor_toggled()
        self._read_source()
        self.vdo_panel.start_requested.connect(self._remember_room)
        self.vdo_panel.stop_requested.connect(self._forget_room)
        self._room_resume = QTimer(self, singleShot=True)
        self._room_resume.timeout.connect(self._resume_room)
        if settings.value('popRoomRunning', False, type=bool):
            self._room_resume.start(0)

    def _resume_room(self):
        if not self._closing and not self.vdo_import.room and self.vdo_panel.url.text():
            self.vdo_panel.connect_button.click()

    def _remember_room(self):
        if self.vdo_import.room and self.vdo_import.bridge:
            self.settings.setValue('popRoomRunning', True)

    def _forget_room(self):
        self.settings.setValue('popRoomRunning', False)

    @staticmethod
    def _scroll(widget):
        area = QScrollArea()
        area.setWidgetResizable(True)
        area.setFrameShape(QScrollArea.Shape.NoFrame)
        area.setWidget(widget)
        return area

    def _add_tab(self, widget, name):
        return self.tabs.addTab(self._scroll(widget), name)

    def _room_page(self, room, inputs):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.addWidget(room)
        self.room_monitor = QCheckBox('Автоматически обновлять состояние камер в vMix')
        self.room_monitor.setChecked(self.settings.value('popCameraMonitor', True, type=bool))
        layout.addWidget(self.room_monitor)
        self.prep_status = QLabel()
        self.prep_status.setWordWrap(True)
        layout.addWidget(self.prep_status)
        self.media_status = QLabel()
        self.media_status.setWordWrap(True)
        layout.addWidget(self.media_status)
        self.room_bank = self._bank_table(['Вход', 'Участник VDO', 'Видео'])
        layout.addWidget(self.room_bank)
        button = QPushButton('Настройка пула vMix…')
        button.setCheckable(True)
        layout.addWidget(button, alignment=Qt.AlignmentFlag.AlignLeft)
        layout.addWidget(inputs)
        inputs.layout().addWidget(self.bindings)
        inputs.setVisible(False)
        button.toggled.connect(inputs.setVisible)
        self.reload_pages = QPushButton('Повторно загрузить страницы камер…')
        self.reload_pages.clicked.connect(self._reload_pages)
        inputs.layout().addWidget(self.reload_pages)
        self.new_pool = QPushButton('Начать подготовку нового состава')
        self.new_pool.clicked.connect(self._release_layout)
        inputs.layout().addWidget(self.new_pool)
        layout.addStretch()
        return page

    @staticmethod
    def _bank_table(columns):
        table = QTableWidget(12, len(columns))
        table.setHorizontalHeaderLabels(columns)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        table.verticalHeader().hide()
        table.setAlternatingRowColors(True)
        table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        table.setMinimumHeight(245)
        for i in range(12):
            for col in range(len(columns)):
                table.setItem(i, col, QTableWidgetItem())
        return table

    def _match_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.addWidget(self._source_page())
        layout.addWidget(self._sync_page())
        row = QHBoxLayout()
        self.mapping_button = QPushButton('Сопоставить игроков с камерами…')
        self.mapping_button.clicked.connect(self._edit_matches)
        row.addWidget(self.mapping_button)
        order = QPushButton('Сверить порядок игроков…')
        order.clicked.connect(self._edit_order)
        row.addWidget(order)
        self.recover_button = QPushButton('Восстановить раскладку до прерванной сортировки')
        row.addWidget(self.recover_button)
        layout.addLayout(row)
        self.recovery_details = QPushButton('Журнал восстановления…')
        self.recovery_details.clicked.connect(self._inspect_recovery)
        layout.addWidget(self.recovery_details, alignment=Qt.AlignmentFlag.AlignLeft)
        return page

    def _inspect_recovery(self):
        endpoint, preset = self._endpoint(), self._recovery_preset()
        if not preset or self.native.busy or not self.native.has_recovery(endpoint, preset):
            return
        dialog = QDialog(self)
        dialog.setWindowTitle('До прерванной сортировки')
        dialog.resize(700, 460)
        layout = QVBoxLayout(dialog)
        rows = self.native.recovery_rows(endpoint, preset)
        table = QTableWidget(len(rows), 3)
        table.setHorizontalHeaderLabels(['Вход', 'Название', 'GUID'])
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        for i,(n,guid,title) in enumerate(rows):
            for col, value in enumerate((str(n), title, guid)):
                table.setItem(i, col, QTableWidgetItem(value))
        layout.addWidget(table)
        close = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        close.rejected.connect(dialog.reject)
        repair = close.addButton('Подтвердить ручное восстановление…', QDialogButtonBox.ButtonRole.ActionRole)
        repair.clicked.connect(dialog.accept)
        layout.addWidget(close)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        answer = QMessageBox.question(self, 'Закрыть журнал',
            'Вы восстановили входы и геометрию по рабочему пресету vMix? Запись об этой прерванной сортировке будет удалена.',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
        if answer == QMessageBox.StandardButton.Yes and self.native.discard_recovery(endpoint, preset):
            self._log('vMix', 'Оператор подтвердил ручное восстановление пресета.')
            self._restore()
            self._suspend_preparation()
            self._sync_preview()

    def _edit_order(self):
        self.tools_button.setChecked(True)
        self.tabs.setCurrentIndex(0)

    def _edit_matches(self):
        def context():
            return (self._room_key(), self._endpoint(), self.match_id, self.names,
                    tuple(sorted(self.camera_roster.slots.items())),
                    tuple((row.guid,row.name) for row in self.vdo_panel.prepared_originals))
        draft = context()
        if self.match_cameras.edit(self.names, self.camera_roster.slots, self.vdo_panel.prepared_originals,
                                   self, current=lambda: draft == context()):
            self._sync_preview()

    def _show_tools(self, opened):
        self.workspaces.setCurrentIndex(1 if opened else 0)
        self.tools_button.setText('Вернуться к камерам' if opened else 'Инструменты')

    def _account_map(self):
        return operator_camera_mapping(self.camera_roster, self.cameras, self.vdo_import)

    def _show_companion(self):
        self.tools_button.setChecked(True)
        self.tabs.setCurrentIndex(self._companion_index)

    def _source_target(self):
        self._read_source()

    def _sync_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        self.preview = QTableWidget(12, 4)
        self.preview.setHorizontalHeaderLabels(['Позиция / клавиша', 'Игрок', 'Live → вход', 'Replay → вход'])
        self.preview.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.preview.verticalHeader().hide()
        self.preview.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        for row in range(12):
            for col in range(4):
                self.preview.setItem(row, col, QTableWidgetItem())
        layout.addWidget(self.preview)
        self.sync_hint = QLabel()
        self.sync_hint.setWordWrap(True)
        self.sync_hint.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.sync_hint)
        self.sync_button = QPushButton('Синхронизировать с матчем')
        self.sync_button.setObjectName('primary')
        self.sync_button.clicked.connect(self._synchronize)
        layout.addWidget(self.sync_button, alignment=Qt.AlignmentFlag.AlignLeft)
        self.sync_result = QLabel()
        self.sync_result.setWordWrap(True)
        self.sync_result.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.sync_result)
        return page

    def _source_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        self.mode = QComboBox()
        self.mode.addItem('По Match ID (SourceTV)', 'match')
        self.mode.addItem('Panorama по сети (HUD Manager)', 'remote')
        layout.addWidget(self.mode)
        self.sources = QStackedWidget()
        self.source_tv.players.hide()
        self.sources.addWidget(self.source_tv)
        network = QWidget()
        form = QFormLayout(network)
        self.remote_url = QLineEdit(self.settings.value('povHudUrl', '', type=str))
        self.remote_url.setPlaceholderText('Из HUD Manager · Статистика → Копировать URL JSON матча')
        self.remote_url.setEchoMode(QLineEdit.EchoMode.PasswordEchoOnEdit)
        form.addRow('URL JSON матча', self.remote_url)
        buttons = QHBoxLayout()
        connect = QPushButton('Подключить')
        connect.clicked.connect(self._connect_remote)
        self.remote_url.returnPressed.connect(self._connect_remote)
        stop = QPushButton('Отключить')
        stop.clicked.connect(self._stop_remote)
        buttons.addWidget(connect)
        buttons.addWidget(stop)
        form.addRow(buttons)
        self.remote_status = QLabel()
        self.remote_status.setWordWrap(True)
        form.addRow(self.remote_status)
        self.sources.addWidget(network)
        layout.addWidget(self.sources)
        self.order_status = QLabel()
        self.order_status.setWordWrap(True)
        self.order_status.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.order_status)
        layout.addStretch()
        return page

    def _output_page(self, role):
        live = role == 'live'
        tag = role.title()
        page = QWidget()
        layout = QVBoxLayout(page)
        controls = QHBoxLayout()
        enabled = QCheckBox(f'Управлять {tag} из Pop Manager')
        enabled.setChecked(self.settings.value(f'pop{tag}Enabled', True, type=bool))
        controls.addWidget(enabled)
        mix = QSpinBox()
        mix.setRange(1 if live else 2, 99)
        mix.setValue(self.settings.value('popLiveMix' if live else 'povVirtualReplayMix', 1 if live else 2, type=int))
        controls.addWidget(QLabel('Выход в vMix'))
        mix.setPrefix('Mix ')
        controls.addWidget(mix)
        controls.addStretch()
        layout.addLayout(controls)
        if live:
            self.live_enabled, self.live_mix = enabled, mix
            self.follow = QCheckBox('Следовать за обсервером')
            self.follow.setChecked(self.settings.value('popLiveFollow', False, type=bool))
            self.follow.toggled.connect(self._output_config)
            layout.addWidget(self.follow)
        else:
            self.replay_enabled, self.replay_mix = enabled, mix
            companion = QPushButton('Настройки Companion…')
            companion.clicked.connect(self._show_companion)
            controls.addWidget(companion)
        status = QLabel()
        status.setWordWrap(True)
        layout.addWidget(status)
        buttons = []
        grid = QGridLayout()
        for slot in range(1, 13):
            button = QPushButton()
            button.setMinimumHeight(58)
            button.setEnabled(False)
            button.clicked.connect(self._output_clicked)
            grid.addWidget(button, (slot-1)//4, (slot-1)%4)
            buttons.append(button)
        layout.addLayout(grid)
        if live:
            self.live_status, self.live_buttons = status, buttons
        else:
            self.external_status, self.replay_buttons = status, buttons
            self.virtual_status = QLabel()
            self.virtual_status.setWordWrap(True)
            layout.addWidget(self.virtual_status)
        enabled.toggled.connect(self._output_config)
        mix.valueChanged.connect(self._output_config)
        layout.addStretch()
        return page

    def _output_clicked(self):
        button = self.sender()
        if button in self.live_buttons:
            self._take_output(self.live_buttons.index(button)+1, 'live')
        elif button in self.replay_buttons:
            self._take_virtual(self.replay_buttons.index(button)+1)

    def _output_config(self):
        self.settings.setValue('popLiveEnabled', self.live_enabled.isChecked())
        self.settings.setValue('popReplayEnabled', self.replay_enabled.isChecked())
        self.settings.setValue('popLiveMix', self.live_mix.value())
        self.settings.setValue('povVirtualReplayMix', self.replay_mix.value())
        self.settings.setValue('popLiveFollow', self.follow.isChecked())
        self._last_follow = self._observed_player()
        self._pending_follow = None
        self._export()

    def _capture_preparation(self, successful, skipped, errors):
        if self.vdo_panel.submitted_mode != 'preparation':
            return
        receipt = self.vdo_publisher.last_receipt if not skipped and not errors else None
        captured = self.vdo_panel.accept_preparation_receipt(receipt) if receipt else False
        self.bindings.set_receipt(self.vdo_panel.prepared_catalog if captured else None)
        if captured:
            self._native_owner = True

    def _log(self, scope, text):
        if not self._closing and text and self._last_log.get(scope) != text and '://' not in text:
            self._last_log[scope] = text
            self.cameras.record(f'{scope} · {text}')

    def _endpoint(self):
        return self.vdo_panel.vmix_host.text().strip(), self.vdo_panel.vmix_port.value()

    def _room_key(self):
        return self.vdo_import.room.key if self.vdo_import.room else ''

    def _can_setup(self):
        return not (self._desired_sync or self._fixed or self.native.busy or self.vdo_publisher.busy
                    or self.cameras.conflicting_modules(self._endpoint(), set(self.bindings.inputs))
                    or (not self.pov.suspended and self.pov.endpoint == self._endpoint()
                        and (self.pov.rename or self.pov.player_pages)))

    def _signature(self, pairs):
        receipt = self.bindings.receipt
        if not receipt or not pairs or not self.match_id or not self._room_key() or receipt.endpoint != self._endpoint():
            return None
        return MatchLayout(self._room_key(), self.match_id, receipt.endpoint, receipt.preset, pairs)

    def _record(self, key):
        try:
            value = json.loads(self.settings.value(key, '{}', type=str))
        except ValueError:
            value = {}
        return value if isinstance(value, dict) else {}

    def _restore(self):
        if self._closing or self._desired_sync or self.native.busy:
            return
        meta = self._record('popLastMatchLayout')
        endpoint, preset = self._endpoint(), meta.get('preset')
        if not preset or list(endpoint) != meta.get('endpoint'):
            return
        saved = self.native.saved_layout(endpoint, preset)
        if saved:
            self._fixed = MatchLayout(meta.get('room', ''), saved.match_id, endpoint, preset, saved.pairs)
            self._native_owner = True
            self._fixed_meta = meta if saved.match_id == meta.get('match') else {}
            self._suspend_preparation()
            if not self.native.has_recovery(endpoint, preset):
                layout = self._fixed
                self.native.restore_confirmed(endpoint, preset, saved.match_id,
                    validate=lambda: layout == self._fixed and self._layout_allowed(layout))

    def _endpoint_changed(self):
        host, port = self._endpoint()
        try:
            ip = IPv4Address(host)
        except ValueError:
            ip = None
        if ip and (ip.is_loopback or is_lan_address(ip)):
            self.settings.setValue(HOST_KEY, host)
            self.settings.setValue(PORT_KEY, port)
        if self._fixed and self._fixed.endpoint != self._endpoint():
            self._fixed = None
            self._fixed_meta = {}
            self._drop_native()
            self._native_owner = False
        self._restore()
        self._suspend_preparation()

    def _reload_pages(self):
        endpoint = self._endpoint()
        guids = [p.original_guid for p in self._fixed.pairs] if self._fixed else [r.guid for r in self.vdo_panel.prepared_originals]
        if not guids or not self.room_monitor.isChecked() or self.native.busy:
            return
        answer = QMessageBox.question(self, 'Перезагрузить камеры',
                'Повторно открыть ссылки активных камер в браузерах vMix? Видео может прерваться на время подключения.',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
        if answer == QMessageBox.StandardButton.Yes:
            self.vdo_publisher.forget_pages(endpoint, guids)
            self.monitor.refresh()

    def _release_layout(self):
        if not self._fixed or self.native.busy:
            return
        result = QMessageBox.question(self, 'Новый состав',
            'Завершить подготовленный матч и разрешить назначение камер участникам комнаты?')
        if result != QMessageBox.StandardButton.Yes:
            return
        self._fixed = None
        self._fixed_meta = {}
        self.settings.remove('popLastMatchLayout')
        self._drop_native()
        self._native_owner = False
        self._suspend_preparation()
        self.prematch.refresh()
        self._sync_preview()

    def _recovery_preset(self):
        if self.bindings.receipt and self.bindings.receipt.endpoint == self._endpoint():
            return self.bindings.receipt.preset
        record = self._record('popSyncTarget')
        return record.get('preset', '') if record.get('endpoint') == list(self._endpoint()) else ''

    def _recover(self):
        endpoint, preset = self._endpoint(), self._recovery_preset()
        if not preset or self.native.busy:
            return
        self._native_owner = True
        self.prematch.set_suspended(True)
        guids = {guid for n, guid, _ in self.native.recovery_rows(endpoint, preset) if 1 <= n <= 24}
        self.native.recover(endpoint, preset, validate=lambda: endpoint == self._endpoint()
                            and self._unclaimed_virtual(endpoint, guids), authorize=self._unclaimed_virtual)

    def _monitor_toggled(self):
        enabled = self.room_monitor.isChecked()
        self.settings.setValue('popCameraMonitor', enabled)
        self.monitor.set_enabled(enabled)
        self._suspend_preparation()
        if enabled:
            self.monitor.refresh()
        else:
            self.media_status.setText('Мониторинг камер выключен.')
        self._export()

    def _suspend_preparation(self):
        outstanding = self._recovery_preset()
        self.prematch.set_suspended(bool(self._fixed or self._desired_sync or not self.room_monitor.isChecked()
                                    or (outstanding and self.native.has_recovery(self._endpoint(), outstanding))))

    def _layout_allowed(self, layout):
        return not self._closing and self._endpoint() == layout.endpoint and self._unclaimed_virtual(layout.endpoint, layout.guids)

    def _confirmed_order(self):
        return bool(self.names and (self.remote.snapshot if self.mode.currentData() == 'remote'
                                    else self.camera_roster.manual_names()))

    def _available_pairs(self):
        if not self._confirmed_order():
            return ()
        self.match_cameras.select(self._room_key(), self.bindings.receipt)
        originals = camera_matches(self.names, self.camera_roster.slots, self.vdo_panel.prepared_originals,
                                   self.vdo_panel.originals_for_order(),
                                   self.match_cameras.for_prepared(self.vdo_panel.prepared_originals))
        return self.bindings.pairs(originals)

    def _sync_preview(self, *_):
        if self._closing or self._native_refreshing:
            return
        pairs = self._available_pairs()
        signature = self._signature(pairs)
        for i in range(12):
            player = self.names[i] if i < len(self.names) else '—'
            values = [f'{i+1} / {self.camera_roster.position_keys[i]}', player, '—', '—']
            if pairs:
                pair = pairs[i]
                for col, guid, target in ((2, pair.original_guid, i+1), (3, pair.virtual_guid, i+13)):
                    number = self.native.numbers.get(guid) or self.bindings.inputs.get(guid, {}).get('number')
                    values[col] = f'{number or "?"} → {target}'
            for col, text in enumerate(values):
                item = self.preview.item(i, col)
                if item.text() != text:
                    item.setText(text)
        if not self._confirmed_order():
            hint = ('Сверьте позиции SourceTV с игрой и подтвердите порядок в «Инструменты → Игроки».'
                    if self.names else 'Подключите источник и дождитесь 12 игроков.')
        elif not self.bindings.confirmed:
            hint = 'Проверьте пул камер во вкладке VDO Ninja.'
        elif not pairs:
            hint = self.vdo_panel.originals_issue or 'Проверьте, что каждому игроку назначен оригинал.'
        else:
            hint = 'Входы 1–12 будут располагаться по позициям игроков, их копии — на входах 13–24.'
        if self._fixed and (self.match_id != self._fixed.match or tuple(self.names) != tuple(p.name for p in self._fixed.pairs)):
            hint = ('Получен другой состав или порядок. Для обновления выходов нажмите «Синхронизировать с матчем».'
                    if self.names else f'Ожидаем игровой источник. Сохранена раскладка матча {self._fixed.match}.') + ' ' + hint
        self.sync_hint.setText(hint)
        self.mapping_button.setEnabled(bool(self.names and self.vdo_panel.prepared_originals))
        preset = self._recovery_preset()
        recovery = bool(preset and self.native.has_recovery(self._endpoint(), preset))
        self.recover_button.setVisible(recovery)
        self.recovery_details.setVisible(recovery)
        prepared = bool(self._fixed or self.prematch.ready or self.vdo_panel.preparation_complete
                        or (not self.room_monitor.isChecked() and self.vdo_panel.prepared_catalog))
        self.sync_button.setEnabled(bool(signature) and prepared and not self.native.busy
                                    and not self.bindings.setup.busy and not recovery)
        if self._monitor_key:
            self.monitor.refresh()
        self._export()

    def _drop_native(self):
        self._desired_sync = self._authorized_sync = self._monitor_key = None
        self.monitor.stop()
        self.native.cancel()

    def _synchronize(self):
        pairs = self._available_pairs()
        signature = self._signature(pairs)
        if not signature or not self.sync_button.isEnabled():
            return
        self._desired_sync = signature
        self.prematch.set_suspended(True)
        self.monitor.stop()
        self._monitor_key = None
        self._authorized_sync = None
        self._native_owner = True
        accounts = self.camera_roster.slots
        aliases = {r.guid: r.name for r in self.vdo_panel.prepared_originals if r.name}
        self._requested_meta = dict(room=signature.room, match=signature.match, endpoint=list(signature.endpoint),
                                    preset=signature.preset, accounts=[accounts.get(i, '') for i in range(1,13)],
                                    keys=list(self.camera_roster.position_keys), aliases=aliases)
        self.settings.setValue('popSyncTarget', json.dumps(dict(endpoint=list(signature.endpoint), preset=signature.preset)))
        receipt = self.bindings.receipt
        self.sync_result.setText('Проверка и синхронизация входов vMix…')
        guids = {p.original_guid for p in pairs} | {p.virtual_guid for p in pairs}
        def valid():
            if self._desired_sync is None:
                return signature == self._fixed and self._layout_allowed(signature)
            return (self._desired_sync == signature and signature == self._signature(self._available_pairs())
                    and (self._authorized_sync != signature or self._unclaimed_virtual(receipt.endpoint, guids)))

        def authorize(endpoint, targets):
            if self._authorize_virtual(endpoint, targets, signature):
                self._authorized_sync = signature
                return True
            return False

        if not self.native.start(receipt.endpoint, receipt.preset, pairs, match_id=self.match_id,
                                 validate=valid, authorize=authorize) and self._desired_sync:
            self._sync_finished(False, self.native.message)

    def _sync_finished(self, ok, message):
        if self._closing:
            return
        if self._desired_sync:
            candidate, self._desired_sync = self._desired_sync, None
            if ok:
                self._fixed, self._fixed_meta = candidate, self._requested_meta
                self.settings.setValue(HOST_KEY, candidate.endpoint[0])
                self.settings.setValue(PORT_KEY, candidate.endpoint[1])
                self.settings.setValue('popLastMatchLayout', json.dumps(self._fixed_meta, ensure_ascii=False))
                # A verified account match also survives a later display-name change.
                accounts = self._fixed_meta['accounts']
                self.match_cameras.confirm(accounts, candidate.pairs, self._fixed_meta['aliases'])
                self._last_follow = self._observed_player()
                self._pending_follow = None
        if not self.native.ready and self._fixed and not self._desired_sync:
            self._restore_timer.start()
        self._suspend_preparation()
        self.sync_result.setText(' '.join(filter(None, (message, self.native.verification_note))))
        self._native_changed()

    def _native_changed(self):
        if self._closing or self._native_refreshing:
            return
        self._native_refreshing = True
        try:
            if self.native.message:
                self.sync_result.setText(' '.join(filter(None, (self.native.message, self.native.verification_note))))
            layout = self._fixed
            if self.native.ready and layout and not self._desired_sync and tuple(self.native.pairs) == layout.pairs:
                self.vdo_panel.update_original_numbers(self.native.numbers, preset=layout.preset)
                if self._monitor_key != layout:
                    self._monitor_key = layout
                    self.monitor.start(layout.endpoint, layout.preset, layout.pairs, media=self._media_sources,
                                       validate=self._monitor_current)
                self._hydrate_room()
            self._export()
        finally:
            self._native_refreshing = False
        self._sync_preview()
        self._route_observer()

    def _hydrate_room(self):
        layout = self._fixed
        if (not self.native.ready or not layout or self._room_key() != layout.room
                or self.vdo_panel.prepared_originals or not self.vdo_import.fresh):
            return
        catalog = self.vdo_panel.restore_original_catalog(layout.endpoint, layout.preset, layout.pairs, self.native.numbers)
        if catalog:
            self.bindings.set_receipt(catalog)

    def _media_sources(self):
        if not self._fixed or self._room_key() != self._fixed.room:
            return {}
        return self.vdo_panel.media_for_pairs(self._fixed.pairs, self._fixed_meta.get('aliases'))

    def _monitor_current(self):
        return bool(self._fixed and self._monitor_key == self._fixed and not self._desired_sync
                    and self.native.ready and self.vdo_import.fresh and self._fixed.room == self._room_key()
                    and self.room_monitor.isChecked() and self._layout_allowed(self._fixed))

    def _unclaimed_virtual(self, endpoint, guids):
        return not (self.cameras.conflicting_modules(endpoint, guids) or
                    (not self.pov.suspended and self.pov.endpoint == endpoint
                     and (self.pov.rename or self.pov.player_pages)))

    def _authorize_virtual(self, endpoint, guids, signature):
        roles = self.cameras.conflicting_modules(endpoint, guids)
        legacy = (not self.pov.suspended and self.pov.endpoint == endpoint
                  and (self.pov.rename or self.pov.player_pages))
        if roles or legacy:
            names = ', '.join([r.title() for r in roles] + (['POV vMix'] if legacy else []))
            result = QMessageBox.question(self, 'Управление входами',
                f'Входами управляет {names}. Передать их режиму синхронизации с матчем?',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
            if result != QMessageBox.StandardButton.Yes or self._desired_sync != signature:
                return False
            if legacy:
                self.cameras.managed = True
                self.cameras.activated.emit()
                self.cameras.save()
        self.cameras.release_inputs(endpoint, guids, roles)
        return True

    def _mix_conflict(self, role):
        endpoint = self.native.endpoint
        if not endpoint:
            return False
        mix = self.live_mix.value() if role == 'live' else self.replay_mix.value()
        if self.live_mix.value() == self.replay_mix.value():
            return True
        if not self.pov.suspended and self.pov.endpoint == endpoint and mix in (*self.pov.original_mixes, *self.pov.copy_mixes):
            return True
        return any(cfg['enabled'] and cfg['mode'] == 'program' and cfg['mix'] == mix
                   and endpoint_key(cfg) == endpoint for cfg in self.cameras.config.values())

    def _take_virtual(self, slot):
        return self._take_output(slot, 'replay')

    def _take_output(self, slot, role):
        layout = self._fixed
        live = role == 'live'
        enabled = self.live_enabled if live else self.replay_enabled
        field = self.live_mix if live else self.replay_mix
        mix = field.value()
        def valid():
            return (layout and layout == self._fixed and not self._desired_sync and enabled.isChecked()
                    and field.value() == mix and self._layout_allowed(layout) and not self._mix_conflict(role))
        if self.native.route(slot) and valid():
            take = self.native.take_live if live else self.native.take
            return take(slot, mix, validate=valid)
        return False

    def _observed_player(self):
        if self.observed and 0 < self.observed <= len(self.names):
            return self.match_id, self.names[self.observed - 1], self.camera_roster.slots.get(self.observed)
        return None

    def _route_observer(self):
        current = self._observed_player()
        if not (self._fixed and current and current[0] == self._fixed.match and self.follow.isChecked()
                and self.live_enabled.isChecked() and self.native.ready and not self._desired_sync):
            self._last_follow, self._pending_follow = current, None
            return
        if self._last_follow != current:
            # The first packet after connection or a gap establishes the baseline.
            self._pending_follow = current if self._last_follow else None
            self._last_follow = current
        if self._pending_follow and not self.native.busy:
            self._pending_follow = None
            accounts = self._fixed_meta.get('accounts', ())
            _, name, account = current
            slots = [i for i,p in enumerate(self._fixed.pairs, 1)
                     if (len(accounts) == 12 and account and accounts[i-1] == account) or
                        (p.name.casefold() == name.casefold() and not (len(accounts) == 12 and account and accounts[i-1]))]
            if len(slots) == 1:
                self._take_output(slots[0], 'live')

    def _roster_tools(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.addWidget(self.camera_roster)
        prepare = QPushButton('Камеры до матча…')
        prepare.clicked.connect(self._edit_preparation)
        layout.addWidget(prepare, alignment=Qt.AlignmentFlag.AlignLeft)
        return page

    def _edit_preparation(self):
        self.cameras.edit_preparation(self)

    def _switch_source(self, index):
        self.settings.setValue('povMatchSource', self.mode.currentData())
        self.sources.setCurrentIndex(index)
        if self.mode.currentData() == 'remote':
            self.source_tv.stop()
        else:
            self.remote.stop()
        self._read_source()

    def _connect_remote(self):
        url = self.remote_url.text().strip()
        self.settings.setValue('povHudUrl', url)
        self.remote.set_url(url)

    def _stop_remote(self):
        self.remote.stop()

    def _read_source(self, *_):
        net = self.mode.currentData() == 'remote'
        packet = self.remote.snapshot if net else None
        roster = self.source_tv.roster
        if net:
            roster = packet.roster if packet else None
        if not net and self.source_tv.requested_match_id and str((roster or {}).get('matchId')) != self.source_tv.requested_match_id:
            roster = None
        slots = dict(enumerate(packet.names, 1)) if packet else {}
        self._update_in_progress = True
        try:
            self.camera_roster.update_match(roster, {str(i): name for i, name in slots.items()},
                                            packet.observed if packet else None, bool(packet and roster))
        finally:
            self._update_in_progress = False
        self._render_order()

    def _render_order(self):
        if self._closing or self._update_in_progress:
            return
        packet = self.remote.snapshot if self.mode.currentData() == 'remote' else None
        trusted = self.camera_roster.manual_names()
        match_id = self.camera_roster.match_id or ''
        observed = None
        if packet:
            # Follow the same person when an operator overrides the visual ordering.
            names = trusted or self.camera_roster.orient(packet.names)
            selected = packet.names[packet.observed - 1] if packet.observed else None
            observed = names.index(selected) + 1 if selected in names else None
            source = (f'Ручной порядок · матч {packet.match_id}' if trusted else f'Panorama по сети · {self.camera_roster.direction_text} · матч {packet.match_id}')
            match_id = packet.match_id
        elif self.mode.currentData() == 'match':
            roster = self.source_tv.roster
            requested = self.source_tv.requested_match_id
            if requested and str((roster or {}).get('matchId')) != requested:
                roster = None
            match_id = str((roster or {}).get('matchId') or '')
            api = players_by_match_position(roster)
            names = trusted or self.camera_roster.orient(tuple(api[str(i)] for i in range(1, len(api) + 1)))
            source = f'Ручной порядок · матч {match_id}' if trusted else f'SourceTV · матч {match_id} · сверьте порядок по линиям с HUD.'
        else:
            names, source = (), ''
        if not match_id or len(names) != 12 or len({name.strip().casefold() for name in names}) != 12:
            names, source = (), ''
        self.names, self.match_id, self.observed = names, match_id, observed
        self.order_status.setText(source or 'Ожидание позиций игроков.')
        self.vdo_panel.set_hud_order(names, source)
        if not self._native_owner:
            self.pov.set_hud_slots({str(i): name for i, name in enumerate(names, 1)})
            self.pov.set_observed(observed)
        self._sync_preview()
        self._route_observer()

    def _export(self):
        if self._closing:
            return
        cameras = self.cameras
        fixed = self._fixed
        direct = bool(fixed and self.native.ready and not self._desired_sync and self.native.pairs == fixed.pairs)
        direct_owner = bool(fixed or self._native_owner)
        mix_conflict = direct and self._mix_conflict('replay')
        live_conflict = direct and self._mix_conflict('live')
        external = self.native.external2 if direct else ''
        if external.startswith('mix=') and external[4:].isdecimal():
            external = f'Mix {int(external[4:]) + 1}'
        for role, field, label in [('live', self.live_mix, self.live_status), ('replay', self.replay_mix, self.external_status)]:
            mix = field.value()
            guid = self.native.mixes.get(mix) if direct else None
            number = self.native.numbers.get(guid)
            text = f'Mix {mix} · Program {number or "—"}'
            if role == 'replay':
                text += ' · External 2: ' + (external or 'проверьте назначение в vMix')
            elif live_conflict:
                text += ' · Конфликт управления выходом'
            label.setText(text)
        self.virtual_status.setText('Этот Mix занят. Выберите отдельный Mix для Replay.' if mix_conflict else '')
        fixed_media = self._media_sources() if fixed else {}
        exported_names = tuple(p.name for p in fixed.pairs) if fixed else self.names
        exported_match = fixed.match if fixed else self.match_id
        fixed_accounts = self._fixed_meta.get('accounts', ())
        fixed_keys = self._fixed_meta.get('keys', ())
        slots = {}
        replay_inputs = {}
        labels = {}
        pov_inputs = {}
        numbers = tuple(field.value() for field in self.vdo_panel.positions.inputs)
        if cameras.managed:
            numbers = tuple(live or direct for live, direct in zip(cameras.input_numbers(), numbers))
        elif self.pov.auto or self.pov.rename or self.pov.copy_mixes or self.pov.player_pages:
            numbers = self.pov.inputs
        for i, name in enumerate(exported_names, 1):
            key = str(i)
            account = (fixed_accounts[i-1] if len(fixed_accounts) == 12 else '') if fixed else self.camera_roster.slots.get(i, '')
            bank = cameras.owners.index(account) if account and account in cameras.owners else None
            physical = numbers[i - 1]
            ready = cameras.routable('replay', account) if cameras.managed and account else bool(
                not cameras.managed and self.pov.targets(i))
            media = fixed_media.get(fixed.pairs[i-1].original_guid, ('unknown',))[0] if fixed else self.vdo_panel.position_media(i)
            if cameras.managed:
                has_camera = bool(account and cameras.has_camera(account))
            else:
                has_camera = media == 'live'
            source_guid = cameras.config['live']['guids'][bank] if bank is not None else ''
            replay_guid = cameras.config['replay']['guids'][bank] if bank is not None else ''
            replay_number = None
            mix = cameras.config['replay']['mix'] if cameras.managed else 0
            route = self.native.route(i) if direct else None
            if direct_owner:
                ready = bool(route and not mix_conflict and self.replay_enabled.isChecked())
                replay_guid = route['virtual_guid'] if route else ''
                mix = self.replay_mix.value()
                if route:
                    replay_number = replay_inputs[key] = route['virtual_number']
                    source_guid = route['original_guid']
                    physical = route['original_number']
                    has_camera = media == 'live'
            if physical and (direct or not direct_owner):
                pov_inputs.setdefault(str(physical), []).append(name)
            player = self.camera_roster.players.get(account, {})
            slots[key] = dict(name=name, account_id=account, match_id=exported_match,
                              key=(fixed_keys if len(fixed_keys) == 12 else self.camera_roster.position_keys)[i - 1],
                              has_camera=has_camera, vdo_video=media, replay_ready=ready, hero=player.get('hero'),
                              hero_id=player.get('heroId'), team=player.get('side'),
                              live_guid=source_guid, replay_guid=replay_guid, replay_input=replay_number,
                              replay_mix=mix)
            labels[key] = name if direct_owner else name + ('\nНет камеры' if (cameras.managed and not has_camera) or media == 'absent' else
                                  '\nНедоступна' if cameras.managed and not ready else '')
        camera_status = {'live': 'Есть видео', 'absent': 'Нет видео', 'unknown': 'Нет данных'}
        prepared = {r.number: r for r in self.vdo_panel.prepared_originals}
        bank_rows = []
        matched_labels = set()
        for pos in range(1, 13):
            item = slots.get(str(pos), {})
            for role, buttons, on, offset in [('live', self.live_buttons, self.live_enabled, 0),
                                              ('replay', self.replay_buttons, self.replay_enabled, 12)]:
                button = buttons[pos-1]
                txt = f"№ {pos+offset} · {item.get('name') or '—'}"
                txt += '\n' + camera_status[item.get('vdo_video', 'unknown')]
                mix_number = self.live_mix.value() if role == 'live' else self.replay_mix.value()
                guid = item.get('live_guid' if role == 'live' else 'replay_guid')
                active = bool(direct and guid and self.native.mixes.get(mix_number) == guid)
                if active:
                    txt += ' · Program'
                if button.text() != txt:
                    button.setText(txt)
                if button.property('onProgram') != active:
                    button.setProperty('onProgram', active)
                    button.style().unpolish(button)
                    button.style().polish(button)
                button.setEnabled(bool(direct and on.isChecked() and not (live_conflict if role == 'live' else mix_conflict)))
            row = prepared.get(pos)
            source = ''
            if fixed:
                p = fixed.pairs[pos-1]
                source = self._fixed_meta.get('aliases', {}).get(p.original_guid) or p.name
                media = item.get('vdo_video', 'unknown')
            else:
                source = row.name if row else ''
                media = row.media if row else 'unknown'
            if source:
                matched_labels.add(source.casefold())
            bank_rows.append((str(pos), source or '—', camera_status[media]))
        guests = self.vdo_panel.room_guests
        unassigned = [g for g in guests if g.issue or g.label.casefold() not in matched_labels]
        if unassigned:
            bank_rows = [r for r in bank_rows if r[1] != '—']
            bank_rows.extend(('—', g.label or 'Без имени',
                              g.issue or camera_status[g.video if self.vdo_import.fresh else 'unknown']) for g in unassigned)
        if self.room_bank.rowCount() != len(bank_rows):
            self.room_bank.setRowCount(len(bank_rows))
        for idx, row in enumerate(bank_rows):
            for col, val in enumerate(row):
                cell = self.room_bank.item(idx,col)
                if cell is None:
                    cell = QTableWidgetItem()
                    self.room_bank.setItem(idx,col,cell)
                if cell.text() != val:
                    cell.setText(val)
        self.new_pool.setEnabled(bool(fixed and not self.native.busy))
        self.reload_pages.setEnabled(bool(self.room_monitor.isChecked() and (fixed or prepared) and not self.native.busy))
        observed = self.observed
        if fixed:
            selected = self._observed_player()
            observed = (exported_names.index(selected[1])+1 if selected and selected[0] == exported_match
                        and selected[1] in exported_names else None)
        self.companion.payload = dict(version=1, replay_inputs=replay_inputs, matchId=exported_match or None,
            status='live' if slots else 'waiting', hud_slots={key: row['name'] for key, row in slots.items()}, hud_observed_slot=observed,
            pov_inputs={key: group[0] for key, group in pov_inputs.items() if len(group) == 1},
            camera_slots=slots, replay_button_labels={str(i): labels.get(str(i), '—') for i in range(1, 13)})

    def _take(self, slot, account, match_id, name, guid, mix):
        row = self.companion.payload.get('camera_slots', {}).get(str(slot), {})
        if not row.get('replay_ready') or (row['account_id'], row['match_id'], row['name'],
                row['replay_guid'], row['replay_mix']) != (account, match_id, name, guid, mix):
            return
        if self._native_owner:
            self._take_virtual(slot)
        elif self.cameras.managed:
            self.cameras.take('replay', slot)
        else:
            self.pov.take(slot)

    def _room_fresh(self, fresh):
        if not fresh:
            self.vdo_publisher.cancel()
        elif self._fixed:
            self._hydrate_room()
        self._export()

    def _claimed(self, endpoint, guids):
        if self.vdo_publisher.active_endpoint == endpoint:
            self.vdo_publisher.cancel()
        layout = self._desired_sync or self._fixed
        if layout and layout.endpoint == endpoint and layout.guids.intersection(guids):
            self._drop_native()
            if self._fixed:
                self._restore_timer.start()
        self.vdo_publisher.forget(guids, endpoint=endpoint)

    def _publish(self, host, port, rows):
        if self.vdo_panel.submitted_mode == 'positions':
            self.vdo_panel.vmix_finished('Используйте «Синхронизировать с матчем» для перемещения пар.')
            return
        if self._fixed or self._desired_sync:
            self.vdo_panel.vmix_finished('Физическая раскладка матча зафиксирована.')
            return
        self._drop_native()
        if self.vdo_panel.submitted_mode == 'preparation':
            self.bindings.set_receipt(None)
            if [field.value() for field in self.vdo_panel.preparation.inputs] != list(range(1, 13)):
                self.vdo_panel.vmix_finished('Для этого пресета нужны оригиналы на входах 1–12.')
                return
        publish_room_cameras(self, self.vdo_panel, self.vdo_import, self.vdo_publisher,
                             self.cameras, self.pov, host, port, rows)

    def closeEvent(self, event):
        self._closing = True
        self._restore_timer.stop()
        self._room_resume.stop()
        self.prematch.stop()
        self.camera_roster.bind_camera_mapping(dict)
        self._drop_native()
        self.bindings.cancel()
        self.companion.stop()
        self.remote.stop()
        self.source_tv.stop()
        self.vdo_publisher.cancel()
        self.vdo_import.stop()
        self.cameras.close()
        self.pov.shutdown()
        self.source_tv.process.waitForFinished(1500)
        self.settings.sync()
        super().closeEvent(event)


def main(settings=None):
    set_dpi_awareness()
    app = QApplication(sys.argv[:1])
    app.setWindowIcon(QIcon(str(Path(__file__).with_name('assets') / 'dhm.ico')))
    from PySide6.QtWidgets import QMessageBox
    from .pov_instance import PovInstance

    try:
        instance = PovInstance()
        if not instance.acquire():
            return 0
    except OSError as exc:
        QMessageBox.warning(None, 'Deadlock POV Manager', str(exc))
        return 1
    if settings is None:
        from .manager_settings import pov_settings
        settings = pov_settings()
    window = PovManager(settings)
    def activate():
        if window.isMinimized():
            window.showNormal()
        window.raise_()
        window.activateWindow()

    instance.activate.connect(activate)
    window.show()
    try:
        return app.exec()
    finally:
        instance.close()


if __name__ == '__main__':
    raise SystemExit(main())
