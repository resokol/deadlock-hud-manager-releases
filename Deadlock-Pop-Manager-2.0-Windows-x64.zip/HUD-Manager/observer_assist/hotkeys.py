"""Hotkey parsing is portable; registration is supplied by the Windows adapter."""


def parse_hotkey(text):
    parts = [p.strip().upper() for p in text.split('+')]
    if not parts or len(parts) != len(set(parts)):
        raise ValueError("Неверное сочетание клавиш")
    mods = 0
    mapping = {'ALT': 1, 'CTRL': 2, 'SHIFT': 4, 'WIN': 8}
    for part in parts[:-1]:
        if part not in mapping:
            raise ValueError("Модификаторы: Ctrl, Alt, Shift, Win")
        mods |= mapping[part]
    key = parts[-1]
    if key.startswith('F') and key[1:].isdigit() and 1 <= int(key[1:]) <= 24:
        vk = 0x70 + int(key[1:]) - 1
    elif len(key) == 1 and key.isascii() and key.isalnum():
        vk = ord(key)
    else:
        raise ValueError("Используйте букву, цифру или F1–F24")
    if mods == 0:
        raise ValueError("Добавьте модификатор, чтобы не перехватывать клавиши игры")
    return mods, vk


class HotkeyManager:
    def __init__(self, backend):
        self.backend = backend
        self.actions = {}

    def register(self, bindings):
        parsed = [(action, parse_hotkey(key)) for action,key in bindings.items()]
        if len({keys for _,keys in parsed}) != len(parsed):
            raise ValueError("Действиям нужны разные сочетания клавиш")
        self.unregister()
        try:
            for i,(action,(mods,vk)) in enumerate(parsed,1):
                if not self.backend.register(i, mods | 0x4000, vk):
                    raise ValueError(f"Сочетание для «{action}» занято. Выберите другое.")
                self.actions[i] = action
        except Exception:
            self.unregister()
            raise

    def unregister(self):
        for i in list(self.actions):
            self.backend.unregister(i)
        self.actions.clear()
