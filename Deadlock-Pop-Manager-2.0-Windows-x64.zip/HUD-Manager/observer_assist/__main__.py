import argparse
from ipaddress import IPv4Address
import json
from pathlib import Path
import sys
import os
from time import perf_counter

from .panorama import DEFAULT_PORTRAIT_KEYS
from .profile import Profile


def analyze_video(path,profile):
    from .events import EventEngine
    from .tracking import Tracker
    from .replay import replay
    tracker,engine=Tracker(),EventEngine()
    events={}
    frames=0
    last=0
    started=perf_counter()
    for now,detections in replay(path,profile):
        frames+=1;last=now
        for e in engine.update(tracker.update(detections,now),now,profile):
            if e.id not in events:
                events[e.id]={'id':e.id,'kind':e.kind,'first_visible':now,'last_visible':now,
                              'x':e.x,'y':e.y,'reason':e.reason}
                if e.eta_seconds is not None:
                    events[e.id]['eta_seconds']=round(e.eta_seconds,2)
                    events[e.id]['risk']=e.risk
            events[e.id]['last_visible']=now
    if not frames:
        raise ValueError('В видео нет доступных кадров')
    return {'frames_analyzed':frames,'last_video_time':last,
            'processing_seconds':round(perf_counter()-started,4),'events':list(events.values()),
            'limitations':['Эвристический интерес, не подтверждённый бой.',
                           'Точность и время предупреждения требуют ручной разметки настоящего матча.',
                           'Результаты зависят от калибровки цветов и перекрытий значков.']}


def main(argv=None):
    from .broadcast import PORT

    parser=argparse.ArgumentParser(description='Deadlock Observer Assist — экспериментальный локальный помощник')
    parser.add_argument('--profile',type=Path,help='JSON-профиль калибровки')
    parser.add_argument('--replay',type=Path,help='Проверить видеозапись без запуска GUI')
    parser.add_argument('--report',type=Path,help='Сохранить JSON-отчёт проверки')
    parser.add_argument('--panorama-log',type=Path,help='Локальный console.log Deadlock с дополнением Panorama')
    parser.add_argument('--vmix-host',type=IPv4Address,
                        help='IPv4-адрес помощника для vMix. По умолчанию определяется автоматически.')
    parser.add_argument('--vmix-port',default=PORT,type=int,help=f'Порт источников vMix, по умолчанию {PORT}')
    parser.add_argument('--sourcetv-worker',type=Path,help='Локальный обработчик SourceTV для обновления K/D/A в vMix')
    parser.add_argument('--hero-icons',type=Path,help='Папка с локальными эталонами значков героев')
    parser.add_argument('--portrait-keys',default=''.join(DEFAULT_PORTRAIT_KEYS),
                        help='Клавиши портретов слева направо: 1234567890-=')
    args=parser.parse_args(argv)
    try:
        profile=Profile.load(args.profile) if args.profile else None
        if (args.vmix_host and args.vmix_host.is_unspecified) or not 1 <= args.vmix_port <= 65535:
            raise ValueError('Для vMix укажите адрес сетевого интерфейса и порт от 1 до 65535.')
        if (not args.portrait_keys or len(set(args.portrait_keys)) != len(args.portrait_keys)
                or any(key not in DEFAULT_PORTRAIT_KEYS for key in args.portrait_keys)):
            raise ValueError('Для портретов используйте разные клавиши из набора 1234567890-=')
        if args.replay:
            if profile is None:
                raise ValueError('Для проверки видео укажите --profile')
            report=analyze_video(args.replay,profile)
            text=json.dumps(report,ensure_ascii=False,indent=2)
            if args.report:
                args.report.parent.mkdir(parents=True,exist_ok=True)
                args.report.write_text(text,encoding='utf-8')
            else:
                print(text)
            return 0
        if args.report:
            raise ValueError('--report используется вместе с --replay')
    except (ValueError,OSError) as exc:
        print(f'Ошибка: {exc}',file=sys.stderr)
        return 2
    from .win32 import set_dpi_awareness
    set_dpi_awareness()
    from PySide6.QtWidgets import QApplication
    app=QApplication(sys.argv[:1])
    panel=create_panel(
        profile, panorama_log=args.panorama_log, portrait_keys=args.portrait_keys,
        hero_icon_dir=args.hero_icons, source_tv_worker=args.sourcetv_worker,
        vmix_host=args.vmix_host, vmix_port=args.vmix_port,
    )
    panel.show()
    return app.exec()


def create_panel(profile=None, *, panorama_log=None, portrait_keys=DEFAULT_PORTRAIT_KEYS,
                 hero_icon_dir=None, source_tv_worker=None, vmix_host=None, vmix_port=None):
    from .broadcast import Broadcast, BroadcastServer, PORT, detect_vmix_address, load_token
    from .hero_icons import HeroIcons
    from .win32 import WindowsApi
    from .ui import ControlPanel

    config_root=Path(os.environ.get('LOCALAPPDATA',os.environ.get('XDG_CONFIG_HOME',str(Path.home()/'.config'))))
    config_path=config_root/'DeadlockObserverAssist'/'profile.json'
    saved_error=None
    if profile is None and config_path.is_file():
        try:profile=Profile.load(config_path)
        except ValueError:saved_error='Сохранённая настройка повреждена. Повторите автонастройку.'
    error=None
    try:
        api=WindowsApi()
    except (RuntimeError,OSError,AttributeError) as exc:
        api=None;error=str(exc)
    icons_dir=hero_icon_dir or config_path.parent/'hero-minimap-assets'
    icons=None
    if panorama_log and (icons_dir/'catalog.json').is_file():
        try:
            icons=HeroIcons.from_cache(icons_dir)
        except (OSError, ValueError, KeyError, TypeError, AttributeError) as exc:
            print(f'Не удалось прочитать эталоны значков: {exc}',file=sys.stderr)
    broadcast = None
    broadcast_error = None
    if panorama_log:
        try:
            source_tv = None
            if source_tv_worker:
                from .sourcetv import SourceTV
                source_tv = SourceTV(source_tv_worker, panorama_log)
            feed = Broadcast(panorama_log, source_tv=source_tv)
            host = vmix_host or detect_vmix_address()
            port = PORT if vmix_port is None else vmix_port
            broadcast = BroadcastServer(feed, str(host), port, load_token(config_path.parent))
        except (OSError, ValueError) as exc:
            broadcast_error = f'Источники vMix недоступны. {exc}'
    panel=ControlPanel(api=api,profile=profile,config_path=config_path,
                       panorama_log=panorama_log, portrait_keys=portrait_keys, hero_icons=icons,
                       broadcast=broadcast, broadcast_error=broadcast_error)
    if error:
        panel.status.setText(error+' Здесь доступны калибровка по файлу и проверка записи.')
    elif saved_error:panel.status.setText(saved_error)
    return panel


if __name__=='__main__':
    raise SystemExit(main())
