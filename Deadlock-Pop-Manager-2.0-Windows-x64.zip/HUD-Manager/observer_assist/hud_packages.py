"""Validate and store the web packages used by the browser overlay."""

from copy import copy
from dataclasses import dataclass, replace
import json
from pathlib import Path
import re
import shutil
import stat
from tempfile import NamedTemporaryFile
from threading import RLock
from uuid import uuid4
from zipfile import ZIP_DEFLATED, ZIP_STORED, BadZipFile, ZipFile
from zlib import error as CompressionError


WEB_ROOT = Path(__file__).with_name('hud_web')
DEFAULT_ID = 'deadlock-default'
SLUG = re.compile(r'[a-z0-9][a-z0-9-]{0,47}')
FIELD_KEY = re.compile(r'[a-zA-Z][a-zA-Z0-9_]{0,47}')
COLOR = re.compile(r'#[0-9a-fA-F]{6}')
MAX_ARCHIVE = 100 * 1024 * 1024
MAX_EXPANDED = 240 * 1024 * 1024
MAX_ASSET = 48 * 1024 * 1024
MAX_METADATA = 64 * 1024
SOURCE_EXTENSIONS = {'.html', '.htm', '.css', '.js', '.mjs'}


@dataclass(frozen=True)
class HudField:
    key: str
    label: str
    kind: str
    default: str | bool

    def normalize(self, value):
        if self.kind == 'toggle' and type(value) is bool:
            return value
        if isinstance(value, str):
            if self.kind == 'text':
                return value[:120]
            if self.kind == 'color' and COLOR.fullmatch(value):
                return value.lower()
        return self.default


@dataclass(frozen=True)
class HudPackage:
    id: str
    name: str
    author: str
    version: str
    variants: tuple[str, ...]
    fields: tuple[HudField, ...]
    files: frozenset[str]
    path: Path
    built_in: bool = False

    @property
    def source_files(self):
        if self.built_in or 'studio.json' in self.files:
            return ()
        names = (name for name in self.files if Path(name).suffix.lower() in SOURCE_EXTENSIONS)
        return tuple(sorted(names, key=lambda name: (name != 'index.html', name)))


def _valid_path(path):
    parts = path.split('/')
    return ('\\' not in path and len(path) <= 240 and
            all(part not in ('', '.', '..') and not part.endswith((' ', '.'))
                and not re.search(r'[<>:"|?*\x00-\x1f]', part) for part in parts))


def _parse_json(data, filename):
    if len(data) > MAX_METADATA:
        raise ValueError(f'{filename} превышает допустимый размер.')
    try:
        value = json.loads(data.decode('utf-8-sig'))
    except (UnicodeError, ValueError, RecursionError) as exc:
        raise ValueError(f'Не удалось прочитать {filename}.') from exc
    if not isinstance(value, dict):
        raise ValueError(f'{filename} должен содержать объект JSON.')
    return value


def _text(data, key):
    value = data.get(key)
    if not isinstance(value, str) or not value.strip() or len(value) > 120:
        raise ValueError(f'Некорректное поле {key}.')
    return value.strip()


def _read_fields(data):
    fields = _parse_json(data, 'panel.json').get('fields')
    if not isinstance(fields, list) or len(fields) > 16:
        raise ValueError('В panel.json укажите список fields, не более 16 полей.')
    seen = set()
    for item in fields:
        if not isinstance(item, dict):
            raise ValueError('Поле настроек должно быть объектом JSON.')
        key = _text(item, 'key')
        kind = item.get('type')
        if not FIELD_KEY.fullmatch(key) or key in seen or kind not in ('text', 'toggle', 'color'):
            raise ValueError(f'Некорректное описание поля {key}.')
        seen.add(key)
        field = HudField(key, _text(item, 'label'), kind, {'text': '', 'toggle': False, 'color': '#ffffff'}[kind])
        yield HudField(key, field.label, kind, field.normalize(item.get('default')))


def _describe(path, read, files, built_in=False):
    if not {'hud.json', 'index.html'}.issubset(files):
        raise ValueError('Положите hud.json и index.html в корень ZIP.')
    data = _parse_json(read('hud.json'), 'hud.json')
    package_id = _text(data, 'id')
    if not SLUG.fullmatch(package_id) or (package_id == DEFAULT_ID and not built_in):
        raise ValueError('Укажите уникальный id из латинских строчных букв, цифр и дефисов.')
    if data.get('game') != 'deadlock':
        raise ValueError('В hud.json укажите "game": "deadlock".')
    variants = data.get('variants', [])
    if (not isinstance(variants, list) or len(variants) > 12 or
            any(not isinstance(item, str) or not SLUG.fullmatch(item) for item in variants) or
            len(set(variants)) != len(variants)):
        raise ValueError('В variants укажите уникальные имена вариантов HUD.')
    return HudPackage(package_id, _text(data, 'name'), _text(data, 'author'), _text(data, 'version'),
                      tuple(variants), tuple(_read_fields(read('panel.json'))) if 'panel.json' in files else (),
                      frozenset(files), path, built_in)


def _read_zip(path, *, verify=False):
    if path.stat().st_size > MAX_ARCHIVE:
        raise ValueError('ZIP превышает 100 МБ.')
    try:
        with ZipFile(path) as archive:
            entries = archive.infolist()
            if len(entries) > 1500 or sum(item.file_size for item in entries) > MAX_EXPANDED:
                raise ValueError('Слишком большой набор файлов HUD.')
            files, names = set(), set()
            for item in entries:
                filename = item.filename.rstrip('/') if item.is_dir() else item.filename
                mode = item.external_attr >> 16
                if (not _valid_path(filename) or filename.casefold() in names or
                        stat.S_ISLNK(mode) or item.flag_bits & 1 or item.file_size > MAX_ASSET or
                        item.compress_type not in (ZIP_STORED, ZIP_DEFLATED)):
                    raise ValueError(f'Недопустимый файл в ZIP: {filename!r}.')
                names.add(filename.casefold())
                if not item.is_dir():
                    files.add(filename)
            for name in files & {'hud.json', 'panel.json'}:
                if archive.getinfo(name).file_size > MAX_METADATA:
                    raise ValueError(f'{name} превышает допустимый размер.')
            package = _describe(path, archive.read, files)
            if verify and archive.testzip() is not None:
                raise ValueError('Архив содержит повреждённый файл.')
            return package
    except (BadZipFile, CompressionError, NotImplementedError, RuntimeError, EOFError) as exc:
        raise ValueError('Не удалось прочитать ZIP-пакет HUD.') from exc


class HudPackages:
    def __init__(self, directory):
        self.directory = Path(directory)
        self._lock = RLock()
        default = WEB_ROOT / 'default'
        built_in = _describe(default, lambda name: (default / name).read_bytes(),
                             {path.name for path in default.iterdir() if path.is_file()}, built_in=True)
        self._packages = {built_in.id: built_in}
        self._revisions = {built_in.id: uuid4().hex}
        self._active = built_in.id
        self._opacity = 100
        self._settings = {}
        self.unreadable = []
        for path in sorted(self.directory.glob('*.zip')):
            try:
                package = _read_zip(path)
                if path.stem != package.id:
                    raise ValueError('Имя ZIP в библиотеке должно совпадать с id.')
            except (OSError, ValueError):
                self.unreadable.append(path.name)
                continue
            self._register(package)

    def all(self):
        with self._lock:
            return tuple(self._packages.values())

    def get(self, package_id):
        with self._lock:
            return self._packages.get(package_id)

    def _register(self, package):
        self._packages[package.id] = package
        self._revisions[package.id] = uuid4().hex

    def install(self, source, *, expected_revision=None):
        source = Path(source)
        self.directory.mkdir(parents=True, exist_ok=True)
        with NamedTemporaryFile(dir=self.directory, suffix='.tmp', delete=False) as staged:
            temporary = Path(staged.name)
        try:
            if source.stat().st_size > MAX_ARCHIVE:
                raise ValueError('ZIP превышает 100 МБ.')
            shutil.copyfile(source, temporary)
            package = _read_zip(temporary, verify=True)
            target = self.directory / (package.id + '.zip')
            with self._lock:
                if expected_revision is not None and self._revisions.get(package.id) != expected_revision:
                    raise ValueError('Пакет HUD изменился. Откройте актуальный макет или сохраните копию.')
                temporary.replace(target)
                saved = replace(package, path=target)
                self._register(saved)
                return saved
        finally:
            temporary.unlink(missing_ok=True)

    def update_sources(self, package_id, changes, *, expected_revision):
        with self._lock:
            package = self._packages.get(package_id)
            if package is None or self._revisions[package_id] != expected_revision:
                raise ValueError('Пакет HUD изменился. Откройте его заново.')
            if not changes:
                return expected_revision
            if not changes.keys() <= set(package.source_files):
                raise ValueError('Редактировать можно только существующие файлы HTML, CSS и JavaScript.')
            if any(len(content) > MAX_ASSET for content in changes.values()):
                raise ValueError('Один из исходных файлов превышает 48 МБ.')
            with NamedTemporaryFile(dir=self.directory, suffix='.tmp', delete=False) as staged:
                temporary = Path(staged.name)
            try:
                with ZipFile(package.path) as source, ZipFile(temporary, 'w') as target:
                    target.comment = source.comment
                    for entry in source.infolist():
                        content = changes.get(entry.filename)
                        if content is not None:
                            target.writestr(copy(entry), content)
                        else:
                            with source.open(entry) as original, target.open(copy(entry), 'w') as preserved:
                                shutil.copyfileobj(original, preserved)
                saved = replace(_read_zip(temporary), path=package.path)
                if saved != package:
                    raise ValueError('Состав пакета HUD изменился. Откройте его заново.')
                temporary.replace(package.path)
                self._register(saved)
                return self._revisions[package_id]
            except (BadZipFile, CompressionError, EOFError, RuntimeError) as exc:
                raise ValueError('Не удалось прочитать ZIP-пакет HUD.') from exc
            finally:
                temporary.unlink(missing_ok=True)

    def export_template(self, destination):
        destination = Path(destination)
        default = self.get(DEFAULT_ID)
        with NamedTemporaryFile(dir=destination.parent, suffix='.tmp', delete=False) as staged:
            temporary = Path(staged.name)
        try:
            with ZipFile(temporary, 'w', compression=ZIP_DEFLATED) as archive:
                manifest = json.loads((default.path / 'hud.json').read_text(encoding='utf-8'))
                manifest.update(id='my-deadlock-hud', name='Мой Deadlock HUD', author='Автор HUD')
                archive.writestr('hud.json', json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
                for name in sorted(default.files - {'hud.json'}):
                    archive.write(default.path / name, name)
            temporary.replace(destination)
        finally:
            temporary.unlink(missing_ok=True)

    def remove(self, package_id):
        with self._lock:
            package = self._packages.get(package_id)
            if package is None or package.built_in:
                return
            package.path.unlink(missing_ok=True)
            del self._packages[package_id]
            self._revisions.pop(package_id)
            self._settings.pop(package_id, None)
            if self._active == package_id:
                self._active = DEFAULT_ID

    def activate(self, package_id):
        with self._lock:
            self._active = package_id if package_id in self._packages else DEFAULT_ID

    @property
    def opacity(self):
        with self._lock:
            return self._opacity

    @opacity.setter
    def opacity(self, percent):
        with self._lock:
            self._opacity = max(0, min(100, percent))

    def active(self, package_id=None):
        with self._lock:
            package_id = self._active if package_id is None else package_id
            if package_id not in self._revisions:
                return None
            state = {'id': package_id, 'revision': self._revisions[package_id], 'opacity': self._opacity}
            if 'studio.json' in self._packages[package_id].files:
                state['studio'] = True
            return state

    def set_settings(self, package_id, values):
        with self._lock:
            package = self._packages[package_id]
            self._settings[package_id] = {field.key: field.normalize(values.get(field.key)) for field in package.fields}

    def settings(self, package_id):
        with self._lock:
            package = self._packages.get(package_id)
            if package is None:
                return None
            return dict(self._settings.get(package_id, {field.key: field.default for field in package.fields}))

    def asset(self, package_id, name):
        with self._lock:
            package = self._packages.get(package_id)
            if package is None or name not in package.files:
                return None
            if package.built_in:
                return (package.path / name).read_bytes()
            try:
                with ZipFile(package.path) as archive:
                    return archive.read(name)
            except (BadZipFile, CompressionError, EOFError, KeyError, RuntimeError):
                return None
