from dataclasses import asdict, dataclass, field
import json
import math
from pathlib import Path


@dataclass
class Rect:
    left: int
    top: int
    width: int
    height: int

    def contains(self, other):
        return (other.left >= self.left and other.top >= self.top
                and other.left + other.width <= self.left + self.width
                and other.top + other.height <= self.top + self.height)

    def intersects(self, other):
        return (max(self.left, other.left) < min(self.left + self.width, other.left + other.width)
                and max(self.top, other.top) < min(self.top + self.height, other.top + other.height))


@dataclass
class TeamColor:
    team: int
    hue: int
    tolerance: int = 8
    saturation_min: int = 100
    value_min: int = 100
    min_area: int = 12
    max_area: int = 240
    min_size: int = 3
    max_size: int = 24
    radius: float = 0


@dataclass
class Objective:
    name: str
    x: float
    y: float
    radius: float = .14


@dataclass
class Profile:
    roi: Rect = field(default_factory=lambda: Rect(0, 0, 0, 0))
    target_size: tuple = (1920, 1080)
    dpi: int = 96
    monitor: str = ""
    teams: list[TeamColor] = field(default_factory=list)
    exclusions: list[tuple] = field(default_factory=list)
    objectives: list[Objective] = field(default_factory=list)
    fps: int = 15
    overlay_key: str = "Ctrl+Alt+F9"
    analysis_key: str = "Ctrl+Alt+F10"
    contact_radius: float = .14
    approach_radius: float = .25
    marker_mode: str = 'components'

    def validate(self):
        from .hotkeys import parse_hotkey
        try:
            if len(self.target_size) != 2 or any(type(v) is not int or v <= 0 for v in self.target_size):
                raise ValueError("Некорректный размер окна")
            if any(type(v) is not int for v in asdict(self.roi).values()):
                raise ValueError("Область карты задаётся целыми пикселями")
            if self.roi.width < 20 or self.roi.height < 20 or not Rect(0, 0, *self.target_size).contains(self.roi):
                raise ValueError("Выберите область миникарты внутри окна игры")
            if type(self.fps) is not int or not 5 <= self.fps <= 30 or not 48 <= self.dpi <= 480:
                raise ValueError("Частота: 5–30 кадров/с; проверьте DPI")
            if sorted(t.team for t in self.teams) != [1, 2]:
                raise ValueError("Нужна калибровка двух разных команд")
            for t in self.teams:
                if (not 0 <= t.hue <= 179 or not 1 <= t.tolerance <= 30
                        or not 1 <= t.saturation_min <= 255 or not 1 <= t.value_min <= 255
                        or not 1 <= t.min_area <= t.max_area <= 10000
                        or not 1 <= t.min_size <= t.max_size <= 200
                        or not 0 <= t.radius <= 200):
                    raise ValueError("Проверьте цвет и размер значков команд")
            if self.marker_mode not in ('components','portraits'):
                raise ValueError('Неизвестный способ распознавания значков')
            if self.marker_mode=='portraits' and any(t.radius<2 for t in self.teams):
                raise ValueError('Не определён размер портретов героев')
            a, b = parse_hotkey(self.overlay_key), parse_hotkey(self.analysis_key)
            if a == b:
                raise ValueError("Для видимости и анализа нужны разные клавиши")
            if not 0.01 <= self.contact_radius < self.approach_radius <= .5:
                raise ValueError("Проверьте радиусы интереса")
            for r in self.exclusions:
                if len(r) != 4 or not all(math.isfinite(v) for v in r):
                    raise ValueError("Некорректная маска исключения")
                x, y, w, h = r
                if not (0 <= x < 1 and 0 <= y < 1 and w > 0 and h > 0 and x+w <= 1.000001 and y+h <= 1.000001):
                    raise ValueError("Маска исключения вне миникарты")
            for o in self.objectives:
                if not o.name.strip() or not (0 <= o.x <= 1 and 0 <= o.y <= 1 and 0 < o.radius <= .5):
                    raise ValueError("Некорректный объект")
        except (TypeError, AttributeError, OverflowError) as exc:
            raise ValueError("Некорректные поля профиля") from exc

    def save(self, path: Path):
        self.validate()
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_suffix(path.suffix + '.tmp')
        temp.write_text(json.dumps(asdict(self), ensure_ascii=False, indent=2), encoding='utf-8')
        temp.replace(path)

    @classmethod
    def load(cls, path: Path):
        try:
            data = json.loads(Path(path).read_text(encoding='utf-8'))
            data['roi'] = Rect(**data['roi'])
            data['teams'] = [TeamColor(**t) for t in data['teams']]
            data['objectives'] = [Objective(**o) for o in data.get('objectives', [])]
            data['target_size'] = tuple(data['target_size'])
            data['exclusions'] = [tuple(r) for r in data.get('exclusions', [])]
            p = cls(**data)
            p.validate()
            return p
        except (ValueError, TypeError, KeyError, OSError) as exc:
            raise ValueError(f"Не удалось загрузить профиль: {exc}") from exc
