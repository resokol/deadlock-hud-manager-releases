"""Draw spectator minimap keys in a capture-excluded Windows overlay."""

from PySide6.QtCore import QRect, QRectF, Qt
from PySide6.QtGui import QColor, QGuiApplication, QPainter, QPen
from PySide6.QtWidgets import QWidget

from .capture import physical_to_logical
from .hud_desktop import FLAGS, screen_for_monitor
from .win32 import WindowsApi


class LocalMinimapOverlay(QWidget):
    def __init__(self, api=None):
        super().__init__(None, FLAGS)
        self.api = WindowsApi() if api is None else api
        self.setWindowTitle('Deadlock Local Minimap Labels')
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self._markers = ()
        self._mode = 'overlay'
        self._protected = None
        self._client_size = (1, 1)

    def clear(self):
        self._markers = ()
        self.hide()

    def display(self, markers, mode):
        if not markers:
            self.clear()
            return True
        game = self.api.foreground_snapshot()
        if (game is None or not game.visible or game.minimized or game.title.casefold() != 'deadlock'
                or game.rect.width <= 100 or game.rect.height <= 100):
            self.clear()
            return True
        try:
            monitor, name = self.api.monitor(game.hwnd)
        except RuntimeError:
            self.clear()
            return True
        screen = screen_for_monitor(QGuiApplication.screens(), monitor, name)
        if screen is None:
            self.clear()
            return True
        origin = screen.geometry().topLeft()
        rect = QRect(*physical_to_logical(game.rect, monitor, (origin.x(), origin.y()), screen.devicePixelRatio()))
        if rect != self.geometry():
            self.setGeometry(rect)
        self._client_size = game.rect.width, game.rect.height

        hwnd = int(self.winId())
        if self._protected != hwnd or not self.api.overlay_is_excluded(hwnd):
            self.clear()
            self._protected = None
            if not self.api.exclude_overlay(hwnd):
                return False
            self._protected = hwnd
        self._markers = markers
        self._mode = mode
        if not self.isVisible():
            self.show()
        self.update()
        return True

    def paintEvent(self, event):
        if not self._markers:
            return
        hwnd = int(self.winId())
        if self._protected != hwnd or not self.api.overlay_is_excluded(hwnd):
            return
        with QPainter(self) as painter:
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            font = painter.font()
            font.setBold(True)
            for marker in self._markers:
                client_w, client_h = self._client_size if marker.client_pixels else (10000, 10000)
                if marker.x > client_w or marker.y > client_h:
                    continue
                scale_x, scale_y = self.width() / client_w, self.height() / client_h
                x, y = marker.x * scale_x, marker.y * scale_y
                width, height = marker.width * scale_x, marker.height * scale_y
                if self._mode == 'replace':
                    # Mask the portrait on this desktop surface alone.
                    box_w, box_h = max(18, width + 4), max(18, height + 4)
                    rect = QRectF(x - box_w / 2, y - box_h / 2, box_w, box_h)
                    color = QColor('#141922')
                else:
                    badge = min(22, max(12, height * 0.68))
                    rect = QRectF(x + width / 2 - badge * 0.65, y - height / 2 - badge * 0.25, badge, badge)
                    color = QColor(20, 25, 34, 240)
                side_color = QColor('#79e0f6' if marker.side == 0 else '#ffb574')
                painter.setPen(QPen(side_color, 1.0))
                painter.setBrush(color)
                painter.drawRoundedRect(rect, 3, 3)
                font.setPixelSize(round(min(26, rect.height() * 0.77)))
                painter.setFont(font)
                painter.setPen(QColor('#ffffff'))
                painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, marker.key)
