"""Validate native HUD options and apply them to a managed Panorama pack."""

import json
import re
from pathlib import Path
from tempfile import TemporaryDirectory

from .panorama_outline import OUTLINE_RESOURCE


NATIVE_HUD_ELEMENTS = (
    'minimap', 'topBar', 'health', 'abilities', 'items', 'stats', 'killFeed',
    'spectatorControls', 'announcements', 'chat',
)
NATIVE_HUD_MARKER = b'const nativeHudOptions = null;'


def normalize_native_hud_options(options):
    if options is None:
        return None
    if not isinstance(options, dict) or options.keys() - {'minimapBackground', 'elements', 'minimapTeamColors'}:
        raise ValueError('Некорректные настройки игрового HUD.')
    background = options.get('minimapBackground', True)
    elements = options.get('elements', {})
    colors = options.get('minimapTeamColors')
    if (type(background) is not bool or not isinstance(elements, dict) or
            elements.keys() - set(NATIVE_HUD_ELEMENTS) or any(type(value) is not bool for value in elements.values())):
        raise ValueError('Некорректные настройки элементов игрового HUD.')
    if colors is not None and (not isinstance(colors, dict) or colors.keys() != {'left', 'right'} or
                               any(not isinstance(value, str) or not re.fullmatch(r'#[0-9a-fA-F]{6}', value)
                                   for value in colors.values())):
        raise ValueError('Некорректные цвета команд на миникарте.')
    if background and not elements and colors is None:
        return None
    normalized = {key: elements[key] for key in NATIVE_HUD_ELEMENTS if key in elements}
    result = {'minimapBackground': background, 'elements': normalized}
    if colors is not None:
        result['minimapTeamColors'] = {side: value.lower() for side, value in colors.items()}
    return result


def rewrite_native_hud_pack(source, output, options, *, outline=None):
    source = Path(source)
    normalized = normalize_native_hud_options(options)
    if normalized is None:
        return source

    from .build_panorama_health import ADDON_SCRIPT, read_resource, read_vpk, write_resource, write_vpk

    output = Path(output)
    if output.resolve() == source.resolve():
        raise ValueError('Сохраните пакет с настройками игрового HUD отдельно от исходного.')
    resources = read_vpk(source, None)
    if ADDON_SCRIPT not in resources:
        raise ValueError('Пакет Panorama не поддерживает настройки игрового HUD.')
    kind, blocks = read_resource(resources[ADDON_SCRIPT])
    script = blocks.get(b'DATA', b'')
    if script.count(NATIVE_HUD_MARKER) != 1:
        raise ValueError('Пакет Panorama не поддерживает настройки игрового HUD.')
    body = json.dumps(normalized, separators=(',', ':'), sort_keys=True).encode('ascii')
    blocks[b'DATA'] = script.replace(NATIVE_HUD_MARKER, b'const nativeHudOptions = ' + body + b';', 1)
    resources[ADDON_SCRIPT] = write_resource(kind, blocks)
    if outline is not None:
        resources[OUTLINE_RESOURCE] = outline

    output.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(dir=output.parent, prefix='.panorama-') as directory:
        staged = Path(directory) / output.name
        write_vpk(staged, resources)
        staged.replace(output)
    return output
