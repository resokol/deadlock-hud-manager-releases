from dataclasses import replace
import json
from pathlib import Path
import re
import subprocess
import sys
from threading import Lock, Thread
from time import monotonic
import unicodedata


_HOST = re.compile(rb'\[HostStateManager\] Host activate: ([^\r\n]+)')
_RELAY = re.compile(rb'Playing Broadcast \((https?://[a-z0-9-]+\.steamcontent\.com/tv/([0-9]+)_[0-9]+)\b')
_MAX_LOG_BYTES = 32 * 1024 * 1024
_MAX_AGE = 12


def relay_from_log(path):
    with path.open('rb') as log:
        size = log.seek(0, 2)
        log.seek(max(0, size - _MAX_LOG_BYTES))
        data = log.read(_MAX_LOG_BYTES)
    latest = data.rfind(b'[HostStateManager] Host activate: ')
    if latest == -1:
        return None
    host = _HOST.match(data, latest)
    relay = _RELAY.match(host[1]) if host else None
    return (relay[1].decode('ascii'), relay[2].decode('ascii')) if relay else None


def _identity(name):
    return unicodedata.normalize('NFKC', name).strip().casefold()


def merge_scores(frame, match_id, players):
    if frame.state != 'sample' or not frame.roster or len(players) != len(frame.roster):
        return frame
    names = [_identity(row.player) for row in frame.roster]
    if len(set(names)) != len(names) or set(names) != players.keys():
        return frame
    roster = tuple(replace(row, kills=str(players[key][0]),
                           deaths=str(players[key][1]), assists=str(players[key][2]))
                   for row, key in zip(frame.roster, names))
    return replace(frame, match_id=match_id, roster=roster)


class SourceTV:
    def __init__(self, worker, log_path):
        self.worker, self.log_path = Path(worker).resolve(), Path(log_path)
        self._session = None
        self._match = None
        self._process = None
        self._snapshot = None
        self._lock = Lock()
        self._last_sample = None
        self._retry_after = 0

    def close(self):
        with self._lock:
            process, self._process = self._process, None
            self._snapshot = None
        if process is not None and process.poll() is None:
            process.terminate()

    def observe(self, frame):
        now = monotonic()
        if frame and frame.state == 'sample':
            self._last_sample = now
            if frame.session != self._session:
                self.close()
                self._session = frame.session
                self._retry_after = 0
            if now >= self._retry_after and (self._process is None or self._process.poll() is not None):
                self._retry_after = now + 15
                self._start()
        elif frame and frame.state in ('waiting_for_observer', 'final'):
            self.close()
            self._session = None
        elif self._last_sample is not None and now - self._last_sample > 15:
            self.close()
            self._session = None
            self._last_sample = None

    def _start(self):
        try:
            source = relay_from_log(self.log_path)
            if source is None:
                return
            url, match = source
            options = {'creationflags': subprocess.CREATE_NO_WINDOW} if sys.platform == 'win32' else {}
            self._match = match
            process = subprocess.Popen(['node', str(self.worker), url], stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, encoding='utf-8', **options)
            self._process = process
        except OSError:
            return
        Thread(target=self._read, args=(process, match), daemon=True, name='sourcetv-scores').start()

    def _read(self, process, match):
        try:
            with process.stdout as lines:
                for line in lines:
                    if len(line) > 12000:
                        continue
                    packet = json.loads(line)
                    if not isinstance(packet, dict) or packet.get('match_id') != match:
                        continue
                    rows = packet['players']
                    if not isinstance(rows, list) or len(rows) not in (8, 12):
                        continue
                    scores = {_identity(name): (kills, deaths, assists) for name, kills, deaths, assists in rows
                              if isinstance(name, str) and all(type(n) is int and n >= 0 for n in (kills, deaths, assists))}
                    if len(scores) != len(rows) or '' in scores:
                        continue
                    with self._lock:
                        if self._process is not process:
                            return
                        self._snapshot = (monotonic(), scores)
        except (OSError, UnicodeError, ValueError, KeyError, TypeError):
            pass
        finally:
            process.wait()

    def enrich(self, frame):
        with self._lock:
            snapshot = self._snapshot
        if frame.session == self._session and snapshot and monotonic() - snapshot[0] <= _MAX_AGE:
            return merge_scores(frame, self._match, snapshot[1])
        return frame
