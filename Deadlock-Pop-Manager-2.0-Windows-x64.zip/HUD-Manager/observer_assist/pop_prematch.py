"""Prepare the verified vMix camera banks as guests arrive, before a match is locked."""

from ipaddress import IPv4Address
from time import monotonic
from xml.etree.ElementTree import ParseError

from PySide6.QtCore import QObject, QTimer, QUrl, Signal

from .camera_native_sync import check_native_layout, read_native_catalog
from .camera_vdo_publish import VmixRequest
from .match_stats import is_lan_address


class NativePrematch(QObject):
    status = Signal(str)
    changed = Signal()

    def __init__(self, panel, room, bindings, publisher, parent=None, *, monitor, authorize=None):
        super().__init__(parent)
        self.panel, self.room, self.bindings = panel, room, bindings
        self.publisher, self.monitor, self.authorize = publisher, monitor, authorize
        self.ready = False
        self.message = ''
        self._suspended = self._closed = self._busy = False
        self._dirty = False
        self._owned_monitor = None
        self._media_verified = False
        self._catalog_key = None
        self._session = None
        self._revision = 0
        self._http = VmixRequest(self)
        self._timer = QTimer(self, singleShot=True)
        self._timer.timeout.connect(self._read)
        self._delay = 1000
        self._name_wait = {}
        panel.workflow_changed.connect(self.refresh)
        panel.originals_changed.connect(self.refresh)
        room.freshness_changed.connect(self.refresh)
        bindings.changed.connect(self.refresh)
        publisher.finished.connect(self.refresh)
        monitor.source_navigated.connect(self.refresh)
        panel.vmix_host.textChanged.connect(self.refresh)
        panel.vmix_port.valueChanged.connect(self.refresh)
        self.refresh()

    def _context(self):
        if self._closed or self._suspended or not self.room.fresh or not self.panel.native_preparation:
            return None
        try:
            ip = IPv4Address(self.panel.vmix_host.text().strip())
            if not (ip.is_loopback or is_lan_address(ip)):
                return None
        except ValueError:
            return None
        return self.room.generation, (str(ip), self.panel.vmix_port.value())

    def _state(self, ready, message):
        changed = self.ready != ready or self.message != message
        self.ready = ready
        if self.message != message:
            self.message = message
            self.status.emit(message)
        if changed:
            self.changed.emit()

    def _pause(self):
        self._revision += 1
        self._timer.stop()
        self._http.cancel()
        self._busy = False
        self._media_verified = False
        self._name_wait.clear()
        if self._owned_monitor is not None:
            self._owned_monitor = None
            self.monitor.stop()

    def set_suspended(self, suspended):
        suspended = bool(suspended)
        if self._suspended != suspended:
            self._suspended = suspended
            self.refresh()

    def stop(self):
        self._closed = True
        self._pause()
        self._state(False, '')

    def refresh(self, *_):
        context = self._context()
        if context != self._session:
            self._pause()
            self._session = context
            self._catalog_key = None
        if not context:
            self._state(False, '')
            return
        if self._busy:
            self._dirty = True
        elif not self.publisher.busy:
            self._timer.start(0)

    def _retry(self, message, *, keep_media=False):
        self._busy = False
        if not keep_media:
            self._media_verified = False
        self._state(False, message)
        if self._session:
            self._timer.start(self._delay)
            self._delay = min(30000, self._delay * 2)

    def _allowed(self, pairs):
        guids = {guid for pair in pairs for guid in (pair.original_guid, pair.virtual_guid)}
        return self.authorize is None or self.authorize(self._session[1], guids)

    def _monitor_valid(self):
        if (not self._owned_monitor or not self._media_verified or self._session != self._context()
                or not self._session or not self.bindings.confirmed or self.publisher.busy):
            return False
        topology, pairs = self._owned_monitor
        return topology[0] == self._catalog_key and dict(topology[1]) == self.bindings.mapping() and self._allowed(pairs)

    def _monitor_media(self):
        return {row.guid: (row.media, row.page) for row in self.panel.prepared_originals}

    def _read(self):
        if self._busy or not self._session or self._session != self._context() or self.publisher.busy:
            return
        self._busy = True
        self._dirty = False
        revision = self._revision
        _, (host, port) = self._session
        url = QUrl(f'http://{host}:{port}/api/')

        def receive(error, xml):
            if revision != self._revision:
                return
            if self._session != self._context() or self.publisher.busy:
                self._busy = False
                self.refresh()
                return
            if error:
                self._retry('Ожидание подключения к vMix.')
                return
            try:
                state, parents = read_native_catalog(xml)
                self._reconcile(state, parents, url, revision)
            except (ParseError, ValueError) as exc:
                self._retry(str(exc) if isinstance(exc, ValueError) else 'Некорректный каталог входов vMix.')

        self._http.send(url, None, receive)

    def _reconcile(self, state, parents, url, revision):
        _, endpoint = self._session
        browsers = {state.inputs[guid]['number']: guid for guid in state.browsers}
        preview = self.panel.prematch_inventory(endpoint, state.preset, browsers)
        if not preview:
            raise ValueError('Проверьте оригиналы Web Browser на входах 1–12.')
        banks = tuple(sorted((i['number'], guid, parents.get(guid), i.get('type'), i.get('virtual'))
                             for guid, i in state.inputs.items() if i['number'] <= 24))
        key = self._session, state.preset, banks
        if key != self._catalog_key:
            self._media_verified = False
            self._catalog_key = key
            self._name_wait.clear()
            self._state(False, 'Проверяем пары оригиналов и виртуальных копий.')
            self._busy = False
            self.bindings.set_receipt(preview)
            return
        if not self.bindings.confirmed:
            self._media_verified = False
            self._busy = False
            self._state(False, 'Проверьте и подтвердите связи оригиналов с виртуальными копиями.')
            return
        pairs = self.bindings.pairs(preview.rows)
        check_native_layout(state, parents, pairs, require_names=False)
        if not self._allowed(pairs):
            self._retry('Входами камер управляет другой модуль vMix.')
            return
        inventory = self.panel.prematch_inventory(endpoint, state.preset, browsers, verified=True)
        if not inventory:
            self._media_verified = False
            self._busy = False
            self._state(False, 'Проверьте назначения гостей и их уникальные игровые имена.')
            return
        pairs = self.bindings.pairs(inventory.rows)
        check_native_layout(state, parents, pairs, require_names=False)
        # A title may change as the browser finishes navigating. Caption repair may
        # run while a different verified source's page acknowledgement is in flight.
        self._media_verified = True
        for pair, row in zip(pairs, inventory.rows):
            if not row.name and row.media == 'unknown':
                continue
            if len(pair.name) > 246 or not (pair.name or '-').isprintable() or '://' in pair.name:
                raise ValueError('Проверьте имя гостя в комнате.')
            names = ((pair.original_guid, pair.name or '-'),
                     (pair.virtual_guid, pair.name + ' - Virtual' if pair.name else '-'))
            for guid, title in names:
                if state.inputs[guid]['title'] == title:
                    self._name_wait.pop(guid, None)
                    continue
                wanted, deadline = self._name_wait.get(guid, ('', 0))
                if wanted == title and deadline > monotonic():
                    self._retry('Ожидание подтверждения названия в каталоге vMix.', keep_media=True)
                    return
                self._state(False, 'Обновляем названия камер в vMix.')
                if (self._session != self._context() or self.publisher.busy or not self.bindings.confirmed
                        or revision != self._revision):
                    self._busy = False
                    self.refresh()
                    return

                def renamed(error, _):
                    if self._revision != revision:
                        return
                    if error:
                        self._retry('vMix не подтвердил переименование входа.', keep_media=True)
                    else:
                        self._name_wait[guid] = (title, monotonic() + 2)
                        self._busy = False
                        self.refresh()  # Pin the next write to a new catalog and the latest room data.

                self._http.send(url, dict(Function='SetInputName', Input=guid, Value=title), renamed)
                return
        self._busy = False
        self._delay = 1000
        message = f'Назначено гостей · {sum(bool(row.name) for row in inventory.rows)} из 12.'
        if any(g.issue for g in self.panel.room_guests):
            message += ' Уточните совпадающие или пустые ники в разделе «Имена гостей».'
        self._state(True, message)
        topology = key, tuple((p.original_guid, p.virtual_guid) for p in pairs)
        if not self._owned_monitor or self._owned_monitor[0] != topology:
            self._owned_monitor = topology, pairs
            self.monitor.start(endpoint, state.preset, pairs, media=self._monitor_media,
                               validate=self._monitor_valid, prematch=True)
        else:
            self.monitor.refresh()
        if self._dirty:
            self.refresh()
