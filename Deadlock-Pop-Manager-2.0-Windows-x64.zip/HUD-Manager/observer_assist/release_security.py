"""Signed, purpose-specific licenses and update metadata."""

import base64
import json
import re
import secrets
from time import time

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey


MAX_LICENSE_DAYS = 3650
LICENSE = 'dhm1'
UPDATE = 'dhm-update1'


def encode(data):
    return base64.urlsafe_b64encode(data).rstrip(b'=').decode('ascii')


def decode(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_-]+', value):
        raise ValueError('Некорректная кодировка подписи.')
    try:
        decoded = base64.urlsafe_b64decode(value + '=' * (-len(value) % 4))
    except ValueError as exc:
        raise ValueError('Некорректная кодировка подписи.') from exc
    if encode(decoded) != value:
        raise ValueError('Некорректная кодировка подписи.')
    return decoded


def signed_record(kind, record, key):
    contents = json.dumps(record, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode('ascii')
    message = kind.encode('ascii') + b'.' + encode(contents).encode('ascii')
    signature = Ed25519PrivateKey.from_private_bytes(decode(key)).sign(message)
    return message.decode('ascii') + '.' + encode(signature)


def verified_record(kind, token, key, *, limit):
    if not isinstance(token, str) or len(token) > limit:
        raise ValueError('Недопустимый размер подписанных данных.')
    parts = token.split('.')
    if len(parts) != 3 or parts[0] != kind:
        raise ValueError('Неизвестный формат подписанных данных.')
    _, body, signature = parts
    try:
        public = Ed25519PublicKey.from_public_bytes(decode(key))
        public.verify(decode(signature), (kind + '.' + body).encode('ascii'))
        record = json.loads(decode(body))
    except (InvalidSignature, UnicodeError, ValueError) as exc:
        raise ValueError('Подпись не прошла проверку.') from exc
    if not isinstance(record, dict):
        raise ValueError('Некорректные подписанные данные.')
    return record


def issue_license(days, private_key, *, now=None):
    if type(days) is not int or not 1 <= days <= MAX_LICENSE_DAYS:
        raise ValueError(f'Укажите количество дней от 1 до {MAX_LICENSE_DAYS}.')
    now = int(time()) if now is None else now
    return signed_record(LICENSE, {
        'id': secrets.token_hex(8), 'issued': now, 'expires': now + days * 86400,
    }, private_key)


def check_license(token, public_key, *, now=None):
    record = verified_record(LICENSE, token, public_key, limit=1024)
    issued, expires, code = (record.get(field) for field in ('issued', 'expires', 'id'))
    now = int(time()) if now is None else now
    if (type(issued) is not int or type(expires) is not int or not isinstance(code, str)
            or not re.fullmatch(r'[0-9a-f]{16}', code)
            or issued <= 0 or not 0 < expires - issued <= MAX_LICENSE_DAYS * 86400):
        raise ValueError('Некорректные данные лицензии.')
    if issued > now + 300:
        raise ValueError('Лицензия ещё не действует. Проверьте дату и время Windows.')
    if expires <= now:
        raise ValueError('Срок лицензии истёк.')
    return expires
