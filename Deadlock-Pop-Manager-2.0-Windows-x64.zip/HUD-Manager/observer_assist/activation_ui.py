"""Windows activation and temporary offline access for an already licensed device."""

from datetime import datetime
from http.client import HTTPException
from queue import SimpleQueue
from threading import Thread

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QDialog, QLabel, QLineEdit, QPushButton, QVBoxLayout
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from . import device_key
from .activation import check_lease, detach, public_key, redeem, renew
from .release_security import encode


_KEY = 'release/deviceKey'
_LEASE = 'release/lease'


class ActivationAccess:
    def __init__(self, config, settings):
        self.config, self.settings = config, settings
        protected = settings.value(_KEY, '', type=str)
        if protected:
            self.secret = device_key.unseal(protected)
        else:
            self.secret = encode(Ed25519PrivateKey.generate().private_bytes_raw())
            settings.setValue(_KEY, device_key.seal(self.secret))
            settings.sync()
        self.public = public_key(self.secret)
        self.record = None
        self.usable = False
        token = settings.value(_LEASE, '', type=str)
        if token:
            try:
                self.record = check_lease(token, config['licenseKey'], self.public, allow_expired=True)
                self.usable = bool(check_lease(token, config['licenseKey'], self.public))
            except ValueError:
                pass

    def redeem(self, code):
        return redeem(self.config['activation'], self.config['licenseKey'], self.secret, code)

    def renew(self, license_id):
        return renew(self.config['activation'], self.config['licenseKey'], self.secret, license_id)

    def detach(self, license_id):
        return detach(self.config['activation'], self.secret, license_id)

    def save(self, result):
        token, self.record = result
        self.usable = True
        self.settings.setValue(_LEASE, token)
        self.settings.sync()

    def revoke(self):
        self.usable = False
        self.record = None
        self.settings.remove(_LEASE)
        self.settings.sync()

    def open_dialog(self, parent=None):
        dialog = ActivationDialog(self, parent)
        return dialog.exec() == QDialog.DialogCode.Accepted


class ActivationDialog(QDialog):
    def __init__(self, access, parent):
        super().__init__(parent)
        self.access = access
        self.jobs = SimpleQueue()
        self.setWindowTitle('Активация Deadlock HUD Manager')
        self.setMinimumWidth(440)
        layout = QVBoxLayout(self)
        intro = QLabel('Вставьте код от администратора @dhmtoken_bot. При активации код закрепится за этой установкой.')
        intro.setWordWrap(True)
        layout.addWidget(intro)
        self.code = QLineEdit(placeholderText='Код dhma1_…')
        self.code.setAccessibleName('Код активации')
        self.code.setMaxLength(64)
        self.code.setEchoMode(QLineEdit.EchoMode.Password)
        self.code.returnPressed.connect(self._redeem)
        layout.addWidget(self.code)
        expiry = access.record['expires'] if access.record else None
        self.status = QLabel(f'Лицензия до {datetime.fromtimestamp(expiry):%d.%m.%Y %H:%M}' if expiry else '')
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.activate_button = QPushButton('Активировать')
        self.activate_button.clicked.connect(self._redeem)
        layout.addWidget(self.activate_button)
        self.refresh_button = QPushButton('Продлить доступ через сервер')
        self.refresh_button.setVisible(access.record is not None)
        self.refresh_button.clicked.connect(self._renew)
        layout.addWidget(self.refresh_button)
        cancel = QPushButton('Закрыть')
        cancel.clicked.connect(self.reject)
        layout.addWidget(cancel)
        self.timer = QTimer(self, interval=100)
        self.timer.timeout.connect(self._result)

    def _redeem(self):
        code = self.code.text().strip()
        self._start(lambda: self.access.redeem(code))

    def _renew(self):
        if self.access.record:
            license_id = self.access.record['license']
            self._start(lambda: self.access.renew(license_id))

    def _start(self, call):
        if self.timer.isActive():
            return
        self.activate_button.setEnabled(False)
        self.refresh_button.setEnabled(False)
        self.status.setText('Связываемся с сервером активации…')
        jobs = self.jobs

        def worker():
            try:
                jobs.put((call(), None))
            except (OSError, HTTPException, ValueError) as exc:
                jobs.put((None, exc))

        Thread(target=worker, daemon=True).start()
        self.timer.start()

    def _result(self):
        if self.jobs.empty():
            return
        self.timer.stop()
        result, error = self.jobs.get()
        if error:
            self.status.setText(str(error))
            self.activate_button.setEnabled(True)
            self.refresh_button.setEnabled(True)
        else:
            self.access.save(result)
            self.accept()
