"""Build the optional Panorama HP sampler into a separate VPK."""

import argparse
from pathlib import Path
import re
import struct
from urllib.request import urlopen
import zlib

from .panorama_mount import NUMBER_MODES


STOCK_LAYOUT = 'panorama/layout/base_hud.vxml_c'
OVERLAY_LAYOUT = 'panorama/layout/citadel_hud_and_db_overlay.vxml_c'
SCRIPT_TEMPLATE = 'panorama/scripts/async.vts_c'
ADDON_SCRIPT = 'panorama/scripts/doa_health_sampler.vts_c'
MATCH_SCRIPT = 'panorama/scripts/doa_match_id.vts_c'
MINIMAP_SVG_TEMPLATE = 'panorama/images/hud/core/icon_damage_force.vsvg_c'
MINIMAP_BACKDROP = 'panorama/images/doa/minimap_surface.vsvg_c'
STOCK_LAYOUT_SOURCE = ('https://raw.githubusercontent.com/SteamTracking/GameTracking-Deadlock/'
                       'master/game/citadel/pak01_dir/panorama/layout/base_hud.xml')
OVERLAY_LAYOUT_SOURCE = STOCK_LAYOUT_SOURCE.replace('base_hud.xml', 'citadel_hud_and_db_overlay.xml')
VPK_SIGNATURE = 0x55AA1234


def read_vpk(index, resources):
    archive = index.read_bytes()
    magic, version, tree_size = struct.unpack_from('<III', archive)
    if (magic, version) != (VPK_SIGNATURE, 2):
        raise ValueError('Ожидался индекс Steam VPK версии 2.')
    offset = 28
    end_of_tree = offset + tree_size

    def word():
        nonlocal offset
        end = archive.index(b'\0', offset, end_of_tree)
        value = archive[offset:end].decode('utf-8')
        offset = end + 1
        return value

    result = {}
    while extension := word():
        while directory := word():
            while filename := word():
                _, preload_size, part, start, length, terminator = struct.unpack_from('<IHHIIH', archive, offset)
                offset += 18
                preload = archive[offset:offset + preload_size]
                offset += preload_size
                if terminator != 0xFFFF or offset > end_of_tree:
                    raise ValueError('Повреждён индекс ресурсов Steam.')
                name = f'{directory}/{filename}.{extension}'
                if resources is not None and name not in resources:
                    continue
                if part == 0x7FFF:
                    start += end_of_tree
                    data = archive[start:start + length]
                else:
                    chunk = index.with_name(index.name.replace('_dir.vpk', f'_{part:03d}.vpk'))
                    with chunk.open('rb') as stream:
                        stream.seek(start)
                        data = stream.read(length)
                if len(data) != length:
                    raise ValueError(f'Неполный ресурс Panorama {name}.')
                result[name] = preload + data
                if resources is not None and result.keys() == resources:
                    return result
    if resources is None:
        return result
    missing = ', '.join(sorted(resources - result.keys()))
    raise ValueError(f'Ресурсы не найдены: {missing}')


def read_resource(data):
    _, version, kind, header_offset, count = struct.unpack_from('<IHHII', data)
    if version != 12 or header_offset != 8:
        raise ValueError('Неизвестный формат ресурса Panorama.')
    blocks = {}
    for i in range(count):
        header = 16 + 12 * i
        tag, offset, size = struct.unpack_from('<4sII', data, header)
        start = header + 4 + offset
        if start + size > len(data):
            raise ValueError('Неполный блок ресурса Panorama.')
        blocks[tag] = data[start:start + size]
    return kind, blocks


def write_resource(kind, blocks):
    data = bytearray(16 + 12 * len(blocks))
    for i, (tag, payload) in enumerate(blocks.items()):
        data.extend(bytes(-len(data) % 16))
        header = 16 + i * 12
        struct.pack_into('<4sII', data, header, tag, len(data) - header - 4, len(payload))
        data.extend(payload)
    struct.pack_into('<IHHII', data, 0, len(data), 12, kind, 8, len(blocks))
    return data


def write_vpk(path, files):
    groups = {}
    for name, payload in files.items():
        directory, filename = name.rsplit('/', 1)
        stem, extension = filename.rsplit('.', 1)
        groups.setdefault(extension, {}).setdefault(directory, {})[stem] = payload
    tree = bytearray()
    content = bytearray()
    for extension, directories in groups.items():
        tree.extend(extension.encode() + b'\0')
        for directory, entries in directories.items():
            tree.extend(directory.encode() + b'\0')
            for stem, payload in entries.items():
                tree.extend(stem.encode() + b'\0')
                tree.extend(struct.pack('<IHHIIH', zlib.crc32(payload), 0, 0x7FFF, len(content), len(payload), 0xFFFF))
                content.extend(payload)
            tree.append(0)
        tree.append(0)
    tree.append(0)
    with path.open('xb') as stream:
        stream.write(struct.pack('<7I', VPK_SIGNATURE, 2, len(tree), len(content), 0, 0, 0))
        stream.write(tree)
        stream.write(content)


def _layout_source(url):
    with urlopen(url, timeout=10) as response:
        return response.read(8192).decode('utf-8')


def _include(xml, script):
    if (xml.count('</styles>') != 1 or '<scripts>' in xml or
            not xml.rstrip().endswith('</root>')):
        raise ValueError('Структура HUD изменилась. VPK не создан.')
    include = f'</styles>\n<scripts><include src="s2r://{script}" /></scripts>'
    return xml.replace('</styles>', include).encode('utf-8')


def _layout_resource(resource, xml):
    kind, blocks = read_resource(resource)
    layout_blocks = {tag: blocks[tag] for tag in (b'RERL', b'RED2') if tag in blocks}
    layout_blocks[b'DATA'] = struct.pack('<IH', zlib.crc32(xml), 0) + xml
    return write_resource(kind, layout_blocks)


def build(citadel, output, minimap_only=False, numbers='off'):
    if numbers not in ('off', *NUMBER_MODES):
        raise ValueError('Неизвестный режим номеров на миникарте.')
    resources = read_vpk(citadel / 'pak01_dir.vpk', {STOCK_LAYOUT, OVERLAY_LAYOUT, SCRIPT_TEMPLATE, MINIMAP_SVG_TEMPLATE})
    xml = _layout_source(STOCK_LAYOUT_SOURCE)
    if not re.search(r'<CitadelHud\s+id="Hud"', xml):
        raise ValueError('Структура базового HUD изменилась. VPK не создан.')
    overlay = _layout_source(OVERLAY_LAYOUT_SOURCE)
    debug_label = '<Label id="ClientServerDebugStats"'
    if overlay.count(debug_label) != 1:
        raise ValueError('Подпись состояния сервера в HUD изменилась. VPK не создан.')
    overlay = overlay.replace(debug_label, debug_label + ' style="opacity: 0;"')
    script_kind, script_blocks = read_resource(resources[SCRIPT_TEMPLATE])
    directory = Path(__file__).parent / 'panorama'
    script = b'\n'.join((directory / name).read_bytes() for name in (
        'spectator_slots.js', 'native_hud_elements.js', 'native_objectives.js', 'health_sampler.js',
    ))
    overlay_script = (directory / 'match_id.js').read_bytes()
    default_mode = b'const wantsMinimapOnly = false;'
    if script.count(default_mode) != 1:
        raise ValueError('Не найдено место для режима HUD.')
    if minimap_only:
        script = script.replace(default_mode, b'const wantsMinimapOnly = true;')
        default_logo = b'const hideDefaultLogo = false;'
        if overlay_script.count(default_logo) != 1:
            raise ValueError('Не найдено место для настройки логотипа в HUD.')
        overlay_script = overlay_script.replace(default_logo, b'const hideDefaultLogo = true;')
    if numbers != 'off':
        module = (directory / 'minimap_numbers.js').read_bytes()
        default_numbers = b"const mode = 'off';"
        if module.count(default_numbers) != 1:
            raise ValueError('Не найдено место для режима номеров на миникарте.')
        script += b'\n' + module.replace(default_numbers, f"const mode = '{numbers}';".encode())
    write_vpk(output, {
        STOCK_LAYOUT: _layout_resource(resources[STOCK_LAYOUT], _include(xml, ADDON_SCRIPT)),
        OVERLAY_LAYOUT: _layout_resource(resources[OVERLAY_LAYOUT], _include(overlay, MATCH_SCRIPT)),
        ADDON_SCRIPT: write_resource(script_kind, {**script_blocks, b'DATA': script}),
        MATCH_SCRIPT: write_resource(script_kind, {**script_blocks, b'DATA': overlay_script}),
        MINIMAP_BACKDROP: _layout_resource(
            resources[MINIMAP_SVG_TEMPLATE], (directory / 'minimap_surface.svg').read_bytes(),
        ),
    })


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('citadel', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--minimap-only', action='store_true')
    parser.add_argument('--minimap-numbers', choices=NUMBER_MODES, default='off')
    args = parser.parse_args()
    build(args.citadel, args.output, args.minimap_only, args.minimap_numbers)
    print(args.output)


if __name__ == '__main__':
    main()
