function participant(controller) {
    if (controller?.class.name !== 'CCitadelPlayerController') return null;
    const team = controller.getField('m_iTeamNum');
    const name = controller.getField('m_iszPlayerName');
    const heroId = controller.getField('m_PlayerDataGlobal.m_nHeroID');
    if (![2, 3].includes(team) || typeof name !== 'string' || !name.trim() || !(heroId > 0)) return null;
    return { team, name, heroId };
}

function participantAt(demo, index) {
    if (!Number.isInteger(index) || index <= 0) return null;
    const entity = demo.getEntity(index);
    if (entity?.class.name === 'CCitadelPlayerController') return participant(entity);
    if (entity?.class.name !== 'CCitadelPlayerPawn') return null;
    const handle = entity.getField('m_hController');
    return Number.isInteger(handle) ? participant(demo.getEntityByHandle(handle)) : null;
}

export class MatchEvents {
    #purchases = new Map();
    #kills = [];
    #lastTick;
    #ordinal = 0;

    constructor(matchId) {
        this.matchId = matchId;
    }

    record(demo, tick, gameSeconds, kind, data) {
        if (!Number.isSafeInteger(tick) || tick < 0 || !Number.isFinite(gameSeconds)) return;
        if (tick !== this.#lastTick) {
            this.#lastTick = tick;
            this.#ordinal = 0;
        }
        const id = `${this.matchId}:${kind}:${tick}:${this.#ordinal++}`;
        gameSeconds = Math.max(0, gameSeconds);
        if (kind === 'purchase') {
            const { purchaserPlayerSlot, abilityId: itemId, change } = data;
            if (change !== 0 || !Number.isInteger(purchaserPlayerSlot) || purchaserPlayerSlot < 0 ||
                !Number.isInteger(itemId) || itemId <= 0 || itemId > 0xffffffff) return;
            // Network player slots are zero-based controller indices, unlike lobby slots.
            const controller = demo.getEntity(purchaserPlayerSlot + 1);
            if (!participant(controller)) return;
            const history = this.#purchases.get(controller.handle) ?? [];
            history.push({ id, itemId, gameSeconds });
            if (history.length > 96) history.shift();
            this.#purchases.set(controller.handle, history);
        } else if (kind === 'kill') {
            const victim = participantAt(demo, data.entindexVictim);
            if (!victim) return;
            const killer = participantAt(demo, data.entindexScorer) ?? participantAt(demo, data.entindexAttacker);
            const assists = (data.entindexAssisters ?? []).map(index => participantAt(demo, index)).filter(Boolean);
            const firstBlood = data.firstBlood === true;
            const souls = data.killfeedGold;
            this.#kills.push({
                id, kind, gameSeconds, killer, victim, assists,
                ...(firstBlood && { firstBlood }),
                ...(Number.isSafeInteger(souls) && souls > 0 && { souls }),
            });
            if (this.#kills.length > 32) this.#kills.shift();
        }
    }

    purchasesFor(controller) {
        return this.#purchases.get(controller.handle) ?? [];
    }

    get kills() {
        return this.#kills;
    }
}
