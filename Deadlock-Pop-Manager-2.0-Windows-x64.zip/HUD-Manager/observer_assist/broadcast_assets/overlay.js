'use strict';

const view = document.body.dataset.view;
const overlay = document.getElementById('overlay');
const preview = new URLSearchParams(location.search).get('preview') === '1';
const fields = [['kills', 'Убийства'], ['deaths', 'Смерти'], ['assists', 'Помощь'], ['souls', 'Души']];
let lastData;
let activePlayer;
let playerExpires = 0;
let board;

function node(tag, className = '', text) {
  const element = document.createElement(tag);
  element.className = className;
  if (text !== undefined) element.textContent = text;
  return element;
}

function displayName(player) {
  return player.player || player.hero || '—';
}

function writeText(element, value) {
  const text = String(value);
  if (element.textContent !== text) element.textContent = text;
}

function writeStats(cells, player) {
  for (let index = 0; index < fields.length; index++) {
    const value = player[fields[index][0]];
    writeText(cells[index], value === '' || value == null ? '—' : value);
  }
}

function renderPlayer(player) {
  const identity = JSON.stringify([player.team, player.player, player.hero]);
  if (identity !== activePlayer?.identity) {
    const card = node('article', `player-card ${player.team === 1 ? 'amber' : 'sapphire'}`);
    card.append(node('h1', '', displayName(player)));
    if (player.hero && player.player) card.append(node('p', 'hero', player.hero));
    const metrics = node('dl', 'metrics');
    const cells = fields.map(([key, label]) => {
      const metric = node('div');
      const value = node('dd', key);
      metric.append(node('dt', '', label), value);
      metrics.append(metric);
      return value;
    });
    card.append(metrics);
    overlay.replaceChildren(card);
    activePlayer = {identity, cells};
    playerExpires = Date.now() + 3000;
  }
  writeStats(activePlayer.cells, player);
}

function createTeam(index) {
  const team = node('section', `team ${index === 0 ? 'amber' : 'sapphire'}`);
  team.append(node('h2', '', index === 0 ? 'Эмбер' : 'Сапфир'));
  const table = node('table');
  const heading = table.createTHead().insertRow();
  for (const column of ['Игрок / герой', 'K', 'D', 'A', 'Души']) {
    const cell = node('th', '', column);
    cell.scope = 'col';
    heading.append(cell);
  }
  const body = table.createTBody();
  team.append(table);
  return {team, body, rows: []};
}

function updateTeam({body, rows}, players, sameMatch) {
  // Keep the initial on-air order when the HUD rearranges its portraits.
  const pending = players.slice();
  const ordered = [];
  if (sameMatch) {
    for (const row of rows) {
      const index = pending.findIndex(player => displayName(player) === row.identity);
      if (index !== -1) ordered.push(pending.splice(index, 1)[0]);
    }
  }
  ordered.push(...pending);

  while (rows.length > ordered.length) rows.pop().element.remove();
  while (rows.length < ordered.length) {
    const element = body.insertRow();
    const name = node('span', 'name');
    const hero = node('span', 'hero');
    const heading = node('th');
    heading.scope = 'row';
    heading.append(name, hero);
    const cells = fields.map(([key]) => node('td', key));
    element.append(heading, ...cells);
    rows.push({element, name, hero, cells});
  }
  rows.forEach((row, index) => {
    const player = ordered[index];
    row.identity = displayName(player);
    writeText(row.name, row.identity);
    const hero = player.player && player.hero ? player.hero : '';
    writeText(row.hero, hero);
    if (row.hero.hidden !== !hero) row.hero.hidden = !hero;
    writeStats(row.cells, player);
  });
}

function renderFinal(data) {
  if (!board) {
    const panel = node('article', 'scoreboard');
    const header = node('header', 'score-header');
    const title = node('h1');
    const meta = node('p', 'meta');
    header.append(title, meta);
    const teams = [createTeam(0), createTeam(1)];
    const body = node('div', 'teams');
    body.append(...teams.map(team => team.team));
    panel.append(header, body);
    overlay.replaceChildren(panel);
    board = {title, meta, teams, match: data.match_id};
  }
  writeText(board.title, data.final ? 'Итоги матча' : data.live ? 'Статистика матча' : 'Последние данные матча');
  const meta = [preview && 'Демонстрация', data.match_id && `Матч ${data.match_id}`].filter(Boolean);
  writeText(board.meta, meta.join(' · '));
  const sameMatch = !board.match || !data.match_id || board.match === data.match_id;
  data.teams.forEach((players, index) => updateTeam(board.teams[index], players, sameMatch));
  if (data.match_id) board.match = data.match_id;
}

function draw(data) {
  if (!data) {
    if (view === 'player' && !overlay.hidden) {
      overlay.hidden = true;
      overlay.replaceChildren();
      activePlayer = undefined;
    }
    return;
  }
  if (view === 'player') renderPlayer(data);
  else renderFinal(data);
  if (overlay.hidden) overlay.hidden = false;
}

async function update() {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 1300);
  try {
    const response = await fetch(`api/${view}`, {cache: 'no-store', signal: controller.signal});
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const text = await response.text();
    if (text !== lastData) {
      draw(JSON.parse(text));
      lastData = text;
    }
  } catch {
    // A delayed request should never take an on-air table away.
    if (view === 'player' && activePlayer && Date.now() >= playerExpires) {
      draw(null);
      lastData = undefined;
    }
  } finally {
    clearTimeout(timeout);
    setTimeout(update, 200);
  }
}

if (preview) {
  const names = ['Маршал', 'koda', 'Реверс', 'Echo', 'vetro', 'Норд', 'Maverick', 'Lumen', 'mtn', 'Пульс', 'Fable', 'Штиль'];
  const heroes = ['Абра́мс', 'Динамо', 'Мираж', 'Айви', 'Хейз', 'Виндикта', 'Лэш', 'Бибоп', 'Гейст', 'Севен', 'Шив', 'Макгиннис'];
  const sample = names.map((player, index) => ({player, hero: heroes[index], kills: 3 + (index * 7) % 15,
    deaths: 2 + (index * 3) % 9, assists: 5 + (index * 11) % 18, souls: `${43 - index} 280`}));
  draw(view === 'player' ? {...sample[6], team: 2, hero: `${sample[6].hero} · Демо`} :
    {match_id: '100000001', final: true, teams: [sample.slice(0, 6), sample.slice(6)]});
} else {
  update();
}
