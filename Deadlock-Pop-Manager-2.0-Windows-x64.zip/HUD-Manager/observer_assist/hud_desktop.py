"""Show the active web HUD over Deadlock or on the desktop."""

import json
import sys

from PySide6.QtCore import QEvent, QObject, QRect, QTimer, Qt, QUrl, Signal
from PySide6.QtGui import QColor, QGuiApplication
from PySide6.QtWebEngineCore import QWebEnginePage
from PySide6.QtWebEngineWidgets import QWebEngineView

from .capture import physical_to_logical
from .win32 import WindowsApi


FLAGS = (Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint |
         Qt.WindowType.Tool | Qt.WindowType.WindowTransparentForInput |
         Qt.WindowType.WindowDoesNotAcceptFocus)


def _screen_identity(screen):
    return (screen.name().strip(), screen.manufacturer().strip(),
            screen.model().strip(), screen.serialNumber().strip())


def screen_id(screen):
    return json.dumps(_screen_identity(screen), ensure_ascii=False, separators=(',', ':'))


def screen_by_id(screens, monitor_id):
    for screen in screens:
        if screen_id(screen) == monitor_id:
            return screen
    # Windows may assign a new device name when a physical display reconnects.
    try:
        _, manufacturer, model, serial = json.loads(monitor_id)
    except (ValueError, TypeError):
        return None
    if not serial:
        return None
    matches = [screen for screen in screens if _screen_identity(screen)[1:] == (manufacturer, model, serial)]
    return matches[0] if len(matches) == 1 else None


def screen_for_monitor(screens, monitor, device_name):
    for screen in screens:
        # Windows keeps the monitor origin in physical coordinates in Qt's virtual desktop.
        origin = screen.geometry().topLeft()
        if (origin.x(), origin.y()) == (monitor.left, monitor.top):
            return screen
    return next((screen for screen in screens if screen.name().casefold() == device_name.casefold()), None)


class HudPage(QWebEnginePage):
    def __init__(self, origin, parent, *, pov_navigation=None):
        super().__init__(parent)
        self.origin = QUrl(origin)
        self.pov_navigation = pov_navigation
        self.setBackgroundColor(QColor(Qt.GlobalColor.transparent))

    def acceptNavigationRequest(self, url, navigation_type, is_main_frame):
        if not is_main_frame and url == QUrl('about:srcdoc'):
            return True
        if not is_main_frame and self.pov_navigation and self.pov_navigation(url):
            return True
        return (url == QUrl('about:blank') or
                (url.scheme(), url.host(), url.port()) ==
                (self.origin.scheme(), self.origin.host(), self.origin.port()))


class DesktopHud(QObject):
    closed = Signal()

    def __init__(self, server_url, owner, api=None, *, pov_navigation=None, monitor_id=''):
        super().__init__(owner)
        self.owner = owner
        self.url = server_url + '/hud/'
        self.api = api
        if self.api is None and sys.platform == 'win32':
            self.api = WindowsApi()
        self._monitor_id = monitor_id
        self._screen = None
        self._preview = None
        self._geometry = None
        self._closing = False

        self.view = QWebEngineView()
        self.view.setWindowTitle('Deadlock HUD Overlay')
        self.view.setWindowFlags(FLAGS)
        self.view.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.view.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.view.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.view.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.view.setPage(HudPage(server_url, self.view, pov_navigation=pov_navigation))
        self.view.installEventFilter(self)
        self._timer = QTimer(self, interval=350)
        self._timer.timeout.connect(self.refresh)

    def start(self):
        self.refresh()
        self.view.show()
        if self.api is not None:
            self.api.exclude_overlay(int(self.view.winId()))
        self._timer.start()

    def set_monitor(self, monitor_id):
        if monitor_id != self._monitor_id:
            self._monitor_id = monitor_id
            if self._timer.isActive():
                self.refresh()

    def close(self):
        if self._closing:
            return
        self._closing = True
        self._timer.stop()
        self.view.removeEventFilter(self)
        self.view.stop()
        self.view.close()
        self.view.deleteLater()
        self.deleteLater()

    def eventFilter(self, watched, event):
        if watched is self.view and event.type() == QEvent.Type.Close and not self._closing:
            self._timer.stop()
            self.closed.emit()
        return False

    def _game_window(self):
        if self.api is not None:
            return next((window for window in self.api.windows() if window.title.casefold() == 'deadlock'), None)
        return None

    def refresh(self):
        game = self._game_window()
        screens = QGuiApplication.screens()
        preview = game is None
        selected = None
        if self._monitor_id:
            selected = screen_by_id(screens, self._monitor_id) or QGuiApplication.primaryScreen()
        geometry = None
        if game is not None:
            # Win32 reports physical pixels. Qt expects monitor-relative logical coordinates.
            try:
                monitor, name = self.api.monitor(game.hwnd)
            except RuntimeError:
                pass
            else:
                screen = screen_for_monitor(screens, monitor, name)
                if screen is not None:
                    self._screen = screen
                    if not self._monitor_id or screen == selected:
                        origin = screen.geometry().topLeft()
                        geometry = QRect(*physical_to_logical(game.rect, monitor, (origin.x(), origin.y()),
                                                               screen.devicePixelRatio()))
        if geometry is None:
            if not self._monitor_id:
                if self._screen is None:
                    self._screen = self.owner.screen()
                if self._screen not in screens:
                    self._screen = QGuiApplication.primaryScreen()
                selected = self._screen
            if selected is not None:
                geometry = selected.availableGeometry()
        if geometry is not None and self._geometry != geometry:
            self.view.setGeometry(geometry)
            self._geometry = geometry
        if preview != self._preview:
            self.view.setUrl(QUrl(self.url + ('?preview=1' if preview else '')))
            self._preview = preview
