"""Protect the installation's signing key with Windows DPAPI."""

import ctypes
from ctypes import wintypes

from .release_security import decode, encode


class _Blob(ctypes.Structure):
    _fields_ = [('length', wintypes.DWORD), ('data', ctypes.POINTER(ctypes.c_ubyte))]


def _crypt(data, entry):
    crypt = ctypes.WinDLL('crypt32', use_last_error=True)
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    release = kernel.LocalFree
    release.argtypes = [wintypes.HLOCAL]
    release.restype = wintypes.HLOCAL
    operation = getattr(crypt, entry)
    operation.argtypes = [ctypes.POINTER(_Blob), ctypes.c_void_p, ctypes.c_void_p,
                          ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(_Blob)]
    operation.restype = wintypes.BOOL
    memory = (ctypes.c_ubyte * len(data)).from_buffer_copy(data)
    source, result = _Blob(len(data), memory), _Blob()
    if not operation(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(result)):
        raise OSError('Windows не удалось обработать ключ этой установки.')
    try:
        return ctypes.string_at(result.data, result.length)
    finally:
        release(ctypes.cast(result.data, wintypes.HLOCAL))


def seal(secret):
    return encode(_crypt(decode(secret), 'CryptProtectData'))


def unseal(protected):
    return encode(_crypt(decode(protected), 'CryptUnprotectData'))
