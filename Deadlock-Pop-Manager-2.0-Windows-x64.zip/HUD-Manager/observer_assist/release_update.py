"""Verify release metadata and stage a Windows installer before executing it."""

from dataclasses import dataclass
from hashlib import sha256
from http.client import HTTPException
import os
from pathlib import Path
import re
from tempfile import mkdtemp
from urllib.parse import urlsplit
from urllib.request import HTTPSHandler, HTTPRedirectHandler, Request, build_opener

from .release_security import UPDATE, verified_record


MAX_INSTALLER_BYTES = 512 * 1024 * 1024
MAX_CHANNEL_BYTES = 16384


def version_tuple(value):
    if not isinstance(value, str) or not re.fullmatch(r'(?:0|[1-9][0-9]{0,5})(?:\.(?:0|[1-9][0-9]{0,5})){2}', value):
        raise ValueError('Некорректный номер версии.')
    return tuple(map(int, value.split('.')))


def https_url(value):
    if not isinstance(value, str) or len(value) > 2048 or any(ord(char) <= 32 for char in value):
        raise ValueError('Для обновлений нужен HTTPS URL.')
    parsed = urlsplit(value)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username is not None or parsed.fragment:
        raise ValueError('Для обновлений нужен HTTPS URL.')
    parsed.port  # Validate the port if present.
    return value


class _HTTPSRedirects(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        https_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _open(url):
    request = Request(https_url(url), headers={'User-Agent': 'Deadlock-HUD-Manager', 'Accept-Encoding': 'identity'})
    return build_opener(HTTPSHandler(), _HTTPSRedirects()).open(request, timeout=12)


@dataclass(frozen=True)
class Update:
    version: str
    url: str
    size: int
    sha256: str

    @classmethod
    def parse(cls, record):
        version = record.get('version')
        version_tuple(version)
        url = https_url(record.get('url'))
        size, digest = record.get('size'), record.get('sha256')
        if (type(size) is not int or not 1 <= size <= MAX_INSTALLER_BYTES
                or not isinstance(digest, str) or not re.fullmatch(r'[0-9a-f]{64}', digest)):
            raise ValueError('Некорректные данные установщика.')
        return cls(version, url, size, digest)


def available_update(channel, key, installed, *, opener=_open):
    with opener(https_url(channel)) as stream:
        raw = stream.read(MAX_CHANNEL_BYTES + 1)
    if len(raw) > MAX_CHANNEL_BYTES:
        raise ValueError('Слишком большой ответ канала обновлений.')
    release = Update.parse(verified_record(UPDATE, raw.decode('ascii').strip(), key, limit=MAX_CHANNEL_BYTES))
    return release if version_tuple(release.version) > version_tuple(installed) else None


def download_update(release, *, opener=_open):
    directory = Path(mkdtemp(prefix='dhm-update-'))
    stage = directory / 'download.part'
    installer = directory / f'Deadlock-HUD-Manager-Setup-{release.version}.exe'
    digest = sha256()
    total = 0
    try:
        with opener(https_url(release.url)) as source, stage.open('xb') as output:
            while block := source.read(1024 * 1024):
                total += len(block)
                if total > release.size:
                    raise ValueError('Размер загрузки отличается от подписанного размера.')
                digest.update(block)
                output.write(block)
        if total != release.size or digest.hexdigest() != release.sha256:
            raise ValueError('Контрольная сумма установщика не совпала.')
        os.replace(stage, installer)
        return installer
    except (OSError, HTTPException, ValueError):
        stage.unlink(missing_ok=True)
        directory.rmdir()
        raise
