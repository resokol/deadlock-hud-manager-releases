from copy import deepcopy
from math import ceil
from pathlib import Path
from threading import Event, Thread
from time import monotonic
import ctypes
import os
from ctypes import wintypes
import cv2
import numpy as np
from PySide6.QtCore import Qt, QRectF, QTimer, Signal, QAbstractNativeEventFilter, QRegularExpression
from PySide6.QtGui import QColor, QImage, QPainter, QPen, QFont, QRegularExpressionValidator
from PySide6.QtWidgets import (QApplication, QWidget, QMainWindow, QVBoxLayout,
    QHBoxLayout, QLabel, QPushButton, QComboBox, QFileDialog, QGroupBox, QFormLayout,
    QSpinBox, QLineEdit, QTabWidget, QInputDialog, QScrollArea, QSplitter, QCheckBox)
from .capture import MssSource, desktop_roi, physical_to_logical, validate_snapshot
from .panorama import DEFAULT_PORTRAIT_KEYS, MAX_AGE, PanoramaSession, export_stats
from .profile import Profile, Rect, TeamColor, Objective
from .state import ControlState
from .hotkeys import HotkeyManager
from .session import AnalysisSession
from .vision import detect


COLORS = {'APPROACH':'#F6BD60','CONTACT':'#DCE3EA','INTERCEPT':'#58D6CD','OBJECTIVE':'#C5A4F6'}
NAMES = {'APPROACH':'Сближение','CONTACT':'Контакт','INTERCEPT':'Перехват','OBJECTIVE':'Объект'}
RISK_NAMES = {'low':'низкий','medium':'средний','high':'высокий'}


def qimage(bgr):
    rgb=cv2.cvtColor(np.ascontiguousarray(bgr[:,:,:3]),cv2.COLOR_BGR2RGB)
    return QImage(rgb.data,rgb.shape[1],rgb.shape[0],rgb.strides[0],QImage.Format.Format_RGB888).copy()


class CalibrationCanvas(QWidget):
    changed=Signal()

    def __init__(self,profile):
        super().__init__()
        self.profile=profile
        self.frame=None
        self.mode='roi'
        self.start=None
        self.end=None
        self.detections=[]
        self.setMinimumSize(420,300)
        self.setMouseTracking(True)
        self.setAccessibleName('Снимок игры для калибровки миникарты')

    def set_image(self,image):
        self.frame=image.copy()
        self._image=qimage(image)
        self.detections=[]
        self.update()

    def image_rect(self):
        if self.frame is None:
            return QRectF()
        h,w=self.frame.shape[:2]
        scale=min(self.width()/w,self.height()/h)
        return QRectF((self.width()-w*scale)/2,(self.height()-h*scale)/2,w*scale,h*scale)

    def image_point(self,x,y):
        r=self.image_rect()
        if self.frame is None or not r.contains(x,y):
            return None
        return (min(self.frame.shape[1]-1,int((x-r.x())/r.width()*self.frame.shape[1])),
                min(self.frame.shape[0]-1,int((y-r.y())/r.height()*self.frame.shape[0])))

    def _display_rect(self,x,y,w,h):
        r=self.image_rect()
        ih,iw=self.frame.shape[:2]
        return QRectF(r.x()+x/iw*r.width(),r.y()+y/ih*r.height(),w/iw*r.width(),h/ih*r.height())

    def paintEvent(self,event):
        p=QPainter(self)
        p.fillRect(self.rect(),QColor('#101519'))
        if self.frame is None:
            p.setPen(QColor('#BBC5CA'))
            p.drawText(self.rect(),Qt.AlignmentFlag.AlignCenter,'Сделайте снимок окна игры\nили откройте кадр / видео')
            return
        p.drawImage(self.image_rect(),self._image)
        roi=self.profile.roi
        p.setPen(QPen(QColor('#FFFFFF'),2,Qt.PenStyle.DashLine))
        p.drawRect(self._display_rect(roi.left,roi.top,roi.width,roi.height))
        p.setPen(QPen(QColor('#E7A1A1'),2))
        for x,y,w,h in self.profile.exclusions:
            p.drawRect(self._display_rect(roi.left+x*roi.width,roi.top+y*roi.height,w*roi.width,h*roi.height))
        p.setPen(QPen(QColor(COLORS['OBJECTIVE']),2))
        for o in self.profile.objectives:
            r=self._display_rect(roi.left+o.x*roi.width-4,roi.top+o.y*roi.height-4,8,8)
            p.drawRect(r)
        for d in self.detections:
            p.setPen(QPen(QColor('#F6BD60' if d.team==1 else '#58D6CD'),2))
            r=self._display_rect(roi.left+d.x*roi.width-7,roi.top+d.y*roi.height-7,14,14)
            p.drawEllipse(r)
        if self.start and self.end:
            x,y=self.start;xx,yy=self.end
            p.setPen(QPen(QColor('#58D6CD'),2))
            p.drawRect(self._display_rect(min(x,xx),min(y,yy),abs(xx-x),abs(yy-y)))

    def mousePressEvent(self,event):
        point=self.image_point(event.position().x(),event.position().y())
        if event.button()!=Qt.MouseButton.LeftButton or point is None:
            return
        if self.mode in ('roi','exclude'):
            self.start=self.end=point
        elif self.mode in ('team1','team2'):
            r=self.profile.roi
            if not (r.left<=point[0]<r.left+r.width and r.top<=point[1]<r.top+r.height):
                return
            h,s,v=map(int,cv2.cvtColor(self.frame,cv2.COLOR_BGR2HSV)[point[1],point[0]])
            if s<40 or v<40:
                self.setToolTip('Выберите насыщенный цветной край значка героя')
                return
            team=int(self.mode[-1])
            color=TeamColor(team,h,saturation_min=max(40,s-70),value_min=max(40,v-90))
            self.profile.teams=[t for t in self.profile.teams if t.team!=team]+[color]
            self.profile.teams.sort(key=lambda t:t.team)
            self.changed.emit()
        elif self.mode=='objective':
            r=self.profile.roi
            x,y=(point[0]-r.left)/max(1,r.width),(point[1]-r.top)/max(1,r.height)
            if not (0<=x<=1 and 0<=y<=1):
                return
            name,ok=QInputDialog.getText(self,'Объект','Название объекта:')
            if ok and name.strip():
                self.profile.objectives.append(Objective(name.strip(),x,y))
                self.changed.emit()
        self.update()

    def mouseMoveEvent(self,event):
        if self.start:
            point=self.image_point(event.position().x(),event.position().y())
            if point:
                self.end=point
                self.update()

    def mouseReleaseEvent(self,event):
        if not self.start or not self.end:
            return
        x,y=self.start;xx,yy=self.end
        self.start=self.end=None
        x,y,w,h=min(x,xx),min(y,yy),abs(xx-x),abs(yy-y)
        if self.mode=='roi' and w>=20 and h>=20:
            self.profile.roi=Rect(x,y,w,h)
            self.profile.exclusions=[]
            self.profile.objectives=[]
        elif self.mode=='exclude':
            r=self.profile.roi
            if w<1 or h<1 or not r.contains(Rect(x,y,w,h)):
                return
            self.profile.exclusions.append(((x-r.left)/r.width,(y-r.top)/r.height,w/r.width,h/r.height))
        self.changed.emit()
        self.update()


class OverlayWindow(QWidget):
    def __init__(self):
        flags=(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint
               | Qt.WindowType.Tool | Qt.WindowType.WindowTransparentForInput
               | Qt.WindowType.WindowDoesNotAcceptFocus)
        super().__init__(None,flags)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.events=[]
        self.player_stats=None
        self.show_idle=False

    def set_events(self,events,player_stats=None,*,show_idle=False):
        self.events=list(events)
        self.player_stats=player_stats
        self.show_idle=show_idle and not self.events and player_stats is None
        self.update()

    def paintEvent(self,event):
        p=QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setClipRect(self.rect())
        p.setFont(QFont('Segoe UI',10,QFont.Weight.DemiBold))
        if self.show_idle:
            title='Анализ активен'
            width=p.fontMetrics().horizontalAdvance(title)+16
            box=QRectF(6,6,width,22)
            p.fillRect(box,QColor('#101519'))
            p.setPen(QColor('#DCE3EA'))
            p.drawText(box,Qt.AlignmentFlag.AlignCenter,title)
            return
        stats_box=QRectF(4,4,self.width()-8,42)
        occupied=[stats_box] if self.player_stats else []
        labels=[]
        for event in self.events:
            title=NAMES[event.kind]
            if event.eta_seconds is not None:
                title+=f' · ≈{ceil(event.eta_seconds)} с'
            if event.risk:
                title+=f' · {RISK_NAMES[event.risk]} риск'
            if event.shortcut:
                title=f'[{event.shortcut}] {title}'
            text=p.fontMetrics().elidedText(title,Qt.TextElideMode.ElideRight,max(20,self.width()-12))
            width=p.fontMetrics().horizontalAdvance(text)+12
            x=max(2,min(self.width()-width-2,event.x*self.width()-width/2))
            ys=((event.y-event.radius)*self.height()-24,
                (event.y+event.radius)*self.height()+2,event.y*self.height()-11)
            boxes=[QRectF(x,max(2,min(self.height()-24,y)),width,22) for y in ys]
            box=next((candidate for candidate in boxes
                      if not any(candidate.intersects(other) for other in occupied)),None)
            if box is None:
                continue
            occupied.append(box)
            labels.append((event,box,text))
        for event,_,_ in reversed(labels):
            color=QColor(COLORS[event.kind])
            line=Qt.PenStyle.DashLine if event.eta_seconds is not None else Qt.PenStyle.SolidLine
            p.setPen(QPen(QColor('#101519'),4))
            p.setBrush(Qt.BrushStyle.NoBrush)
            ring=QRectF((event.x-event.radius)*self.width(),(event.y-event.radius)*self.height(),
                       2*event.radius*self.width(),2*event.radius*self.height())
            p.drawEllipse(ring)
            p.setPen(QPen(color,2,line))
            p.drawEllipse(ring)
            if event.eta_seconds is not None:
                p.setBrush(color)
                p.drawEllipse(QRectF(event.x*self.width()-2,event.y*self.height()-2,4,4))
        for event,box,text in labels:
            p.fillRect(box,QColor('#101519'))
            p.setPen(QColor(COLORS[event.kind]))
            p.drawText(box,Qt.AlignmentFlag.AlignCenter,text)
        if self.player_stats:
            player=self.player_stats
            name=' · '.join(value for value in (player.player,player.hero) if value)
            detail=' / '.join(value or '—' for value in (player.kills,player.deaths,player.assists))
            detail=f'K/D/A {detail}' + (f' · Души {player.souls}' if player.souls else '')
            p.fillRect(stats_box,QColor('#101519'))
            p.setPen(QColor('#E8EDF0'))
            for row, value in enumerate((name,detail)):
                text=p.fontMetrics().elidedText(value,Qt.TextElideMode.ElideRight,max(20,self.width()-20))
                p.drawText(QRectF(10,5+row*20,self.width()-20,20),Qt.AlignmentFlag.AlignVCenter,text)


class MinimapPreview(QWidget):
    def __init__(self):
        super().__init__()
        self._image=None
        self.setMinimumHeight(180)
        self.setAccessibleName('Увеличенная миникарта для проверки распознавания')

    def set_image(self,image):
        self._image=qimage(image);self.update()

    def clear(self):
        self._image=None;self.update()

    def paintEvent(self,event):
        p=QPainter(self);p.fillRect(self.rect(),QColor('#101519'))
        if self._image is None:
            p.setPen(QColor('#BBC5CA'))
            p.drawText(self.rect(),Qt.AlignmentFlag.AlignCenter,'Здесь появится увеличенная миникарта')
            return
        scale=min(max(1,self.width()-20)/self._image.width(),max(1,self.height()-20)/self._image.height())
        w,h=self._image.width()*scale,self._image.height()*scale
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        p.drawImage(QRectF((self.width()-w)/2,(self.height()-h)/2,w,h),self._image)


class NativeHotkeys(QAbstractNativeEventFilter):
    def __init__(self,manager,callback):
        super().__init__()
        self.manager,self.callback=manager,callback

    def nativeEventFilter(self,event_type,message):
        if bytes(event_type) in (b'windows_generic_MSG',b'windows_dispatcher_MSG'):
            msg=wintypes.MSG.from_address(int(message))
            if msg.message==0x0312:
                action=self.manager.actions.get(int(msg.wParam))
                if action:
                    self.callback(action)
                    return True,0
        return False,0


class AnalysisWorker(Thread):
    def __init__(self,session,fps):
        super().__init__(daemon=True,name='minimap-analysis')
        self.session,self.fps=session,fps
        self.stop_event=Event()

    def run(self):
        try:
            while not self.stop_event.is_set():
                started=monotonic()
                self.session.tick(started)
                self.stop_event.wait(max(.005,1/self.fps-(monotonic()-started)))
        except Exception as exc:
            self.session.state.invalidate()
            if self.session.state.snapshot()[0]:
                self.session.state.toggle_analysis()
            self.session.status=f'Ошибка анализа: {exc}'
        finally:
            self.session.close()

    def stop(self):
        self.stop_event.set()
        self.join(timeout=2)
        return not self.is_alive()


STYLE='''
QWidget { background: #171D22; color: #E8EDF0; font: 10pt "Segoe UI"; }
QLabel#title { font-size: 23pt; font-weight: 600; }
QLabel#subtle { color: #B2C0C8; }
QPushButton { background: #29343D; border: 1px solid #465661; border-radius: 5px; padding: 8px 12px; }
QPushButton:hover { background: #354551; }
QPushButton:focus { border: 2px solid #89DDD5; }
QPushButton:disabled { color: #8B969E; background: #20282E; border-color: #354049; }
QPushButton#primary { background: #92DAD2; color: #112520; font-weight: 600; }
QPushButton#primary:disabled { background: #29343D; color: #8B969E; border-color: #354049; }
QLineEdit,QSpinBox,QComboBox { padding: 6px; background: #101519; border: 1px solid #51626E; border-radius: 4px; }
QLineEdit:focus,QSpinBox:focus,QComboBox:focus { border-color: #92DAD2; }
QGroupBox { margin-top: 16px; padding-top: 18px; border: 1px solid #35434D; border-radius: 6px; }
QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0 5px; }
QTabBar::tab { padding: 10px 18px; background: #20292F; }
QTabBar::tab:selected { background: #354551; }
QTabWidget::pane { border: 1px solid #35434D; }
'''


class ControlPanel(QMainWindow):
    closed = Signal()
    capture_started = Signal()
    capture_finished = Signal()

    def __init__(self,api=None,profile=None,config_path=None,panorama_log=None,portrait_keys=DEFAULT_PORTRAIT_KEYS,
                 hero_icons=None,broadcast=None,broadcast_error=None):
        super().__init__()
        self.api=api
        self.profile=profile or Profile()
        self.state=ControlState()
        self.worker=None
        self.baseline=None
        self.overlay=OverlayWindow()
        self.capture_excluded=False
        self.panorama_log=panorama_log
        self.portrait_keys=tuple(portrait_keys)
        self.hero_icons=hero_icons
        self.broadcast=broadcast
        self.stats_frame=None
        self._selected_portrait=None
        self._stats_until=0
        self._panorama_geometry=None
        self.config_path=Path(config_path) if config_path else None
        self.auto_result=None
        self.auto_attempted=self.profile.marker_mode=='portraits'
        self._auto_capture=False
        self._closing=False
        self._advanced=False
        self.hotkeys=HotkeyManager(api) if api else None
        self.setWindowTitle('Deadlock Observer Assist · экспериментальный прототип')
        self.resize(850,780)
        self.setMinimumSize(720,650)
        self.setStyleSheet(STYLE)
        root=QWidget(); self.setCentralWidget(root)
        layout=QVBoxLayout(root); layout.setContentsMargins(24,20,24,20); layout.setSpacing(16)
        title=QLabel('Deadlock Observer Assist');title.setObjectName('title');layout.addWidget(title)
        desc=QLabel('Подсказки на миникарте · переключение камеры остаётся за обсервером')
        desc.setObjectName('subtle');desc.setWordWrap(True);layout.addWidget(desc)
        controls=QHBoxLayout()
        self.analysis_button=QPushButton('Включить анализ');self.analysis_button.setObjectName('primary')
        self.overlay_button=QPushButton('Скрыть оверлей')
        controls.addWidget(self.analysis_button);controls.addWidget(self.overlay_button);controls.addStretch()
        self.advanced_button=QPushButton('Дополнительно…')
        self.advanced_button.clicked.connect(self.toggle_advanced)
        controls.addWidget(self.advanced_button)
        layout.addLayout(controls)
        if self.panorama_log:
            match_row=QHBoxLayout()
            match_label=QLabel('ID матча')
            self.match_id_edit=QLineEdit()
            self.match_id_edit.setAccessibleName('ID матча')
            self.match_id_edit.setPlaceholderText('Например, 100000001')
            self.match_id_edit.setToolTip('Номер появится в графике vMix и в имени файла CSV.')
            self.match_id_edit.setValidator(QRegularExpressionValidator(
                QRegularExpression(r'[0-9]{0,20}'),self.match_id_edit))
            self.match_id_edit.setClearButtonEnabled(True)
            self.match_id_edit.setMaximumWidth(245)
            match_label.setBuddy(self.match_id_edit)
            match_row.addWidget(match_label)
            match_row.addWidget(self.match_id_edit)
            match_row.addStretch()
            layout.addLayout(match_row)
            panorama_controls=QHBoxLayout()
            self.live_stats=QCheckBox('Карточка игрока в vMix' if broadcast else 'Карточка при выборе игрока')
            self.live_stats.setChecked(True)
            self.export_button=QPushButton('Выгрузить итоги в CSV…')
            self.export_button.setEnabled(False)
            self.export_button.clicked.connect(self.export_final_stats)
            for widget in (self.live_stats,self.export_button):
                panorama_controls.addWidget(widget)
            layout.addLayout(panorama_controls)
            if broadcast:
                vmix_controls=QHBoxLayout()
                vmix_controls.addWidget(QLabel('vMix'))
                for page, title in (('player', 'Ссылка на карточку'), ('final', 'Ссылка на итоги')):
                    copy=QPushButton(title)
                    copy.setToolTip(broadcast.url(page))
                    copy.clicked.connect(lambda checked=False, button=copy, route=page, label=title:
                                         self.copy_broadcast_url(button, route, label))
                    vmix_controls.addWidget(copy)
                self.vmix_publish=QPushButton('Показать статистику')
                self.vmix_publish.setToolTip('Показывает статистику текущего матча в vMix и обновляет её по мере поступления данных.')
                self.vmix_publish.setEnabled(False)
                self.vmix_publish.clicked.connect(self.publish_broadcast_stats)
                vmix_controls.addWidget(self.vmix_publish)
                vmix_controls.addStretch()
                layout.addLayout(vmix_controls)
            elif broadcast_error:
                message=QLabel(broadcast_error);message.setWordWrap(True);layout.addWidget(message)
        self.status=QLabel('Сначала выберите окно игры и откалибруйте миникарту.')
        if self.panorama_log:
            self.status.setText('Откройте Custom Match или реплей в режиме наблюдателя и включите анализ.')
        self.status.setWordWrap(True);self.status.setMinimumHeight(40);layout.addWidget(self.status)
        self.tabs=QTabWidget();layout.addWidget(self.tabs,1)
        self._make_quick()
        self._make_calibration()
        self._make_settings()
        self.tabs.setTabVisible(1,False);self.tabs.setTabVisible(2,False)
        self.tabs.tabBar().hide()
        self.analysis_button.clicked.connect(self.toggle_analysis)
        self.overlay_button.clicked.connect(self.toggle_overlay)
        if self.hotkeys:
            self.native_filter=NativeHotkeys(self.hotkeys,self.hotkey_action)
            QApplication.instance().installNativeEventFilter(self.native_filter)
            try:
                self.apply_hotkeys()
            except ValueError as exc:
                self.status.setText(str(exc))
        self.timer=QTimer(self);self.timer.timeout.connect(self.refresh);self.timer.start(100)
        self.refresh_windows()

    def _make_quick(self):
        page=QWidget();box=QVBoxLayout(page);box.setContentsMargins(20,20,20,20);box.setSpacing(16)
        if self.panorama_log:
            intro=QLabel('Panorama определяет положение миникарты и видимых игроков по HUD Deadlock.')
            intro.setWordWrap(True)
            box.addWidget(intro)
            keys=QLabel(f'Клавиши Deadlock для портретов слева направо — {" ".join(self.portrait_keys)}')
            keys.setWordWrap(True)
            box.addWidget(keys)
            box.addStretch(1)
            # The existing calibration controls remain available in advanced settings.
        intro=QLabel('Откройте матч в наблюдателе. Программа попробует найти карту и настроить распознавание.')
        intro.setWordWrap(True);box.addWidget(intro)
        row=QHBoxLayout()
        self.auto_button=QPushButton('Найти игру и настроить');self.auto_button.setObjectName('primary')
        self.auto_button.clicked.connect(self.quick_setup)
        self.auto_button.setEnabled(self.api is not None)
        row.addWidget(self.auto_button)
        self.auto_file_button=QPushButton('Проверить снимок / видео…')
        self.auto_file_button.clicked.connect(self.open_auto_image);row.addWidget(self.auto_file_button)
        box.addLayout(row)
        self.quick_status=QLabel('Начните с автоматической настройки. Параметры цветов вводить не нужно.')
        self.quick_status.setWordWrap(True);box.addWidget(self.quick_status)
        self.quick_preview=MinimapPreview()
        box.addWidget(self.quick_preview,1)
        self.quick_confirm=QCheckBox('Кружки отмечают героев, а не объекты карты')
        self.quick_confirm.setEnabled(False)
        self.quick_confirm.toggled.connect(self.confirm_auto_setup)
        box.addWidget(self.quick_confirm)
        fallback=QPushButton('Не нашлась карта? Выделить её один раз…')
        fallback.clicked.connect(self.manual_map_fallback);box.addWidget(fallback)
        note=QLabel('Скрыть слой — Ctrl+Alt+F9. Остановить анализ — Ctrl+Alt+F10.\n'
                    'Если распознавание не прошло проверку, прогнозы не включаются.')
        note.setWordWrap(True);note.setObjectName('subtle');box.addWidget(note)
        if self.panorama_log:
            for widget in (intro,self.auto_button,self.auto_file_button,self.quick_status,self.quick_preview,
                           self.quick_confirm,fallback,note):
                widget.hide()
        self.quick_page=page;self.tabs.addTab(page,'Начало')

    def toggle_advanced(self):
        self._advanced=not self._advanced
        self.tabs.setCurrentIndex(0)
        self.tabs.setTabVisible(1,self._advanced);self.tabs.setTabVisible(2,self._advanced)
        self.tabs.tabBar().setVisible(self._advanced)
        self.advanced_button.setText('Простой режим' if self._advanced else 'Дополнительно…')
        if self._advanced:
            self.resize(1160,850);self.tabs.setCurrentIndex(1)

    def manual_map_fallback(self):
        if not self._advanced:self.toggle_advanced()
        self.tabs.setCurrentIndex(1);self.set_mode('roi')
        self.preview_label.setText('Выделите карту рамкой и нажмите «Настроить по выбранной карте».')

    def quick_setup(self):
        self.refresh_windows()
        games=[i for i in range(self.windows_combo.count())
               if 'deadlock' in self.windows_combo.itemText(i).lower() and self.windows_combo.itemData(i)]
        if len(games)!=1:
            self.quick_status.setText('Откройте одно окно Deadlock. Если их несколько, выберите нужное в дополнительных настройках.')
            return
        self.windows_combo.setCurrentIndex(games[0]);self._auto_capture=True;self.capture_window()

    def open_auto_image(self):
        self._auto_capture=True
        try:self.open_image()
        finally:self._auto_capture=False

    def run_auto_setup(self,roi_hint=None):
        from .autocalibration import autocalibrate
        self.auto_attempted=True;self.auto_result=None
        self.quick_confirm.setChecked(False);self.quick_confirm.setEnabled(False)
        self.state.invalidate()
        try:
            if self.canvas.frame is None:raise ValueError('Сначала откройте кадр игры.')
            result=autocalibrate(self.canvas.frame,self.profile,roi_hint)
            self.profile=result.profile;self.canvas.profile=self.profile
            self.present_calibration_result(result)
        except (ValueError,cv2.error) as exc:
            self.quick_status.setText(str(exc));self.status.setText('Автонастройка не прошла проверку.')
            self.quick_preview.clear()
        self.refresh()

    def present_calibration_result(self,result):
        self.auto_attempted=True;self.auto_result=result
        self.quick_confirm.setChecked(False);self.quick_confirm.setEnabled(result.plausible)
        self.sync_team_controls();self.canvas.update()
        r=self.profile.roi
        mini=self.canvas.frame[r.top:r.top+r.height,r.left:r.left+r.width].copy()
        if result.plausible:
            for d in result.detections:
                cv2.circle(mini,(round(d.x*r.width),round(d.y*r.height)),max(3,round(r.width*.035)),
                           (96,189,246) if d.team==1 else (205,214,88),1)
        self.quick_preview.set_image(mini)
        self.quick_status.setText(result.message)
        self.status.setText('Карта определена. Подсказки ещё не включены.')
        self.tabs.setCurrentIndex(0);self.refresh()

    def auto_from_region(self):
        self.run_auto_setup(self.profile.roi)

    def confirm_auto_setup(self,checked):
        if checked and self.auto_result and self.auto_result.plausible and self.config_path:
            try:self.profile.save(self.config_path)
            except (ValueError,OSError) as exc:self.status.setText(f'Настройка не сохранена: {exc}')
        self.refresh()

    def _make_calibration(self):
        page=QWidget();box=QVBoxLayout(page)
        source=QHBoxLayout()
        self.windows_combo=QComboBox();self.windows_combo.setMinimumWidth(220)
        self.windows_combo.currentIndexChanged.connect(self.source_changed)
        source.addWidget(self.windows_combo,1)
        refresh=QPushButton('Обновить');refresh.clicked.connect(self.refresh_windows);source.addWidget(refresh)
        shot=QPushButton('Снимок окна');shot.clicked.connect(self.capture_window);source.addWidget(shot)
        load=QPushButton('Открыть кадр / видео');load.clicked.connect(self.open_image);source.addWidget(load)
        box.addLayout(source)
        hint=QLabel('Выделите миникарту, затем укажите цветной край значка каждой команды. Нужна проверка на вашем HUD.')
        hint.setWordWrap(True);box.addWidget(hint)
        tools=QHBoxLayout()
        for label,mode in [('Область карты','roi'),('Цвет команды 1','team1'),('Цвет команды 2','team2'),
                           ('Исключить область','exclude'),('Добавить объект','objective')]:
            button=QPushButton(label)
            button.clicked.connect(lambda checked=False,m=mode:self.set_mode(m))
            tools.addWidget(button)
        box.addLayout(tools)
        split=QSplitter()
        self.canvas=CalibrationCanvas(self.profile)
        self.canvas.changed.connect(self.calibration_changed)
        split.addWidget(self.canvas)
        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setMinimumWidth(270);scroll.setMaximumWidth(320)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        side=QWidget();sidebox=QVBoxLayout(side);self.team_controls={}
        for team in (1,2):
            group=QGroupBox(f'Команда {team}');form=QFormLayout(group)
            form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
            form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
            controls={}
            for field,label,lo,hi in [('hue','Тон H',0,179),('tolerance','Допуск H',1,30),
                    ('saturation_min','Мин. насыщенность',1,255),('value_min','Мин. яркость',1,255),
                    ('min_area','Мин. площадь',1,10000),('max_area','Макс. площадь',1,10000),
                    ('min_size','Мин. размер',1,200),('max_size','Макс. размер',1,200)]:
                spin=QSpinBox();spin.setRange(lo,hi)
                spin.valueChanged.connect(lambda value,t=team,f=field:self.set_team_field(t,f,value))
                form.addRow(label,spin);controls[field]=spin
            self.team_controls[team]=controls
            sidebox.addWidget(group)
        sidebox.addStretch();scroll.setWidget(side);split.addWidget(scroll);split.setStretchFactor(0,1)
        box.addWidget(split,1)
        buttons=QHBoxLayout()
        for text,callback in [('Проверить значки',self.preview),('Убрать последнюю маску',self.undo_mask),
                              ('Убрать последний объект',self.undo_objective)]:
            b=QPushButton(text);b.clicked.connect(callback);buttons.addWidget(b)
        box.addLayout(buttons)
        auto_region=QPushButton('Настроить по выбранной карте')
        auto_region.clicked.connect(self.auto_from_region);box.addWidget(auto_region)
        self.preview_label=QLabel('Калибровка ещё не проверена');self.preview_label.setWordWrap(True);box.addWidget(self.preview_label)
        self.calibration_page=page
        self.tabs.addTab(page,'Миникарта и калибровка')
        self.sync_team_controls()

    def _make_settings(self):
        page=QWidget();box=QVBoxLayout(page);form=QFormLayout()
        self.fps_spin=QSpinBox();self.fps_spin.setRange(5,30);self.fps_spin.setValue(self.profile.fps)
        self.overlay_key=QLineEdit(self.profile.overlay_key);self.analysis_key=QLineEdit(self.profile.analysis_key)
        form.addRow('Частота анализа, кадров/с',self.fps_spin)
        form.addRow('Скрыть / показать оверлей',self.overlay_key)
        form.addRow('Выключить / включить анализ',self.analysis_key)
        box.addLayout(form)
        note=QLabel('Скрытие оверлея сохраняет анализ. Остановка анализа прекращает захват и очищает подсказки.\n\n'
                    'В Stream Deck используйте действие Hotkey с теми же сочетаниями. Клавиши выбора игроков программа не регистрирует.\n\n'
                    'Янтарный — возможный контакт; бирюзовый — возможный перехват; фиолетовый — интерес у отмеченного объекта.\n'
                    'Прогнозы эвристические: миникарта не показывает все препятствия, высоту и намерения игроков.')
        note.setWordWrap(True);box.addWidget(note)
        for label,callback in [('Применить настройки',self.apply_settings),('Сохранить профиль…',self.save_profile),
                               ('Загрузить профиль…',self.load_profile)]:
            b=QPushButton(label);b.clicked.connect(callback);box.addWidget(b)
        box.addStretch();self.settings_page=page;self.tabs.addTab(page,'Настройки и профиль')

    def refresh_windows(self):
        previous=self.windows_combo.currentData()
        self.windows_combo.blockSignals(True)
        self.windows_combo.clear()
        if not self.api:
            self.windows_combo.addItem('Живой захват доступен в Windows')
            self.windows_combo.blockSignals(False)
            return
        for snapshot in self.api.windows():
            if snapshot.pid==os.getpid():
                continue
            self.windows_combo.addItem(f'{snapshot.title} · {snapshot.rect.width}×{snapshot.rect.height}',snapshot)
        for i in range(self.windows_combo.count()):
            if 'deadlock' in self.windows_combo.itemText(i).lower():
                self.windows_combo.setCurrentIndex(i);break
        if previous:
            for i in range(self.windows_combo.count()):
                s=self.windows_combo.itemData(i)
                if (s.hwnd,s.pid)==(previous.hwnd,previous.pid):
                    self.windows_combo.setCurrentIndex(i);break
        self.windows_combo.blockSignals(False)
        self.source_changed()

    def source_changed(self,*_):
        selected=self.windows_combo.currentData()
        if self.baseline is None and self.auto_result is None:return
        if selected and self.baseline and (selected.hwnd,selected.pid)==(self.baseline.hwnd,self.baseline.pid):return
        if self.state.snapshot()[0]:self.state.toggle_analysis()
        self.state.invalidate();self.baseline=None;self.auto_result=None
        self.quick_confirm.setChecked(False);self.quick_confirm.setEnabled(False)
        self.quick_status.setText('Окно изменилось. Сделайте новый снимок и повторите настройку.')
        self.refresh()

    def capture_window(self):
        if not self.api or not self.windows_combo.currentData():
            self.status.setText('Выберите окно игры в списке.');return
        if self.windows_combo.currentData().pid==os.getpid():
            self.status.setText('Нельзя выбрать собственное окно помощника. Выберите Deadlock.');return
        hwnd=self.windows_combo.currentData().hwnd
        self.hide()
        self.capture_started.emit()
        def capture():
            if self._closing:
                return
            try:
                import mss
                snapshot=self.api.snapshot(hwnd)
                if not snapshot or snapshot.minimized:
                    raise ValueError('Разверните окно игры и повторите снимок.')
                if snapshot.pid==os.getpid():
                    raise ValueError('Нельзя захватывать собственное окно помощника.')
                r=snapshot.rect
                with mss.mss() as capture_api:
                    image=np.asarray(capture_api.grab(dict(left=r.left,top=r.top,width=r.width,height=r.height)))[:,:,:3].copy()
                self.baseline=snapshot
                self.set_frame(image,snapshot.dpi)
                self.status.setText('Снимок получен. Выделите миникарту и настройте цвета команд.')
                if self._auto_capture:self.run_auto_setup()
            except Exception as exc:
                self.status.setText(f'Снимок не получен: {exc}')
            finally:
                self._auto_capture=False
                self.capture_finished.emit()
                self.show()
        QTimer.singleShot(400,self,capture)

    def set_frame(self,frame,dpi=None):
        if self.auto_attempted:
            self.auto_result=None;self.quick_confirm.setChecked(False);self.quick_confirm.setEnabled(False)
            self.quick_status.setText('Кадр изменился. Повторите автоматическую настройку.')
        size=(frame.shape[1],frame.shape[0])
        if size!=tuple(self.profile.target_size):
            self.profile.roi=Rect(0,0,0,0);self.profile.exclusions=[];self.profile.objectives=[]
        self.profile.target_size=size
        if dpi is not None:
            self.profile.dpi=dpi
        self.canvas.set_image(frame)
        self.state.invalidate()

    def open_image(self):
        path,_=QFileDialog.getOpenFileName(self,'Кадр или запись наблюдения','','Медиа (*.png *.jpg *.jpeg *.bmp *.mp4 *.mkv *.avi)')
        if not path:return
        frame=cv2.imread(path)
        if frame is None:
            cap=cv2.VideoCapture(path);ok,frame=cap.read();cap.release()
            if not ok:frame=None
        if frame is None:
            self.status.setText('Не удалось прочитать кадр или видео.');return
        self.baseline=None
        self.set_frame(frame)
        self.status.setText('Открыт файл для калибровки. Для живого анализа затем выберите окно и сделайте снимок.')
        if self._auto_capture:self.run_auto_setup()

    def set_mode(self,mode):
        self.canvas.mode=mode
        self.preview_label.setText({'roi':'Протяните прямоугольник вокруг миникарты.',
            'exclude':'Выделите внутри карты статичную деталь, которую нужно игнорировать.',
            'objective':'Нажмите на объект внутри карты.',
            'team1':'Нажмите на цветной край значка героя команды 1.',
            'team2':'Нажмите на цветной край значка героя команды 2.'}[mode])

    def sync_team_controls(self):
        for team,controls in self.team_controls.items():
            value=next((t for t in self.profile.teams if t.team==team),None)
            for field,spin in controls.items():
                spin.blockSignals(True);spin.setValue(getattr(value,field) if value else spin.minimum())
                spin.setEnabled(value is not None);spin.blockSignals(False)

    def set_team_field(self,team,field,value):
        marker=next((t for t in self.profile.teams if t.team==team),None)
        if marker:
            setattr(marker,field,value);self.state.invalidate();self.canvas.detections=[];self.canvas.update()
            if self.profile.marker_mode=='portraits':
                self.auto_attempted=True;self.auto_result=None
                self.quick_confirm.setChecked(False);self.quick_confirm.setEnabled(False)

    def calibration_changed(self):
        self.auto_attempted=self.profile.marker_mode=='portraits';self.auto_result=None
        self.quick_confirm.setChecked(False);self.quick_confirm.setEnabled(False)
        self.state.invalidate();self.canvas.detections=[];self.sync_team_controls();self.canvas.update()
        r=self.profile.roi
        self.preview_label.setText(f'Область: {r.width}×{r.height}. Масок: {len(self.profile.exclusions)}. Объектов: {len(self.profile.objectives)}.')

    def undo_mask(self):
        if self.profile.exclusions:self.profile.exclusions.pop();self.calibration_changed()

    def undo_objective(self):
        if self.profile.objectives:self.profile.objectives.pop();self.calibration_changed()

    def preview(self):
        try:
            self.profile.validate()
            if self.canvas.frame is None:raise ValueError('Сначала откройте снимок')
            r=self.profile.roi
            self.canvas.detections=detect(self.canvas.frame[r.top:r.top+r.height,r.left:r.left+r.width],self.profile)
            counts=[sum(d.team==team for d in self.canvas.detections) for team in (1,2)]
            self.preview_label.setText(f'На снимке найдено: команда 1 — {counts[0]}, команда 2 — {counts[1]}. '
                'Сверьте кружки с героями; исключите ложные объекты и настройте размеры/цвет.')
            self.canvas.update()
            if self.profile.marker_mode=='portraits':
                from .autocalibration import CalibrationResult
                plausible=all(1<=count<=6 for count in counts)
                message=(f'Проверка исправленной настройки: {counts[0]} и {counts[1]} кандидатов. Сверьте кружки.'
                         if plausible else 'Исправленная настройка не прошла проверку. Анализ заблокирован.')
                self.present_calibration_result(CalibrationResult(self.profile,list(self.canvas.detections),
                                                                  {'manual_preview':True},message,plausible))
        except ValueError as exc:self.preview_label.setText(str(exc))

    def apply_hotkeys(self):
        if self.hotkeys:
            self.hotkeys.register({'overlay':self.profile.overlay_key,'analysis':self.profile.analysis_key})

    def apply_settings(self):
        before=deepcopy(self.profile)
        try:
            self.profile.fps=self.fps_spin.value()
            self.profile.overlay_key=self.overlay_key.text().strip()
            self.profile.analysis_key=self.analysis_key.text().strip()
            # Hotkeys can be configured before map calibration is complete.
            from .hotkeys import parse_hotkey
            if parse_hotkey(self.profile.overlay_key)==parse_hotkey(self.profile.analysis_key):
                raise ValueError('Назначьте разные сочетания клавиш')
            self.apply_hotkeys();self.state.invalidate()
            self.status.setText('Настройки применены.')
        except ValueError as exc:
            self.profile.fps=before.fps;self.profile.overlay_key=before.overlay_key;self.profile.analysis_key=before.analysis_key
            try:self.apply_hotkeys()
            except ValueError:pass
            self.status.setText(str(exc))

    def save_profile(self):
        path,_=QFileDialog.getSaveFileName(self,'Сохранить профиль','profile.json','Профиль (*.json)')
        if path:
            try:
                self.profile.save(Path(path));self.status.setText('Профиль сохранён.')
            except (ValueError,OSError) as exc:self.status.setText(str(exc))

    def load_profile(self):
        path,_=QFileDialog.getOpenFileName(self,'Загрузить профиль','','Профиль (*.json)')
        if not path:return
        try:
            profile=Profile.load(Path(path))
            previous=self.profile
            self.profile=profile
            try:self.apply_hotkeys()
            except ValueError:
                self.profile=previous;self.apply_hotkeys();raise
            self.canvas.profile=profile;self.baseline=None;self.canvas.frame=None;self.canvas.detections=[]
            self.fps_spin.setValue(profile.fps);self.overlay_key.setText(profile.overlay_key);self.analysis_key.setText(profile.analysis_key)
            self.calibration_changed()
            self.status.setText('Профиль загружен. Выберите окно игры и перепроверьте снимок.')
        except (ValueError,OSError) as exc:self.status.setText(str(exc))

    def hotkey_action(self,action):
        if action=='overlay':self.toggle_overlay()
        elif action=='analysis':self.toggle_analysis()

    def toggle_overlay(self):
        self.state.toggle_overlay();self.refresh()

    def toggle_analysis(self):
        if self.state.snapshot()[0]:
            self.state.toggle_analysis();self.overlay.set_events([]);self.refresh()
            self.status.setText('Анализ выключен. Подсказки очищены.');return
        if self.panorama_log:
            try:
                self.start_panorama()
            except (ValueError,RuntimeError,OSError) as exc:
                self.status.setText(str(exc))
            return
        try:
            if self.auto_attempted and (not self.auto_result or not self.auto_result.plausible or not self.quick_confirm.isChecked()):
                raise ValueError('Автонастройка ещё не подтверждена. Проверьте карту и кружки перед запуском.')
            if not self.api:raise ValueError('Живой анализ запускается в Windows 10–11.')
            self.profile.validate()
            if not self.baseline:raise ValueError('Сделайте снимок выбранного окна игры перед запуском.')
            if (self.baseline.rect.width,self.baseline.rect.height)!=tuple(self.profile.target_size) or self.baseline.dpi!=self.profile.dpi:
                raise ValueError('Размер или DPI профиля не совпадает с окном. Перепроверьте калибровку.')
            if self.worker and not self.worker.stop():
                raise ValueError('Предыдущая обработка ещё завершается. Повторите включение чуть позже.')
            rect=desktop_roi(self.baseline,self.profile)
            self.move_overlay_to_map(rect)
            self.overlay.show()
            self.capture_excluded=self.api.exclude_overlay(int(self.overlay.winId()))
            if not self.capture_excluded:
                self.overlay.hide()
                raise ValueError('Windows не подтвердила исключение оверлея из захвата. Нужна Windows 10 2004+ или Windows 11.')
            profile=deepcopy(self.profile);baseline=self.baseline;api=self.api;ignored={int(self.overlay.winId())}
            session=AnalysisSession(self.state,profile,lambda:MssSource(api,baseline,profile,ignored,True),clock=monotonic)
            if self.config_path:
                self.profile.save(self.config_path)
            self.worker=AnalysisWorker(session,profile.fps)
            self.state.toggle_analysis();self.worker.start();self.refresh()
            self.status.setText('Запуск анализа. Панель можно убрать с области миникарты.')
        except (ValueError,RuntimeError,OSError) as exc:self.status.setText(str(exc))

    def move_overlay_to_map(self,rect):
        monitor,_=self.api.monitor(self.baseline.hwnd)
        for screen in QApplication.screens():
            g=screen.geometry()
            scale=screen.devicePixelRatio()
            # On Windows Qt keeps physical desktop origins and uses logical sizes.
            if ((g.x(),g.y())==(monitor.left,monitor.top)
                    and abs(round(g.width()*scale)-monitor.width)<=1
                    and abs(round(g.height()*scale)-monitor.height)<=1):
                self.overlay.setGeometry(*physical_to_logical(rect,monitor,(g.x(),g.y()),scale))
                return
        raise RuntimeError('Не удалось определить экран для оверлея.')

    def start_panorama(self):
        if not self.api:
            raise ValueError('Оверлей Panorama запускается в Windows 10–11.')
        games=[window for window in self.api.windows() if window.title.strip().casefold()=='deadlock']
        if len(games)!=1:
            raise ValueError('Откройте одно окно Deadlock и включите анализ снова.')
        if self.worker and not self.worker.stop():
            raise ValueError('Предыдущая обработка ещё завершается.')
        self.baseline=games[0]
        self._panorama_geometry=None
        self._selected_portrait=None
        self._stats_until=0
        self.overlay.set_events([])
        self.overlay.show()
        self.capture_excluded=self.api.exclude_overlay(int(self.overlay.winId()))
        self.overlay.hide()
        if not self.capture_excluded:
            raise ValueError('Windows не подтвердила исключение оверлея из захвата.')
        profile=deepcopy(self.profile)
        baseline,api,overlay=self.baseline,self.api,int(self.overlay.winId())
        session=PanoramaSession(self.state,profile,self.panorama_log,self.portrait_keys,
            hero_icons=self.hero_icons, minimap_source=lambda: MssSource(api,baseline,profile,{overlay},True))
        self.worker=AnalysisWorker(session,15)
        self.state.toggle_analysis()
        self.worker.start()
        self.refresh()

    def panorama_frame(self,session,now):
        frame=session.frame
        seen=session.last_success
        if frame is not None and seen is not None and now-seen<=MAX_AGE:
            return frame
        return None

    def export_final_stats(self):
        frame=self.stats_frame
        if frame is None:
            return
        final=frame.state=='final'
        title='Итоговая статистика' if final else 'Последние данные матча'
        match_id=frame.match_id or (self.match_id_edit.text() if self.match_id_edit.hasAcceptableInput() else '')
        prefix=f'deadlock-{match_id}' if match_id else 'deadlock'
        suffix='final' if final else 'last-observed'
        filename=f'{prefix}-{suffix}.csv'
        path,_=QFileDialog.getSaveFileName(self,title,filename,'CSV (*.csv)')
        if not path:
            return
        try:
            export_stats(path,frame.roster)
            self.status.setText(f'{title} · CSV сохранён.')
        except (ValueError,OSError) as exc:
            self.status.setText(f'Не удалось сохранить CSV. {exc}')

    def copy_broadcast_url(self, button, route, label):
        QApplication.clipboard().setText(self.broadcast.url(route))
        button.setText('Ссылка скопирована')
        QTimer.singleShot(1200, button, lambda: button.setText(label))

    def publish_broadcast_stats(self):
        if self.broadcast.feed.publish(self.match_id_edit.text()):
            self.vmix_publish.setText('Статистика отправлена')
            QTimer.singleShot(1200, self.vmix_publish, lambda: self.vmix_publish.setText('Показать статистику'))

    def render_panorama(self,enabled,visible,events):
        session=self.worker.session if self.worker else None
        stats_frame=session.stats_frame if session else None
        if self.broadcast:
            self.broadcast.feed.poll(self.match_id_edit.text(), self.live_stats.isChecked())
            if broadcast_stats := self.broadcast.feed.stats_frame:
                self.vmix_publish.setEnabled(True)
                if stats_frame is None or broadcast_stats.time >= stats_frame.time:
                    stats_frame=broadcast_stats
        if stats_frame:
            self.stats_frame=stats_frame
            text='Выгрузить итоги в CSV…' if self.stats_frame.state=='final' else 'Выгрузить последние данные в CSV…'
            self.export_button.setText(text)
            self.export_button.setEnabled(True)
        now=monotonic()
        frame=self.panorama_frame(session,now) if enabled and session else None
        roi=frame.desktop_map(self.baseline.rect) if frame else None
        if frame is None:
            self._selected_portrait=None
            self._stats_until=0
        stats=None
        if visible and roi and self.capture_excluded:
            validity=validate_snapshot(self.baseline,self.api.snapshot(self.baseline.hwnd),roi,
                self.api.occluders(self.baseline.hwnd,{int(self.overlay.winId())}))
            if validity.valid:
                if self._panorama_geometry!=roi:
                    try:
                        self.move_overlay_to_map(roi)
                        self._panorama_geometry=roi
                    except (RuntimeError,OSError) as exc:
                        self.status.setText(str(exc))
                        self.overlay.hide()
                        return
                selected=[row for row in frame.roster if row.selected] if not self.broadcast else []
                if len(selected)==1:
                    player=selected[0]
                    identity=(frame.session,player.portrait,player.player)
                    if self._selected_portrait!=identity:
                        self._selected_portrait=identity
                        self._stats_until=now+3
                    if self.live_stats.isChecked() and now<self._stats_until and (player.player or player.hero):
                        stats=player
                else:
                    self._selected_portrait=None
                self.overlay.set_events(events,stats,show_idle=True)
                self.overlay.show()
                return
            self.status.setText(validity.reason)
        self.overlay.set_events([])
        self.overlay.hide()

    def refresh(self):
        enabled,visible,_,events=self.state.snapshot()
        self.analysis_button.setText('Остановить анализ' if enabled else 'Включить анализ')
        ready=(self.panorama_log or not self.auto_attempted
               or bool(self.auto_result and self.auto_result.plausible and self.quick_confirm.isChecked()))
        self.analysis_button.setEnabled(bool(enabled or ready))
        self.overlay_button.setText('Скрыть оверлей' if visible else 'Показать оверлей')
        self.calibration_page.setEnabled(not enabled);self.settings_page.setEnabled(not enabled)
        self.quick_page.setEnabled(not enabled)
        if self.worker:
            session=self.worker.session
            if not self.panorama_log and enabled and session.last_success is not None and monotonic()-session.last_success>1:
                self.state.invalidate();events=[]
            if enabled or session.status.startswith('Ошибка'):
                detail=session.status
                if enabled and session.last_success is not None:
                    age=max(0,round((monotonic()-session.last_success)*1000))
                    detail+=f' · возраст кадра {age} мс · значков {len(session.detections)}'
                self.status.setText(detail)
        if self.panorama_log:
            self.render_panorama(enabled,visible,events)
            return
        self.overlay.set_events(events if enabled and visible else [])
        self.overlay.setVisible(bool(enabled and visible and self.capture_excluded))

    def closeEvent(self,event):
        self._closing=True
        self.timer.stop()
        if self.state.snapshot()[0]:self.state.toggle_analysis()
        if self.worker:self.worker.stop()
        if self.broadcast:
            self.broadcast.close()
            self.broadcast.feed.close()
        if self.hotkeys:
            self.hotkeys.unregister()
            QApplication.instance().removeNativeEventFilter(self.native_filter)
        self.overlay.close();event.accept()
        self.closed.emit()
