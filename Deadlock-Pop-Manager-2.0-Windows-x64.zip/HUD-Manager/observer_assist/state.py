from threading import RLock


class ControlState:
    """Thread-safe generation boundary between controls and analysis results."""

    def __init__(self):
        self._lock = RLock()
        self.overlay_visible = True
        self.analysis_enabled = False
        self.epoch = 0
        self.result = []

    def snapshot(self):
        with self._lock:
            return self.analysis_enabled, self.overlay_visible, self.epoch, list(self.result)

    def toggle_overlay(self):
        with self._lock:
            self.overlay_visible = not self.overlay_visible

    def toggle_analysis(self):
        with self._lock:
            self.analysis_enabled = not self.analysis_enabled
            self.invalidate()

    def invalidate(self):
        with self._lock:
            self.epoch += 1
            self.result = []

    def accept_result(self, epoch, result):
        with self._lock:
            if not self.analysis_enabled or epoch != self.epoch:
                return False
            self.result = list(result)
            return True
