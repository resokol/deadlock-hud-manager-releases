"""Read-only projection of camera assignments for the local match operator."""

from typing import NamedTuple
from urllib.parse import parse_qs, urlsplit


class OperatorCamera(NamedTuple):
    stream: str = ''
    bank: str = ''
    original: str = ''
    virtual: str = ''
    status: str = ''


def viewer_stream_id(page):
    try:
        url = urlsplit(page)
        if url.hostname in ('vdo.ninja', 'www.vdo.ninja'):
            query = parse_qs(url.query)
            return (query.get('view') or query.get('v') or [''])[0]
    except ValueError:
        pass
    return ''


def operator_camera_mapping(roster, cameras, room_import):
    """Account-keyed values for display only. Keep private pages out of the public export."""
    banks = {owner: i for i, owner in enumerate(cameras.owners) if owner}
    records = {}
    for account in roster.players:
        page = roster.pages.get(account, '')
        stream = viewer_stream_id(page)
        i = banks.get(account)
        live = cameras.config['live']['guids'][i] if i is not None else ''
        replay = cameras.config['replay']['guids'][i] if i is not None else ''
        labels = []
        attribution = cameras.vdo_bank_status(account)
        if attribution:
            labels.append(attribution if room_import.fresh else 'Нет свежих данных VDO')
        if not page:
            labels.append('Нет URL')
        elif i is None:
            labels.append('Пара не назначена')
        else:
            for role, name in (('live', 'Live'), ('replay', 'Replay')):
                cfg = cameras.config[role]
                if not cfg['enabled']:
                    state = 'выкл.'
                elif not cfg['guids'][i]:
                    state = 'нет GUID'
                elif account not in roster.slots.values():
                    state = 'порядок не подтверждён'
                else:
                    state = 'готов' if cameras.routable(role, account) else 'не готов'
                labels.append(f'{name} {state}')
        records[account] = OperatorCamera(stream, str(i + 1) if i is not None else '', live, replay,
                                          ' · '.join(labels))
    return records
