"""Native window and package storage for the visual HUD editor."""

from base64 import b64decode, b64encode
import json
from pathlib import Path
import re
from tempfile import NamedTemporaryFile, TemporaryDirectory
from uuid import uuid4
from zipfile import ZIP_DEFLATED, ZIP_STORED, ZipFile

from PySide6.QtCore import QByteArray, QBuffer, QFile, QIODevice, QObject, Qt, QTimer, QUrl, Signal, Slot
from PySide6.QtGui import QImageReader
from PySide6.QtWebChannel import QWebChannel
from PySide6.QtWebEngineCore import QWebEnginePage, QWebEngineScript
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWidgets import QDialog, QFileDialog, QMessageBox, QVBoxLayout

from .hud_packages import COLOR, WEB_ROOT


STUDIO_LAYOUT = 'studio.json'
STUDIO_ASSETS = ('render.js', 'canvas.css', 'overlay.js', 'hud_code.js')
LAYER_TYPES = {'clock', 'score', 'networth', 'roster', 'player', 'health', 'abilities',
               'items', 'kda', 'boss', 'text', 'panel', 'image', 'code', 'names', 'panorama', 'pov', 'rift', 'midboss',
               'active-items', 'stamina', 'ammo', 'insecure-souls', 'purchase', 'rift-timer', 'series'}
WIDTH, HEIGHT = 1920, 1080
MAX_LAYOUT = 256 * 1024
IMAGE_PATH = re.compile(r'images/[0-9a-f]{32}\.(png|jpg|webp)')
IMAGE_TYPES = {'png': ('image/png', b'png'), 'jpg': ('image/jpeg', b'jpeg'), 'webp': ('image/webp', b'webp')}
PANORAMA_PATH = re.compile(r'[a-zA-Z][a-zA-Z0-9_-]*(?:\.(?:[a-zA-Z][a-zA-Z0-9_-]*|0|[1-9][0-9]*)|\[(?:0|[1-9][0-9]*)\])*')
MAX_IMAGE = 4 * 1024 * 1024
MAX_IMAGES = 16 * 1024 * 1024


def _number(layer, key, low, high, default=None):
    value = layer.get(key, default)
    if type(value) is not int or not low <= value <= high:
        raise ValueError(f'Проверьте значение {key} у блока.')
    return value


def _checked(layer, field, default):
    value = layer.get(field, default)
    if type(value) is not bool:
        raise ValueError(f'Проверьте значение {field} у блока.')
    return value


def _roster_style(layer):
    style = {field: _checked(layer, field, default) for field, default in (
        ('rosterHighlight', True), ('rosterShowNames', True), ('rosterShowRejuvenator', True),
        ('rosterShowHealth', False), ('rosterShowUltimate', False),
        ('rosterShowRespawn', False), ('rosterShowInvisible', False),
    )}
    for prefix, frame_color, frame_width, background, fill in (
        ('roster', '#52666a', 1, '#121d22', 0),
        ('rosterActive', '#9bf2db', 3, '#264941', 65),
    ):
        for field, default in (('FrameColor', frame_color), ('Background', background)):
            key = prefix + field
            color = layer.get(key, default)
            if not isinstance(color, str) or not COLOR.fullmatch(color):
                raise ValueError(f'Проверьте цвет {key} у блока.')
            style[key] = color
        for field, maximum, default in (('FrameWidth', 16, frame_width), ('FrameRadius', 64, 6), ('Fill', 100, fill)):
            key = prefix + field
            style[key] = _number(layer, key, 0, maximum, default)
    return style


def _panorama_settings(layer):
    path = layer.get('panoramaPath', 'gameClock')
    if not isinstance(path, str) or len(path) > 160:
        raise ValueError('Проверьте путь Panorama.')
    path = path.strip()
    if path and (not PANORAMA_PATH.fullmatch(path) or
                 any(part in ('constructor', 'prototype') for part in re.split(r'[.\[\]]+', path))):
        raise ValueError('Проверьте путь Panorama.')
    settings = {'panoramaPath': path}
    for field in ('panoramaPrefix', 'panoramaSuffix'):
        label = layer.get(field, '')
        if not isinstance(label, str) or len(label) > 80:
            raise ValueError('Добавьте не более 80 символов до и после значения Panorama.')
        settings[field] = label
    return settings


def read_layout(raw):
    if len(raw) > MAX_LAYOUT:
        raise ValueError('Макет превышает допустимый размер.')
    try:
        layout = json.loads(raw)
    except (ValueError, RecursionError) as exc:
        raise ValueError('Не удалось прочитать макет HUD.') from exc
    if not isinstance(layout, dict) or layout.get('version') != 1:
        raise ValueError('Неизвестная версия макета HUD.')
    name, layers = layout.get('name'), layout.get('layers')
    if not isinstance(name, str) or not name.strip() or len(name) > 80:
        raise ValueError('Укажите название HUD длиной от 1 до 80 символов.')
    if not isinstance(layers, list) or len(layers) > 60:
        raise ValueError('Добавьте не более 60 блоков.')
    cleaned, seen = [], set()
    for layer in layers:
        if not isinstance(layer, dict):
            raise ValueError('Некорректный блок в макете HUD.')
        kind, identity = layer.get('type'), layer.get('id')
        if not isinstance(kind, str) or kind not in LAYER_TYPES:
            raise ValueError('Неизвестный тип блока.')
        if not isinstance(identity, str) or not identity or len(identity) > 64 or identity in seen:
            raise ValueError('Повторяющийся или некорректный блок.')
        seen.add(identity)
        width = _number(layer, 'w', 24, WIDTH)
        height = _number(layer, 'h', 24, HEIGHT)
        x = _number(layer, 'x', 0, WIDTH - width)
        y = _number(layer, 'y', 0, HEIGHT - height)
        color, background = layer.get('color'), layer.get('background')
        for value in (color, background):
            if not isinstance(value, str) or not COLOR.fullmatch(value):
                raise ValueError('Проверьте цвет блока.')
        text = layer.get('text', '')
        align = layer.get('align', 'center')
        if not isinstance(text, str) or len(text) > 160 or align not in ('left', 'center', 'right'):
            raise ValueError('Проверьте текст и выравнивание блока.')
        image = layer.get('image', '')
        image_fit = layer.get('imageFit', 'contain' if kind == 'pov' else 'stretch')
        if (not isinstance(image, str) or (image and not IMAGE_PATH.fullmatch(image)) or
                image_fit not in ('stretch', 'contain', 'cover')):
            raise ValueError('Проверьте настройки изображения.')
        data_w = _number(layer, 'dataW', 1, 100, 100)
        data_h = _number(layer, 'dataH', 1, 100, 100)
        frame_color = layer.get('frameColor', '#a4e3d8')
        if not isinstance(frame_color, str) or not COLOR.fullmatch(frame_color):
            raise ValueError('Проверьте цвет рамки блока.')
        cleaned.append(dict(id=identity, type=kind, x=x, y=y, w=width, h=height,
                            size=_number(layer, 'size', 10, 160), color=color, background=background,
                            opacity=_number(layer, 'opacity', 0, 100),
                            fill=_number(layer, 'fill', 0, 100), align=align, text=text,
                            radius=_number(layer, 'radius', 0, 540, 0),
                            frameWidth=_number(layer, 'frameWidth', 0, 32, 0), frameColor=frame_color,
                            image=image, imageFit=image_fit,
                            dataX=_number(layer, 'dataX', 0, 100 - data_w, 0),
                            dataY=_number(layer, 'dataY', 0, 100 - data_h, 0),
                            dataW=data_w, dataH=data_h))
        if kind in ('roster', 'player', 'names'):
            name_overflow = layer.get('nameOverflow', 'ellipsis')
            if name_overflow not in ('ellipsis', 'wrap'):
                raise ValueError('Проверьте отображение длинных ников.')
            cleaned[-1]['nameOverflow'] = name_overflow
        if kind == 'roster':
            cleaned[-1].update(_roster_style(layer))
        elif kind == 'player':
            for field in ('playerShowRejuvenator', 'playerShowRespawn', 'playerShowInvisible'):
                cleaned[-1][field] = _checked(layer, field, False)
        elif kind == 'abilities':
            cleaned[-1]['abilitiesShowLevels'] = _checked(layer, 'abilitiesShowLevels', True)
        elif kind == 'items':
            items_mode = layer.get('itemsMode', 'all')
            if items_mode not in ('all', 'passive'):
                raise ValueError('Проверьте выбор предметов.')
            cleaned[-1]['itemsMode'] = items_mode
        elif kind == 'names':
            team, direction = layer.get('namesTeam', 'all'), layer.get('namesDirection', 'row')
            if team not in ('all', 'first', 'second', 'selected') or direction not in ('row', 'column'):
                raise ValueError('Проверьте команду и расположение ников игроков.')
            cleaned[-1].update(namesTeam=team, namesDirection=direction)
        elif kind == 'panorama':
            cleaned[-1].update(_panorama_settings(layer))
        elif kind == 'code':
            for field in ('html', 'css'):
                value = layer.get(field, '')
                if not isinstance(value, str) or len(value) > 32_000:
                    raise ValueError('HTML и CSS должны содержать не более 32 000 символов каждый.')
                cleaned[-1][field] = value
    return {'version': 1, 'name': name.strip(), 'layers': cleaned}


def _image_paths(layout):
    return set(layer['image'] for layer in layout['layers'] if layer.get('image'))


def _validate_image(path, data):
    mime, kind = IMAGE_TYPES[path.rpartition('.')[2]]
    if not data or len(data) > MAX_IMAGE:
        raise ValueError('Размер одного изображения должен быть не более 4 МБ.')
    buffer = QBuffer()
    buffer.setData(QByteArray(data))
    buffer.open(QIODevice.OpenModeFlag.ReadOnly)
    image = QImageReader(buffer)
    size = image.size()
    if image.format() != kind or not (1 <= size.width() <= 4096 and 1 <= size.height() <= 4096):
        raise ValueError('Загрузите PNG, JPEG или WebP размером до 4096 × 4096.')
    return mime


def _decode_project(raw, cached=None):
    if len(raw) > (MAX_IMAGES * 4 // 3) + 2 * MAX_LAYOUT:
        raise ValueError('Изображения в макете занимают больше 16 МБ.')
    try:
        payload = json.loads(raw)
    except (ValueError, RecursionError) as exc:
        raise ValueError('Не удалось прочитать макет HUD.') from exc
    if not isinstance(payload, dict):
        raise ValueError('Не удалось прочитать макет HUD.')
    layout = read_layout(json.dumps(payload.get('layout', payload), ensure_ascii=False))
    images = payload.get('images', {})
    paths = _image_paths(layout)
    cached = cached or {}
    if not isinstance(images, dict) or not images.keys() <= paths or not paths <= (cached.keys() | images.keys()):
        raise ValueError('В макете отсутствует изображение.')
    decoded = {path: cached[path] for path in paths - images.keys()}
    total = sum(map(len, decoded.values()))
    for path, value in images.items():
        expected = 'data:' + IMAGE_TYPES[path.rpartition('.')[2]][0] + ';base64,'
        if not isinstance(value, str) or not value.startswith(expected):
            raise ValueError('Не удалось прочитать изображение.')
        try:
            image = b64decode(value[len(expected):], validate=True)
        except ValueError as exc:
            raise ValueError('Не удалось прочитать изображение.') from exc
        _validate_image(path, image)
        total += len(image)
        if total > MAX_IMAGES:
            raise ValueError('Изображения в макете занимают больше 16 МБ.')
        decoded[path] = image
    return layout, decoded


def _archive(destination, package_id, layout, images=None):
    assets = WEB_ROOT / 'editor'
    manifest = dict(id=package_id, name=layout['name'], author='Deadlock HUD Manager',
                    version='1.0.0', game='deadlock')
    with NamedTemporaryFile(dir=destination.parent, suffix='.tmp', delete=False) as staged:
        temporary = Path(staged.name)
    try:
        with ZipFile(temporary, 'w', compression=ZIP_DEFLATED) as archive:
            archive.writestr('hud.json', json.dumps(manifest, ensure_ascii=False))
            archive.writestr(STUDIO_LAYOUT, json.dumps(layout, ensure_ascii=False))
            archive.write(assets / 'overlay.html', 'index.html')
            for file in STUDIO_ASSETS:
                archive.write(assets / file, file)
            for path, data in (images or {}).items():
                archive.writestr(path, data, compress_type=ZIP_STORED)
        temporary.replace(destination)
    finally:
        temporary.unlink(missing_ok=True)


class StudioBridge(QObject):
    committed = Signal(int, str)

    def __init__(self, library, package_id, parent):
        super().__init__(parent)
        self.library = library
        self.package_id = package_id
        self.revision = None
        self.layout = None
        self.images = {}
        self.dirty = False
        self._pending = None
        self._save_timer = QTimer(self, interval=180, singleShot=True)
        self._save_timer.timeout.connect(self.flush)
        if package_id:
            packages = library.packages
            active = packages.active(package_id)
            asset = packages.asset(package_id, STUDIO_LAYOUT)
            if active is None or asset is None:
                raise ValueError('Макет HUD отсутствует в библиотеке.')
            self.revision = active['revision']
            self.layout = read_layout(asset)
            total = 0
            for path in _image_paths(self.layout):
                image = packages.asset(package_id, path)
                if image is None:
                    raise ValueError('В пакете отсутствует изображение из макета.')
                _validate_image(path, image)
                total += len(image)
                if total > MAX_IMAGES:
                    raise ValueError('Изображения в макете занимают больше 16 МБ.')
                self.images[path] = image

    @Slot(result=str)
    def project(self):
        images = {path: 'data:' + IMAGE_TYPES[path.rpartition('.')[2]][0] + ';base64,' +
                  b64encode(image).decode('ascii') for path, image in self.images.items()}
        return json.dumps({'layout': self.layout, 'images': images}, ensure_ascii=False)

    @Slot(bool)
    def setDirty(self, dirty):
        self.dirty = dirty

    @Slot(str, int)
    def queueSave(self, raw, token):
        self._pending = raw, token
        self.dirty = True
        self._save_timer.start()

    @Slot()
    def flush(self):
        self._save_timer.stop()
        if self._pending is None:
            return not self.dirty
        raw, token = self._pending
        result = self.save(raw, self.package_id is None)
        if json.loads(result).get('ok'):
            self._pending = None
        self.committed.emit(token, result)
        return self._pending is None

    @Slot(str, bool, result=str)
    def save(self, raw, activate):
        try:
            layout, images = _decode_project(raw, self.images)
            package_id = self.package_id or 'hud-' + uuid4().hex
            with TemporaryDirectory(prefix='deadlock-hud-') as directory:
                staged = Path(directory) / (package_id + '.zip')
                _archive(staged, package_id, layout, images)
                packages = self.library.packages
                package = packages.install(staged, expected_revision=self.revision)
            self.package_id = package.id
            self.revision = packages.active(package.id)['revision']
            self.layout = layout
            self.images.update(images)
            self.dirty = False
            self.library.project_saved(package, activate)
            return json.dumps({'ok': True, 'name': package.name, 'images': list(images)}, ensure_ascii=False)
        except (OSError, ValueError) as exc:
            return json.dumps({'error': str(exc)}, ensure_ascii=False)

    @Slot(str, result=str)
    def export(self, raw):
        try:
            layout, images = _decode_project(raw, self.images)
            suggested = ''.join(c if c.isalnum() or c in '_- ' else '_' for c in layout['name'])
            name, _ = QFileDialog.getSaveFileName(self.parent(), 'Экспорт HUD', suggested + '.zip',
                                                 'Пакет HUD (*.zip)')
            if not name:
                return '{}'
            path = Path(name)
            if path.suffix.lower() != '.zip':
                path = path.with_name(path.name + '.zip')
                if path.exists() and QMessageBox.question(
                        self.parent(), 'Заменить файл?', f'Заменить пакет «{path.name}»?'
                ) != QMessageBox.StandardButton.Yes:
                    return '{}'
            # A portable copy can be imported without replacing the library's original.
            _archive(path, 'hud-' + uuid4().hex, layout, images)
            return json.dumps({'ok': True, 'name': path.name}, ensure_ascii=False)
        except (OSError, ValueError) as exc:
            return json.dumps({'error': str(exc)}, ensure_ascii=False)


class StudioPage(QWebEnginePage):
    def __init__(self, url, parent, *, pov_navigation=None):
        super().__init__(parent)
        self.studio_url = url
        self.pov_navigation = pov_navigation

    def acceptNavigationRequest(self, url, navigation_type, is_main_frame):
        if is_main_frame:
            return url == self.studio_url
        return url == QUrl('about:srcdoc') or bool(self.pov_navigation and self.pov_navigation(url))


class HudEditor(QDialog):
    def __init__(self, server_url, library, package_id, parent=None, *, pov_navigation=None):
        super().__init__(parent)
        self.setWindowTitle('Редактор HUD')
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.setMinimumSize(620, 435)
        area = self.screen().availableGeometry()
        self.resize(min(1400, max(620, area.width() - 48)), min(830, max(435, area.height() - 70)))
        self.bridge = StudioBridge(library, package_id, self)
        self.view = QWebEngineView(self)
        url = QUrl(server_url + '/hud-editor/')
        page = StudioPage(url, self.view, pov_navigation=pov_navigation)
        self.view.setPage(page)
        self.channel = QWebChannel(page)
        self.channel.registerObject('studio', self.bridge)
        page.setWebChannel(self.channel)
        library_script = QFile(':/qtwebchannel/qwebchannel.js')
        if not library_script.open(QIODevice.OpenModeFlag.ReadOnly):
            raise RuntimeError('Не удалось загрузить связь с редактором.')
        script = QWebEngineScript()
        script.setName('Qt WebChannel')
        script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentCreation)
        script.setWorldId(QWebEngineScript.ScriptWorldId.MainWorld)
        script.setRunsOnSubFrames(False)
        script.setSourceCode(bytes(library_script.readAll()).decode('utf-8'))
        page.scripts().insert(script)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.view)
        self.view.load(url)

    def reject(self):
        if not self.bridge.flush() and QMessageBox.question(
                self, 'Закрыть редактор?', 'Закрыть редактор без сохранения изменений?',
                defaultButton=QMessageBox.StandardButton.No,
        ) != QMessageBox.StandardButton.Yes:
            return
        super().reject()
