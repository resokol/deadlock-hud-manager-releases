"""Read a spectator minimap crop and apply the active broadcast palette."""

from threading import Lock
from time import monotonic

import cv2
import numpy as np

from .autocalibration import REFERENCE, locate_minimap
from .capture import validate_snapshot
from .hud_packages import COLOR
from .profile import Rect
from .win32 import WindowsApi


def recolor_minimap(image, colors):
    """Keep map detail and line positions from the current game frame."""
    hue, saturation, light = np.moveaxis(cv2.cvtColor(image, cv2.COLOR_BGR2HSV).astype(np.float32), -1, 0)
    result = image.astype(np.float32)
    for color, center, spread in zip(colors, (22, 114), (15, 12)):
        if not isinstance(color, str) or not COLOR.fullmatch(color):
            continue
        ink = np.array([int(color[i:i + 2], 16) for i in (5, 3, 1)], dtype=np.float32)
        membership = np.clip((spread - np.abs(hue - center)) / 5, 0, 1)
        membership *= np.clip((saturation - 36) / 26, 0, 1)
        membership *= np.clip((light - 55) / 41, 0, 1)
        weight = membership[:, :, None]
        target = np.clip((light[:, :, None] / 205) * ink, 0, 255)
        result += weight * (target - result)
    pixels = cv2.cvtColor(np.rint(result).astype(np.uint8), cv2.COLOR_BGR2BGRA)
    height, width = image.shape[:2]
    contour = np.zeros((height, width), dtype=np.uint8)
    cv2.ellipse(contour, (width // 2, round(height * .52)),
                (round(width * .49), round(height * .48)), 0, 0, 360, 255, -1, cv2.LINE_AA)
    pixels[:, :, 3] = contour
    pixels[contour == 0] = 0
    return pixels


def _png(image, colors):
    ok, encoded = cv2.imencode('.png', recolor_minimap(image, colors), [cv2.IMWRITE_PNG_COMPRESSION, 1])
    return encoded.tobytes() if ok else None


def minimap_preview(colors):
    example = cv2.imread(str(REFERENCE))
    return _png(example, colors) if example is not None else None


def _map_edges(image):
    gray = cv2.cvtColor(cv2.resize(image, (112, 112), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 24, 70) > 0
    y, x = np.ogrid[-1:1:112j, -1:1:112j]
    return edges & (x * x + y * y < .76)


class SpectatorMinimap:
    def __init__(self, api=None):
        self.api = WindowsApi() if api is None else api
        self.lock = Lock()
        self.window = None
        self.roi = None
        self.reference_edges = None
        self.retry_at = 0
        self.next_frame = 0
        self.cached = None

    def frame(self, match, colors):
        with self.lock:
            return self._frame(match, colors)

    def _frame(self, match, colors):
        from mss import mss
        from mss.exception import ScreenShotError

        game = self.api.foreground_snapshot()
        if not match or not game or game.title.casefold() != 'deadlock' or game.minimized:
            self.window = self.cached = None
            return None
        identity = (match, game.hwnd, game.pid, game.rect, game.dpi)
        now = monotonic()
        if self.window != identity:
            self.window = identity
            self.roi = self.cached = None
            self.retry_at = self.next_frame = 0
        if self.roi is not None and not validate_snapshot(game, game, self.roi,
                                                         self.api.occluders(game.hwnd, set())).valid:
            self.cached = None
            return None
        if now < self.next_frame:
            return self.cached
        self.next_frame = now + .12
        try:
            with mss() as capture:
                if self.roi is None:
                    if now < self.retry_at:
                        return None
                    self.retry_at = now + 2
                    size = min(game.rect.width, round(game.rect.height * .62))
                    search = Rect(game.rect.left + game.rect.width - size,
                                  game.rect.top + game.rect.height - size, size, size)
                    region = self._grab(capture, search)
                    relative, _ = locate_minimap(region)
                    self.roi = Rect(search.left + relative.left, search.top + relative.top,
                                    relative.width, relative.height)
                    image = region[relative.top:relative.top + relative.height, relative.left:relative.left + relative.width]
                    self.reference_edges = _map_edges(image)
                else:
                    image = self._grab(capture, self.roi)
                foreground = self.api.foreground_snapshot()
                if not validate_snapshot(game, foreground, self.roi, self.api.occluders(game.hwnd, set())).valid:
                    self.cached = None
                    return None
                edges = cv2.dilate(_map_edges(image).astype(np.uint8), np.ones((3, 3), dtype=np.uint8)) > 0
                if np.count_nonzero(edges & self.reference_edges) < .45 * np.count_nonzero(self.reference_edges):
                    self.roi = self.cached = None
                    return None
                self.cached = _png(image, colors)
        except (ValueError, OSError, ScreenShotError, cv2.error):
            self.roi = self.cached = None
        return self.cached

    @staticmethod
    def _grab(capture, rect):
        return np.asarray(capture.grab(dict(left=rect.left, top=rect.top, width=rect.width,
                                            height=rect.height)))[:, :, :3].copy()
