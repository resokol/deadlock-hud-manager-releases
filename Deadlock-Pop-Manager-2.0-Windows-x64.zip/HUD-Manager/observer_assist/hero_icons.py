from collections import Counter
from dataclasses import replace
import json
from math import hypot
import re

import cv2
import numpy as np


class HeroIcons:
    """Associate visible minimap icons with the heroes named in the top bar."""

    def __init__(self, icons):
        self.icons = {name.strip().casefold(): image for name, image in icons.items()}
        self.roster = None
        self.learned = {}
        self.pending = {}
        self.template_width = None
        self.templates = {}

    @classmethod
    def from_cache(cls, root):
        icons = {}
        catalog = json.loads((root/'catalog.json').read_text(encoding='utf-8-sig'))
        for hero, entry in catalog.items():
            path = root/f'{hero}.png'
            if not re.fullmatch(r'hero_[a-z0-9_]+', hero) or not path.is_file():
                continue
            image = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_UNCHANGED)
            if image is not None and image.ndim == 3 and image.shape[2] == 4:
                for name in entry['names']:
                    icons[name] = image
        return cls(icons)

    def _variants(self, hero, width):
        if width != self.template_width:
            self.templates.clear()
            self.template_width = width
        if hero not in self.templates:
            raw = self.icons[hero]
            variants = []
            for scale in (.053, .057, .060, .064):
                size = max(8, round(width*scale))
                image = cv2.resize(raw, (size, size), interpolation=cv2.INTER_AREA)
                mask = (image[:, :, 3] >= 210).astype(np.uint8)
                if np.count_nonzero(mask) >= size*size/8:
                    variants.append((image[:, :, :3].copy(), mask))
            self.templates[hero] = variants
        return self.templates[hero]

    def _match(self, frame, image, choices, reserved):
        height, width = image.shape[:2]
        results = {}
        for marker in frame.players:
            if marker.portrait or marker.id in self.learned or any(
                other.id != marker.id and hypot(marker.x-other.x, marker.y-other.y) < .075
                for other in frame.players
            ):
                continue
            # Panorama reports the marker panel's top-left corner.
            x, y = round((marker.x+.036)*width), round((marker.y+.036)*height)
            radius = round(.053*width)
            left, top = max(0, x-radius), max(0, y-radius)
            crop = image[top:y+radius+1, left:x+radius+1]
            scores = []
            for slot, hero in choices.items():
                best = float('inf')
                for icon, mask in self._variants(hero, width):
                    size = len(icon)
                    if min(crop.shape[:2]) < size:
                        continue
                    scores_map = cv2.matchTemplate(crop, icon, cv2.TM_SQDIFF_NORMED, mask=mask)
                    y0, x0 = (max(0, round(center-radius*.42-size/2))
                              for center in (y-top, x-left))
                    y1, x1 = (round(center+radius*.42-size/2)+1 for center in (y-top, x-left))
                    if y1 <= y0 or x1 <= x0:
                        continue
                    local = scores_map[y0:y1, x0:x1]
                    finite = local[np.isfinite(local)]
                    if finite.size:
                        best = min(best, float(finite.min()))
                scores.append((best, slot))
            scores.sort()
            if scores:
                score, slot = scores[0]
                margin = scores[1][0]-score if len(scores) > 1 else float('inf')
                if slot not in reserved and score <= .14 and margin >= .06:
                    results[marker.id] = slot
        counts = Counter(results.values())
        return {marker: slot for marker, slot in results.items() if counts[slot] == 1}

    def read(self, frame, grab_image):
        if not frame.roster:
            return frame
        roster = (frame.session, tuple((p.player, p.hero) for p in frame.roster))
        if roster != self.roster:
            self.roster = roster
            self.learned.clear()
            self.pending.clear()
        confirmed = {marker.id: marker.portrait for marker in frame.players if marker.portrait}
        occupied = {slot: marker for marker, slot in confirmed.items()}
        self.learned = {marker: slot for marker, slot in self.learned.items()
                        if marker not in confirmed and slot not in occupied}
        reserved = set(occupied) | set(self.learned.values())
        labels = {row.portrait: row.hero.strip().casefold() for row in frame.roster}
        counts = Counter(labels.values())
        choices = {slot: hero for slot, hero in labels.items() if hero in self.icons and counts[hero] == 1}
        if choices.keys() - reserved and any(p.id not in confirmed and p.id not in self.learned for p in frame.players):
            image = grab_image()
            if image is not None:
                matches = self._match(frame, image, choices, reserved)
                for marker, slot in matches.items():
                    previous = self.pending.get(marker)
                    if previous and previous[0] == slot and .1 <= frame.time-previous[1] <= .75:
                        self.learned[marker] = slot
                self.pending = {marker: (slot, frame.time) for marker, slot in matches.items()}
        return replace(frame, players=tuple(replace(player, portrait=self.learned[player.id])
                       if player.id in self.learned else player for player in frame.players))
