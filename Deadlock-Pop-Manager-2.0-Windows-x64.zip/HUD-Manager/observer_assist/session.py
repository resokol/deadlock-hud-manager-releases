from .events import EventEngine
from .tracking import Tracker
from .vision import detect


class AnalysisSession:
    """A tick is run on one worker; controls may invalidate its generation."""

    def __init__(self,state,profile,source_factory,detector=detect,clock=None):
        self.state,self.profile,self.source_factory = state,profile,source_factory
        self.detector = detector
        self.clock = clock
        self.tracker,self.engine = Tracker(),EventEngine()
        self.source = None
        self._epoch = -1
        self.last_success = None
        self.status = 'Анализ выключен'
        self.detections = []

    def close(self):
        if self.source is not None:
            try:
                self.source.close()
            finally:
                self.source = None
        self.tracker.reset()
        self.engine.reset()
        self.detections = []
        self.last_success = None

    def tick(self,now):
        enabled,_,epoch,_ = self.state.snapshot()
        if epoch != self._epoch or not enabled:
            self.close()
            self._epoch = epoch
        if not enabled:
            self.status = 'Анализ выключен'
            return
        try:
            if self.source is None:
                self.source = self.source_factory()
            frame = self.source.grab()
            if not frame.validity.valid:
                raise RuntimeError(frame.validity.reason)
            current = self.clock() if self.clock else now
            if not -.1 <= current-frame.captured_at <= 1:
                raise RuntimeError('Нет свежих кадров')
            ds = self.detector(frame.image,self.profile)
            tracks = self.tracker.update(ds,frame.captured_at)
            events = self.engine.update(tracks,frame.captured_at,self.profile)
            if self.clock and self.clock()-frame.captured_at>1:
                raise RuntimeError('Нет свежих результатов: обработка кадра заняла слишком долго')
            if self.state.accept_result(epoch,events):
                self.detections = ds
                self.last_success = frame.captured_at
                self.status = 'Анализ работает'
        except (OSError,RuntimeError,ValueError) as exc:
            self.state.invalidate()
            self.close()
            self.status = str(exc)
