"""Read-only match statistics for local graphics and opt-in LAN export."""

from functools import partial
from hmac import compare_digest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from ipaddress import IPv4Address, IPv4Interface, IPv4Network
import json
import re
from threading import Event, Thread
from urllib.parse import parse_qs, urlencode, urlsplit

from .broadcast_tables import BROADCAST_ROUTES
from .fight_recap import FIGHT_RECAP_ROUTE
from .hero_stats import HERO_STATS_ROUTE
from .pov_match_data import POV_MATCH_ROUTE


STATS_ROUTE = '/api/v1/stats'
STATS_PORT = 53558
LAN_NETWORKS = tuple(map(IPv4Network, ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16')))
STATS_PAGES = ('/stats/', '/hero-stats/', '/fight-recap/')
STATS_WEB_FILES = {
    '/stats/': ('stats.html', 'text/html; charset=utf-8'),
    '/stats/stats.js': ('stats.js', 'text/javascript; charset=utf-8'),
    '/stats/stats.css': ('stats.css', 'text/css; charset=utf-8'),
    '/hero-stats/': ('hero-stats.html', 'text/html; charset=utf-8'),
    '/hero-stats/hero-stats.js': ('hero-stats.js', 'text/javascript; charset=utf-8'),
    '/hero-stats/hero-stats.css': ('hero-stats.css', 'text/css; charset=utf-8'),
    '/fight-recap/': ('fight-recap.html', 'text/html; charset=utf-8'),
    '/fight-recap/fight-recap.js': ('fight-recap.js', 'text/javascript; charset=utf-8'),
    '/fight-recap/fight-recap.css': ('fight-recap.css', 'text/css; charset=utf-8'),
}


def is_stats_asset(path):
    return (path in STATS_WEB_FILES or path in (
        '/hud/packages/deadlock-default/icons.json', '/hud/packages/deadlock-default/icons.webp',
        '/game-icons/catalog.json',
    ) or bool(re.fullmatch(r'/game-icons/icons-[0-9a-f]{16}\.webp', path)))


def is_lan_address(address):
    return any(address in network for network in LAN_NETWORKS)


def match_stats(telemetry, broadcast_url=None):
    data = telemetry or {}
    teams = data.get('teams') or []
    live = any(team.get('players') for team in teams)
    match = broadcast_url.rsplit('/', 1)[-1].partition('_')[0] if broadcast_url else None
    return {
        'version': 1,
        'status': 'live' if live else 'waiting',
        'matchId': match if live else None,
        'sampledAt': data.get('sampledAt') if live else None,
        'gameClock': data.get('gameClock') if live else None,
        'midBossTimer': data.get('midBossTimer') if live else None,
        'midBoss': data.get('midBoss'),
        'teams': teams if live else [],
        'selected': data.get('selected') if live else None,
        'kdaSource': data.get('kdaSource') if live else None,
    }


class StatsLanServer:
    def __init__(self, address, token, snapshot, port=STATS_PORT, *, hero_snapshot=None,
                 fight_snapshot=None, assets=None, stream=None, broadcast=None, take=None, control_token=None, pov_snapshot=None):
        interface = IPv4Interface(address)
        if not (is_lan_address(interface.ip) or interface.ip.is_loopback) or not token:
            raise ValueError('Выберите локальный IPv4-адрес.')
        self.address = str(interface.ip)
        self._token = token
        self._control_token = control_token
        self._closing = Event()
        routes = {STATS_ROUTE: snapshot}
        if hero_snapshot is not None:
            routes[HERO_STATS_ROUTE] = hero_snapshot
        if fight_snapshot is not None:
            routes[FIGHT_RECAP_ROUTE] = fight_snapshot
        streams = {path + '/events': read for path, read in routes.items()} if stream else {}
        if pov_snapshot is not None:
            routes[POV_MATCH_ROUTE] = pov_snapshot
        if broadcast is not None:
            routes.update({path: partial(broadcast, table) for path, table in BROADCAST_ROUTES.items()})

        class Request(BaseHTTPRequestHandler):
            def setup(request):
                request.request.settimeout(3)
                super().setup()

            def do_POST(request):
                if (request.headers.get('Host') != f'{self.address}:{self.port}' or
                        IPv4Address(request.client_address[0]) not in interface.network):
                    request.send_error(403)
                    return
                address = urlsplit(request.path)
                match = re.fullmatch(r'/api/v1/pov/program/([1-9]|1[0-2])', address.path)
                if not match or not take or not control_token:
                    request.send_error(404)
                    return
                keys = parse_qs(address.query).get('token', [])
                if len(keys) != 1 or not keys[0].isascii() or not compare_digest(keys[0], control_token):
                    request.send_error(403)
                    return
                if not take(int(match[1])):
                    request.send_error(409, 'Position or Mix unavailable')
                    return
                request.send_response(202)
                request.send_header('Content-Length', '0')
                request.end_headers()

            def do_GET(request):
                if (request.headers.get('Host') != f'{self.address}:{self.port}' or
                        IPv4Address(request.client_address[0]) not in interface.network):
                    request.send_error(403)
                    return
                try:
                    address = urlsplit(request.path)
                except ValueError:
                    request.send_error(400)
                    return
                path = address.path
                read = routes.get(path)
                events = streams.get(path)
                asset = assets is not None and is_stats_asset(path)
                if read is None and events is None and not asset:
                    request.send_error(404)
                    return
                if read is not None or events is not None or path in STATS_PAGES:
                    keys = parse_qs(address.query).get('token', [])
                    if len(keys) != 1 or not keys[0].isascii() or not compare_digest(keys[0], self._token):
                        request.send_error(403)
                        return
                if events is not None:
                    stream(request, events, stopped=self._closing.is_set)
                    return
                if read is not None:
                    body = json.dumps(read(), ensure_ascii=False).encode('utf-8')
                    kind = 'application/json; charset=utf-8'
                else:
                    try:
                        result = assets(path)
                    except OSError:
                        result = None
                    if result is None:
                        request.send_error(404)
                        return
                    body, kind = result
                request.send_response(200)
                request.send_header('Content-Type', kind)
                if read is not None:
                    request.send_header('Access-Control-Allow-Origin', '*')
                request.send_header('Cache-Control', 'no-store')
                request.send_header('X-Content-Type-Options', 'nosniff')
                request.send_header('Referrer-Policy', 'no-referrer')
                request.send_header('Content-Length', str(len(body)))
                request.end_headers()
                try:
                    request.wfile.write(body)
                except OSError:
                    pass

            def log_message(request, *args):
                pass

        self._server = ThreadingHTTPServer((self.address, port), Request)
        self.port = self._server.server_port
        Thread(target=self._server.serve_forever, kwargs={'poll_interval': 0.1}, daemon=True).start()

    @property
    def url(self):
        return self._url(STATS_ROUTE)

    @property
    def hero_url(self):
        return self._url(HERO_STATS_ROUTE)

    def program_url(self, slot):
        return f'http://{self.address}:{self.port}/api/v1/pov/program/{slot}?' + urlencode({'token': self._control_token})

    def graphic_url(self, path):
        if path not in STATS_PAGES:
            raise ValueError('Неизвестная таблица статистики.')
        return self._url(path)

    def broadcast_url(self, path):
        if path not in BROADCAST_ROUTES:
            raise ValueError('Неизвестная таблица для графики.')
        return self._url(path)

    def _url(self, path):
        return f'http://{self.address}:{self.port}{path}?' + urlencode({'token': self._token})

    def close(self):
        self._closing.set()
        self._server.shutdown()
        self._server.server_close()
