"""Collect VDO.Ninja room snapshots through a private loopback browser page."""

import html
import json
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit


DEFAULT_POLL_SECONDS = 3
MAX_POLL_SECONDS = 60


def poll_seconds(value):
    try:
        return max(1, min(MAX_POLL_SECONDS, int(value)))
    except (ValueError, TypeError, OverflowError):
        return DEFAULT_POLL_SECONDS


# The direct iframe commands in VDO.Ninja main.js return the objects built by
# getGuestList and getDetailedState in lib.js, keyed by slot and stream ID respectively.
_SCRIPT = """
const frame = document.querySelector('#director');
const status = document.querySelector('#status');
const target = new URL(frame.src).origin;
const scene = frame.dataset.mode === 'scene';
const tabHeader = {'X-Room-Tab': frame.dataset.tab};
let interval = Number(frame.dataset.pollSeconds) * 1000;
let serial = 0;
let pending = '';
let unanswered = 0;
let posting = false;
let stopped = false;
let checking = false;
let missedChecks = 0;
let slots;
let snapshot;
let inbound;
let fallback;
let videoHistory = new Map();
let previewRates = new Map();
let receiverMedia = {};
let priorStreams = new Set();
let confirmDeparture;
let lastSignaling = -Infinity;

function stop(message) {
    stopped = true;
    pending = '';
    clearInterval(timer);
    clearInterval(heartbeat);
    clearTimeout(fallback);
    clearTimeout(confirmDeparture);
    frame.remove();
    status.textContent = message;
}

async function checkSession() {
    if (checking || stopped) return;
    checking = true;
    try {
        const result = await fetch('active', {headers: tabHeader, credentials:'omit',
                                             signal:AbortSignal.timeout(4500)});
        if (result.status === 410) return stop('Подключение продолжено в другой вкладке.');
        if (!result.ok) throw new Error();
        const next = Number(result.headers.get('X-Room-Poll-Seconds')) * 1000;
        if (!stopped && next > 0 && next !== interval) {
            clearInterval(timer);
            interval = next;
            unanswered = 0;
            timer = setInterval(poll, interval);
            poll();
        }
        missedChecks = 0;
    } catch {
        if (++missedChecks >= 3) stop('Подключение остановлено. Откройте комнату из POV Manager.');
    } finally {
        checking = false;
    }
}

function poll() {
    if (stopped) return;
    if (frame.dataset.login === '1') {
        pending = '';
        unanswered = 0;
        return;
    }
    if (unanswered >= Math.max(3, Math.ceil(60000 / interval))) {
        unanswered = 0;
        pending = '';
        status.textContent = 'Переподключение к VDO.Ninja…';
        frame.src = frame.src;
        return;
    }
    if (unanswered >= 2) status.textContent = 'Ожидание ответа VDO.Ninja…';
    unanswered++;
    pending = 'guests-' + (++serial);
    clearTimeout(fallback);
    fallback = undefined;
    slots = undefined;
    snapshot = undefined;
    inbound = undefined;
    const request = {getDetailedState: true};
    if (!scene) request.getGuestList = true;
    frame.contentWindow.postMessage({...request, cib: pending}, target);
    // Optional stats must not disrupt directory commands on older builds.
    frame.contentWindow.postMessage({getStats: true, cib: pending}, target);
}

function object(value) {
    return Object.prototype.toString.call(value) === '[object Object]';
}

function directorGuests(slots, excluded) {
    if (!object(slots)) return;
    const rows = [];
    for (const [slot, guest] of Object.entries(slots)) {
        if (!/^[1-9][0-9]*$/.test(slot) || !object(guest)) return;
        if (excluded.has(String(guest.streamID))) continue;
        if (typeof guest.streamID !== 'string' || !guest.streamID.trim() || typeof guest.label !== 'string') return;
        if (!guest.streamID.endsWith(':s')) rows.push({streamID: guest.streamID, label: guest.label});
    }
    return rows;
}

function peers(state) {
    if (!object(state)) return;
    const rows = [];
    const excluded = new Set();
    const remote = new Map();
    let includesSelf = false;
    for (const [key, peer] of Object.entries(state)) {
        if (!object(peer)) return;
        if (peer.localStream === true) {
            includesSelf = true;
            excluded.add(key);
            continue;
        }
        if (peer.localStream !== false || typeof peer.director !== 'boolean'
            || typeof peer.UUID !== 'string' || !peer.UUID || !key.trim() || peer.streamID !== key) return;
        if (peer.director || peer.iframeSrc || key.endsWith(':s')) {
            excluded.add(key);
            continue;
        }
        if (peer.label != null && peer.label !== false && typeof peer.label !== 'string') return;
        rows.push({streamID: key, label: peer.label || ''});
        remote.set(key, peer);
    }
    if (includesSelf) return {rows, excluded, remote};
}

function cameraVideo(peer, stats, next, now, managed = false) {
    if (!peer) return 'unknown';
    // The publisher also sends videoMuted=true when it removes its final video track.
    if (peer.videoMuted === true) return 'absent';
    const info = peer.miscellaneous;
    if (!managed && peer.videoMuted === false && Number.isFinite(info?.video_init_width) && info.video_init_width > 0
        && Number.isFinite(info.video_init_height) && info.video_init_height > 0) return 'live';

    // getStats returns cached track counters. A positive total from an old sample
    // cannot establish that frames are arriving in the current peer connection.
    const previous = videoHistory.get(peer.streamID);
    const samePeer = previous?.uuid === peer.UUID && now - previous.sampled <= Math.max(7000, interval + 3000);
    const frames = new Map();
    let lastFrame = -Infinity;
    const receiver = managed ? receiverMedia[peer.UUID] : undefined;
    if (receiver && Number.isSafeInteger(receiver.frames) && receiver.frames >= 0) {
        frames.set('dom-frames', receiver.frames);
        const prior = samePeer ? previous.frames.get('dom-frames') : undefined;
        if (receiver.frames > prior) lastFrame = now;
        else if (receiver.frames === prior) lastFrame = previous?.lastFrame ?? -Infinity;
    }
    for (const [id, track] of Object.entries(stats || {})) {
        if (!Number.isSafeInteger(track?._decodeFrames) || track._decodeFrames < 0) continue;
        if (track._type !== 'video' && track.type !== 'Video Stream'
            && !(track._frameWidth > 0 && track._frameHeight > 0)) continue;
        frames.set(id, track._decodeFrames);
        const prior = samePeer ? previous.frames.get(id) : undefined;
        if (track._decodeFrames > prior) lastFrame = now;
        else if (track._decodeFrames === prior) lastFrame = Math.max(lastFrame, previous.lastFrame);
    }
    const probing = previewRates.get(peer.UUID) === 35;
    const ended = receiver?.connected && receiver.endedTrack && samePeer &&
        (previous.ended || (probing && previous.probing && previous.liveTrack));
    next.set(peer.streamID, {uuid:peer.UUID, frames, lastFrame, sampled:now, probing,
                             liveTrack:receiver?.liveTrack === true, ended});
    if (ended) return 'absent';
    // Upstream refreshes RTC stats every three seconds by default.
    return now - lastFrame < 7000 ? 'live' : 'unknown';
}

async function deliver() {
    clearTimeout(fallback);
    fallback = undefined;
    if (!pending || !snapshot) return;
    if (frame.dataset.managed === '1' && performance.now() - lastSignaling > 4000) return;
    const rows = scene ? snapshot.rows : directorGuests(slots, snapshot.excluded);
    if (!rows) return;
    pending = '';
    unanswered = 0;
    const next = new Map();
    const now = performance.now();
    const rates = new Map();
    for (const guest of rows) {
        const peer = snapshot.remote.get(guest.streamID);
        const managed = frame.dataset.managed === '1';
        guest.video = cameraVideo(peer, inbound?.[guest.streamID], next, now, managed);
        if (managed && peer && !scene) {
            // Keep standard director previews paused. Brief, low-rate samples prove that
            // frames are still flowing; old publisher dimensions cannot prove this.
            const last = next.get(guest.streamID)?.lastFrame ?? -Infinity;
            const rate = peer.videoMuted === true || now - last < 3000 ? 0 : 35;
            if (rate !== (previewRates.get(peer.UUID) || 0)) {
                frame.contentWindow.postMessage({bitrate:rate, UUID:peer.UUID, lock:true}, target);
            }
            rates.set(peer.UUID, rate);
        }
    }
    previewRates = rates;
    videoHistory = next;
    if (posting) return;
    posting = true;
    try {
        const response = await fetch('guests', {
            method: 'POST', credentials: 'omit', headers: {...tabHeader, 'Content-Type': 'application/json'},
            body: JSON.stringify(rows), signal: AbortSignal.timeout(4500)
        });
        if (response.status === 410) return stop('Подключение продолжено в другой вкладке.');
        if (!response.ok) throw new Error();
        if (frame.dataset.managed === '1') {
            const current = new Set(rows.map(row => row.streamID));
            if (interval > 1000 && [...priorStreams].some(id => !current.has(id))) {
                clearTimeout(confirmDeparture);
                confirmDeparture = setTimeout(poll, 550);
            }
            priorStreams = current;
        }
        status.textContent = 'Связь с POV Manager установлена. Гостей: ' + rows.length + '.';
    } catch {
        status.textContent = 'Нет связи с POV Manager. Проверьте подключение комнаты в приложении.';
    } finally {
        posting = false;
    }
}

window.addEventListener('message', event => {
    if (event.source !== frame.contentWindow || event.origin !== target) return;
    const data = event.data;
    if (frame.dataset.managed === '1' && typeof data?.popMonitorSignaling === 'boolean') {
        lastSignaling = data.popMonitorSignaling ? performance.now() : -Infinity;
        receiverMedia = object(data.popMonitorMedia) ? data.popMonitorMedia : {};
        if (!data.popMonitorSignaling) {
            videoHistory.clear();
            priorStreams.clear();
        }
        return;
    }
    if (!pending || !data || data.cib !== pending) return;
    if (object(data.stats?.inbound)) inbound = data.stats.inbound;
    if ('detailedState' in data) snapshot = peers(data.detailedState);
    if (object(data.guestList)) slots = data.guestList;
    if (!snapshot || (!scene && !slots)) return;
    if (inbound) return deliver();
    // Older clients may omit optional stats. Still deliver the authoritative room
    // snapshot with whatever the publisher itself reported.
    if (fallback === undefined) fallback = setTimeout(deliver, 200);
});

frame.addEventListener('load', () => {videoHistory.clear(); previewRates.clear(); priorStreams.clear(); receiverMedia = {}; lastSignaling = -Infinity; poll();});
// Keep tab revocation and preferences responsive even with slow guest polling.
const heartbeat = setInterval(checkSession, 2000);
let timer = setInterval(poll, interval);
poll();
"""

_PAGE = """<!doctype html><html lang="ru"><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>VDO.Ninja · POV Manager</title>
<style nonce="{nonce}">
html, body {{ margin:0; height:100%; }} body {{ display:flex; flex-direction:column;
font:16px system-ui,sans-serif; color:#eef1f3; background:#192127; }}
header {{ padding:.75rem 1rem; }} p {{ margin:.25rem 0; }} iframe {{ flex:1; border:0; width:100%; }}
</style>
<header><p><strong>VDO.Ninja · POV Manager</strong></p>
<p>{instruction}</p>
<p id="status" role="status">Подключение к комнате…</p></header>
<iframe id="director" data-mode="{mode}" data-managed="{managed}" data-tab="{tab}" data-poll-seconds="{poll_seconds}"
title="Комната VDO.Ninja" referrerpolicy="no-referrer"
allow="autoplay" src="{director}"></iframe>
<script nonce="{nonce}">{script}</script></html>"""


def _guests(body):
    values = json.loads(body.decode('utf-8'))
    if not isinstance(values, list) or len(values) > 512:
        raise ValueError
    result = []
    for guest in values:
        if not isinstance(guest, dict):
            raise ValueError
        stream_id, label = guest.get('streamID'), guest.get('label')
        if (not isinstance(stream_id, str) or not stream_id.strip() or len(stream_id) > 256
                or not isinstance(label, str) or len(label) > 512):
            raise ValueError
        video = guest.get('video', 'unknown')
        if video not in ('live', 'absent', 'unknown'):
            raise ValueError
        result.append(dict(streamID=stream_id, label=label, video=video))
    return result


class _Handler(BaseHTTPRequestHandler):
    def setup(self):
        super().setup()
        self.connection.settimeout(5)

    def log_message(self, *args):
        pass  # The local capability path and private room link are never logged.

    def _reply(self, code, body=b'', content_type='text/plain; charset=utf-8', *, interval=None):
        self.send_response(code)
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Content-Security-Policy', self.server.csp)
        if interval is not None:
            self.send_header('X-Room-Poll-Seconds', str(interval))
        self.end_headers()
        if body:
            try:
                self.wfile.write(body)
            except (ConnectionError, TimeoutError):
                pass

    def do_GET(self):
        server = self.server
        if self.headers.get_all('Host') != [server.authority]:
            self._reply(404)
            return
        if self.path == server.path + 'active':
            if self._current():
                self._reply(204, interval=server.poll_seconds)
            else:
                self._reply(410)
        elif self.path == server.path:
            with server.delivery_lock:
                server.tab = secrets.token_urlsafe(24)
                page = _PAGE.format(tab=server.tab, poll_seconds=server.poll_seconds, **server.page_options).encode()
            self._reply(200, page, 'text/html; charset=utf-8')
        else:
            self._reply(404)

    def _current(self):
        return (not self.server.closed and self.server.tab and
                self.headers.get_all('X-Room-Tab') == [self.server.tab])

    def do_POST(self):
        server = self.server
        if self.headers.get_all('Host') != [server.authority] or self.path != server.path + 'guests':
            self._reply(404)
            return
        if self.headers.get_all('Origin') != [server.origin]:
            self._reply(403)
            return
        if self.headers.get_all('Content-Type') != ['application/json']:
            self._reply(415)
            return
        if not self._current():
            self._reply(410)
            return
        lengths = self.headers.get_all('Content-Length') or []
        if len(lengths) != 1 or not lengths[0].isascii() or not lengths[0].isdecimal() or self.headers.get('Transfer-Encoding'):
            self._reply(400)
            return
        if len(lengths[0]) > 6 or int(lengths[0]) > 65536:
            self._reply(413)
            return
        try:
            length = int(lengths[0])
            body = self.rfile.read(length)
            if len(body) != length:
                raise ValueError
            guests = _guests(body)
        except (ValueError, UnicodeError, RecursionError, TimeoutError):
            self._reply(400)
            return
        # close() waits for a callback already in progress and excludes later ones.
        with server.delivery_lock:
            if not self._current():
                self._reply(410)
                return
            try:
                server.on_guests(guests)
            except Exception:
                self._reply(500)
                return
        self._reply(204)


class VdoRoomBridge:
    """Serve an operator-only room tab. on_guests is called on a server thread."""

    def __init__(self, room_url, on_guests, *, scene=False, interval=DEFAULT_POLL_SECONDS, managed=False):
        if scene:
            from .camera_vdo_room import scene_url as frame_url
        else:
            from .camera_vdo_room import director_url as frame_url

        parts = urlsplit(frame_url(room_url))
        if parts.scheme != 'https' or not parts.hostname or parts.username or parts.password:
            raise ValueError('Нужна HTTPS-ссылка директора VDO.Ninja.')
        server = ThreadingHTTPServer(('127.0.0.1', 0), _Handler)
        self._server = server
        server.authority = f'127.0.0.1:{server.server_port}'
        server.origin = 'http://' + server.authority
        server.path = '/' + secrets.token_urlsafe(32) + '/'
        self.url = server.origin + server.path
        overrides = {'iframetarget'}
        if managed and not scene:
            overrides.update(('pausepreview', 'dpp', 'noaudio', 'na', 'hideaudio'))
        def without_target(component):
            return [(k, v) for k, v in parse_qsl(component, keep_blank_values=True)
                    if k.casefold() not in overrides]
        query = without_target(parts.query)
        if managed and not scene:
            query.extend([('pausepreview', ''), ('noaudio', '')])
        query.append(('iframetarget', server.origin))
        source = urlunsplit(parts._replace(query=urlencode(query), fragment=urlencode(without_target(parts.fragment))))
        nonce = secrets.token_urlsafe(24)
        server.csp = (f"default-src 'none'; frame-src https://{parts.netloc}; "
                      f"script-src 'nonce-{nonce}'; style-src 'nonce-{nonce}'; connect-src 'self'; "
                      "base-uri 'none'; frame-ancestors 'none'; form-action 'none'")
        instruction = ('Завершите вход в комнату ниже.' if managed else
                       'Оставьте эту вкладку открытой. Если VDO.Ninja запросит вход, завершите его ниже.')
        server.page_options = dict(nonce=nonce, mode='scene' if scene else 'director',
                                   managed=int(managed), instruction=instruction, director=html.escape(source, quote=True), script=_SCRIPT)
        server.tab = ''
        server.poll_seconds = poll_seconds(interval)
        server.delivery_lock = threading.RLock()
        server.closed = False
        server.on_guests = on_guests
        self._thread = threading.Thread(target=server.serve_forever, kwargs={'poll_interval': 0.05}, daemon=True)
        self._thread.start()

    def set_interval(self, seconds):
        self._server.poll_seconds = poll_seconds(seconds)

    def close(self):
        with self._server.delivery_lock:
            if self._server.closed:
                return
            self._server.closed = True
        self._server.shutdown()
        self._server.server_close()
        self._thread.join()
