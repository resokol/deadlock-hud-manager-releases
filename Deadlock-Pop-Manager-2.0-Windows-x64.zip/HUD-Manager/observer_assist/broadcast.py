from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib.resources import files
from ipaddress import IPv4Address, IPv4Network
import json
from pathlib import Path
from secrets import token_urlsafe
import socket
import subprocess
import sys
from threading import Thread
from time import time
from urllib.parse import urlsplit

from .panorama import MAX_AGE, PanoramaLog, STATS_COLUMNS


CARD_DURATION = 3
PORT = 8765
LAN_NETWORKS = tuple(IPv4Network(network) for network in ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16'))


def select_vmix_address(addresses):
    for value in addresses:
        try:
            address = IPv4Address(value)
        except ValueError:
            continue
        if any(address in network for network in LAN_NETWORKS):
            return address
    return IPv4Address('127.0.0.1')


def detect_vmix_address():
    if sys.platform == 'win32':
        # Exclude VPNs and Hyper-V adapters when looking up the studio interface.
        command = (
            "$adapters = @(Get-NetAdapter -Physical | Where-Object Status -eq 'Up' | Select-Object -ExpandProperty ifIndex); "
            "Get-NetIPInterface -AddressFamily IPv4 -ConnectionState Connected | "
            "Where-Object { $_.InterfaceIndex -in $adapters } | Sort-Object InterfaceMetric | "
            "ForEach-Object { Get-NetIPAddress -InterfaceIndex $_.InterfaceIndex -AddressFamily IPv4 "
            "-AddressState Preferred | Where-Object { !$_.SkipAsSource } | Select-Object -ExpandProperty IPAddress }"
        )
        try:
            result = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', command],
                                    capture_output=True, text=True, timeout=5, creationflags=subprocess.CREATE_NO_WINDOW)
        except (OSError, subprocess.TimeoutExpired):
            return select_vmix_address(())
        return select_vmix_address(result.stdout.split())
    try:
        addresses = socket.getaddrinfo(socket.gethostname(), None, family=socket.AF_INET)
    except OSError:
        addresses = ()
    return select_vmix_address(row[4][0] for row in addresses)


def load_token(config_dir):
    config_dir.mkdir(parents=True, exist_ok=True)
    path = config_dir / 'vmix-token'
    try:
        with path.open('x', encoding='ascii') as file:
            file.write(token_urlsafe(24))
    except FileExistsError:
        pass
    token = path.read_text(encoding='ascii').strip()
    if len(token) < 24 or any(char not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_' for char in token):
        raise ValueError('Повреждён ключ доступа к источникам vMix.')
    return token


def _card(player):
    return {field: getattr(player, field) for field in STATS_COLUMNS[1:]}


class Broadcast:
    def __init__(self, log_path, clock=time, *, source_tv=None):
        self.log_path = Path(log_path)
        self.clock = clock
        self.reader = None
        self.source_tv = source_tv
        self.stats_frame = None
        self._selected = None
        self._live = (0, None)
        self._final = None
        self._follow_session = None

    def close(self):
        if self.reader is not None:
            self.reader.close()
            self.reader = None
        if self.source_tv:
            self.source_tv.close()

    def snapshot(self, page):
        if page == 'final':
            return self._final
        expires, card = self._live
        return card if self.clock() < expires else None

    def publish(self, match_id):
        frame = self.stats_frame
        if frame is None:
            return False
        self._follow_session = frame.session if frame.state == 'sample' and self.clock() - frame.time <= MAX_AGE else None
        self._show_table(frame, match_id)
        return True

    def _show_table(self, frame, match_id):
        mid = len(frame.roster) // 2
        self._final = {'match_id': frame.match_id or match_id, 'final': frame.state == 'final',
                       'live': self._follow_session == frame.session,
                       'teams': [[_card(row) for row in team]
                                 for team in (frame.roster[:mid], frame.roster[mid:])]}

    def _stop_following(self):
        self._follow_session = None
        if self._final and self._final['live']:
            self._final = {**self._final, 'live': False}

    def poll(self, match_id, live_enabled):
        if not live_enabled:
            self._live = (0, None)
            self._selected = None
        try:
            if self.reader is None:
                self.reader = PanoramaLog(self.log_path)
                self.reader.file.seek(max(0, self.log_path.stat().st_size - 65536))
            frame = self.reader.read()
        except OSError:
            self.close()
            return
        now = self.clock()
        if frame is not None and not -.3 <= now - frame.time <= MAX_AGE:
            frame = None
        if self.source_tv:
            self.source_tv.observe(frame)
        stats = self.reader.stats_frame
        if stats and stats is not self.stats_frame and (
            -.3 <= now - stats.time <= MAX_AGE or stats is frame and stats.match_id and stats.state == 'final'
        ):
            if self.source_tv:
                stats = self.source_tv.enrich(stats)
            if stats != self.stats_frame:
                self.stats_frame = stats
                if stats.state == 'final':
                    self.publish(match_id)
                elif stats.session == self._follow_session:
                    self._show_table(stats, match_id)
                elif self._follow_session:
                    self._stop_following()
        if frame is None:
            return
        if frame.state in ('final', 'waiting_for_observer', 'waiting_for_final_stats'):
            self._live = (0, None)
            self._selected = None
            self._stop_following()
        if not live_enabled or frame.state != 'sample':
            return
        if self.source_tv:
            frame = self.source_tv.enrich(frame)
        selected = [row for row in frame.roster if row.selected]
        if len(selected) != 1 or not (selected[0].player or selected[0].hero):
            return
        player = selected[0]
        identity = (frame.session, player.portrait, player.player, player.hero)
        expires, _ = self._live
        if identity != self._selected:
            self._selected = identity
            expires = now + CARD_DURATION
        if now < expires:
            self._live = (expires, {**_card(player), 'team': 1 if player.portrait <= len(frame.roster)//2 else 2})


class BroadcastServer:
    def __init__(self, feed, host, port, token):
        self.feed = feed
        self.prefix = f'/{token}/'
        assets = files('observer_assist').joinpath('broadcast_assets')
        self.routes = {}
        template = assets.joinpath('overlay.html').read_text(encoding='utf-8')
        for route in ('player', 'final'):
            self.routes[route] = ('text/html; charset=utf-8', template.replace('@view@', route).encode('utf-8'))
        for name, content_type in (('overlay.css', 'text/css'), ('overlay.js', 'text/javascript')):
            self.routes[name] = (content_type + '; charset=utf-8', assets.joinpath(name).read_bytes())
        self.httpd = ThreadingHTTPServer((host, port), self._handler())
        address, port = self.httpd.server_address
        self.origin = f'http://{address}:{port}'
        self.thread = Thread(target=self.httpd.serve_forever, kwargs={'poll_interval': .1},
                             daemon=True, name='vmix-browser-inputs')
        self.thread.start()

    def url(self, page):
        return f'{self.origin}{self.prefix}{page}'

    def _handler(self):
        bridge = self

        class Handler(BaseHTTPRequestHandler):
            def setup(self):
                self.request.settimeout(4)
                super().setup()

            def log_message(self, *_):
                pass

            def do_GET(self):
                path = urlsplit(self.path).path
                if not path.startswith(bridge.prefix):
                    self.send_error(404)
                    return
                route = path[len(bridge.prefix):]
                if route in ('api/player', 'api/final'):
                    mime = 'application/json; charset=utf-8'
                    data = json.dumps(bridge.feed.snapshot(route[4:]), ensure_ascii=False).encode('utf-8')
                elif route in bridge.routes:
                    mime, data = bridge.routes[route]
                else:
                    self.send_error(404)
                    return
                self.send_response(200)
                self.send_header('Content-Type', mime)
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Cache-Control', 'no-store')
                self.send_header('X-Content-Type-Options', 'nosniff')
                self.send_header('Referrer-Policy', 'no-referrer')
                self.send_header('Content-Security-Policy', "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; frame-ancestors 'none'")
                self.end_headers()
                try:
                    self.wfile.write(data)
                except (ConnectionError, TimeoutError):
                    pass

        return Handler

    def close(self):
        self.httpd.shutdown()
        self.httpd.server_close()
        self.thread.join()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()
