"""Portable verification and transport for device-bound activation leases."""

from hashlib import sha256
import json
import re
from time import time
from urllib.error import HTTPError
from urllib.parse import urlsplit
from urllib.request import Request, build_opener

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from .release_security import decode, encode, verified_record
from .release_update import _HTTPSRedirects, https_url


LEASE = 'dhm-lease1'
LEASE_SECONDS = 24 * 60 * 60
RENEW_AFTER_SECONDS = 2 * 60 * 60
TOKEN_PATTERN = re.compile(r'dhma1_[A-Za-z0-9_-]{32}')
ID_PATTERN = re.compile(r'[0-9a-f]{32}')
CHALLENGE_PATTERN = re.compile(r'[A-Za-z0-9_-]{43}')


def public_key(secret):
    return encode(Ed25519PrivateKey.from_private_bytes(decode(secret)).public_key().public_bytes_raw())


def fingerprint(key):
    data = decode(key)
    if len(data) != 32:
        raise ValueError('Ключ установки некорректен.')
    return sha256(data).hexdigest()


def challenge_message(license_id, nonce, *, action='renew'):
    return f'dhm-{action}1.{license_id}.{nonce}'.encode('ascii')


def _sign(secret, license_id, nonce, action):
    key = Ed25519PrivateKey.from_private_bytes(decode(secret))
    return encode(key.sign(challenge_message(license_id, nonce, action=action)))


def prove(secret, license_id, nonce):
    return _sign(secret, license_id, nonce, 'renew')


def prove_detach(secret, license_id, nonce):
    return _sign(secret, license_id, nonce, 'detach')


def verify_proof(key, license_id, nonce, proof, *, action='renew'):
    try:
        Ed25519PublicKey.from_public_bytes(decode(key)).verify(decode(proof),
                                                               challenge_message(license_id, nonce, action=action))
    except (ValueError, InvalidSignature) as exc:
        raise ValueError('Установка не подтвердила владение ключом.') from exc


def check_lease(lease, authority, key, *, now=None, allow_expired=False):
    record = verified_record(LEASE, lease, authority, limit=1536)
    now = int(time()) if now is None else now
    values = (record.get(field) for field in ('license', 'device', 'issued', 'until', 'expires'))
    license_id, device, issued, until, expires = values
    if (not isinstance(license_id, str) or not ID_PATTERN.fullmatch(license_id)
            or device != fingerprint(key) or any(type(value) is not int for value in (issued, until, expires))
            or not 0 < until - issued <= LEASE_SECONDS or until > expires):
        raise ValueError('Лицензия относится к другой установке или повреждена.')
    if issued > now + 300:
        raise ValueError('Проверьте дату и время Windows.')
    if until <= now and not allow_expired:
        raise ValueError('Срок доступа истёк. Подключитесь к серверу активации.')
    return record


class ActivationRejected(ValueError):
    """The server explicitly declined this activation or renewal."""


def activation_origin(url):
    origin = urlsplit(https_url(url))
    if origin.query or origin.path not in ('', '/'):
        raise ValueError('Для активации укажите адрес HTTPS без пути и параметров.')
    return url.rstrip('/')


def request_activation(url, operation, body):
    endpoint = activation_origin(url) + '/v1/' + operation
    request = Request(endpoint, json.dumps(body).encode(), {
        'Content-Type': 'application/json', 'Accept': 'application/json',
    })
    try:
        with build_opener(_HTTPSRedirects()).open(request, timeout=8) as response:
            data = response.read(8193)
            if len(data) > 8192:
                raise ValueError('Слишком большой ответ сервера активации.')
            packet = json.loads(data)
    except HTTPError as exc:
        if exc.code in (400, 403, 409):
            with exc:
                try:
                    error = json.loads(exc.read(4096)).get('error')
                except (AttributeError, ValueError):
                    error = None
            raise ActivationRejected(error if isinstance(error, str) else 'Сервер отклонил активацию.') from None
        raise
    if not isinstance(packet, dict):
        raise ValueError('Некорректный ответ сервера активации.')
    return packet


def redeem(url, authority, secret, code, *, request=request_activation):
    if not TOKEN_PATTERN.fullmatch(code):
        raise ValueError('Введите код активации dhma1_…')
    key = public_key(secret)
    lease = request(url, 'redeem', {'code': code, 'device': key}).get('lease')
    return lease, check_lease(lease, authority, key)


def _nonce(url, key, license_id, operation, request):
    if not ID_PATTERN.fullmatch(license_id):
        raise ValueError('Некорректный ID лицензии.')
    nonce = request(url, operation, {'license': license_id, 'device': key}).get('nonce')
    if not isinstance(nonce, str) or not CHALLENGE_PATTERN.fullmatch(nonce):
        raise ValueError('Некорректный запрос на подтверждение установки.')
    return nonce


def renew(url, authority, secret, license_id, *, request=request_activation):
    key = public_key(secret)
    nonce = _nonce(url, key, license_id, 'challenge', request)
    lease = request(url, 'renew', {
        'license': license_id, 'nonce': nonce, 'proof': prove(secret, license_id, nonce),
    }).get('lease')
    record = check_lease(lease, authority, key)
    if record['license'] != license_id:
        raise ValueError('Сервер вернул другую лицензию.')
    return lease, record


def detach(url, secret, license_id, *, request=request_activation):
    nonce = _nonce(url, public_key(secret), license_id, 'detach-challenge', request)
    response = request(url, 'detach', {
        'license': license_id, 'nonce': nonce, 'proof': prove_detach(secret, license_id, nonce),
    })
    if response.get('detached') is not True:
        raise ValueError('Сервер не подтвердил отвязку лицензии.')
    return True
