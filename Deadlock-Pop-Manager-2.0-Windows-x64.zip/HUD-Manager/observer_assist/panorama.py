"""Consume the observer HUD telemetry written to Deadlock's local console log."""

import csv
from dataclasses import dataclass, replace
import json
from math import hypot
import os
from pathlib import Path
import re
from tempfile import NamedTemporaryFile
from time import time

from .events import EventEngine, InterestEvent
from .profile import Rect
from .tracking import Track


PREFIX = b'[PanoramaScript] [ObserverTelemetry] '
MAX_AGE = 1.0
MAX_TRACK_SPEED = .5
ZONE_CONFIRM_SECONDS = .5
ZONE_HOLD_SECONDS = .85
STATS_COLUMNS = ('portrait', 'player', 'hero', 'kills', 'deaths', 'assists', 'souls')
KDA_COLUMNS = ('kills', 'deaths', 'assists')
DEFAULT_PORTRAIT_KEYS = tuple('1234567890-=')
ROSTER_SIZES = (8, 12)
_LEGACY_HEADER = ('version','session','state','time','map','players')
_FIELD = re.compile(r'\s*"([a-zA-Z]+)"\s*:\s*')
_COMMA = re.compile(r'\s*,')


def _normalized(value):
    return type(value) in (float, int) and 0 <= value <= 1


def _point(value):
    if isinstance(value, list) and len(value) == 2 and all(map(_normalized, value)):
        return tuple(value)
    return None


@dataclass(frozen=True)
class Portrait:
    portrait: int
    player: str
    hero: str
    kills: str
    deaths: str
    assists: str
    souls: str
    point: tuple | None
    selected: bool


def ordered_portraits(roster):
    if any(row.point is None or not 0 < row.point[0] < 1 or not 0 < row.point[1] < .25 for row in roster):
        return ()
    ordered = tuple(sorted(roster, key=lambda row: row.point[0]))
    if any(right.point[0] - left.point[0] < .001 for left, right in zip(ordered, ordered[1:])):
        return ()
    return ordered


@dataclass(frozen=True)
class Marker:
    id: int
    team: int
    x: float
    y: float
    portrait: int | None


@dataclass(frozen=True)
class HudFrame:
    state: str
    session: str
    time: float
    bounds: tuple | None
    players: tuple[Marker, ...]
    roster: tuple[Portrait, ...]
    match_id: str | None = None

    def has_stats(self):
        return len(self.roster) in ROSTER_SIZES and all(
            (row.player.strip() or row.hero.strip())
            and row.souls.strip()
            for row in self.roster
        )

    def desktop_map(self, window):
        if self.bounds is None:
            return None
        x, y, w, h = self.bounds
        left = window.left + round(x * window.width)
        top = window.top + round(y * window.height)
        width = round((x + w) * window.width) + window.left - left
        height = round((y + h) * window.height) + window.top - top
        return Rect(left, top, width, height) if min(width, height) >= 20 else None


@dataclass(frozen=True)
class VisibleZone:
    event: InterestEvent
    slot: int
    identity: tuple[str,str]
    shown_at: float


def _recover_legacy_sample(body):
    """Keep the complete positions before a roster cut off by the console."""
    text = body.decode('utf-8',errors='surrogateescape')
    if not text.startswith('{'):
        return None
    decoder = json.JSONDecoder()
    offset = 1
    fields = {}
    try:
        for field in _LEGACY_HEADER:
            match = _FIELD.match(text,offset)
            if not match or match[1] != field:
                return None
            fields[field], offset = decoder.raw_decode(text,match.end())
            comma = _COMMA.match(text,offset)
            if not comma:
                return None
            offset = comma.end()
    except ValueError:
        return None
    roster = _FIELD.match(text,offset)
    if fields.get('state') == 'sample' and roster and roster[1] == 'roster' and text[roster.end():].startswith('['):
        return fields
    return None


def _decode(body):
    try:
        return json.loads(body)
    except ValueError:
        return _recover_legacy_sample(body)


def _parse(line):
    _, prefix, body = line.partition(PREFIX)
    return _snapshot(_decode(body)) if prefix else None


def _snapshot(data):
    try:
        if not isinstance(data, dict) or data.get('version') != 1:
            return None
        state, session, stamp = data['state'], data['session'], data['time']
        if not isinstance(state, str) or not isinstance(session, str) or type(stamp) is not int:
            return None
        match_id = data.get('match_id')
        if not isinstance(match_id, str) or not re.fullmatch(r'[0-9]{6,20}', match_id):
            match_id = None
        native_scoreboard = state == 'final' and match_id and data.get('source') == 'scoreboard'
        bounds = data.get('map')
        if (not isinstance(bounds, list) or len(bounds) != 4 or not all(map(_normalized, bounds))
                or min(bounds[2:]) <= 0 or bounds[0] + bounds[2] > 1.000001 or bounds[1] + bounds[3] > 1.000001):
            bounds = None
        roster_data = data.get('roster')
        roster = ()
        if (isinstance(roster_data, list) and len(roster_data) in ROSTER_SIZES
                and all(isinstance(row, dict) for row in roster_data)):
            roster = tuple(Portrait(
                i, *(row.get(key, '')[:160] if isinstance(row.get(key), str) else '' for key in STATS_COLUMNS[1:]),
                point=_point(row.get('point')), selected=(row.get('selected') is True),
            ) for i, row in enumerate(roster_data, 1))
            # The collapsed top bar can leave every count at its default zero.
            has_kda = any(re.fullmatch(r'[0-9]+', raw) and int(raw) > 0
                          for row in roster for key in KDA_COLUMNS if (raw := getattr(row, key).strip()))
            if not native_scoreboard and not has_kda:
                roster = tuple(replace(row, kills='', deaths='', assists='') for row in roster)
        screen_roster = ordered_portraits(roster)
        portrait_numbers = {row.portrait:i for i,row in enumerate(screen_roster,1)}
        if screen_roster:
            roster = tuple(replace(row,portrait=i) for i,row in enumerate(screen_roster,1))
        players = []
        seen = set()
        for row in data.get('players', []):
            identifier, team, x, y = row['id'], row['team'], row['x'], row['y']
            if type(identifier) is not int or identifier < 1 or identifier in seen:
                return None
            if type(team) is not int or team not in (1, 2) or not _normalized(x) or not _normalized(y):
                return None
            portrait = row.get('portrait')
            portrait = portrait_numbers.get(portrait) if type(portrait) is int else None
            players.append(Marker(identifier, team, x, y, portrait))
            seen.add(identifier)
        return HudFrame(state, session, stamp / 1000, tuple(bounds) if bounds else None, tuple(players), roster, match_id)
    except (ValueError, KeyError, TypeError, OverflowError):
        return None


class PanoramaLog:
    def __init__(self, path):
        self.path = Path(path)
        self.file = self.path.open('rb')
        self.file.seek(0, os.SEEK_END)
        self.pending = b''
        self.stats_frame = None
        self._chunk_key = None
        self._parts = []

    def _reset_chunks(self):
        self._chunk_key = None
        self._parts.clear()

    def _messages(self, payload):
        _, *messages = payload.split(PREFIX)
        if messages and b'\n' not in messages[-1]:
            tail = messages.pop()
            self.pending = PREFIX + tail if len(tail) <= 16384 else b''
        else:
            # Keep enough of the tail to recognize a prefix split across two reads.
            self.pending = payload.rsplit(b'\n',1)[-1][1-len(PREFIX):]
        for body in messages:
            yield body.partition(b'\n')[0]

    def _frame(self, body):
        packet = _decode(body)
        if not isinstance(packet,dict) or packet.get('version') != 2:
            return _snapshot(packet)
        session, sequence = packet.get('session'),packet.get('sequence')
        index, total, part = packet.get('index'),packet.get('total'),packet.get('part')
        if (not isinstance(session,str) or not 1 <= len(session) <= 64 or type(sequence) is not int
                or type(index) is not int or type(total) is not int or not 0 <= index < total <= 64
                or not isinstance(part,str) or len(part) > 650 or not part.isascii()):
            self._reset_chunks()
            return None
        key = (session,sequence,total)
        if index == 0:
            self._reset_chunks()
            self._chunk_key = key
        if key != self._chunk_key or index != len(self._parts):
            self._reset_chunks()
            return None
        self._parts.append(part)
        if len(self._parts) != total:
            return None
        joined = ''.join(self._parts)
        self._reset_chunks()
        try:
            frame = _snapshot(json.loads(joined))
        except ValueError:
            return None
        return frame if frame is not None and frame.session == session else None

    def read(self):
        current = self.path.stat()
        opened = os.fstat(self.file.fileno())
        if (current.st_dev, current.st_ino) != (opened.st_dev, opened.st_ino):
            self.file.close()
            self.file = self.path.open('rb')
            self.pending = b''
            self._reset_chunks()
        elif current.st_size < self.file.tell():
            self.file.seek(0)
            self.pending = b''
            self._reset_chunks()
        # After a busy interval only recent complete frames are useful.
        if current.st_size - self.file.tell() > 65536:
            self.file.seek(-65536, os.SEEK_END)
            self.pending = b''
            self._reset_chunks()
        payload = self.pending + self.file.read(65536)
        latest = None
        for body in self._messages(payload):
            frame = self._frame(body)
            if frame is not None:
                latest = frame
                if frame.state in ('sample', 'final') and frame.has_stats():
                    previous = self.stats_frame
                    if (previous is None or previous.session != frame.session
                            or previous.state != 'final' or frame.state == 'final'):
                        self.stats_frame = frame
        return latest

    def close(self):
        self.file.close()


def _csv_text(value):
    if value.lstrip().startswith(('=', '+', '-', '@')) or value.startswith(('\t', '\r', '\n')):
        return "'" + value
    return value


def export_stats(path, roster):
    if len(roster) not in ROSTER_SIZES:
        raise ValueError('Полная итоговая таблица ещё не получена')
    path = Path(path)
    temp = None
    try:
        with NamedTemporaryFile('w', encoding='utf-8-sig', newline='', dir=path.parent, delete=False) as stream:
            temp = Path(stream.name)
            writer = csv.writer(stream)
            writer.writerow(STATS_COLUMNS)
            for row in roster:
                writer.writerow(_csv_text(str(getattr(row, key))) for key in STATS_COLUMNS)
        temp.replace(path)
    finally:
        if temp is not None:
            temp.unlink(missing_ok=True)


class PanoramaSession:
    def __init__(self, state, profile, log_path, keys, clock=time, *, hero_icons=None, minimap_source=None):
        self.state, self.profile, self.log_path, self.keys, self.clock = state, profile, log_path, keys, clock
        self.engine = EventEngine()
        self.reader = None
        self.frame = None
        self.stats_frame = None
        self.last_success = None
        self.status = 'Анализ выключен'
        self.detections = ()
        self._epoch = -1
        self._tracks = {}
        self._visible_zones = {}
        self.hero_icons = hero_icons
        self.minimap_source = minimap_source
        self._capture = None

    def _clear_live(self):
        self.engine.reset()
        self._tracks.clear()
        self._visible_zones.clear()
        self.frame = None
        self.last_success = None
        self.detections = ()

    @property
    def final_roster(self):
        frame = self.stats_frame
        return frame.roster if frame and frame.state == 'final' else ()

    def close(self):
        if self.reader is not None:
            self.reader.close()
            self.reader = None
        if self._capture is not None:
            self._capture.close()
            self._capture = None
        self._clear_live()

    def _minimap_image(self, frame):
        from mss.exception import ScreenShotError

        try:
            if self._capture is None:
                self._capture = self.minimap_source()
            roi = frame.desktop_map(self._capture.baseline.rect)
            if roi is not None:
                result = self._capture.grab(roi)
                if result.validity.valid and self.clock()-frame.time <= .35:
                    return result.image
        except (OSError, ScreenShotError):
            pass
        return None

    def _track(self, frame):
        if self.frame is None or self.frame.session != frame.session or not 0 < frame.time - self.frame.time <= MAX_AGE:
            self._tracks.clear()
            self.engine.reset()
            self._visible_zones.clear()
        tracks = []
        for player in frame.players:
            old = self._tracks.get(player.id)
            track = Track(player.id, player.team, player.x, player.y, seen=frame.time)
            if old and old.team == player.team:
                dt = frame.time - old.seen
                vx, vy = (player.x - old.x) / dt, (player.y - old.y) / dt
                speed = hypot(vx, vy)
                if speed <= MAX_TRACK_SPEED:
                    # Smooth nearby samples without extrapolating the old heading after a turn.
                    if old.vx*vx + old.vy*vy > 0 and speed > .012:
                        weight = dt / (dt + .2)
                        vx = old.vx + (vx - old.vx)*weight
                        vy = old.vy + (vy - old.vy)*weight
                    track.vx, track.vy = vx, vy
                    track.age = old.age + dt
            tracks.append(track)
        self._tracks = {track.id: track for track in tracks}
        return tracks

    def _event_profile(self, frame):
        profile = self.profile
        if not profile.objectives:
            return profile
        objectives = []
        roi = profile.roi
        if frame.bounds and roi.width > 0 and roi.height > 0:
            x,y,w,h = frame.bounds
            width,height = profile.target_size
            x,y,w,h = x*width,y*height,w*width,h*height
            overlap_w = min(x+w, roi.left+roi.width) - max(x, roi.left)
            overlap_h = min(y+h, roi.top+roi.height) - max(y, roi.top)
            if overlap_w >= .7*min(w,roi.width) and overlap_h >= .7*min(h,roi.height):
                scale = min(roi.width/w,roi.height/h)
                for target in profile.objectives:
                    tx = (roi.left+target.x*roi.width-x)/w
                    ty = (roi.top+target.y*roi.height-y)/h
                    if 0 <= tx <= 1 and 0 <= ty <= 1:
                        objectives.append(replace(target,x=tx,y=ty,radius=min(.5,target.radius*scale)))
        return replace(profile,objectives=objectives)

    def _display_events(self, events, frame):
        now = frame.time
        players = {player.id: player for player in frame.players
                   if player.portrait and player.portrait <= min(len(frame.roster),len(self.keys))
                   and self.keys[player.portrait - 1]}
        identities = {row.portrait: (row.player,row.hero) for row in frame.roster}
        ready = {}
        for event in events:
            previous = self._visible_zones.get(event.id)
            if event.last_seen != now or (previous is None and now-event.first_seen < ZONE_CONFIRM_SECONDS):
                continue
            if previous is None and event.eta_seconds is not None and event.eta_seconds < .3:
                continue
            focus = event.focus_members or event.members
            choices = [player for player in players.values() if player.id in focus]
            if not choices:
                choices = [player for player in players.values() if player.id in event.members
                           and hypot(player.x-event.x,player.y-event.y) <= event.radius+.025]
            if choices:
                player = min(choices,key=lambda player: (
                    previous is None or player.portrait != previous.slot
                    or identities[player.portrait] != previous.identity,
                    hypot(player.x-event.x,player.y-event.y), player.portrait,
                ))
                slot = player.portrait
                zone = replace(event,shortcut=self.keys[slot-1])
                ready[event.id] = VisibleZone(zone,slot,identities[slot],previous.shown_at if previous else now)

        carried = {}
        for identifier,previous in self._visible_zones.items():
            event = previous.event
            elapsed = now-event.last_seen
            if (identifier in ready or not 0 <= elapsed < ZONE_HOLD_SECONDS
                    or not any(previous.identity) or identities.get(previous.slot) != previous.identity):
                continue
            if any(zone.event.members & event.members and hypot(zone.event.x-event.x,zone.event.y-event.y) < .16
                   for zone in ready.values()):
                continue
            if event.eta_seconds is not None:
                if event.eta_seconds <= elapsed:
                    continue
                carried[identifier] = replace(event,eta_seconds=event.eta_seconds-elapsed)
            else:
                carried[identifier] = event

        ready.update((identifier,self._visible_zones[identifier]) for identifier in carried)
        visible = sorted(ready.values(),key=lambda zone: (
            now-zone.shown_at >= ZONE_HOLD_SECONDS, -zone.event.rank, zone.event.id,
        ))[:3]
        self._visible_zones = {zone.event.id:zone for zone in visible}
        return [carried.get(zone.event.id,zone.event) for zone in visible]

    def tick(self, now):
        enabled, _, epoch, _ = self.state.snapshot()
        if epoch != self._epoch:
            self.close()
            self._epoch = epoch
        if not enabled:
            self.status = 'Анализ выключен'
            return
        try:
            if self.reader is None:
                self.reader = PanoramaLog(self.log_path)
            frame = self.reader.read()
        except OSError:
            self.close()
            self.state.accept_result(epoch, [])
            self.status = 'Ждём локальный журнал Deadlock. Запустите игру с -condebug.'
            return
        stats = self.reader.stats_frame
        current = self.clock()
        if stats and -.3 <= current - stats.time <= MAX_AGE:
            self.stats_frame = stats
        if frame is None:
            if self.last_success is not None and now - self.last_success <= MAX_AGE:
                return
        elif frame.state == 'sample' and -.3 <= current - frame.time <= MAX_AGE:
            if self.hero_icons and self.minimap_source and frame.bounds:
                frame = self.hero_icons.read(frame, lambda: self._minimap_image(frame)
                                             if self.clock()-frame.time <= .35 else None)
            tracks = self._track(frame)
            events = self.engine.update(tracks,frame.time,self._event_profile(frame),limit=None)
            visible = self._display_events(events,frame) if frame.bounds else []
            if not frame.bounds:
                self._visible_zones.clear()
            if self.state.accept_result(epoch, visible):
                self.frame, self.last_success, self.detections = frame, now, frame.players
                self.status = 'Panorama · приём данных' if frame.bounds else 'Panorama · ждём границы миникарты'
                if not frame.roster:
                    self.status += ' · ждём координаты портретов'
                elif events and not visible:
                    self.status += ' · ждём подтверждение зоны и клавиши'
            return
        self._clear_live()
        self.state.accept_result(epoch, [])
        if self.final_roster:
            self.status = 'Итоги доступны для выгрузки'
        elif self.stats_frame:
            self.status = 'Последние данные матча доступны для выгрузки'
        else:
            self.status = 'Ждём свежих данных наблюдателя'
