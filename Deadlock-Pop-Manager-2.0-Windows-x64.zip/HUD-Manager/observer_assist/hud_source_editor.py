"""Native code editor for the source files of an installed HUD ZIP."""

from codecs import BOM_UTF8
import re

from PySide6.QtCore import QTimer, Qt
from PySide6.QtGui import QColor, QFontDatabase, QKeySequence, QShortcut, QTextCursor, QTextDocument
from PySide6.QtWidgets import (
    QDialog, QHBoxLayout, QLabel, QLineEdit, QListWidget, QMessageBox, QPlainTextEdit, QPushButton,
    QSplitter, QStackedWidget, QTextEdit, QVBoxLayout, QWidget,
)

from .hud_source_preview import PackagePreview, SourceMap


class _PreviewFrame(QWidget):
    def __init__(self):
        super().__init__()
        self.view = None
        self.setMinimumSize(230, 130)
        self.setObjectName('sourcePreviewFrame')
        self.setStyleSheet('#sourcePreviewFrame { background: #101619; }')

    def fit(self):
        if self.view:
            width = min(self.width(), self.height() * 16 // 9)
            height = width * 9 // 16
            self.view.setGeometry((self.width() - width) // 2, (self.height() - height) // 2, width, height)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.fit()


class PackageSourceEditor(QDialog):
    def __init__(self, library, package_id, parent=None):
        super().__init__(parent)
        self.library = library
        self.packages = library.packages
        self.package = self.packages.get(package_id)
        if not self.package or not self.package.source_files:
            raise ValueError('У пакета нет доступных исходников.')
        self.revision = self.packages.active(package_id)['revision']
        self._documents = {}
        self._source_cache = {}
        self._source_map = SourceMap(package_id, self.package.source_files, self._read_source)
        self._last_hover = self._hover_span = self._hover_editor = None
        self._picked = self._preview_text = None
        self._links = {}
        self.setWindowTitle(f'Исходники HUD · {self.package.name}')
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.setMinimumSize(620, 435)
        area = self.screen().availableGeometry()
        self.resize(min(1280, max(620, area.width() - 48)), min(730, max(435, area.height() - 70)))

        layout = QVBoxLayout(self)
        self.split = QSplitter(Qt.Orientation.Horizontal)
        self.split.setChildrenCollapsible(False)
        self.files = QListWidget()
        self.files.setAccessibleName('Исходные файлы HUD')
        self.files.setMinimumWidth(104)
        self.files.addItems(self.package.source_files)
        self.pages = QStackedWidget()
        source = QWidget()
        source.setMinimumWidth(215)
        source_layout = QVBoxLayout(source)
        source_layout.setContentsMargins(0, 0, 0, 0)
        source_layout.addWidget(self._build_search())
        source_layout.addWidget(self.pages, 1)

        self.preview_pane = QWidget()
        self.preview_pane.hide()
        preview_layout = QVBoxLayout(self.preview_pane)
        preview_layout.setContentsMargins(0, 0, 0, 0)
        self.preview_frame = _PreviewFrame()
        preview_layout.addWidget(self.preview_frame, 1)
        self.preview_location = QLabel('Наведите курсор на элемент HUD и нажмите, чтобы открыть код.')
        self.preview_location.setTextFormat(Qt.TextFormat.PlainText)
        self.preview_location.setWordWrap(True)
        preview_layout.addWidget(self.preview_location)
        self.preview_snippet = QLabel()
        self.preview_snippet.setTextFormat(Qt.TextFormat.PlainText)
        self.preview_snippet.setWordWrap(True)
        self.preview_snippet.setFont(QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont))
        preview_layout.addWidget(self.preview_snippet)
        related = QHBoxLayout()
        self.preview_jumps = {}
        for section, label in (('css', 'Стили CSS'), ('text', 'Текст в JavaScript')):
            button = QPushButton(label)
            button.setAutoDefault(False)
            button.setEnabled(False)
            button.clicked.connect(lambda _, mode=section: self._go_to(self._links.get(mode)))
            self.preview_jumps[section] = button
            related.addWidget(button, 1)
        preview_layout.addLayout(related)

        for pane in (self.files, source, self.preview_pane):
            self.split.addWidget(pane)
        self.split.setStretchFactor(1, 1)
        self.split.setStretchFactor(2, 1)
        self.split.setSizes([160, 610, 0])
        layout.addWidget(self.split, 1)

        self.status = QLabel('Изменения применяются автоматически.')
        self.status.setObjectName('subtle')
        self.status.setTextFormat(Qt.TextFormat.PlainText)
        self.status.setWordWrap(True)
        self.apply_button = QPushButton('Применить')
        self.apply_button.setEnabled(False)
        self.apply_button.clicked.connect(self.flush)
        preview = QPushButton('Предпросмотр')
        preview.setToolTip('Открыть предпросмотр в браузере')
        preview.clicked.connect(self._preview)
        self.inspect_button = QPushButton('Встроенный просмотр')
        self.inspect_button.setCheckable(True)
        self.inspect_button.toggled.connect(self._toggle_preview)
        aliases = QPushButton('Эфирные ники…')
        aliases.clicked.connect(lambda: self.library.edit_player_aliases())
        close = QPushButton('Закрыть')
        close.clicked.connect(self.reject)
        controls = QHBoxLayout()
        controls.addWidget(self.status, 1)
        for button in (self.inspect_button, preview, aliases, self.apply_button, close):
            button.setAutoDefault(False)
            controls.addWidget(button)
        layout.addLayout(controls)

        save = QShortcut(QKeySequence.StandardKey.Save, self)
        save.activated.connect(self.flush)
        self.timer = QTimer(self, singleShot=True, interval=500)
        self.timer.timeout.connect(self.flush)
        self.files.currentTextChanged.connect(self._show_source)
        self.files.setCurrentRow(0)

    def _show_source(self, name):
        if not name:
            return
        if name not in self._documents:
            editor = QPlainTextEdit()
            editor.setAccessibleName(name)
            editor.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
            editor.setFont(QFontDatabase.systemFont(QFontDatabase.SystemFont.FixedFont))
            editor.setTabStopDistance(editor.fontMetrics().horizontalAdvance(' ') * 4)
            encoding, newline = 'utf-8', '\n'
            try:
                content = self.packages.asset(self.package.id, name)
                if content is None:
                    raise ValueError('Не удалось открыть файл.')
                if content.startswith(BOM_UTF8):
                    encoding = 'utf-8-sig'
                source = content.decode(encoding)
                match = re.search(r'\r\n|\r|\n', source)
                newline = match.group() if match else '\n'
                editor.setPlainText(source)
            except UnicodeError:
                editor.setReadOnly(True)
                editor.setPlainText('Этот файл сохранён в другой кодировке. Редактор поддерживает UTF-8.')
            except (OSError, ValueError):
                editor.setReadOnly(True)
                editor.setPlainText('Не удалось прочитать файл из пакета HUD.')
            editor.document().setModified(False)
            editor.textChanged.connect(self._queue_apply)
            editor.cursorPositionChanged.connect(self._refresh_text_link)
            editor.selectionChanged.connect(self._refresh_text_link)
            self._documents[name] = editor, encoding, newline
            self.pages.addWidget(editor)
        self.pages.setCurrentWidget(self._documents[name][0])
        self._mark_hover()
        self._refresh_text_link()
        if not self.search_bar.isHidden() and self.search.text():
            self._find(restart=True)

    def _build_search(self):
        self.search_bar = QWidget()
        self.search_bar.hide()
        bar = QHBoxLayout(self.search_bar)
        bar.setContentsMargins(0, 0, 0, 0)
        self.search = QLineEdit()
        self.search.setAccessibleName('Поиск в исходнике')
        self.search.setPlaceholderText('Найти в файле')
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(lambda: self._find(restart=True))
        self.search.returnPressed.connect(self._find)
        self.search_result = QLabel()
        self.search_result.setAccessibleName('Результат поиска')
        bar.addWidget(self.search, 1)
        for caption, name, action in (
            ('↑', 'Предыдущее совпадение', lambda: self._find(backwards=True)),
            ('↓', 'Следующее совпадение', self._find),
            ('×', 'Закрыть поиск', self._close_search),
        ):
            button = QPushButton(caption)
            button.setAccessibleName(name)
            button.setToolTip(name)
            button.setAutoDefault(False)
            button.setFixedWidth(30)
            button.clicked.connect(action)
            bar.addWidget(button)
        bar.addWidget(self.search_result)
        find = QShortcut(QKeySequence.StandardKey.Find, self)
        find.activated.connect(self._open_search)
        self.search_escape = QShortcut(QKeySequence(Qt.Key.Key_Escape), self)
        self.search_escape.setEnabled(False)
        self.search_escape.activated.connect(self._close_search)
        return self.search_bar

    def _open_search(self):
        self.search_bar.show()
        self.search_escape.setEnabled(True)
        self.search.setFocus()
        self.search.selectAll()

    def _close_search(self):
        self.search_escape.setEnabled(False)
        self.search_bar.hide()
        if self.pages.currentWidget():
            self.pages.currentWidget().setFocus()

    def _find(self, *, backwards=False, restart=False):
        editor = self.pages.currentWidget()
        query = self.search.text()
        self.search_result.clear()
        if not query or editor is None:
            return
        cursor = editor.textCursor()
        if restart:
            cursor.setPosition(cursor.selectionStart())
        options = QTextDocument.FindFlag.FindBackward if backwards else QTextDocument.FindFlag(0)
        document = editor.document()
        found = document.find(query, cursor, options)
        wrapped = found.isNull()
        if wrapped:
            edge = QTextCursor(document)
            if backwards:
                edge.movePosition(QTextCursor.MoveOperation.End)
            found = document.find(query, edge, options)
        if found.isNull():
            cursor.clearSelection()
            editor.setTextCursor(cursor)
            self.search_result.setText('Не найдено')
            return
        editor.setTextCursor(found)
        editor.centerCursor()
        if wrapped:
            self.search_result.setText('С конца' if backwards else 'С начала')

    def _read_source(self, name):
        if name in self._documents:
            editor = self._documents[name][0]
            return '' if editor.isReadOnly() else editor.document().toRawText().replace('\u2029', '\n')
        if name not in self._source_cache:
            try:
                data = self.packages.asset(self.package.id, name)
                text = data.decode('utf-8-sig') if data is not None else ''
                self._source_cache[name] = text.replace('\r\n', '\n').replace('\r', '\n')
            except (OSError, ValueError):
                self._source_cache[name] = ''
        return self._source_cache[name]

    def _toggle_preview(self, visible):
        if not visible:
            self.preview_pane.hide()
            self._picked = None
            self._refresh_links()
            self._inspection({'hover': None})
            return
        if not self.flush():
            self.inspect_button.setChecked(False)
            return
        if not self.preview_frame.view:
            url = self.library._open_url(self.library._package_route(preview=True, package_id=self.package.id))
            if not url:
                self.inspect_button.setChecked(False)
                return
            view = PackagePreview(url, self.preview_frame)
            view.inspection.connect(self._inspection)
            self.preview_frame.view = view
        self.preview_pane.show()
        self.split.setSizes([135, 455, 440])
        self.preview_frame.fit()
        self.preview_frame.view.show()

    def _cursor(self, editor, span):
        source = self._read_source(span.file)
        cursor = QTextCursor(editor.document())
        cursor.setPosition(len(source[:span.start].encode('utf-16-le', 'surrogatepass')) // 2)
        cursor.setPosition(len(source[:span.end].encode('utf-16-le', 'surrogatepass')) // 2,
                           QTextCursor.MoveMode.KeepAnchor)
        return cursor

    def _mark_hover(self):
        if self._hover_editor:
            self._hover_editor.setExtraSelections([])
            self._hover_editor = None
        editor = self.pages.currentWidget()
        if self._hover_span and editor and editor.accessibleName() == self._hover_span.file:
            selection = QTextEdit.ExtraSelection()
            selection.cursor = self._cursor(editor, self._hover_span)
            selection.format.setBackground(QColor('#496559'))
            editor.setExtraSelections([selection])
            self._hover_editor = editor

    def _inspection(self, result):
        hovered = result.get('hover')
        if hovered != self._last_hover:
            self._last_hover = hovered
            self._hover_span = self._source_map.locate(hovered)
            if self._hover_span:
                span = self._hover_span
                source = self._read_source(span.file)
                line = source.count('\n', 0, span.start) + 1
                self.preview_location.setText(f'{span.file}:{line}')
                self.preview_snippet.setText(source[span.start:span.end].strip()[:280])
            else:
                self.preview_location.setText('Совпадение в исходниках не найдено.' if hovered else
                                              'Наведите курсор на элемент HUD и нажмите, чтобы открыть код.')
                self.preview_snippet.clear()
            self._mark_hover()
        picked = result.get('pick')
        if picked:
            self._picked = picked
            self._refresh_links()
            self._go_to(self._source_map.locate(picked))

    def _refresh_links(self):
        related = self._source_map.related(self._picked)
        self._preview_text = related.get('text')
        self._set_link('css', related.get('css'), 'Выберите элемент во встроенном просмотре.')
        self._refresh_text_link()

    @staticmethod
    def _source_offsets(source, start, end):
        if source.isascii():
            return start, end
        units = source.encode('utf-16-le', 'surrogatepass')
        return tuple(len(units[:position * 2].decode('utf-16-le', 'surrogatepass')) for position in (start, end))

    def _refresh_text_link(self):
        span, identified = None, False
        editor = self.pages.currentWidget()
        if editor and not editor.isReadOnly():
            file = editor.accessibleName()
            cursor = editor.textCursor()
            source = self._read_source(file)
            start, end = self._source_offsets(source, cursor.selectionStart(), cursor.selectionEnd())
            span, identified = self._source_map.text_at(file, source, start, end)
        hint = ('Для выбранного ID нет однозначной записи. Поставьте курсор на строку, которая меняет текст.'
                if identified else 'Найдите ID элемента, поставьте курсор на строку записи текста в JavaScript '
                                   'или выберите элемент во встроенном просмотре.')
        self._set_link('text', span if identified else self._preview_text, hint)

    def _set_link(self, section, span, hint):
        self._links[section] = span
        button = self.preview_jumps[section]
        button.setEnabled(span is not None)
        if span:
            line = self._read_source(span.file).count('\n', 0, span.start) + 1
            button.setToolTip(f'{span.file}:{line}')
        else:
            button.setToolTip(hint)

    def _go_to(self, span):
        if not span:
            return
        items = self.files.findItems(span.file, Qt.MatchFlag.MatchExactly)
        if items:
            self.files.setCurrentItem(items[0])
            editor = self.pages.currentWidget()
            editor.setTextCursor(self._cursor(editor, span))
            editor.centerCursor()
            editor.setFocus()

    def _queue_apply(self):
        self.status.setText('Есть изменения. Применяем…')
        self.apply_button.setEnabled(True)
        self.timer.start()

    def flush(self):
        self.timer.stop()
        edited = {name: (editor, encoding, newline) for name, (editor, encoding, newline) in self._documents.items()
                  if editor.document().isModified()}
        if not edited:
            if self.apply_button.isEnabled():
                self.status.setText('Изменения применяются автоматически.')
            self.apply_button.setEnabled(False)
            return True
        try:
            changes = {name: editor.document().toRawText().replace('\u2029', newline).encode(encoding)
                       for name, (editor, encoding, newline) in edited.items()}
            self.revision = self.packages.update_sources(self.package.id, changes, expected_revision=self.revision)
        except (OSError, ValueError) as exc:
            self.status.setText(f'Не удалось применить изменения. {exc}')
            return False
        for editor, _, _ in edited.values():
            editor.document().setModified(False)
        self._source_cache.clear()
        self._last_hover = None
        self._refresh_links()
        self.status.setText('Изменения применены.')
        self.apply_button.setEnabled(False)
        self.library.project_saved(self.package, activate=False)
        return True

    def _preview(self):
        if self.flush():
            self.library.preview_package(self.package.id)

    def reject(self):
        if not self.flush() and QMessageBox.question(
                self, 'Закрыть редактор?', 'Сбросить неприменённые правки и закрыть редактор?',
                defaultButton=QMessageBox.StandardButton.No,
        ) != QMessageBox.StandardButton.Yes:
            return
        super().reject()
