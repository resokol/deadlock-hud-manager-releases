"""Provision the fixed Replay input bank on an explicit operator command."""
import json
from hashlib import sha256
from ipaddress import IPv4Address
from xml.etree.ElementTree import ParseError

from PySide6.QtCore import QObject, QTimer, QUrl, Signal

from .camera_native_sync import read_native_catalog
from .camera_vdo_publish import VmixRequest
from .camera_vmix import browser_source, virtual_source
from .match_stats import is_lan_address


def pool_key(endpoint, preset, key):
    host, port = endpoint
    digest = sha256(preset.encode()).hexdigest()[:24]
    return f'vdoVirtualCopies/{host}/{port}/{digest}/{key}'


def pair_signature(mapping):
    return sha256(repr(sorted(mapping.items())).encode()).hexdigest()


def _catalog_order(state):
    by_number = sorted(state.inputs, key=lambda guid: state.inputs[guid]['number'])
    if [state.inputs[g]['number'] for g in by_number] != list(range(1, len(by_number) + 1)):
        raise ValueError('Номера входов пресета неоднозначны. Проверьте пресет в vMix.')
    return by_number


def _is_copy(info):
    return (virtual_source(info) and info.get('virtual') is not False
            and info['type'].casefold() in ('virtual', 'browser', 'webbrowser', 'web browser'))


class NativePoolSetup(QObject):
    """CreateVirtualInput has no idempotency key. Journal the GUIDs *before* each command."""
    finished = Signal(bool, str)

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.settings = settings
        self.http = VmixRequest(self)
        self.retry = QTimer(self, singleShot=True, interval=150)
        self.retry.timeout.connect(self._read)
        self.busy = False
        self.endpoint = None

    def cancel(self):
        self.busy = False
        self.retry.stop()
        self.http.cancel()

    def start(self, endpoint, *, confirmed_pairs=None, validate=None, confirm_pairs=None, confirm_retry=None):
        if self.busy:
            return False
        try:
            host, port = endpoint
            ip = IPv4Address(host)
            if not (is_lan_address(ip) or ip.is_loopback) or type(port) is not int or not 1 <= port <= 65535:
                raise ValueError
        except (ValueError, TypeError):
            self.finished.emit(False, 'Проверьте адрес vMix и порт Web Controller.')
            return False
        self.endpoint = str(ip), port
        self.url = QUrl(f'http://{ip}:{port}/api/')
        self.validate, self.confirm_pairs, self.confirm_retry = validate, confirm_pairs, confirm_retry
        self.confirmed = dict(confirmed_pairs or {})
        self.busy = True
        self.preset = None
        self.pending = None
        self.ack = False
        self.issued = False
        self.reads = 0
        self.gate_order = None
        self.programs = None
        self._read()
        return True

    def _finish(self, ok, message):
        self.cancel()
        self.finished.emit(ok, message)

    def _read(self):
        if self._current():
            self.http.send(self.url, None, self._received)

    def _current(self):
        if self.busy and self.validate and not self.validate():
            self._finish(False, 'Операция остановлена. Проверьте текущий адрес и управление входами.')
        return self.busy

    def _key(self, key):
        return pool_key(self.endpoint, self.preset, key)

    def _received(self, error, xml):
        if not self._current():
            return
        if error:
            self._finish(False, 'Не удалось прочитать пресет vMix. После восстановления связи проверьте пул.')
            return
        try:
            state, parents = read_native_catalog(xml)
            if self.preset is None:
                self.preset = state.preset
                self.pending = json.loads(self.settings.value(self._key('pendingCreation'), 'null', type=str))
            elif state.preset != self.preset:
                raise ValueError('Пресет vMix сменился. Операция остановлена.')
            if self.programs is None:
                self.programs = dict(state.mixes)
            elif state.mixes != self.programs:
                raise ValueError('Во время настройки изменился Program. Проверьте выходы и повторите проверку пула.')
            order = _catalog_order(state)
            if self.gate_order is not None and order != self.gate_order:
                raise ValueError('Список входов изменился во время проверки. Повторите настройку.')
            self.gate_order = None
            if self.pending:
                self._recover(state, parents, order)
            else:
                self._inspect(state, parents, order)
        except (ValueError, ParseError, KeyError, TypeError) as exc:
            message = str(exc) if isinstance(exc, ValueError) and not isinstance(exc, json.JSONDecodeError) else ''
            self._finish(False, message or 'Не удалось проверить пул в текущем пресете vMix.')

    def _inspect(self, state, parents, order):
        originals, copies = order[:12], order[12:24]
        if len(originals) != 12 or any(not browser_source(state.inputs[g]) or g in parents for g in originals):
            raise ValueError('Подготовьте в vMix 12 оригинальных входов через Add Input → Web Browser на местах 1–12.')
        if any(not _is_copy(state.inputs[g]) for g in copies):
            raise ValueError('В местах 13–24 есть посторонний вход. Освободите банк копий в пресете и повторите.')
        mapping = {}
        unknown = []
        for copy in copies:
            if copy in parents:
                original = parents[copy]
            else:
                known = [g for g in originals if self.confirmed.get(g) == copy or
                         self.settings.value(self._key(g), '', type=str) == copy]
                if len(known) > 1:
                    raise ValueError('Привязки GUID конфликтуют. Проверьте пары в vMix.')
                original = known[0] if known else ''
                if not original:
                    unknown.append(copy)
                    continue
            if original not in originals or original in mapping:
                raise ValueError('У копии другой оригинал или найдена повторная копия. Проверьте пресет vMix.')
            mapping[original] = copy
        if unknown:
            if not self.confirm_pairs:
                raise ValueError('vMix скрывает связь с оригиналом. Сверьте существующие копии в пресете.')
            remaining = [g for g in originals if g not in mapping]
            selected = self.confirm_pairs(state.inputs, remaining, unknown)
            if not self._current():
                return
            if (not isinstance(selected, dict) or set(selected) - set(remaining)
                    or set(selected.values()) != set(unknown) or len(selected) != len(unknown)):
                raise ValueError('Привязка существующих копий не подтверждена.')
            self.confirmed.update(selected)
            self.gate_order = order
            self._read()
            return
        for original, copy in mapping.items():
            self.settings.setValue(self._key(original), copy)
        if len(mapping) == 12:
            if self.pending:
                self._clear_pending()
            self.settings.setValue(self._key('approvedPairs'), pair_signature(mapping))
            self._finish(True, 'Проверены 12 оригиналов и 12 нативных копий. Сохраните пресет в vMix.')
            return
        original = next(g for g in originals if g not in mapping)
        self.pending = {'source': original, 'before': order}
        self.settings.setValue(self._key('pendingCreation'), json.dumps(self.pending))
        self.settings.sync()
        self._create(original)

    def _create(self, original):
        if not self._current():
            return
        self.issued, self.ack, self.reads = True, False, 0

        def sent(error, _):
            self.ack = not error
            self._read()
        self.http.send(self.url, {'Function': 'CreateVirtualInput', 'Input': original}, sent)

    def _recover(self, state, parents, order):
        before, original = self.pending['before'], self.pending['source']
        if not isinstance(before, list) or not 12 <= len(before) < 24 or original not in before[:12]:
            raise ValueError('Проверьте сохранённое состояние настройки пула.')
        # A full pool manually repaired between launches can be adopted without replaying the create.
        if not self.issued and not self.ack and len(order) >= 24 and set(order[:12]) == set(before[:12]):
            self._inspect(state, parents, order)
            return
        if any(g in state.inputs and (g in parents or not browser_source(state.inputs[g])) for g in before[:12]):
            raise ValueError('Тип оригинала изменился. Проверьте 12 браузерных входов.')
        if order == before:
            if self.issued:
                self.reads += 1
                if self.reads < 8:
                    self.retry.start()
                    return
                raise ValueError('vMix не подтвердил создание копии. Проверьте каталог перед повторной попыткой.')
            if not self.confirm_retry or not self.confirm_retry(state.inputs[original]['number']):
                raise ValueError('Проверьте в vMix результат предыдущей команды создания.')
            if self._current():
                # The dialog may stay open while vMix finishes the previous command.
                self._clear_pending()
                self.gate_order = before
                self._read()
            return
        added = set(order) - set(before)
        if len(added) != 1 or len(order) != len(before) + 1:
            raise ValueError('Во время создания изменилось несколько входов. Сверьте каталог vMix.')
        copy = added.pop()
        if [g for g in order if g != copy] != before or not _is_copy(state.inputs[copy]):
            raise ValueError('Не удалось подтвердить новую виртуальную копию. Проверьте входы в vMix.')
        if copy in parents and parents[copy] != original:
            raise ValueError('Новая копия связана с другим GUID. Проверьте исходный вход.')
        if copy not in parents and not self.ack and self.confirmed.get(original) != copy:
            selection = self.confirm_pairs(state.inputs, [original], [copy]) if self.confirm_pairs else None
            if not self._current():
                return
            if selection != {original: copy}:
                raise ValueError('Подтвердите происхождение новой копии в vMix.')
            self.confirmed.update(selection)
            self.gate_order = order
            self._read()
            return
        if order[-1] != copy:
            # Adjacent moves work with either insertion- or swap-based MoveInput implementations.
            number = state.inputs[copy]['number']
            expected = list(order)
            expected[number - 1], expected[number] = expected[number], expected[number - 1]
            self.gate_order = expected

            def moved(error, _):
                if error:
                    self._finish(False, 'vMix не подтвердил перемещение новой копии. Проверьте пресет.')
                else:
                    self._read()
            self.http.send(self.url, {'Function': 'MoveInput', 'Input': copy, 'Value': number + 1}, moved)
            return
        self.confirmed[original] = copy
        self.settings.setValue(self._key(original), copy)
        self._clear_pending()
        self._inspect(state, parents, order)

    def _clear_pending(self):
        self.settings.remove(self._key('pendingCreation'))
        self.settings.sync()
        self.pending = None
        self.issued = self.ack = False
