"""Local, experimental spectator assistance. No game input or memory access."""

__version__ = "0.4.0"
