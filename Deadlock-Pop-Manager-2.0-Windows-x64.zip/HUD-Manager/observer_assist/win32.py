"""Windows-only desktop APIs. No game memory, injection or keyboard hooks."""
import ctypes as C
from ctypes import wintypes as W
import os
import sys
from .capture import WindowSnapshot
from .profile import Rect


class MonitorInfo(C.Structure):
    _fields_ = [('cbSize',W.DWORD),('rcMonitor',W.RECT),('rcWork',W.RECT),
                ('dwFlags',W.DWORD),('szDevice',W.WCHAR*32)]


class WindowsApi:
    def __init__(self):
        if sys.platform != 'win32':
            raise RuntimeError('Живой захват доступен только в Windows 10–11')
        self.u = C.WinDLL('user32',use_last_error=True)
        signatures = {
            'GetClientRect':([W.HWND,C.POINTER(W.RECT)],W.BOOL),
            'GetWindowRect':([W.HWND,C.POINTER(W.RECT)],W.BOOL),
            'ClientToScreen':([W.HWND,C.POINTER(W.POINT)],W.BOOL),
            'GetWindowThreadProcessId':([W.HWND,C.POINTER(W.DWORD)],W.DWORD),
            'IsWindow':([W.HWND],W.BOOL),'IsWindowVisible':([W.HWND],W.BOOL),
            'IsIconic':([W.HWND],W.BOOL),'GetDpiForWindow':([W.HWND],W.UINT),
            'GetWindowTextLengthW':([W.HWND],C.c_int),
            'GetWindowTextW':([W.HWND,W.LPWSTR,C.c_int],C.c_int),
            'GetTopWindow':([W.HWND],W.HWND),'GetWindow':([W.HWND,W.UINT],W.HWND),
            'GetForegroundWindow':([],W.HWND),
            'RegisterHotKey':([W.HWND,C.c_int,W.UINT,W.UINT],W.BOOL),
            'UnregisterHotKey':([W.HWND,C.c_int],W.BOOL),
            'SetWindowDisplayAffinity':([W.HWND,W.DWORD],W.BOOL),
            'GetWindowDisplayAffinity':([W.HWND,C.POINTER(W.DWORD)],W.BOOL),
            'MonitorFromWindow':([W.HWND,W.DWORD],W.HANDLE),
            'GetMonitorInfoW':([W.HANDLE,C.POINTER(MonitorInfo)],W.BOOL),
        }
        for name,(args,result) in signatures.items():
            func=getattr(self.u,name)
            func.argtypes,func.restype=args,result

    def snapshot(self,hwnd):
        if not self.u.IsWindow(hwnd):
            return None
        pid=W.DWORD()
        self.u.GetWindowThreadProcessId(hwnd,C.byref(pid))
        r,p=W.RECT(),W.POINT()
        if not self.u.GetClientRect(hwnd,C.byref(r)) or not self.u.ClientToScreen(hwnd,C.byref(p)):
            return None
        buf=C.create_unicode_buffer(self.u.GetWindowTextLengthW(hwnd)+1)
        self.u.GetWindowTextW(hwnd,buf,len(buf))
        return WindowSnapshot(int(hwnd),pid.value,Rect(p.x,p.y,r.right-r.left,r.bottom-r.top),
                              self.u.GetDpiForWindow(hwnd) or 96,bool(self.u.IsWindowVisible(hwnd)),
                              bool(self.u.IsIconic(hwnd)),buf.value)

    def windows(self):
        result=[]
        hwnd=self.u.GetTopWindow(None)
        seen=set()
        while hwnd and int(hwnd) not in seen:
            seen.add(int(hwnd))
            s=self.snapshot(hwnd)
            if s and s.visible and s.title and not s.minimized and s.rect.width>100 and s.rect.height>100:
                result.append(s)
            hwnd=self.u.GetWindow(hwnd,2)
        return result

    def foreground_snapshot(self):
        hwnd = self.u.GetForegroundWindow()
        return self.snapshot(hwnd) if hwnd else None

    def occluders(self,target,ignored):
        result=[]
        hwnd=self.u.GetTopWindow(None)
        seen=set()
        while hwnd and int(hwnd)!=target and int(hwnd) not in seen:
            seen.add(int(hwnd))
            if int(hwnd) not in ignored and self.u.IsWindowVisible(hwnd) and not self.u.IsIconic(hwnd):
                pid = W.DWORD()
                self.u.GetWindowThreadProcessId(hwnd, C.byref(pid))
                if pid.value != os.getpid() or not self.overlay_is_excluded(hwnd):
                    r=W.RECT()
                    if self.u.GetWindowRect(hwnd,C.byref(r)):
                        result.append(Rect(r.left,r.top,r.right-r.left,r.bottom-r.top))
            hwnd=self.u.GetWindow(hwnd,2)
        return result

    def monitor(self,hwnd):
        info=MonitorInfo()
        info.cbSize=C.sizeof(info)
        if not self.u.GetMonitorInfoW(self.u.MonitorFromWindow(hwnd,2),C.byref(info)):
            raise RuntimeError('Не удалось определить монитор игры')
        r=info.rcMonitor
        return Rect(r.left,r.top,r.right-r.left,r.bottom-r.top),info.szDevice

    def exclude_overlay(self,hwnd):
        # Older Windows can turn 0x11 into an opaque capture block. Do not
        # quietly feed that block into the detector as if it were game footage.
        if sys.getwindowsversion().build < 19041:
            return False
        return bool(self.u.SetWindowDisplayAffinity(hwnd,0x11) and self.overlay_is_excluded(hwnd))

    def overlay_is_excluded(self, hwnd):
        flags = W.DWORD()
        return bool(self.u.GetWindowDisplayAffinity(hwnd, C.byref(flags)) and flags.value == 0x11)

    def register(self,i,mods,vk):
        return bool(self.u.RegisterHotKey(None,i,mods,vk))

    def unregister(self,i):
        self.u.UnregisterHotKey(None,i)


def set_dpi_awareness():
    if sys.platform == 'win32':
        u=C.WinDLL('user32',use_last_error=True)
        try:
            u.SetProcessDpiAwarenessContext.argtypes=[W.HANDLE]
            u.SetProcessDpiAwarenessContext.restype=W.BOOL
            u.SetProcessDpiAwarenessContext(C.c_void_p(-4))
        except AttributeError:
            u.SetProcessDPIAware()
