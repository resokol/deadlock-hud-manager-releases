"""Replace the two observer outline colors in the installed game's VData."""

from struct import pack, pack_into, unpack_from


OUTLINE_RESOURCE = 'scripts/generic_data.vdata_c'
_HEADER_SIZE = 120
_STOCK_PALETTE = pack('<24I',
    215, 201, 175, 255, 230, 25, 25, 255, 231, 182, 89, 255,
    91, 121, 230, 255, 0, 125, 125, 255, 162, 34, 34, 255,
)


def _unpack_lz4(source, expected):
    result = bytearray()
    offset = 0

    def length(value):
        nonlocal offset
        if value == 15:
            while True:
                extra = source[offset]
                offset += 1
                value += extra
                if extra != 255:
                    break
        return value

    while offset < len(source):
        token = source[offset]
        offset += 1
        literal_size = length(token >> 4)
        end = offset + literal_size
        if end > len(source) or len(result) + end - offset > expected:
            raise ValueError('Invalid VData LZ4 literals')
        result.extend(source[offset:end])
        offset = end
        if offset == len(source):
            break
        distance = int.from_bytes(source[offset:offset + 2], 'little')
        offset += 2
        size = length(token & 15) + 4
        if not 0 < distance <= len(result) or len(result) + size > expected:
            raise ValueError('Invalid VData LZ4 match')
        result.extend((result[-distance:] * ((size + distance - 1) // distance))[:size])
    if len(result) != expected:
        raise ValueError('Unexpected VData buffer size')
    return result


def recolor_spectator_outlines(resource, colors):
    from .build_panorama_health import read_resource, write_resource

    kind, blocks = read_resource(resource)
    data = blocks.get(b'DATA', b'')
    if len(data) < _HEADER_SIZE or data[:4] != b'\x05\x33\x56\x4b':
        return None
    compression, = unpack_from('<I', data, 20)
    size, compressed, _, second = unpack_from('<4I', data, 72)
    if compression != 1 or size > 1024 * 1024 or _HEADER_SIZE + compressed + second > len(data):
        return None
    first = _unpack_lz4(data[_HEADER_SIZE:_HEADER_SIZE + compressed], size)
    if (b'm_OutlineColorTeam1\0' not in first or b'm_OutlineColorTeam2\0' not in first or
            first.count(_STOCK_PALETTE) != 1):
        return None
    start = first.index(_STOCK_PALETTE) + 32
    for side, offset in (('left', start), ('right', start + 16)):
        pack_into('<4I', first, offset, *bytes.fromhex(colors[side][1:]), 255)

    # Emit the modified buffer as a valid literal-only LZ4 block and retain the other KV3 data.
    extra, last = divmod(len(first) - 15, 255)
    encoded = b'\xf0' + b'\xff' * extra + bytes((last,)) + first
    header = bytearray(data[:_HEADER_SIZE])
    previous_total, = unpack_from('<I', header, 52)
    pack_into('<I', header, 52, previous_total - compressed + len(encoded))
    pack_into('<I', header, 76, len(encoded))
    blocks[b'DATA'] = header + encoded + data[_HEADER_SIZE + compressed:]
    return write_resource(kind, blocks)
