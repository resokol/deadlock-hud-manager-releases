"""Keep player reservations attached to verified vMix originals through input moves."""

from dataclasses import dataclass, field
from hashlib import sha256
import json

from .vmix_control import _guid


@dataclass(frozen=True)
class PreparedCatalog:
    endpoint: tuple
    preset: str
    rows: tuple


@dataclass(frozen=True)
class CameraOriginal:
    slot: int
    name: str
    guid: str
    number: int
    media: str
    page: str = field(repr=False)


class OriginalReservations:
    def __init__(self, settings):
        self.settings = settings
        self.numbers = {}
        self.guids = ()
        self.owners = {}
        self.players = {}
        self.streams = {}
        self.preset = ''
        self.key = ''

    def saved_owners(self, room, endpoint, preset):
        scope = json.dumps((room, endpoint, preset))
        key = 'vdoOriginalOwners/' + sha256(scope.encode()).hexdigest()
        try:
            saved = json.loads(self.settings.value(key, '{}', type=str))
        except (TypeError, ValueError):
            saved = {}
        return key, saved if isinstance(saved, dict) else {}

    def catalog_reservations(self, room, endpoint, preset, catalog, numbers, *, source_names=None):
        guids = {n: _guid(catalog.get(n)) for n in numbers}
        if len(guids) != 12 or None in guids.values() or len(set(guids.values())) != 12:
            return None
        _, saved = self.saved_owners(room, endpoint, preset)
        outside = set(catalog.values()) - set(guids.values())
        if any(isinstance(saved.get(g), dict) and (saved[g].get('owner') or saved[g].get('player'))
               for g in outside):
            return None  # A reserved original is still present, but in a different bank.
        held = {}
        for n, guid in guids.items():
            row = saved.get(guid)
            if isinstance(row, dict):
                name = (source_names or {}).get(row.get('stream')) or row.get('owner') or row.get('player')
                if isinstance(name, str) and name:
                    held[n] = name
        return guids, held

    def capture(self, receipt, room, seats, commands, *, streams=None):
        """Accept only the catalog and acknowledgements for this exact preparation."""
        published = {r.number: (r.label, r.empty) for r in receipt.rows}
        expected = {n: (label, not page) for page, label, n in commands}
        if (not room or len(seats) != 12 or len(published) != len(receipt.rows)
                or len(expected) != len(commands) or published != expected):
            return False
        catalog = dict(getattr(receipt, 'browser_inputs', {}) or {})
        for row in receipt.rows:
            if row.number in catalog and catalog[row.number] != row.guid:
                return False
            catalog[row.number] = row.guid
        guids = tuple(_guid(catalog.get(n)) for n in seats)
        if None in guids or len(set(guids)) != 12:
            return False
        return self.bind_inventory(room, receipt.endpoint, receipt.preset, guids, seats, streams=streams)

    def bind_inventory(self, room, endpoint, preset, guids, seats, *, streams=None):
        key, saved = self.saved_owners(room, endpoint, preset)
        owners = {}
        players = {}
        identities = {}
        taken = {name.casefold() for name, _ in seats.values() if name}
        for guid, (name, release) in zip(guids, seats.values()):
            saved_row = saved.get(guid, {})
            if not isinstance(saved_row, dict):
                saved_row = {}
            previous = saved_row.get('owner')
            if name or (not release and isinstance(previous, str) and previous and previous.casefold() not in taken):
                owners[guid] = name or previous
                stream = (streams or {}).get(owners[guid].casefold())
                if not stream and owners[guid] == previous:
                    stream = saved_row.get('stream')
                if isinstance(stream, str) and stream:
                    identities[guid] = stream
            if not name and not release and isinstance(saved_row.get('player'), str):
                players[guid] = saved_row['player']
        if len({n.casefold() for n in owners.values()}) != len(owners):
            return False
        self.key, self.preset = key, preset
        self.guids, self.numbers = guids, dict(zip(guids, seats))
        self.owners, self.players, self.streams = owners, players, identities
        self.save()
        return True

    def save(self):
        values = {g: {'owner': self.owners.get(g, ''), 'player': self.players.get(g, ''),
                      'stream': self.streams.get(g, '')} for g in self.guids}
        serialized = json.dumps(values, ensure_ascii=False, sort_keys=True)
        if self.settings.value(self.key, '', type=str) != serialized:
            self.settings.setValue(self.key, serialized)

    def assign(self, names):
        """Retain prepared owners first, then returning players without a camera."""
        if len(names) != 12 or not self.guids:
            return ()
        requested = {n.casefold(): n for n in names}
        if len(requested) != 12:
            return ()
        assigned = {n.casefold(): g for g, n in self.owners.items() if n.casefold() in requested}
        for guid in self.guids:
            name = self.players.get(guid, '').casefold()
            if guid not in self.owners and name in requested and name not in assigned:
                assigned[name] = guid
        free = [g for g in self.guids if g not in self.owners and g not in assigned.values()]
        missing = sorted(requested.keys() - assigned.keys())
        if len(free) < len(missing):
            return ()
        assigned.update(zip(missing, free))
        players = {guid: requested[name] for name, guid in assigned.items() if guid not in self.owners}
        if players != self.players:
            self.players = players
            self.save()
        return tuple(assigned[n.casefold()] for n in names)

    def update_numbers(self, numbers, preset):
        if not self.guids or (preset is not None and self.preset != preset):
            return False
        current = {guid: numbers.get(guid) for guid in self.guids}
        if (any(type(n) is not int or n < 1 for n in current.values())
                or len(set(current.values())) != 12):
            return False
        self.numbers = current
        return True
