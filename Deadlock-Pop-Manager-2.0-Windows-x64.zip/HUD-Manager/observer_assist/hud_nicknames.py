"""Broadcast labels for players, independent of game identities."""

import unicodedata


MAX_ALIASES = 128
MAX_PLAYER_NAME = 256
MAX_DISPLAY_NAME = 80


def normalize_name(name: str | None) -> str:
    return ' '.join(unicodedata.normalize('NFC', name or '').casefold().split())


def _name(value):
    return unicodedata.normalize('NFC', value.strip()) if isinstance(value, str) else ''


def clean_aliases(values):
    if not isinstance(values, dict):
        return {}
    aliases = {}
    for raw, display in values.items():
        if len(aliases) == MAX_ALIASES:
            break
        raw, display = _name(raw), _name(display)
        if 0 < len(raw) <= MAX_PLAYER_NAME and 0 < len(display) <= MAX_DISPLAY_NAME and raw != display:
            aliases[raw] = display
    return aliases


def roster_names(telemetry):
    return tuple(dict.fromkeys(
        _name(player.get('name')) for team in (telemetry or {}).get('teams', ())
        for player in team.get('players', ())
        if isinstance(player.get('name'), str) and player['name'].strip()
    ))


def with_display_names(telemetry, aliases):
    if telemetry is None:
        return None

    def label(item, key):
        name = item.get(key) if isinstance(item, dict) else None
        return {**item, 'displayName': aliases.get(_name(name), name)} if isinstance(name, str) and name else item

    view = dict(telemetry)
    if isinstance(telemetry.get('selected'), dict):
        view['selected'] = label(telemetry['selected'], 'player')
    if isinstance(telemetry.get('teams'), list):
        view['teams'] = [
            {**team, 'players': [label(player, 'name') for player in team['players']]}
            if isinstance(team, dict) and isinstance(team.get('players'), list) else team
            for team in telemetry['teams']
        ]
    return view
