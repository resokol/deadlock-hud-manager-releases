"""Director and solo-view URLs for rooms hosted on VDO.Ninja."""
from dataclasses import dataclass
from hashlib import sha256
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit


@dataclass(frozen=True)
class VdoRoom:
    director: str
    root: str
    room: str
    viewer_options: tuple
    private_options: tuple
    codirector: bool

    @property
    def key(self):
        return sha256((self.root + '\n' + self.room).encode()).hexdigest()

    def viewer(self, stream):
        if not isinstance(stream, str) or not stream.strip() or len(stream) > 512:
            raise ValueError('Пустой или некорректный Stream ID гостя.')
        return self.view_url([('view', stream), ('solo', '1')])

    def view_url(self, selectors):
        query = urlencode([*selectors, ('room', self.room), *self.viewer_options])
        return self.root + '?' + query + ('#' + urlencode(self.private_options) if self.private_options else '')


def parse_director(link):
    message = 'Вставьте HTTPS-ссылку режиссёра VDO.Ninja с параметром director и названием комнаты.'
    try:
        parts = urlsplit(link.strip())
        valid = (parts.scheme == 'https' and parts.hostname in ('vdo.ninja', 'www.vdo.ninja') and
                 not parts.username and not parts.password and parts.port in (None, 443))
        query = parse_qsl(parts.query, keep_blank_values=True, max_num_fields=180)
        fragment = parse_qsl(parts.fragment.lstrip('?&'), keep_blank_values=True, max_num_fields=180)
    except (UnicodeError, ValueError, AttributeError):
        raise ValueError(message) from None
    if not valid:
        raise ValueError(message)
    # A fragment may hold private options. Never copy a complete director query into a player link.
    options = dict(fragment + query)
    if not any(k in options for k in ('director', 'dir')):
        raise ValueError(message)
    room = next((options[k] for k in ('director', 'dir', 'roomid', 'r', 'room') if options.get(k)), '')
    if not room.strip() or len(room) > 256 or any(not ch.isprintable() for ch in room):
        raise ValueError(message)
    root = urlunsplit(('https', parts.hostname, parts.path or '/', '', ''))
    viewer_options = []
    pass_keys = ('password', 'pass', 'pw', 'p')
    password = next((options[k] for k in pass_keys if k in options), None)
    if password == '' or (password is None and any(k in options for k in ('hash', 'check'))):
        raise ValueError('Для автоматических ссылок укажите пароль комнаты в ссылке директора параметром password.')
    if password is not None:
        viewer_options.append(('password', password))
    elif any(k in options for k in ('nopassword', 'nopass', 'nopw', 'p0')):
        viewer_options.append(('password', 'false'))
    if 'invitecam' in options or 'auth' in options and not options.get('universaltoken'):
        raise ValueError('Для этой комнаты нужны отдельные права просмотра. Используйте готовые ссылки гостей в «Камеры до матча».')
    for k in ('roomkey', 'token', 'universaltoken', 'wss', 'wss2', 'pie'):
        if options.get(k):
            viewer_options.append((k, options[k]))
    # Leave a main director's published stream ID with their existing tab.
    # Strip integration endpoints too; this local tab is used only for reading guests.
    remove = {'push', 'publish', 'id', 'permaid', 'api', 'apiserver', 'webhook', 'label', 'l'}
    filtered = [(k, v) for k, v in query if k not in remove]
    private = [(k, v) for k, v in fragment if k not in remove]
    director = urlunsplit(('https', parts.hostname, parts.path or '/', urlencode(filtered), urlencode(private)))
    query_keys = {k for k, _ in query}
    fragment_keys = {k for k, _ in fragment} - query_keys
    pass_in_fragment = bool(fragment_keys.intersection(pass_keys)) and not query_keys.intersection(pass_keys)
    private_viewer = [(k, v) for k, v in viewer_options if k in fragment_keys or k == 'password' and pass_in_fragment]
    public_viewer = [item for item in viewer_options if item not in private_viewer]
    return VdoRoom(director, root, room, tuple(public_viewer), tuple(private_viewer),
                   any(k in options for k in ('codirector', 'directorpassword', 'dirpass', 'dp')))



def director_url(link):
    return parse_director(link).director


def scene_url(link):
    return parse_director(link).view_url([('scene', '0'), ('novideo', '1'), ('noaudio', '1'), ('cleanoutput', '1')])
