@echo off
call "%~dp0START.cmd" --pov
exit /b %errorlevel%
