"""Discover, provision and align the fixed native vMix camera banks."""
import json
from hashlib import sha256
from ipaddress import IPv4Address
from xml.etree.ElementTree import ParseError

from PySide6.QtCore import QObject, QTimer, QUrl, Signal

from .camera_native_sync import read_native_catalog
from .camera_vdo_publish import VmixRequest
from .camera_vmix import browser_source, virtual_source
from .match_stats import is_lan_address


def pool_key(endpoint, preset, key):
    host, port = endpoint
    digest = sha256(preset.encode()).hexdigest()[:24]
    return f'vdoVirtualCopies/{host}/{port}/{digest}/{key}'


def pair_signature(mapping):
    return sha256(repr(sorted(mapping.items())).encode()).hexdigest()


def _catalog_order(state):
    by_number = sorted(state.inputs, key=lambda guid: state.inputs[guid]['number'])
    if [state.inputs[g]['number'] for g in by_number] != list(range(1, len(by_number) + 1)):
        raise ValueError('Номера входов пресета неоднозначны. Проверьте пресет в vMix.')
    return by_number


def _is_copy(info):
    return (virtual_source(info) and info.get('virtual') is not False
            and info['type'].casefold() in ('virtual', 'browser', 'webbrowser', 'web browser'))


def fixed_bank(settings, endpoint, state, parents):
    """Resolve native lineage first, saved GUIDs second, and first-import positions last."""
    order = _catalog_order(state)
    originals, copies = order[:12], order[12:24]
    if len(originals) != 12 or any(not browser_source(state.inputs[g]) or g in parents for g in originals):
        raise ValueError('На входах 1–12 нужны оригиналы Web Browser.')
    if any(not _is_copy(state.inputs[g]) for g in copies):
        raise ValueError('На входах 13–24 обнаружен посторонний вход. Проверьте банк виртуальных копий.')
    if any(parents.get(g) in originals for g in order[24:]):
        raise ValueError('Копия оригинала находится за пределами банка 13–24.')
    settings.beginGroup(pool_key(endpoint, state.preset, '').rstrip('/'))
    try:
        saved = {g: settings.value(g, '', type=str) for g in settings.childKeys()
                 if g not in ('approvedPairs', 'pendingCreation')}
    finally:
        settings.endGroup()
    if any(g not in originals and (g in state.inputs or copy in state.inputs) for g, copy in saved.items()):
        raise ValueError('Сохранённый оригинал или его копия находятся вне ожидаемого банка.')
    mapping = {}
    for original in originals:
        copy = saved.get(original)
        if copy not in state.inputs:
            continue
        if copy not in copies or (copy in parents and parents[copy] != original) or copy in mapping.values():
            raise ValueError('Сохранённые GUID пар расходятся с каталогом vMix.')
        mapping[original] = copy
    for copy in copies:
        if copy not in parents:
            continue
        original = parents[copy]
        if original not in originals or mapping.get(original, copy) != copy:
            raise ValueError('У копии другой оригинал или найдена повторная копия.')
        mapping[original] = copy
    for original, copy in zip(originals, copies):
        if copy in mapping.values():
            continue
        if original in mapping:
            raise ValueError('Связь копии с оригиналом расходится с фиксированным порядком 1–12 и 13–24.')
        mapping[original] = copy
    return order, mapping


class NativePoolSetup(QObject):
    """CreateVirtualInput has no idempotency key. Journal the GUIDs *before* each command."""
    finished = Signal(bool, str)

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.settings = settings
        self.http = VmixRequest(self)
        self.retry = QTimer(self, singleShot=True, interval=150)
        self.retry.timeout.connect(self._read)
        self.busy = False
        self.endpoint = None

    def cancel(self):
        self.busy = False
        self.retry.stop()
        self.http.cancel()

    def start(self, endpoint, *, validate=None, preset=None):
        if self.busy:
            return False
        try:
            host, port = endpoint
            ip = IPv4Address(host)
            if not (is_lan_address(ip) or ip.is_loopback) or type(port) is not int or not 1 <= port <= 65535:
                raise ValueError
        except (ValueError, TypeError):
            self.finished.emit(False, 'Проверьте адрес vMix и порт Web Controller.')
            return False
        self.endpoint = str(ip), port
        self.url = QUrl(f'http://{ip}:{port}/api/')
        self.validate = validate
        self.expected_preset = preset
        self.busy = True
        self.preset = None
        self.pending = None
        self.issued = False
        self.reads = 0
        self.gate_order = None
        self.programs = None
        self._read()
        return True

    def _finish(self, ok, message):
        self.cancel()
        self.finished.emit(ok, message)

    def _read(self):
        if self._current():
            self.http.send(self.url, None, self._received)

    def _current(self):
        if self.busy and self.validate and not self.validate():
            self._finish(False, 'Операция остановлена. Проверьте текущий адрес и управление входами.')
        return self.busy

    def _key(self, key):
        return pool_key(self.endpoint, self.preset, key)

    def _received(self, error, xml):
        if not self._current():
            return
        if error:
            self._finish(False, 'Не удалось прочитать пресет vMix. После восстановления связи проверьте пул.')
            return
        try:
            state, parents = read_native_catalog(xml)
            if self.expected_preset is not None and self.expected_preset != state.preset:
                raise ValueError('Пресет vMix изменился.')
            if self.preset is None:
                self.preset = state.preset
                self.pending = json.loads(self.settings.value(self._key('pendingCreation'), 'null', type=str))
            elif state.preset != self.preset:
                raise ValueError('Пресет vMix сменился. Операция остановлена.')
            if self.programs is None:
                self.programs = dict(state.mixes)
            elif state.mixes != self.programs:
                raise ValueError('Во время настройки изменился Program. Проверьте выходы и повторите проверку пула.')
            order = _catalog_order(state)
            if self.gate_order is not None and order != self.gate_order:
                raise ValueError('Список входов изменился во время проверки. Повторите настройку.')
            self.gate_order = None
            if self.pending:
                self._recover(state, parents, order)
            else:
                self._inspect(state, parents, order)
        except (ValueError, ParseError, KeyError, TypeError) as exc:
            message = str(exc) if isinstance(exc, ValueError) and not isinstance(exc, json.JSONDecodeError) else ''
            self._finish(False, message or 'Не удалось проверить пул в текущем пресете vMix.')

    def _inspect(self, state, parents, order):
        _, mapping = fixed_bank(self.settings, self.endpoint, state, parents)
        originals = order[:12]
        for original, copy in mapping.items():
            self.settings.setValue(self._key(original), copy)
        if len(mapping) == 12:
            if self.pending:
                self._clear_pending()
            for i, original in enumerate(originals, 12):
                copy = mapping[original]
                if order[i] != copy:
                    current = order.index(copy)
                    self._move(order, copy, current - 1)
                    return
            self.settings.setValue(self._key('approvedPairs'), pair_signature(mapping))
            self._finish(True, 'Проверены 12 оригиналов и 12 нативных копий. Сохраните пресет в vMix.')
            return
        original = next(g for g in originals if g not in mapping)
        self.pending = {'source': original, 'before': order}
        self.settings.setValue(self._key('pendingCreation'), json.dumps(self.pending))
        self.settings.sync()
        self._create(original)

    def _create(self, original):
        if not self._current():
            return
        self.issued, self.reads = True, 0

        def sent(error, _):
            self._read()
        self.http.send(self.url, {'Function': 'CreateVirtualInput', 'Input': original}, sent)

    def _recover(self, state, parents, order):
        before, original = self.pending['before'], self.pending['source']
        if not isinstance(before, list) or not 12 <= len(before) < 24 or original not in before[:12]:
            raise ValueError('Проверьте сохранённое состояние настройки пула.')
        # A full pool manually repaired between launches can be adopted without replaying the create.
        if len(order) > 24 and set(order[:12]) == set(before[:12]):
            self._inspect(state, parents, order)
            return
        if (any(g not in state.inputs or not browser_source(state.inputs[g]) for g in before[:12])
                or any(g not in state.inputs or not _is_copy(state.inputs[g]) for g in before[12:])):
            raise ValueError('Состав исходного банка изменился. Проверьте оригиналы и копии в vMix.')
        if order == before:
            # Wait for a delayed catalog update before issuing any further create.
            self.reads += 1
            if self.reads < 8:
                self.retry.start()
                return
            if self.issued:
                raise ValueError('vMix не подтвердил создание копии. Повторяем проверку каталога.')
            self._clear_pending()
            self.gate_order = list(before)
            self._read()
            return
        added = set(order) - set(before)
        if len(added) != 1 or len(order) != len(before) + 1:
            raise ValueError('Во время создания изменилось несколько входов. Сверьте каталог vMix.')
        copy = added.pop()
        if [g for g in order if g != copy] != before or not _is_copy(state.inputs[copy]):
            raise ValueError('Не удалось подтвердить новую виртуальную копию. Проверьте входы в vMix.')
        if copy in parents and parents[copy] != original:
            raise ValueError('Новая копия связана с другим GUID. Проверьте исходный вход.')
        if order[-1] != copy:
            self._move(order, copy, order.index(copy) + 1)
            return
        self.settings.setValue(self._key(original), copy)
        self._clear_pending()
        self._inspect(state, parents, order)

    def _move(self, order, copy, target):
        # Adjacent moves have identical results on swap- and insertion-based vMix versions.
        current = order.index(copy)
        expected = list(order)
        expected[current], expected[target] = expected[target], expected[current]
        self.gate_order = expected

        def moved(error, _):
            # Even an unsuccessful HTTP reply may follow an applied move.
            self._read()

        self.http.send(self.url, {'Function': 'MoveInput', 'Input': copy, 'Value': target + 1}, moved)

    def _clear_pending(self):
        self.settings.remove(self._key('pendingCreation'))
        self.settings.sync()
        self.pending = None
        self.issued = False
