"""Discover the owner's fixed camera banks through the remote vMix Web Controller."""

from PySide6.QtCore import QSettings

from .camera_native_geometry import read_input_alphas
from .camera_native_recovery import safe_title
from .camera_native_setup import fixed_bank
from .camera_native_sync import NativePair, NativePairSync


class AttachedBank(NativePairSync):
    """Read-only discovery and monitoring; the only output command is an explicit take."""

    def __init__(self, parent=None, *, settings=None):
        super().__init__(parent, settings=settings)
        self._settings = settings if settings is not None else QSettings()
        self._known = {}
        self._alphas = {}

    def start(self, endpoint, *, validate=None):
        if self.endpoint == endpoint and self._armed:
            self._validate = validate
            return True
        if self.endpoint is not None:
            self.cancel()
        return self._begin('observe', endpoint, '', (), validate, None)

    def _observe_bank(self, state, parents, xml):
        order, mapping = fixed_bank(self._settings, self.endpoint, state, parents)
        if len(mapping) != 12 or [mapping[g] for g in order[:12]] != order[12:24]:
            raise ValueError('Ожидаем парный порядок оригиналов 1–12 и копий 13–24 в vMix.')
        scope = self.endpoint, state.preset
        previous = self._known.get(scope, {})
        former_parents = {copy: original for original, copy in previous.items()}
        pairs, names = [], set()
        for number, original in enumerate(order[:12], 1):
            copy = mapping[original]
            # vMix can omit lineage. For the first import use the fixed-slot convention
            # and matching captions. Subsequent reads must preserve the learned GUIDs.
            if copy not in parents and (previous.get(original, copy) != copy
                                        or former_parents.get(copy, original) != original):
                raise ValueError('Ожидаем совпадения ранее прочитанных GUID оригинала и копии.')
            title = state.inputs[original]['title']
            empty = title == '-'
            normalized = title.strip().casefold()
            if (not normalized or len(title) > 246 or not title.isprintable()
                    or not isinstance(safe_title(title), str) or (not empty and normalized in names)):
                raise ValueError(f'Ожидаем однозначного имени камеры на входе {number}.')
            if state.inputs[copy]['title'] != ('-' if empty else title + ' - Virtual'):
                raise ValueError(f'Ожидаем совпадения названий входов {number} и {number + 12}.')
            names.add(normalized)
            pairs.append(NativePair(original, copy, '' if empty else title, empty, operator_verified=True))
        self._known[scope] = dict(mapping)
        self._alphas = read_input_alphas(xml)
        return tuple(pairs)

    def media(self, slot):
        route = self.route(slot)
        if route and (route['empty'] or all(self._alphas.get(route[key]) == 0
                                             for key in ('original_guid', 'virtual_guid'))):
            return 'absent'
        return 'unknown'
